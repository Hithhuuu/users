import os
import pandas as pd
import re
from api.utils.utils import get_logger, get_env_config, get_dbconnection, get_filter_config, get_alias_config, columns_info, get_header_v8
app_log = get_logger('parserv8')
header_v8 = get_header_v8()


def clean_list_data(data):
    """
    This function is used to clean each row of the data frame.
    param: raw row level input
    return: cleaned row
    """
    ### Image list load===>
    try:
        imgIndex = data.lower().find('images')
        if imgIndex >= 0:
            data = data.replace(';', "").replace('""', "NA")
            imgList = data[imgIndex:]
            imgCount = imgList.split("{")[0].split(' ')[1]
            imgList = imgCount + '|'+ imgList.split("{")[1].replace("}", "").replace(" ", "-").replace('"','')
            data = data[0:imgIndex] + imgList
    except Exception as e:
        app_log.error(f"something is wrong while parsing file. {e}",)

    ###<=== end of change
    data = data.replace(';', "").replace('""', "NA").split(" ")
    out = []
    flag = None
    for i in data:
        if '"' in i:
            if '"' == i[-1] and '"' == i[0]:
                out.append(i.replace('"', ''))
            elif flag:
                out.append(flag + ' ' + i.replace('"', ''))
                flag = None
            else:
                flag = i.replace('"', '')
        elif flag:
            flag = flag + ' ' + i
        else:
            out.append(i)
    return out


def parse_field(data):
    """
    This function is used to parse the field type rows.
    """
    data = data.split(' ', 3)
    name = data[1]
    pattern = re.compile(r"[^_@.:\-,\w]")
    actual_data = re.sub(pattern, '', data[3]).split(',')
    return name, actual_data


def parse_record(data):
    """
    This function is used to parse the record type rows.
    """
    data = data.split(' ', 2)
    le = len(data)
    l = []
    if (3-le) != 0:
        l = ['NaN'] * (3 - le)
    data += l
    data[-1] = data[-1].replace('"', '')
    return data[1:]


def process_header_meta_v8(data_record, data_file):
    """
    This function is used to create the header meta data from record and field.
    param: data_record, data_file
    return: final header meta data
    """
    meta_dict_rec = {i[0]: i[1] for i in data_record if i[0]
                     in ['FileRecord', 'LotRecord', 'WaferRecord']}
    meta_dict_file = {}
    for i, j in data_file:
        if i in ['ResultTimeStamp', 'FileTimeStamp']:
            meta_dict_file[i] = ' '.join([str(elem) for elem in j])
        if i == 'InspectionStationID':
            meta_dict_file[i] = ' '.join([str(elem) for elem in j[1:]])
        if i in ['DiePitch', 'SampleCenterLocation', 'DieOrigin']:
            meta_dict_file[i] = ','.join([str(elem) for elem in j])
        if i in ['RecipeID', 'DeviceID', 'StepID', 'SlotNumber', 'SampleSize', 'SampleOrientationMarkType', 'OrientationMarkLocation', 'SampleType']:
            meta_dict_file[i] = j[0]
        if i in ['ImageFileName']:
            meta_dict_file['tifffilename']=[str(elem) for elem in j][0]

    meta_dict_file.update(meta_dict_rec)
    return meta_dict_file


def parse_klarf(filename):
    """
    This is main driver function which iterate over file and parse it.
    param: filename
    return: main df and meta data
    """
    all_field_type = []
    all_list_type = []
    all_record_type = []
    export_dict={'fileversion': "1.8"}
    prefix=""
    suffix=""
    columnsname=""
    app_log.info('Reading file now.')
    with open(filename, 'r') as handle:
        lines1 = handle.readlines()
    lines = list(map(str.strip, lines1))
    app_log.info('Parsing file now.')
    try:
        for index, data in enumerate(lines):
            if data.startswith('Field'):
                parsed_field = parse_field(lines[index])
                all_field_type.append(parsed_field)
            if data.startswith('List'):
                df_name = lines[index].replace('\n', "").split(" ")[-1]
                column_data = lines[index:]
                column_end = lines[index:].index('}')
                columns = " ".join(column_data[2:column_end])

                columns = columns.split('{ ')[-1]

                columns = columns.split(", ")
                columns = tuple(map(lambda x: x.split(" ")[-1] if not x.split(" ")[-1]=="ImageInfo" else "imageList", columns))

                main_data = column_data[column_end + 1:]
                data_end = main_data.index('}')
                main_data = main_data[2:data_end]
                main_data = list(map(clean_list_data, main_data))
                if df_name == 'ClassLookupList':
                    # all_list_type.append((df_name, columns, main_data))
                    ###changed to list of dictionaries
                    all_list_type.append({"df_name": df_name, "columns": columns, "main_data": main_data})
                if df_name == 'DefectList':
                    # all_list_type.append((df_name, columns, main_data))
                    ###changed to list of dictionaries
                    all_list_type.append({"df_name": df_name, "columns": columns, "main_data": main_data})
                    for i in lines1[:index + 10]:
                        prefix += i
                    export_dict['prefixdata'] = prefix
                    for i in [i.strip() for i in lines1[index+2:index+15]]:
                        if "}" in i:
                            break
                        else:
                            columnsname += i

                    export_dict["columnsname"] = str(columnsname)
                else:
                    continue
            if data.startswith('Record TestRecord'):
                for i in lines1[index-2:]:
                    suffix+=i
                export_dict['suffixdata']=suffix
            if data.startswith('Record'):
                parsed_record = parse_record(lines[index])
                all_record_type.append(parsed_record)
            else:
                continue
    except Exception as e:
        app_log.error(f"something is wrong while parsing file. {e}",)
        raise RuntimeError('something is wrong while parsing file')

    main_data_ind = next((i for i, item in enumerate(all_list_type) if item["df_name"] == "DefectList"), None)
    classlookup_ind = next((i for i, item in enumerate(all_list_type) if item["df_name"] == "ClassLookupList"), None)
    main_df = pd.DataFrame(all_list_type[main_data_ind]["main_data"], columns=all_list_type[main_data_ind]["columns"])
    # main_df = pd.DataFrame(all_list_type[1][2], columns=all_list_type[1][1])
    main_df["imageList"].replace({"N": "0"}, inplace=True)

    classlookup_df = pd.DataFrame(
        all_list_type[classlookup_ind]["main_data"], columns=all_list_type[classlookup_ind]["columns"]).drop('CLASSCODE', axis=1)
    # classlookup_df = pd.DataFrame(
    #     all_list_type[0][2], columns=all_list_type[0][1]).drop('CLASSCODE', axis=1)

    app_log.info(f"main df is processed. Shape: {main_df.shape}")
    meta_data = process_header_meta_v8(all_record_type, all_field_type)
    app_log.info(f"Header meta data prepard.")
    return main_df, meta_data, classlookup_df,export_dict


def parser_v8(filename):
    """
    This is a caller function for parse_klarf. This returns the main_df and metadata to the data_processing.
    """
    app_log.info('Parsing file with v8 code.')
    app_log.info(f'Parsing file at: {filename}')
    intermediate_df, meta_datav8, class_df ,export_dict= parse_klarf(filename)
    app_log.info(
        f'Main DataFrame and Meta data has been parsed. Returning now..')
    meta_df = pd.DataFrame(meta_datav8.values(), index=[
                           x.lower() for x in meta_datav8.keys()]).T
    return intermediate_df, meta_df, class_df, export_dict


def check_key_v8(filename):
    """
    Return: Boolean
    True - If key exist
    False - Otherwise
    """
    all_field_type = []
    all_record_type = []
    app_log.info("Extracting metadata only.")
    app_log.info('Reading file now.')
    with open(filename, 'r') as handle:
        lines = handle.readlines(1000)
    lines = list(map(str.strip, lines))
    app_log.info('Parsing file now.')
    try:
        for index, data in enumerate(lines):
            if data.startswith('Field'):
                parsed_field = parse_field(lines[index])
                all_field_type.append(parsed_field)
            if data.startswith('Record'):
                parsed_record = parse_record(lines[index])
                all_record_type.append(parsed_record)
            else:
                continue
    except Exception as e:
        app_log.error(f"something is wrong while parsing file. {e}")
        raise ValueError('something is wrong while parsing file')
    app_log.info("Processing extracted metedata")
    meta_data = process_header_meta_v8(all_record_type, all_field_type)
    meta_data = {k.lower(): v for k, v in meta_data.items()}
    meta_data['resulttimestamp'] = pd.to_datetime(
        meta_data.get('resulttimestamp')).strftime('%Y/%m/%d %H:%M:%S'),
    app_log.info(f"Returning metedata.")
    return meta_data
