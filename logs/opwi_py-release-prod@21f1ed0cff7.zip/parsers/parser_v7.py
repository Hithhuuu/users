# title                 : parser_v7.py
# description           : This is the parser for v7 klarf file.
# author                : Utkarsh Kumar
# date                  : 18-Aug-2020 -> 22-Sep-2020
# version               : 1.0 -> 1.1
# usage                 :
################################################################################################################

import os
import pandas as pd
import re
from api.utils.utils import get_logger, get_env_config, get_dbconnection, get_filter_config, get_alias_config, columns_info, get_header_v8
app_log = get_logger('parserv7')


def process_header_meta_v7(records):
    meta_dict_v7 = {}
    pattern = re.compile(r"[\"]")
    for i, j in records.items():
        if i == 'FileVersion':
            meta_dict_v7[i] = '.'.join([str(elem) for elem in j.split()])
        if i == 'InspectionStationID':
            meta_dict_v7[i] = re.sub(pattern, '', ' '.join(
                [str(elem) for elem in j.split()[1:]]))
        if i in ['ResultTimestamp', 'FileTimestamp']:
            meta_dict_v7[i] = j
        if i in ['DeviceID', 'StepID', 'LotID', 'WaferID']:
            meta_dict_v7[i] = re.sub(pattern, '', j)
        if i in ['DiePitch', 'SampleCenterLocation', 'DieOrigin']:
            meta_dict_v7[i] = ','.join([str(elem) for elem in j.split()])
        if i in ['Slot', 'SampleOrientationMarkType', 'OrientationMarkLocation', 'SampleType', 'TiffFileName']:
            meta_dict_v7[i] = j
        if i == 'SampleSize':
            meta_dict_v7[i] = j.split()[-1]
        if i == 'SetupID':
            meta_dict_v7[i] = re.sub(pattern, '', j.split()[0])
    return meta_dict_v7


def microns_to_nm(main_df, meta_data):
    app_log.info("Converting microns to nm.")
    meta_data['DiePitch'] = ','.join(
        [str(float(i) * 1000) for i in meta_data.get('DiePitch').split(',')])
    meta_data['SampleCenterLocation'] = ','.join(
        [str(float(i) * 1000) for i in meta_data.get('SampleCenterLocation').split(',')])
    meta_data['SampleSize'] = str(int(meta_data['SampleSize']) * 1000000)
    change_dict = {'xrel': float, 'yrel': float, 'dsize': float}
    main_df = main_df.astype(change_dict)
    main_df['xrel'] *= 1000
    main_df['yrel'] *= 1000
    main_df['dsize'] *= 1000
    app_log.info("Converting microns to nm done.")
    return main_df, meta_data


def clean_list_data(data):
    """
    This function is used to clean each row of the data frame.
    param: raw row level input
    return: cleaned row
    """
    try:
        # app_log.info(f"*************Data in list data : {data}")
        if len(data.split(' '))>20:
            imgIndex = data.lower().find('images')
            if imgIndex >= 0:
                imgList = data[imgIndex:]
                imgList = imgList.split(" ")[1].split(',')[:-1]
                data = data[0:imgIndex][:-1]+'|'+','.join(imgList)
            # data.pop(data.index(data[-1]))
    except Exception as e:
        app_log.error(f"*********ERROR: clean list data------{e}")
        pass
    
    # app_log.info(f"*************after img parsing : {data}")

    data = data.strip().replace('""', "NA").replace(
        ";", "").strip().replace('\n', '').split(" ")
    out = []
    flag = None
    for i in data:
        if '"' in i:
            if '"' == i[-1] and '"' == i[0]:
                out.append(i.replace('"', ''))
            elif flag:
                out.append(flag + ' ' + i.replace('"', ''))
                flag = None
            else:
                flag = i.replace('"', '')
        elif flag:
            flag = flag + ' ' + i
        else:
            out.append(i)
    return out


def parse_klarf(filename):
    meta_data = {}
    defect_df = []
    class_df = {}
    export_dict={}
    prefix =""
    suffix=""
    columnsname=""
    try:
        app_log.info('Reading file now.')
        with open(filename, 'r') as handle:
            lines = handle.readlines()
            for i in lines:
                prefix += i
                if "DefectList" in i:
                    break


        ls = [i for i in range(0, len(lines)) if "SummarySpec " in lines[i]]
        for i in lines[ls[0]:]:
            suffix += i

        ls = [i for i in range(0, len(lines)) if "DefectRecordSpec" in lines[i]]
        for i in lines[ls[0]:ls[0] + 1]:
            columnsname += i
        export_dict["fileversion"] = "1.7"
        export_dict["prefixdata"] = prefix
        export_dict["suffixdata"] = suffix
        export_dict["columnsname"] = columnsname

        app_log.info('Extracting metadata.')
        meta_pattern = re.compile(r"[\";]")
        class_lookup_start = 0
        class_lookup_stop = 0
        class_lookup_data = []
        for index, line in enumerate(lines):
            l = line.strip()
            l = re.sub(meta_pattern, '', l).split(' ', 1)
            if 'classlookup' in line.lower():
                class_lookup_start = index
                for line_no in range(class_lookup_start+1, len(lines)):
                    if ';' in lines[line_no]:
                        class_lookup_stop = line_no
                        break
            meta_data[l[0]] = l[-1]

        class_lookup_data = list(
            map(clean_list_data, lines[class_lookup_start+1:class_lookup_stop+1]))
        meta_data = process_header_meta_v7(meta_data)
        app_log.info('Meta data Extraction completed.')
        app_log.info('Extracting main dataframe.')
        defect_list_data_index = lines.index('DefectList\n')
        defect_header = lines[defect_list_data_index-1]
        cols = defect_header.lower().strip().strip(';').strip().split(' ')[2:]
        for index, line in enumerate(lines[::-1]):
            if 'summaryspec' in line.lower():
                defect_list_end_index = len(lines) - (index+1)
            else:
                try:
                    if len(line.strip().split(" "))>=20 and int(line.split(" ")[-2])>0:
                        img_count = int(line.split(" ")[-2])
                        lines[-index-1] = lines[-index-1] + " Images "
                        for i in range(1, img_count+1):
                            image_list = lines[-index-1 +i].strip()
                            a = image_list.replace(' ', '-') + ','
                            lines[-index-1] = lines[-index-1] + a 
                            lines[-index-1] = lines[-index-1].replace('\n', '').strip() 
                except Exception as e:
                        continue
        defect_df = lines[defect_list_data_index+1:defect_list_end_index]
        defect_df[-1] = defect_df[-1].replace(';', '')
        defect_df = list(map(clean_list_data, defect_df))
    except Exception as e:
        app_log.info(f"something is wrong while parsing file. {e}", )
        raise RuntimeError('something is wrong while parsing file')
    main_df = pd.DataFrame(defect_df, columns=cols)
    if class_lookup_data:
        class_df = pd.DataFrame(class_lookup_data, columns=[
                                "classnumber", "classname"])
    main_df = main_df.dropna(thresh=5).reset_index(drop=True)
    app_log.info(f"Main df is processed. Shape: {main_df.shape}")
    return main_df, meta_data, class_df, export_dict


def parser_v7(filename):
    """
    This is a caller function for parse_klarf. This returns the main_df and metadata to the data_processing.
    """
    app_log.info('Parsing file with v7 code.')
    app_log.info(f'Parsing file at: {filename}')
    intermediate_df, meta_data, class_df, export_dict = parse_klarf(filename)
    intermediate_df, meta_data = microns_to_nm(intermediate_df, meta_data)
    app_log.info(
        f'Main DataFrame and Meta data has been parsed. Returning now..')
    meta_df = pd.DataFrame(meta_data.values(), index=[
                           x.lower() for x in meta_data.keys()]).T
    return intermediate_df, meta_df, class_df, export_dict


def get_metadata_only_v7(filename):
    vals_dict = {}
    pattern = re.compile(r"[\";]")
    filename = 'upload/'+filename

    with open(filename, 'r') as lines:
        for line in lines:
            l = line.strip()
            l = re.sub(pattern, '', l).split(' ', 1)
            if l[0] == 'ClassLookup':
                break
            vals_dict[l[0]] = l[-1]
    meta_data = process_header_meta_v7(vals_dict)
    meta_data = {k.lower(): v for k, v in meta_data.items()}
    meta_data['resulttimestamp'] = pd.to_datetime(
        meta_data.get('resulttimestamp')).strftime('%Y/%m/%d %H:%M:%S')
    return meta_data
