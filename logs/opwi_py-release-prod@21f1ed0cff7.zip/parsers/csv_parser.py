# title                 : csv_parser.py
# description           : This is the parser for csv file.
# author                : Kamal Rana
# date                  : 03/02/2021
# version               : 1.0
# usage                 :
################################################################################################################

import re
import pandas as pd
import numpy as np
from tornado.gen import coroutine, Return
from api.utils.utils import get_logger, connection_pool, columns_info

app_log = get_logger("csv_parser")


def csv_parser(file_path, parent_id=None):
    """
    This is a caller function to parse csv file. This returns the list of all the scan sets dataframes to the data_processing.
    1. seperate all unified, global and scansets
    """

    '''Inside csv parser'''

    df = pd.read_csv(file_path, low_memory=False)
    df.columns = [col.lower() for col in df.columns]

    '''Extracting unified dataset'''
    unified_df =  df.loc[:, df.columns.str.contains('unified')]
    unified_df.columns = unified_df.iloc[0].values
    unified_df = unified_df.loc[1:, :]
    unified_df.columns = [col.lower().replace(' ', '_').replace('(i)', 'i').replace('-', '_') for col in unified_df.columns]

    '''Extracting global dataset'''
    global_df =  df.loc[:, df.columns.str.contains('global')]
    global_df.columns = global_df.iloc[0].values
    global_df = global_df.loc[1:, :]
    global_df.columns = [col.lower().replace(' ', '_').replace('(i)', 'i').replace('-', '_') for col in global_df.columns]

    '''Updation all scanset names with format X (not scan set X)'''
    if True in df.columns.str.contains('^\d*(\.\d+)?$'):
        pattern = re.compile("^\d*(\.\d+)?$")
        df.columns = [f'scan set {col}' if pattern.match(col) else col.lower() for col in df.columns]

    '''Extracting all scansets'''
    if not True in df.columns.str.contains('scan set'):
        raise Exception('Invalid File Format')
    ss_df =  df.loc[:, df.columns.str.contains('scan set')]
    all_ss = sorted(set([col.split('.')[0] for col in ss_df.columns]))
    app_log.info(f"Order of Scan set in parser: {all_ss}")
    ss_dfs = [ss_df.loc[:, ss_df.columns.str.contains(ss)] for ss in all_ss]

    for index, ss_df in enumerate(ss_dfs):
        ss_df.columns = ss_df.iloc[0].values
        ss_df = ss_df.loc[1:, ss_df.columns[2:]]
        ss_df.columns = [col.lower().replace(' ', '_').replace('(i)', 'i').replace('-', '_') for col in ss_df.columns]
        ss_df = pd.concat([ss_df, unified_df, global_df], axis=1)
        '''Temp code : start'''
        ss_df['grade'] = ss_df['total_grade']

        dtype_dict = {k: columns_info['main_cols'][k] for k in (ss_df.columns).intersection(columns_info['main_cols'].keys())}
        ss_df = ss_df.apply(pd.to_numeric, errors='ignore')
        ss_df = ss_df.loc[:, ~ss_df.columns.duplicated()]
        ss_df = ss_df.loc[~ss_df['volume'].isna(), :].astype(dtype_dict)
        ss_dfs[index] = ss_df

    return ss_dfs
