from api.utils.utils import connection_pool, get_logger

app_log = get_logger("droppartition")

def drop_partiton(cursor, table_name):
    query = f"select distinct partition from system.parts where database = 'raw' and table='{table_name}' and modification_time <= date_sub(DAY, 1, toDate(now()))"
    app_log.info(f"Partition select query: {query}")
    cursor.execute(query)

    for partition in cursor.fetchall():
        app_log.info(f"Dropping partitions {partition[0]}")
        drop_query = f"ALTER TABLE raw.{table_name} DROP PARTITION '{partition[0]}'"
        cursor.execute(drop_query)
        app_log.info(f"Completed dropping partition {partition[0]} from {table_name}")

try:
    tableList = ['opwi_defect_main_wip', 'opwi_defect_main_radial_wip']
    connection = connection_pool.connect()
    cursor = connection.cursor()
    for tbl in tableList:
        drop_partiton(cursor, tbl)
    cursor.close()
    connection.close()

except Exception as e:
    import traceback
    app_log.info("Error while optiimizing the table")
    app_log.error(traceback.format_exc())