from api.utils.utils import connection_pool, get_logger, get_env_config
import os
import datetime
from re import sub as substitute


class Backup:
    def __init__(self, parent_dir):
        self.parent_dir = parent_dir
        self.connection = connection_pool.connect()
        self.primary_key = dict()
        self.duplicates = dict()

    def get_primary_key(self, table, table_desc):
        primary_key = None
        for line in table_desc[0][0].split("\n"):
            if 'PRIMARY KEY' in line:
                print(line)
                primary_key = substitute('PRIMARY KEY|\(|\)', '', line).strip()
                self.primary_key[table] = primary_key

    def get_duplicates(self, tables):
        query = []
        print(tables)
        for i in tables:
            if i[0] in self.primary_key.keys():
                query.append(
                    f"select '{i[0]}' as table_name, count(1) from (select count(1) from {i[0]} group by {self.primary_key[i[0]]} having count(1) > 1) a")

        if len(query) == 0:
            return
        duplicate_count_query = " union all ".join(query)
        print(duplicate_count_query)

        data = self.execute_query(duplicate_count_query)
        print(data)
        for i in data:
            print(data)
            self.duplicates[i[0]] = i[1]

    def create_duplicate_files(self):
        file_name = self.parent_dir + "/" + "duplicate_file.txt"
        with open(file_name, 'w') as f:
            for key, values in self.duplicates.items():
                f.write(f"{key}:{self.primary_key[key]}:{values}")
                f.write("\n")

    def create_sql_file(self, destination_dir, table_name, file_content):
        if os.path.isdir(destination_dir):
            file_path = f"{destination_dir}/{table_name.lower()}.sql"
            with open(file_path, 'w') as f:
                f.write(file_content[0][0])
                return True
        else:
            if self.directory(destination_dir):
                self.create_sql_file(destination_dir, table_name, file_content)
            else:
                print(
                    f"Unable to create the destination Directory: {destination_dir}")

    def directory(self, directory):
        try:
            path = os.path.join(parent_dir, directory)
            if os.path.isdir(path):
                print("Already exists")
            else:
                os.makedirs(path)
            return True
        except Exception as e:
            print(e)
            return False

    def execute_query(self, query):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            data = cursor.fetchall()
            return data
        except Exception as e:
            print("Error executing the query")
            print(f"Error Message: {e}")
            return None

    def get_tables(self, schema=None, pattern=''):
        if schema is None or schema == '':
            query = f"show tables like '%{pattern}%' limit 1"
        else:
            query = f"show tables from {schema} like '%{pattern}%'"
        print(query)
        tables = self.execute_query(query)
        return tables


if __name__ == "__main__":
    bkp = Backup("/Application/opwi_python/schema_backup")
    dt = datetime.datetime.now().strftime('%b_%d_%Y')
    print(dt.lower())

    tables = bkp.get_tables(schema='raw', pattern='opwi')
    parent_dir = f"{bkp.parent_dir}\\{dt.lower()}"
    print(tables)
    for t in tables:
        show_query = f"show create table {t[0]}"
        print(show_query)
        metadata = bkp.execute_query(show_query)
        if metadata is not None:
            bkp.get_primary_key(t[0], metadata)
            bkp.get_duplicates([(t[0],)])
            # bkp.get_duplicates(t[0])
            #f"{parent_dir}\\{t[0].lower()}", t[0], metadata)
            bkp.create_sql_file(
                f"{parent_dir}/{t[0].lower()}", t[0], metadata)

    # bkp.get_duplicates(tables)
    print(bkp.duplicates)
    bkp.create_duplicate_files()
