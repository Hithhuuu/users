from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_logger, get_columns_info, columns_info
from api.utils.datastore import DataStore
from api.utils.common import (make_query, update_query, get_prep_level, prep_range_query_selectedmaps,
                          get_commonality_filter, get_condition_cols, get_rmapid, commonality_query, execute_query)

app_log = get_logger('Defect_Table_Model')


class Defecttable():
    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2['defecttable']
        self.ds = DataStore(self.connection)
        self.defectlimit = 5000
        self.columns = get_columns_info()

    def check_null_columns(self, mapid):
        null_cols_query = f"select null_cols from opwi_map_header final where rfg=1 and mapid in {tuple(mapid)}"
        val = execute_query(self.connection, null_cols_query)
        null_cols = []
        for i in val:
            if i[0] != '':
                null_cols.extend(i[0].split(","))
        null_cols.append("appearances")
        selected_columns = [key for key in self.columns["attribute_fields"] if key.lower() in null_cols]
        selected_columns.extend(["defectid", "mapid","refcm", "mapname"])
        return selected_columns

    def commonality_query(self, data, appearances, query_data, commonality_filter):
        app_log.info(appearances)
        if commonality_filter:
            mapids = data['inputs']['selectedMaps'] if data['inputs'].get('selectedMaps') else data['values']['mapid']
            smapid = [ i for i in mapids if i != data['inputs']['ref_mapid']]
            query_data['commonality'] = self.queries['commonality'].format(
                **{
                    "projectid": data['projectid'],
                    "rmapid": data['inputs']['ref_mapid'],
                    "smapid": tuple(smapid + [0]) if len(smapid) > 0 else "(null, 0)"
                }
            )
            commonality_mapping = columns_info['commonality_attr_mapping']
            value_c = tuple([commonality_mapping[i] for i in commonality_filter])
            query_data['count_condition_commonality'] = f" AND cm.refcm in {value_c}"
        else:
            query_data['commonality'] = ''
            query_data['count_condition_commonality'] = ''
        return query_data

    def prepare_defect_main_columns(self, defecttable, orientation):
        columns = " , ".join(
            [f"defects.{i}" for i in defecttable['selected_columns'] if
             i.lower() not in ['refcm', 'mapname', 'classname', 'appearances']])
        columns = update_query(columns, orientation)
        for colm in ['xrel', 'xindex', 'yrel', 'yindex']:
            if f"as {colm}_{orientation}" in columns:
                columns = columns.replace(
                    f'as {colm}_{orientation}', f'as {colm}')

        return columns

    def get_class_query(self, data):
        UNION_ALL=" union all "
        class_query = []
        if len(data['values'].get('classification', [])) == 0:
            class_query.append(self.queries['opwi_map_class'].format(
                **{
                    'mapid': tuple(data['values']['mapid']),
                }
            ))
            return UNION_ALL.join(class_query)

        if 'classification' in data['filters'].get('multiDropdown'):
            if isinstance(data['values']['classification'][0]['classnumber'], list) \
                    and 'groupname' in data['values']['classification'][0].keys():
                query = self.queries['opwi_map_class'].format(
                    **{
                        'mapid': tuple(data['values']['mapid']),
                    }
                )
                query += f" AND classnumber in {tuple([k for i in data['values']['classification'] for k in i['classnumber']])}"
                class_query.append(query)
            else:
                for i, mapid in enumerate(data['values'].get('mapid')):
                    query = self.queries['opwi_map_class'].format(
                        **{
                            'mapid': f"({mapid})"
                        }
                    )
                    query += f" AND classnumber = {data['values']['classification'][i]['classnumber'][0]}"
                    class_query.append(query)
        else:
            class_query.append(self.queries['opwi_map_class'].format(
                **{
                    'mapid': tuple(data['values']['mapid']),
                }
            ))
        return UNION_ALL.join(list(set(class_query)))


    def prepare_columns(self, defecttable, orientation, alias=True):
        '''Prepare select columns for query'''
        
        columns = " , ".join([f"defects.{i} as {i}" for i in defecttable['selected_columns'] if i.lower() not in ['refcm','xindex', 'yindex', 'mapname', 'appearances']])
        
        if 'defects.mapname' in columns:
            columns = columns.replace('defects.mapname', 'header.mapname')

        if 'defects.classname' in columns:
            columns = columns.replace('defects.classname', 'class.classname')
        columns = update_query(columns, orientation)
        if alias == True:
            for colm in ['xrel', 'xindex', 'yrel', 'yindex']:
                if f"as {colm}_{orientation}" in columns:
                    columns = columns.replace(
                        f'as {colm}_{orientation}', f'as {colm}')
                # elif colm == 'imagelist':
                #     print(columns)
                #     columns += f" multiIf(isNull(imagelist), 'No', imagelist = '0', 'No', imagelist like '%|%, 'yes') as hasimage",
        return columns

    def prepare_search(self, defecttable, type='column'):
        '''Prepare search query for defect table'''
        if type == 'column':
            if defecttable['column_search']:
                column_search = mapname_srch = other_col_srch = otyp_srch = appearances_srch =""

                if 'mapname' in defecttable['column_search'].keys():
                    value = defecttable['column_search']['mapname'].replace('|', '')
                    if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'"):
                        mapname_srch = f" AND upper(mapname) = upper('{value[1:-1]}')"
                    else:
                        mapname_srch = f" AND upper(mapname) like upper('%{value}%')"

                if 'otype' in defecttable['column_search'].keys():
                    value = defecttable['column_search']['otype']
                    if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'"):
                        otyp_srch = f" AND case when defects.otype = 17 then 'VV' when defects.otype = 16 then 'VM' when defects.otype = 15 then 'V0' when defects.otype = 14 then 'MV' when defects.otype = 13 then 'MM' when defects.otype = 12 then 'M0' when defects.otype = 11 then '0V' when defects.otype = 10 then '0M' when defects.otype = 9 then 'EOA' when defects.otype = 8 then 'S' when defects.otype = 7 then 'OO' when defects.otype = 6 then 'B' when defects.otype = 5 then 'S' when defects.otype = 4 then 'VV' when defects.otype = 3 then 'VM' when defects.otype = 2 then 'MV' when defects.otype = 1 then 'MM' when defects.otype = 0 then 'UN' else '' end =upper('{value[1:-1]}')"
                    else:
                        otyp_srch = f" AND case when defects.otype = 17 then 'VV' when defects.otype = 16 then 'VM' when defects.otype = 15 then 'V0' when defects.otype = 14 then 'MV' when defects.otype = 13 then 'MM' when defects.otype = 12 then 'M0' when defects.otype = 11 then '0V' when defects.otype = 10 then '0M' when defects.otype = 9 then 'EOA' when defects.otype = 8 then 'S' when defects.otype = 7 then 'OO' when defects.otype = 6 then 'B' when defects.otype = 5 then 'S' when defects.otype = 4 then 'VV' when defects.otype = 3 then 'VM' when defects.otype = 2 then 'MV' when defects.otype = 1 then 'MM' when defects.otype = 0 then 'UN' else '' end like upper('%{value}%')"
                if 'appearances' in defecttable['column_search'].keys():
                    value = defecttable['column_search']['appearances']
                    if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'"):
                        appearances_srch = f" AND toString(appearances) = '{value[1:-1]}'"
                    else:
                        appearances_srch = f" AND toString(appearances) like '%{value}%'"                        
                other_col_srch = " AND ".join(
                    [f"toString({key})='{value[1:-1]}'" if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'") else f"toString({key}) ilike '%{value}%'"
                     for key, value in {i: j for i, j in defecttable['column_search'].items()
                                        if i not in ['mapname', "otype", "appearances"]}.items()
                     ])

                column_search = f"{f'AND {other_col_srch}' if other_col_srch != '' else ''} {mapname_srch}"
                column_search += otyp_srch
                column_search += appearances_srch
                return f"  {column_search}"

            return ""

        if type == 'overall':
            from string import punctuation
            search_string = ""
            if defecttable.get('search_text'):
                for i in defecttable.get('search_text'):
                    if i in list(punctuation):
                        search_string += f"\\{i}"
                    else:
                        search_string += i
                overall_search = f" AND lower(defects.srch_id||'!'||coalesce(toString(class.classname),'')||'!'||coalesce(toString(defects.classnumber),'')||'!'||coalesce(" \
                                 f"toString(header.mapname),'')||'!'||coalesce(toString(xrel),'')||'!'||coalesce(toString(" \
                                 f"yrel),'')||'!'||coalesce(toString(xindex),'')||'!'||coalesce(toString(yindex)," \
                                 f"'')||'!'||coalesce(toString(appearances),'')||'!'||coalesce(toString(refcm),'')||'!'||(case when defects.otype = 17 then 'VV' when defects.otype = 16 then 'VM' when defects.otype = 15 then 'V0' when defects.otype = 14 then 'MV' when defects.otype = 13 then 'MM' when defects.otype = 12 then 'M0' when defects.otype = 11 then '0V' when defects.otype = 10 then '0M' when defects.otype = 9 then 'EOA' when defects.otype = 8 then 'S' when defects.otype = 7 then 'OO' when defects.otype = 6 then 'B' when defects.otype = 5 then 'S' when defects.otype = 4 then 'VV' when defects.otype = 3 then 'VM' when defects.otype = 2 then 'MV' when defects.otype = 1 then 'MM' when defects.otype = 0 then 'UN' else '' end)) like lower('%{search_string}%') "
                return overall_search
            return ""

    def prepare_column_sort(self, defecttable, orientation):
        ''' Preparing query string for column sorting '''
        if defecttable.get('column_sort'):
            columns_sort_query = [f"{key} {value} " for key, value in defecttable['column_sort'].items(
            ) if defecttable['column_sort'][key]]
            column_sort_query = " , ".join(columns_sort_query)
            sort_query = update_query(
                f' ORDER BY {column_sort_query}', orientation)
            return sort_query
        return " ORDER BY defects.defectid DESC"

    def prepare_query_inputs(self, input_data, inputs, values, count_condition, condition, orientation,
                             commonality_filter, condition_cols, appearances):
        '''prepare query inputs'''
        app_log.info(inputs)
        defecttable = inputs['defecttable']
        data = {'mapid': tuple(values.get('mapid')), 'fieldx': inputs.get('fieldx', 1),
                'fieldy': inputs.get('fieldy', 1), 'diepitch_x': inputs.get('diepitch_x', 1),
                'diepitch_y': inputs.get('diepitch_y', 1), "xsite": f'xsite_{orientation}',
                "ysite": f'ysite_{orientation}', "condition": update_query(condition, orientation),
                "orientation": orientation, "selected_maps": tuple(inputs.get('selectedMaps', '')),
                "prep_column": inputs.get('prep_column', None),
                "count_condition": update_query(count_condition, orientation),
                "columns": self.prepare_columns(defecttable, orientation),
                "inner_columns": self.prepare_columns(defecttable, orientation, False),
                "defect_main_cols": self.prepare_defect_main_columns(defecttable, orientation),
                "condition_columns": condition_cols,
                "waferView": inputs.get('waferView', 'stack')}
        data_count = data
        data_count['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get('selectedMaps') else data['mapid']
        data_count['count_condition'] = data_count['count_condition'].replace(str(data['mapid']),str(data['selected_maps'])) if len(data['selected_maps']) != 0 else data['count_condition']
        data_count['offset'] = self.queries['offset_join'].format(**{"mapid": data['mapid'], "orientation": orientation}) if inputs.get(
                    'waferView', 'stack') != 'multi1' and inputs.get('waferView', 'stack') else ''
        if 'fieldrelx' in data_count['count_condition']:
            data_count['count_condition'] = data_count['count_condition'].replace('fieldrelx',
                                                                                  f"(floor((abs(round(((defects.{data['xsite']} + rtn.offset_x) - defects.xrel_{orientation}) / rtn.diepitch_x_{orientation}) % {data['fieldx']}) * {data['diepitch_x']}) + xrel_{orientation}))")
            data_count['count_condition'] = data_count['count_condition'].replace('fieldrely',
                                                                                  f"(floor((abs(round(((defects.{data['ysite']} + rtn.offset_y) - defects.yrel_{orientation}) / rtn.diepitch_y_{orientation}) % {data['fieldy']}) * {data['diepitch_y']}) + yrel_{orientation}))")
        app_log.info(data)
        data_count = self.commonality_query(input_data, appearances, data_count, commonality_filter)
        app_log.info(data_count)
        #commonality_query(input_data, commonality_filter, data_count)
        prep_data = get_prep_level(
            self.connection, data_count, limit=self.defectlimit)
        data['xsite'] = prep_data['xsite']
        data['ysite'] = prep_data['ysite']
        if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
            data['offset_columns'] = self.queries['offset_columns'].format(**{
                       "xsite": prep_data['xsite'],
                        "ysite": prep_data['ysite'],
                        "orientation": orientation,
                        "fieldx": data['fieldx'],
                        "fieldy": data['fieldy'],
                        "diepitch_x": data['diepitch_x'],
                        "diepitch_y": data['diepitch_y']
                })
        else:
            data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": prep_data['xsite'],
                    "ysite": prep_data['ysite'],
                    "orientation": orientation,
                    "fieldx": data['fieldx'],
                    "fieldy": data['fieldy'],
                    "diepitch_x": data['diepitch_x'],
                    "diepitch_y": data['diepitch_y']
                })
        return data

    def get_selected_maps(self, data, query):
        query_count = query
        if data['inputs'].get('selectedMaps', None):
            selected_maps = str(tuple(data['inputs']['selectedMaps']))
            maps = str(tuple(data['values']['mapid']))
            query_count = query.replace(maps, selected_maps)
                          #+ ' group by mapid order by count(1) desc limit 1'
        return query_count

    def get_rmapid(self,inputs, projectid):
        if inputs.get('ref_mapid', '') == '':
            rmapid = get_rmapid(self.connection, projectid) 
            return rmapid if rmapid else None
        else:
            return inputs.get('ref_mapid')


    @coroutine
    def get(self, data):
        '''Returns Data for defect table
            1. prepare columns with alias
            2. prepare for ctrl + click defect selection
            3. prepare search part of query
            4. prepare columns sort query
            5. prepare inputs
        '''

        try:
            if data['values']['mapid'][0] == 0:
                return ({
                'total': 0,
                'limit': 0,
                'offset': 0,
                'data': [],
                'type_mapping': self.columns['Histogram']['Attribute header']
            })
            # if data['inputs'].get('pareto', None):
            #     data['inputs']['pareto_sel'] = True
            inputs = data['inputs']
            filters = data['filters']
            values = data['values']
            UNION_ALL=" union all "
            condition_cols = get_condition_cols(data)
            opwi_map_class = self.get_class_query(data)
            commonality_filter = get_commonality_filter(data)
            appearances = None
            if data['values'].get('attribute_filters', None):
                appearances = data['values'].get('attribute_filters').get('appearances', None)
            
            defect_query = ""
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            defecttable = inputs['defecttable']
            rmapid = self.get_rmapid(inputs,data.get('projectid', None))
            commonality_var = '_commonality' if rmapid else ''
            projectid = data.get('projectid', 'null')
            defecttable['selected_columns'] = self.check_null_columns(values['mapid'])
            mapids = inputs['selectedMaps'] if inputs.get('selectedMaps') else values['mapid']
            
            '''for ctrl + click single defect selection'''
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                # filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN {tuple(values['defectid'])}"
            query_data = make_query(data, alias='defects.')

            '''Defect table condition generation part'''
            dt_multi_dropdown = defecttable.get("multiDropdown", {})
            dt_range_filters = defecttable.get("range", {})
            defect_condition = ''
            cust_condition = ''
            if dt_multi_dropdown or dt_range_filters:
                filter_values = {}
                refcm_clm = dt_multi_dropdown.pop('refcm', None)
                hasimage = dt_multi_dropdown.pop('hasimage', None)
                filter_values.update(dt_multi_dropdown)
                filter_values.update({'attribute_filters': dt_range_filters})

                defect_input = {
                    'inputs': {},
                    'filters': {
                        'multiDropdown': list(dt_multi_dropdown.keys()),
                        'range': ['attribute_filters']
                    },
                    'values': filter_values
                }

                defect_condition = make_query(defect_input, alias='defects.')

                if hasimage:
                    hasimage_cond = f"AND defects.hasimage IN {tuple(hasimage)}"
                    cust_condition = f"{cust_condition} {hasimage_cond}"

                if refcm_clm:
                    refcm_cond = "'N'"
                    if commonality_var:
                        refcm_cond = self.queries['refcm_cond_commonality'].format(**{
                            "rmapid": rmapid,
                            "mapid": tuple(mapids)
                        })

                    refcm_cond = f"AND {refcm_cond} IN {tuple(refcm_clm)}"
                    cust_condition = f"{cust_condition} {refcm_cond}"

            limit, offset = defecttable.get(
                'limit', 10), defecttable.get('offset', 10)
            limit_query = f" LIMIT {offset}, {limit}"

            '''prepare search query'''
            column_search = self.prepare_search(defecttable, type='column')
            overall_search = self.prepare_search(defecttable, type='overall')

            '''sorting query'''
            sort_query = self.prepare_column_sort(defecttable, orientation)
            '''prepping inputs'''
            count_condition = f"{query_data} {defect_condition}"
            condition = f"{count_condition}{defect_query}{column_search}{overall_search}"
            query_inputs = self.prepare_query_inputs(data, inputs, values, count_condition, condition,
                                                     orientation, commonality_filter, condition_cols, appearances)

            query_inputs['rmapid'] = rmapid
            query_inputs['smapid'] = [i for i in mapids if i != query_inputs['rmapid']]
            query_inputs['smapid'] = tuple(query_inputs['smapid']+ [0]) if len(query_inputs['smapid']) > 0 else "(null, 0)"
            query_inputs['projectid'] = projectid
            # query_inputs['defect_condition'] = defect_condition

            if inputs.get('singleMapSelection', None):
                range_query_dict = prep_range_query_selectedmaps(data, '')
                query_list = []
                for key, values in range_query_dict.items():
                    input_data = {
                        "mapid": (int(key.split("_")[0]),),
                        "range_condition": update_query(values,orientation),
                        "orientation": orientation,
                        "defect_main_cols": query_inputs['defect_main_cols'],
                        "xsite": query_inputs['xsite'],
                        "ysite": query_inputs['ysite'],
                        "fieldx": query_inputs['fieldx'],
                        "fieldy": query_inputs['fieldy'],
                        'diepitch_x': query_inputs.get('diepitch_x', 1),
                        'diepitch_y': query_inputs.get('diepitch_y', 1)
                    }
                    query_list.append(self.queries['defect_main'].format(**input_data))
                query_inputs["union_all"] = UNION_ALL.join(query_list)
            query_inputs['opwi_map_class'] = opwi_map_class
            query_inputs['condition'] = f"{query_inputs['condition']} {cust_condition}"
            ''' Calculating Defect Count'''
            app_log.info(commonality_var)
            if inputs.get('singleMapSelection', None):
                defect_count_query = self.queries[f'count_rect{commonality_var}'].format(**query_inputs)
            else:
                defect_count_query = self.queries[f'count{commonality_var}'].format(**query_inputs)
            app_log.info(f"DEFECT COUNT QUERY: {defect_count_query}")
            count = self.ds.fetch(query=defect_count_query, fetch='one')._result

            app_log.info(f"DEFECT COUNT: {count}")
            ''' Fetching Defect table data '''
            query_inputs['condition'] = f"{query_inputs['condition']} {sort_query}{limit_query}"

            if inputs.get('singleMapSelection', None):
                query_to_execute = self.queries[f'read_rect{commonality_var}'].format(**query_inputs)
            else:
                query_to_execute = self.queries[f'read{commonality_var}'].format(**query_inputs)
            app_log.info(f" Defect Query: {query_to_execute}")

            defect_data = self.ds.fetch(
                query=query_to_execute, fetch='all')._result
            resp = {
                'total': int(count.get('cnt', 0)),
                'limit': limit,
                'offset': offset,
                'data': defect_data,
                'type_mapping': self.columns['Histogram']['Attribute header']
            }
            app_log.info(f"Defect table data fetching completed")
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            return {"error": str(e)}
        raise Return(resp)

    def __del__(self):
        ''' Connection close '''
        self.connection.close()
