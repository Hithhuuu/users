import tornado
from api.defecttable.defecttable_api.defecttablehandler import DefectTableHandler
from api.reclassification.reclassification_api.reclassificationhandler import ReclassificationHandler, NewClassHandler


services = {
    'defect_table': [
        tornado.web.url(r"/defect", DefectTableHandler),
        tornado.web.url(r"/reclassification", ReclassificationHandler),
        tornado.web.url(r"/reclassification/addclass", NewClassHandler),
    ],
}