nohup python3 api\defecttable\server.py --port=8030 --env=dev --service=defect_table
nohup python3 api\defecttable\server.py --port=8031 --env=dev --service=defect_table
nohup python3 api\defecttable\server.py --port=8032 --env=dev --service=defect_table
nohup python3 api\defecttable\server.py --port=8033 --env=dev --service=defect_table