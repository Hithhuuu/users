# '''
#     All services and handler are defined in services module.

#     9000 - 8010
#     User and Authentication
#         AuthHandler
#         UserHandler
#         ActivityHandler

#     8010 - 8020
#     Projects
#         ProjectHandler
#         ShareHandler

#     8020 - 8030
#     Maps
#         MapHandler
#         MapFilterHandler

#     8030 - 8040
#     Defect Table
#         DefectTableHandler
#         ReclassificationHandler

#     8040 - 8050
#     ScatterPlot
#         ScatterPlotHandler

#     8050 - 8060
#     Binning
#         BinningHandler

#     8060 - 8070
#     Stacking
#         DieStackingHandler

#     8070 - 8080
#     Pareto
#         ParetoHandler

#     8080 - 8090
#     Sfilters
#         SecondaryFilterHandler

#     8090 - 9000
#     Wafermap
#         WaferMapHandler
#         WaferMapDetailsHandler

#     9000 - 9010
#     Upload
#         UploadHandler
#         StatusHandler
#         ProgressHandler

#     9010 - 9020
#     GrpClass
#         GroupHandler
#         ClassHandler

#     9020 - 9030
#     Commonality
#         CommonalityHandler

#     9031 - 9040
#     Combo Analysis
#         ComboAnalysisHandler
# '''
from api.comboanalysis.comboanalysis_api.comboanalysishandler import ComboAnalysisHandler
from api.share.share_api.sharehandler import ShareHandler
from api.generic.generic_api.refreshhandler import RefreshHandler
from api.generic.generic_api.progresshandler import ProgressHandler
from api.generic.generic_api.statushandler import StatusHandler
from api.copyclassification.copyclassification_api.copyclassificationhandler import CopyClassificationHandler
from api.binning.binning_api.binninghandler import BinningHandler
from api.pareto.pareto_api.paretohandler import ParetoHandler, ParetoFilterHandler
from api.scanset.scanset_api.scansethandler import ScansetHandler
from api.saveasmap.saveasmap_api.saveasmaphandler import SaveAsMapHandler
from api.wafermap.wafermap_api.legendhandler import LegendHandler
from api.wafermap.wafermap_api.wafermapdetailshandler import WaferMapDetailsHandler
from api.wafermap.wafermap_api.wafermaphandler import WaferMapHandler
from api.templateshare.templateshare_api.templatesharehandler import TemplateshareHandler
from api.templates.templates_api.templatehandler import TemplateHandler
from api.groupclass.groupclass_api.classhandler import ClassHandler
from api.groupclass.groupclass_api.grouphandler import GroupHandler
from api.commonality.commonality_api.commonalityhandler import CommonalityHandler
from api.attributechart.attributechart_api.attributecharthandler import AttributeChartFilterHandler
from api.attributechart.attributechart_api.attributecharthandler import AttributeChartHandler
from api.attributecommonality.attributecommonality_api.attributecommonalityhandler import AttributeCommonalityHandler
from api.hitmap.hitmap_api.hitmaphandler import HitMapHandler, HitMapExportHandler
from api.histogram.histogram_api.histogramhandler import HistogramHandler, HistogramFilterHandler
from api.sfilter.sfilter_api.sfilterhandler import SecondaryFilterHandler
from api.stacking.stacking_api.fieldstackinghandler import FieldStackingHandler
from api.stacking.stacking_api.diestackinghandler import DieStackingHandler
from api.maps.maps_api.mapfilterhandler import MapFilterHandler
from api.maps.maps_api.maphandler import MapHandler
from api.capturerate.capturerate_api.captureratehandler import CaptureRateHandler
from api.reclassification.reclassification_api.reclassificationhandler import ReclassificationHandler
from api.projects.projects_api.projectshandler import ProjectHandler
from api.user.user_api.activityhandler import ActivityHandler
from api.user.user_api.authhandler import AuthHandler
from api.user.user_api.userhandler import UserHandler
from api.defecttable.defecttable_api.defecttablehandler import DefectTableHandler
from api.scatterplot.scatterplot_api.scatterplothandler import ScatterPlotHandler, ScatterPlotFilterHandler
from api.export.export_api.exporthandler import ExportHandler
import tornado
from api.upload.upload_api.uploadhandler import UploadHandler
from api.flow.flow_api.flowhandler import FlowHandler


''' New API handlers '''

services = {
    'user_authentication': [
        tornado.web.url(r"/auth", AuthHandler),
        tornado.web.url(r"/auth/refresh", RefreshHandler),
        tornado.web.url(r"/user", UserHandler),
        tornado.web.url(r"/activity", ActivityHandler)
    ],
    'projects': [
        tornado.web.url(r"/project", ProjectHandler),
        tornado.web.url(r"/share", ShareHandler),
        tornado.web.url(r"/template", TemplateHandler),
        tornado.web.url(r"/templateshare", TemplateshareHandler)
    ],
    'maps': [
        tornado.web.url(r"/map", MapHandler),
        tornado.web.url(r"/mapfilter", MapFilterHandler),
        tornado.web.url(r"/map/scanset", ScansetHandler)
    ],
    'defect_table': [
        tornado.web.url(r"/defect", DefectTableHandler),
        tornado.web.url(r"/reclassification", ReclassificationHandler),
    ],
    'pareto': [
        tornado.web.url(r"/pareto", ParetoHandler),
        tornado.web.url(r"/pareto/filter", ParetoFilterHandler)
    ],
    'stacking': [
        tornado.web.url(r"/diestacking", DieStackingHandler),
        tornado.web.url(r"/fieldstacking", FieldStackingHandler),
    ],
    'binning': [
        tornado.web.url(r"/binning", BinningHandler),
    ],
    'wafermap': [
        tornado.web.url(r"/wafermap", WaferMapHandler),
        tornado.web.url(r"/waferdetails", WaferMapDetailsHandler),
        tornado.web.url(r"/wafermap/legends", LegendHandler),
    ],
    'scatterplot': [
        tornado.web.url(r"/scatterplot", ScatterPlotHandler),
        tornado.web.url(r"/scatterplot/filter", ScatterPlotFilterHandler),
    ],
    'sfilter': [
        tornado.web.url(r"/sfilter", SecondaryFilterHandler)
    ],
    'groupclass': [
        tornado.web.url(r"/group", GroupHandler),
        tornado.web.url(r"/class", ClassHandler),
    ],
    'upload': [
        tornado.web.url(r"/upload", UploadHandler),
        tornado.web.url(r"/status", StatusHandler),
        tornado.web.url(r"/progress", ProgressHandler)
    ],
    'commonality': [
        tornado.web.url(r"/commonality", CommonalityHandler),
        tornado.web.url(r"/copyclassification", CopyClassificationHandler)
    ],
    'histogram': [
        tornado.web.url(r"/histogram", HistogramHandler),
        tornado.web.url(r"/histogram/filter", HistogramFilterHandler)
    ],

    'attributecommonality': [
        tornado.web.url(r"/attributecommonality", AttributeCommonalityHandler)
    ],
    'attributechart': [
        tornado.web.url(r"/attributechart", AttributeChartHandler),
        tornado.web.url(r"/attributechart/filter", AttributeChartFilterHandler)
    ],
    'hitmap': [
        tornado.web.url(r"/hitmap", HitMapHandler),
        tornado.web.url(r"/hitmap/export", HitMapExportHandler)
    ],
    'export': [
        tornado.web.url(r"/export", ExportHandler)
    ],
    'capturerate': [
        tornado.web.url(r"/capturerate", CaptureRateHandler)
    ],
    'saveasmap': [
        tornado.web.url(r"/saveasmap", SaveAsMapHandler)
    ],
    'comboanalysis': [
        tornado.web.url(r"/comboanalysis", ComboAnalysisHandler)
        # tornado.web.url(r"/comboanalysis", ComboAnalysisHandler)
    ],
    'flow': [
        tornado.web.url(r"/flow", FlowHandler)
    ]
}

