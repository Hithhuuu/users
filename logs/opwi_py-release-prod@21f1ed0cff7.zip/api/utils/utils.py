import os
import sys
import yaml
import shutil
import logging
import numpy as np
from glob import glob
from tornado.options import options
import sqlalchemy as sa
from Crypto.Cipher import AES
from Crypto import Random
import base64
from clickhouse_driver import connect
import sqlalchemy.pool as pool
from hashlib import md5
from logging.handlers import TimedRotatingFileHandler


FORMATTER = logging.Formatter(
    "%(asctime)s — %(name)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s")
LOG_FILE = "logs/opwi.log"


def get_config():
    """Return the config read from config.yaml file"""
    with open('configs/config.yaml') as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return config


def get_columns_info():
    """Return the config read from columns.yaml file"""
    with open('configs/columns.yaml') as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return columns


def get_env_config():
    """Return the config read from config.yaml file"""
    env = os.getenv('env')
    if env is None:
        env = 'local'
    with open('configs/config.yaml') as file:
        try:
            config = yaml.load(file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader)
        except Exception as e:
            config = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return config['env'][env.lower()]


def create_directories(config):
    """Initialize all required directories"""
    for d in get_env_config()['directories'].values():
        if not (os.path.isdir(d)):
            os.mkdir(d)
    return True


def clean_directories(config):
    """Clean all required directories"""
    try:
        shutil.rmtree('upload')
    finally:
        create_directories(config)


def get_dbconnection():
    ''' Create db connection for clickhouse '''
    cnn = connect(env_config['clickhouse'])
    return cnn


def create_connection_pool():
    """Creates and returns a Connection Pool"""
    connection_pool = pool.QueuePool(
        get_dbconnection, max_overflow=10, pool_size=5)
    return connection_pool


def get_queries():
    with open('queries/queries.yaml') as file:
        queries = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return queries


def get_queries2():
    path = os.path.abspath(os.getcwd())
    query_files = glob(path + '/api/*/*.yaml', recursive=True)
    queries = dict()
    for qfile in query_files:
        key = os.path.splitext(os.path.basename(qfile))[0]
        with open(qfile) as file:
            queries[key] = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
    return queries


def get_console_handler():
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def get_file_handler(LOG_FILE):
    file_handler = TimedRotatingFileHandler(LOG_FILE, when='midnight', backupCount=15)
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_logger(logger_name):
    path_config = {
        'activity': "logs/activity.log",
        'Defect_Table_Model': "logs/defecttable.log",
        'map': "logs/maps.log",
        'pareto': "logs/pareto.log",
        'projects': "logs/projects.log",
        'sfilter': "logs/sfilter.log",
        'share': "logs/share.log",
        'user': "logs/users.log",
        'Wafer_map': "logs/wafermap.log",
        'parserv7': "logs/paser_v7.log",
        'parserv8': "logs/paser_v8.log",
        'upload': "logs/upload.log",
        'dataload': "logs/dataload.log",
        'UploadHandler': "logs/upload.log",
        'Class_Group': "logs/class_group.log",
        'server': "logs/server.log",
        'Scatter_Plot': "logs/scatterplot.log",
        'reclassification': "logs/reclassification",
        'commonality': "logs/commonality.log",
        'copyclassification': "logs/copyclassification.log",
        'template': "logs/template.log",
        'templateshare': "logs/templateshare.log",
        'globalfilter': "logs/globalfilter.log",
        'attributecommonality': "logs/attributecommonality.log",
        'attributechart': "logs/attributechart.log",
        'hitmap': "logs/hitmap.log",
        'histogram': "logs/histogram.log",
        'common': "logs/common.log",
        'export': "logs/export.log",
        'capturerate': "logs/capturerate.log",
        'stacking': "logs/stacking.log",
        'group': 'logs/group.log',
        'class': 'logs/class.log',
        # 'projects': 'logs/projects.log',
        'wafermap': 'logs/wafermap.log',
        'csv_parser': 'logs/csv_parser.log',
        'saveasmap': 'logs/saveasmap.log',
        'scanset': 'logs/scanset.log',
        'watchdog_cron': 'logs/watchdog_cron.log',
        'process_execution': 'logs/process_execution.log',
        'share': 'logs/share.log',
        'binning': 'logs/binning.log',
        'optimizetables': 'logs/optimizetables.log',
        'comboanalysis': 'logs/comboanalysis.log',
        'otf':'logs/otf.log',
        'droppartition': 'logs/droppartition.log'
    }
    create_directories(get_config())
    logger = logging.getLogger(logger_name)
    # better to have too much log than not enough
    logger.setLevel(logging.DEBUG)
    logger.addHandler(get_console_handler())
    logger.addHandler(get_file_handler(f"{path_config[logger_name]}"))
    # with this pattern, it's rarely necessary to propagate the error up to parent
    logger.propagate = False
    return logger


def get_header_v8():
    with open('configs/columns.yaml') as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config['header_meta_for_v8_file']


def get_filter_config():
    with open('configs/columns.yaml') as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config['filter_dict']


def get_alias_config():
    with open('configs/columns.yaml') as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config['alias_dict']


def get_header_columns():
    with open('configs/columns.yaml') as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config['header_cols']


def getdbconnection():
    '''Creates db connection.'''
    engine = sa.create_engine(env_config['clickhouse'])
    return engine


def get_common_query():
    with open('queries/common.yaml') as file:
        queries = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return queries


def unpad(data):
    """ doing unpaddling """
    return data[:-(data[-1] if type(data[-1]) == int else ord(data[-1]))]


def bytes_to_key(data, salt, output=48):
    """ creates key_iv """
    assert len(salt) == 8, len(salt)
    data += salt
    key = md5(data).digest()
    final_key = key
    while len(final_key) < output:
        key = md5(key + data).digest()
        final_key += key
    return final_key[:output]


def pad(data):
    bs = 16
    return data + (bs - len(data) % bs) * chr(bs - len(data) % bs)


def encrypt(password, key):
    '''Encrypts password'''
    data = pad(password)
    salt = Random.new().read(8)
    key_iv = bytes_to_key(key, salt, 32+16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return base64.b64encode(b'Salted__' + salt + aes.encrypt(bytes(data, 'utf-8')))


def decrypt(encrypted, passphrase):
    """ decrypting password """
    encrypted = base64.b64decode(encrypted)
    assert encrypted[0:8] == b"Salted__"
    salt = encrypted[8:16]
    key_iv = bytes_to_key(passphrase, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return unpad(aes.decrypt(encrypted[16:]))


# reused variables
env_config = get_env_config()
connection_pool = create_connection_pool()
queries = get_queries()
queries2 = get_queries2()
common_query = get_common_query()
dtypes = {'str': str, 'float': np.float64, 'int': np.int64, 'bool': np.bool}
columns_info = get_columns_info()
columns_info['main_cols'] = {key: dtypes[val]
                             for key, val in columns_info['main_cols'].items()}
columns_info['header_cols'] = {key: dtypes[val]
                               for key, val in columns_info['header_cols'].items()}
