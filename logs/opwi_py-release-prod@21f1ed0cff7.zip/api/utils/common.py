import os
import re
import itertools
import pandas as pd
import zlib
from PIL import Image
from datetime import datetime
import tornado.web
import copy
from api.utils.auth import jwtauth
from api.utils.utils import get_logger, common_query, columns_info, get_columns_info
app_log = get_logger("common")


class DeleteError(Exception):
    def __init__(self, msg):
        self.msg = msg
        super().__init__(self.msg)


def get_rmapid(connection, projectid=None):
    if projectid is None:
        return None
    query = common_query['read_rmap'].format(**{'projectid': projectid})
    app_log.info(f"Rmapid get query: {query}")
    rmapid = execute_query(connection, query, 'one')
    if rmapid:
        app_log.info(f"Reference Mapid  is {rmapid[0]}")
        return rmapid[0]
    else:
        app_log.info("Reference Mapid not set")
        return None

def get_otype_code(data):
    mapping = []
    multi_attribute_mapping = get_columns_info()['Histogram']['attribute_multi_mapping']
    for d in data:
        if mapping:
            mapping.extend(multi_attribute_mapping.get(int(d)))
        else:
            mapping = multi_attribute_mapping.get(int(d))
    return mapping


def prep_multidropdown_query(data, alias=''):
    ''' Prepare query string for multi dropdown 
        columns in multiDropdown payload
        eg: alias => defects.
    '''
    multi_columns = set(data['filters'].get('multiDropdown', []))
    if 'classification' in multi_columns:
        multi_columns.remove('classification')
    query_string = ""
    if multi_columns:
        values = data.get('values')
        query_string = f' and {" and ".join([f"{alias}{m_item} in {tuple(values.get(m_item))}" for m_item in multi_columns if values.get(m_item)])}'
    return query_string


def prep_bar_selection_query(data, alias=''):
    ''' Prepare query string for bar filtration
        eg: alias => defects.
    '''
    if not(data['inputs'].get('histogram', False)):
        bar_filters = data['inputs'].get('paretoselections', {})
    else:
        bar_filters = data['inputs'].get('histogramselections', {})

    query_string = ""
    if bar_filters:
        for i in range(len(bar_filters.get('mapid'))):
            conditions = []
            for m_col, val in bar_filters.items():
                if m_col=='classification':
                    conditions.append(f"{alias}classnumber in {tuple(val[i]['classnumber'])}")
                elif val and m_col!='otype':
                    conditions.append(f"{alias}{m_col} = {str(val)[1:-1].split(',')[i]}")
                else:
                    conditions.append(f"{alias}{m_col} in {get_otype_code([val[i]])}")
            mitems = " and ".join(conditions)
            query_string = query_string + f'({mitems}) or '

        query_string = f' and ({query_string[:-3]})'
    return query_string


def get_commonality_filter(data):
    if data['values'].get('attribute_filters', None):
        return data['values'].get('attribute_filters').get('refcm', None)


def commonality_query(data, commonality_filter, query_data, alias='defects'):
    if commonality_filter:
        print(commonality_filter)
        commonality_mapping = columns_info['commonality_attr_mapping']
        mapids = data['inputs']['selectedMaps'] \
            if len(data['inputs'].get('selectedMaps', '')) > 0 else data['values']['mapid']
        smapid = [i for i in mapids if i != data['inputs']['ref_mapid']]
        value_c = tuple([commonality_mapping[i] for i in commonality_filter])
        query_data['commonality_condition'] = f"  AND cm.refcm in {value_c}"
        query_data['count_condition_commonality'] = query_data['commonality_condition']
        query_data['commonality'] = common_query['commonality'].format(**{
            "alias": alias,
            "projectid": data['projectid'],
            "rmapid": data['inputs']['ref_mapid'],
            "smapid": tuple(smapid + [0]) if len(smapid) > 0 else "(null, 0)"
        })
        commonality_mapping = columns_info['commonality_attr_mapping']
        value_c = tuple([commonality_mapping[i] for i in commonality_filter])
        query_data['count_condition_commonality'] = f" AND cm.refcm in {value_c}"

    else:
        query_data['commonality'] = ""
        query_data['count_condition_commonality'] = ""
        query_data['commonality_condition'] = ""


def prep_classification_query(data, alias=""):
    '''Prepare query string for the classification data
       eg: alias => defects.
    '''
    values = data.get('values')
    classification_data = values.pop('classification', None)
    query_string = ""
    if classification_data:
        class_numbers = []
        for class_item in classification_data:
            class_numbers.extend(class_item.get('classnumber'))
        query_string = f" and {alias}classnumber in {tuple(class_numbers)}"
    return query_string


def prep_attribute_filter_query(data, alias=''):
    ''' Prepare query string for the attribute filter data
        the payload will contains the inputs in list,tuple,dict,string format
        based on the input type the function creating query string
        eg: alias => defects.
    '''
    values = data.get('values')
    attribute_data = values.pop('attribute_filters', None)
    if attribute_data:
        attribute_data.pop('refcm', 'Not Present')
    query_string = ""
    if attribute_data:
        attr_query = []
        for attr in attribute_data:
            if any(isinstance(attribute_data[attr], t) for t in [str, int]):
                attr_query.append(f"{alias}{attr} = {attribute_data[attr]}")
            elif isinstance(attribute_data[attr], list) and (isinstance(attribute_data[attr][0], dict)):
                join_condtn = 'or'
                if not(attribute_data[attr][0].get('include', True)):
                    join_condtn = 'and'

                if attr in ['xindex', 'yindex']:
                    query = f' {join_condtn} '.join(
                        [f"({attr} {' BETWEEN ' if attribute.get('include', True) else ' NOT BETWEEN ' } {attribute.get('min', 0)} and {attribute.get('max', 0)})" for
                         attribute in attribute_data[attr]])
                else:
                    if attr == 'appearances':
                        alias = ''
                        query = f' {join_condtn} '.join(
                            [f"({alias}toString({attr}) {' BETWEEN ' if attribute.get('include', True) else ' NOT BETWEEN ' } '{str(attribute.get('min', '0'))}' and '{str(attribute.get('max', '0'))}')" for
                             attribute in attribute_data[attr]])
                    else:
                        alias = 'defects.' if alias == '' else alias
                        query = f' {join_condtn} '.join(
                            [f"({alias}{attr} {' BETWEEN ' if attribute.get('include', True) else ' NOT BETWEEN ' } {attribute.get('min', 0)} and {attribute.get('max', 0)})" for
                             attribute in attribute_data[attr]])
                attr_query.append(f" ( {query} )")
            elif isinstance(attribute_data[attr], list):
                attr_query.append(
                    f"{alias}{attr} in {tuple(attribute_data[attr])}")

        query_string = f' and {" and ".join(attr_query)}'
    return query_string


def prep_range_query_selectedmaps(data, alias=''):
    range_items = data['filters'].get('range', None)
    range_query_dict = {}

    if 'attribute_filters' in range_items:
        range_items.remove('attribute_filters')
    if 'xsite' in range_items:
        count = 0
        for i, element in enumerate(data['values']['xsite']):
            count += 1
            import copy
            data_c = copy.deepcopy(data)

            data_c['values']['xsite'] = [data['values']['xsite'][i]]
            data_c['values']['ysite'] = [data['values']['ysite'][i]]
            range_query_dict[f"{element['mapid']}_{count}"] = prep_range_query(
                data_c, alias='')

    elif 'fieldrelx' in range_items:
        count = 0
        for i, element in enumerate(data['values']['fieldrelx']):
            count += 1
            import copy
            data_c = copy.deepcopy(data)
            data_c['values']['fieldrelx'] = [data['values']['fieldrelx'][i]]
            data_c['values']['fieldrely'] = [data['values']['fieldrely'][i]]
            range_query_dict[f"{element['mapid']}_{count}"] = prep_range_query(
                data_c, alias='')

    elif 'xrel' in range_items:
        count = 0
        for i, element in enumerate(data['values']['xrel']):
            count += 1
            import copy
            data_c = copy.deepcopy(data)
            data_c['values']['xrel'] = [data['values']['xrel'][i]]
            data_c['values']['yrel'] = [data['values']['yrel'][i]]
            range_query_dict[f"{element['mapid']}_{count}"] = prep_range_query(
                data_c, alias='')

    return range_query_dict


def prep_range_query(data, alias=''):
    ''' 
    Prepare query string for range filter inputs
    '''
    range_items = data['filters'].get('range', None)
    values = data.get('values')
    ''' Removing attribute_filters from the inputs, this not part of main table columns '''
    offset_x = ''
    offset_y = ''
    if data['inputs'].get('waferView') and data['inputs'].get('waferView') != 'multi':
        offset_x = f"+ rtn.offset_x"
        offset_y = f"+ rtn.offset_y"

    if 'attribute_filters' in range_items:
        range_items.remove('attribute_filters')
    query_string = ""
    if range_items:
        range_query_list = []
        for range_item in range_items:
            if isinstance(values[range_item], dict):
                if range_item in ['xsite', 'ysite']:
                    if range_item == 'xsite':
                        range_query_list.append(
                            f" ({alias}{range_item} {offset_x}) {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                    else:
                        range_query_list.append(
                            f" ({alias}{range_item} {offset_y}) {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                elif range_item in ['fieldrelx', 'fieldrely'] and data['inputs'].get('ref_mapid', None):
                    orientation = data['inputs'].get('orientationmarklocation', 'DOWN').lower()
                    fieldx = data['inputs'].get('fieldx', 1)
                    fieldy = data['inputs'].get('fieldy', 1)
                    diepitch_x = data['inputs'].get('diepitch_x', 1)
                    diepitch_y = data['inputs'].get('diepitch_y', 1)
                    if range_item == 'fieldrelx':
                        field_c = f'floor((abs(round(((defects.xsite + rtn.offset_x) - defects.xrel) / rtn.diepitch_x_{orientation}) % {fieldx}) * {diepitch_x}) + xrel)'
                    else:
                        field_c = f'floor((abs(round(((defects.ysite + rtn.offset_y) - defects.yrel) / rtn.diepitch_y_{orientation}) % {fieldy}) * {diepitch_y}) + yrel)'
                    range_query_list.append(
                        f"({field_c}) {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                elif range_item in ['fieldrelx', 'fieldrely']:
                    range_query_list.append(
                        f"{range_item} {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                else:
                    range_query_list.append(
                        f" {alias}{range_item} {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")

        if isinstance(values.get('xindex'), list) and isinstance(values.get('yindex'), list):
            query_4 = " or ".join(
                [f"(xindex {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xindex'][i]['min']} and {values['xindex'][i]['max']} and yindex {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['yindex'][i]['min']} and {values['yindex'][i]['max']})"
                 for i in range(len(values['xindex']))])
            range_query_list.append(f"({query_4})")
        if isinstance(values.get('xsite'), list) and isinstance(values.get('ysite'), list):
            query_1 = " or ".join(
                [f"(({alias}xsite {offset_x}) {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xsite'][i]['min']} and {values['xsite'][i]['max']} and ({alias}ysite {offset_y}) {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['ysite'][i]['min']} and {values['ysite'][i]['max']})"
                 for i in range(len(values['xsite']))])
            range_query_list.append(f"({query_1})")
        if isinstance(values.get('xrel'), list) and isinstance(values.get('yrel'), list):
            query_2 = " or ".join(
                [f"({alias}xrel {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xrel'][i]['min']} and {values['xrel'][i]['max']} and {alias}yrel {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['yrel'][i]['min']} and {values['yrel'][i]['max']})"
                 for i in range(len(values['xrel']))])
            range_query_list.append(f"({query_2})")
        if isinstance(values.get('fieldrelx'), list) and isinstance(values.get('fieldrely'), list):
            query_3 = " or ".join(
                [f"(fieldrelx {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['fieldrelx'][i]['min']} and {values['fieldrelx'][i]['max']} and fieldrely {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['fieldrely'][i]['min']} and {values['fieldrely'][i]['max']})"
                 for i in range(len(values['fieldrelx']))])
            range_query_list.append(f"({query_3})")

        if range_items not in [['xsite', 'ysite'], ['fieldrelx', 'fieldrely'], ['xindex', 'yindex'], ['xrel', 'yrel']]:
            b = []
            for i in range(len(values[range_items[0]])):
                a = []
                for j in range(len(range_items)):
                    if range_items[j] in ['xindex', 'yindex']:
                        al = ''
                    else:
                        al = alias
                    a.append(
                        f"{al}{range_items[j]} {' BETWEEN ' if values[range_items[j]][i].get('include', True) else ' Not BETWEEN ' } {values[range_items[j]][i]['min']} and {values[range_items[j]][i]['max']}"
                    )
                b.append(" and ".join(a))
            query_5 = " or ".join(b)

            range_query_list.append(f"({query_5})")

        query_string = f' and ({" and ".join(range_query_list)})'
    return query_string


def make_query(data, alias=""):
    multi_drop_down_query = ""
    classification_query = ""
    attribute_query = ""
    bar_selection_query = ""
    if data['inputs'].get('histogram', False) or data['inputs'].get('paretoselections', False):
        bar_selection_query = prep_bar_selection_query(data, alias)

    multi_drop_down_query = prep_multidropdown_query(data, alias)
    classification_query = prep_classification_query(data, alias)
    attribute_query = prep_attribute_filter_query(data, alias)
    if data['inputs'].get('singleMapSelection', None):
        query_string = f"{multi_drop_down_query}{classification_query}{attribute_query}{bar_selection_query}"
    else:
        range_query = prep_range_query(data, alias)
        query_string = f"{multi_drop_down_query}{classification_query}{attribute_query}{bar_selection_query}{range_query}"
    return query_string


def update_query(query, orientation):
    ''' Updating columns with orientation '''
    columns = ['xsite_prep0', 'ysite_prep0', 'xsite', 'ysite', 'xsite_prep1', 'ysite_prep1',
               'xsite_prep2', 'xrel', 'yrel', 'xsite_prep_cm', 'ysite_prep_cm']
    for col in columns:
        if col in query:
            query = query.replace(col, f'{col}_{orientation}')
    return query


def get_condition_cols(data):
    condition_columns = []
    for attr in data['values'].get('attribute_filters', {}).keys():
        if attr == 'refcm' or attr == 'appearances':
            continue
        attr = update_query(attr, data['inputs'].get(
            'orientationmarklocation', '').lower())
        condition_columns.append(attr)
    if len(condition_columns) > 0:
        return f"{','.join(condition_columns)},"
    return ''


def get_prep_level(con, data, limit=25000):
    resp = {}
    if not data.get('prep_column'):
        orientation = data['orientation']
        app_log.info(
            "prep_column is empty in payload. Calculating Prep Level")
        resp = {'xsite': f"{data['xsite']}",
                'ysite': f"{data['ysite']}"}
        app_log.info("............Prep Calculation started...............")
        if data.get('isCallSplit'):
            data['count_condition'] = data['query_c']
        defect_count_0_query = common_query['read_defects_count_level0']
        read_defect_count = common_query['read_defects_count']
        if data['count_condition'].find(' and  ( (toString(appearances') >= 0:
            data['count_condition'] = str.split(data['count_condition'], ' and  ( (toString(appearances')[0]
        all_count_query = f'{defect_count_0_query.format(**data)} union all {read_defect_count.format(**data)}'
        app_log.info(all_count_query)
        all_count = execute_query(con, all_count_query)
        count_level0 = all_count[0][0] if all_count is not None else 0
        count_level2 = all_count[1][0] if all_count is not None else 0
        resp['count'] = count_level0
        # cursor.close()
        app_log.info(f"COUNT LEVEL 0: {count_level0}")
        if count_level0 > limit:
            resp['xsite'] = f'xsite_prep2_{orientation}'
            resp['ysite'] = f'ysite_prep2_{orientation}'
            resp['count'] = count_level2
            app_log.info(f"COUNT 2: {count_level2}")
            if count_level2 > limit:
                if data.get('waferView', None) == 'multi' and count_level2 > 25000:
                    resp['xsite'] = f'xsite_prep0_{orientation}'
                    resp['ysite'] = f'ysite_prep0_{orientation}'
                else:
                    resp['xsite'] = f'xsite_prep1_{orientation}'
                    resp['ysite'] = f'ysite_prep1_{orientation}'
                resp['count'] = count_level2
                app_log.info(f"SET PREP LEVEL AS X and Y PREP1_{orientation}")
        app_log.info(f"PREPING VALUES ARE {resp['xsite'], resp['ysite']}")
        app_log.info("............Prep Calculation End...............")
    else:
        app_log.info(
            f"The Prep column already in payload")
        resp = {'xsite': data['prep_column'][0],
                'ysite': data['prep_column'][1]
                }
    return resp


def extract_tif_file(path, dest_path, filename, file_type):
    start_time = datetime.now()
    n_frame = 0
    # extract images files
    if filename.endswith(f".{file_type}"):
        abs_path = os.path.join(path, filename)
        file_title_name = str(filename.replace(f".{file_type}",''))
        im = Image.open(abs_path)
        n_frame = im.n_frames
        index = 0
        for i in range(im.n_frames):
            index = i+1
            im.seek(i)
            if im.mode != 'L':
                im.mode = 'I'
                im.point(lambda i:i*(1./256)).convert('L').save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
            else:
                im.save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
        app_log.info(f'Extracted {index} JPEGs')
    end_time = datetime.now()
    app_log.info(f"Tiff file processing time: {datetime.now() - start_time}")
    return n_frame


def add_map_attachment(connection, filename, ftype='otf', n_frames = 'null'):
    try:
        original_filename = filename
        filename, ext = os.path.splitext(filename)
        if ftype != 'otf':
            filename_list = original_filename.rsplit('_')
            original_filename = "_".join(filename_list[:-1]) + f".csv"
            filename = original_filename.rsplit('_attributes')[0]
           
        rfg_query = common_query['attachment_rfg_query'].format(**{'filename': filename, 'ftype': ftype,'n_frames':n_frames})
        app_log.info(f'rfg_query: {rfg_query}')
        execute_query(connection, rfg_query, '')

        insert_attachment_query = common_query['insert_attachment_query'].format(**{'filename': filename, 'original_filename': original_filename, 'ftype': ftype,'n_frames':n_frames})
        
        app_log.info(f'insert_attachment_query: {insert_attachment_query}')
        execute_query(connection, insert_attachment_query, '')
        app_log.info(f'Successfully added {original_filename} to attachment.')
    except Exception as e:
        app_log.exception(e)
        app_log.error(f'Error while adding file to attachment.')

def populate_hasTiff(connection,filename,file_type="otf"):
    #Condition based on file type
    if file_type == 'klarf':
        condition = f"AND omh.filename = '{filename}'"
    elif file_type == 'otf':
        condition = f"AND omh.tifffilename = '{filename}'"
 
    check_query = common_query['extract_mapid_nframes'].format(**{'condition':condition})
    tiff_data = execute_query(connection,check_query,fetch='all',resptype="df")

    # Populating has tiff based on the mapids and n_frames obtained
    if not tiff_data.empty:
        mapids = tuple(tiff_data['mapid'].to_list())
        n_frames = tiff_data['n_frames'].iloc[0]
        tiff_query = common_query['have_image'].format(**{'n_frames':n_frames, 'mapid':mapids})
        defect_data =  execute_query(connection,tiff_query,fetch="all", resptype="df")

       
def execute_query(connection, query, fetch='all', resptype='', memory=None):
    """ Execute the cursor with provided query and increased memory
    """
    # This is with new execute settings, memory Unit is Bytes
    if not memory:
        memory_executor_settings = {
            0: {'name': '2 GB',
                'memory': '2G'},
            1: {'name': '4 GB',
                'memory': '4G'},
            2: {'name': '10 GB',
                'memory': '10G'},
            3: {'name': '16 GB',
                'memory': '16G'}
        }
    else:
        memory_executor_settings = {
            0: {'name': f'{memory} GB',
                'memory': f'{memory}G'}
        }
    query_fail_flag = 0
    memory_flg = copy.deepcopy(memory)
    cursor = connection.cursor()
    for k, v in memory_executor_settings.items():
        try:
            memory = v['memory']
            cursor.set_settings({'max_memory_usage': memory})
            cursor.execute(query)
            app_log.info(
                f"{'*' * 20}QUERY SUCCESS{'*' * 20}\nMEMORY SETTING: {v['name']}\nQUERY: {query}")
            app_log.info(f"{'*' * 40}")
            break
        except Exception as e:
            query_fail_flag += 1
            is_memory_error = re.search("memory limit", str(e), flags=re.I)
            if is_memory_error is None:
                app_log.exception(
                    f"{'*' * 20}QUERY FAILED{'*' * 20}\nMEMORY SETTING: {v['name']}\nQUERY: {query}\nERROR: {e}")
                app_log.info(f"{'*' * 40}")
                raise RuntimeError(f"Query Execution Failed. Error: {e}")
            app_log.warning(
                f"{'*'*20}QUERY FAILED{'*'*20}\nMEMORY SETTING: {v['name']}\nQUERY: {query}\nERROR: {e}")
            app_log.info(f"{'*' * 40}")
        if k==3 or memory_flg:
            app_log.info(f"exceeded memory space : {query}")
    if query_fail_flag >= 4:
        raise RuntimeError(
            f"Query did not Executed with 10GB limit. Please consider simplifying the query.")
    if fetch == 'all':
        data = cursor.fetchall()
        if resptype == 'df':
            df = pd.DataFrame(data, columns = cursor._columns)
            cursor.close()
            return df
        elif len(data) == 0:
            cursor.close()
            return []
        elif resptype == 'list':
            resp = list(map(lambda row: dict(
                itertools.zip_longest(list(cursor._columns), row)), data))
            cursor.close()
            return resp
        else:
            return data
    else:
        data = cursor.fetchone()
        if resptype=='fetchonelist' and data:
            data = dict(zip(list(cursor._columns), list(data)))
        cursor.close()

        if not data:
            return {}
        return data


class zlib1:
    def zipit(self, resp):
        gzip_compress = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
        content = gzip_compress.compress(str.encode(resp)) + gzip_compress.flush()
        compressed_content_length = len(content)
        return content, compressed_content_length


@jwtauth
class BaseHandler(tornado.web.RequestHandler):

    def __init__(self, *args, logger=None, **kwargs):
        self.logger = logger
        super().__init__(*args, **kwargs)
    
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Credentials", "true")
        self.set_header(
            "Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Authorization, Accept",
        )
        self.set_header(
            "Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS"
        )
        """
        # Below Headers are for compression response. May useful in future.
        self.set_header("X-Consumed-Content-Encoding", "gzip")
        self.set_header("Accept-Encoding", "gzip, compress, deflate")
        """
        self.content_type = "application/json"