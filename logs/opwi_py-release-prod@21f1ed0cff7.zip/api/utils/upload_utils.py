import time
import itertools
import pandas as pd
from datetime import datetime
from tornado.gen import coroutine, Return
from api.utils.utils import queries, connection_pool, get_logger
from api.utils.common import DeleteError, execute_query
app_log = get_logger('upload')


class Upload():

    def __init__(self):
        '''Initialize Upload process.'''
        self.connection = connection_pool.connect()
        self.queries = queries['upload']
        self.cursor = self.connection.cursor()

    def create(self, data):
        '''Create entry on opwi_job_log'''
        data['id'] = datetime.now().timestamp()
        execute_query(self.connection, self.queries['create'].format(**data), '')
       

    def update_job_status(self, data, status_type=None):
        exists_query = f"select count(1) as cnt from opwi_job_log final where file_name = '{data['file_name']}';"
       
        count = execute_query(self.connection, exists_query, 'one')
        
        data['err_message'] = "err_message"
        data['unique_header_id']="unique_header_id"
        if count[0] == 0:
            self.create(data)
        else:
            data.update({'update_condition':""})
            if status_type == 'failure':
                data.update({'update_condition': f", err_message = '{data['error_msg']}'"})
                data['err_message'] = f"'{data['error_msg']}'"
                data['unique_header_id'] = "unique_header_id"
            if status_type == 'picked':
                data.update({'update_condition': f", unique_header_id = '{data.get('unique_header_id', 'NA')}'"})
                data['err_message'] = "err_message"
                data['unique_header_id'] = data.get('unique_header_id', 'NA')

            try:
                exist_job_query = f"select * from opwi_job_log final where file_name = '{data['file_name']}';"
                app_log.info(f"query to get exist job log entry : {exist_job_query}")

                exist_job = execute_query(self.connection, exist_job_query, 'all', 'list')
                app_log.info(f"output of query to get exist job log: {exist_job}")
                if status_type == 'picked':
                    process_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                else:
                    process_start_time = exist_job[0].get("process_start_time")

                process_end_time = datetime.now()
                process_duration_time = process_end_time - exist_job[0].get("process_start_time")
                data.update({
                    "process_duration":process_duration_time.total_seconds(),
                    "process_start_time":process_start_time
                })
            except Exception as e:
                app_log.error(f"Error: **********exist_job_query********{repr(e)}")
                data.update({
                    "process_duration":0
                })
            app_log.info(f"data dict to update status -- > {data}")
            query = self.queries['update_file_status'].format(**data)
            app_log.info(f"Update status query is: {query}")
            execute_query(self.connection, query)

    def __del__(self):
        '''Closing the DB connection'''
        self.connection.close()