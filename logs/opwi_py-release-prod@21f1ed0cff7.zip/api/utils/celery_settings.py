from kombu import Exchange, Queue

default_exchange = Exchange('default', type='direct')
user_exchange = Exchange('Opwi_User_Queue', type='direct')
tool_exchange = Exchange('Opwi_Tool_Queue', type='direct')

BROKER_TRANSPORT_OPTIONS = {
    'priority_steps': list(range(10)),
    'queue_order_strategy': 'priority',
}

BROKER_HEARTBEAT = 10
TASK_QUEUE_MAX_PRIORITY = 10
BROKER_HEARTBEAT_CHECKRATE = 10
BROKER_CONNECTION_RETRY = True
BROKER_CONNECTION_MAX_RETRIES = 0
CELERY_ACKS_LATE = True

CELERY_QUEUES = (
    Queue('default', default_exchange, routing_key='default',
          consumer_arguments={'x-priority': 0}),
    Queue('Opwi_User_Queue', user_exchange, routing_key='Opwi_User_Queue',
          consumer_arguments={'x-priority': 10}),
    Queue('Opwi_Tool_Queue', tool_exchange, routing_key='Opwi_Tool_Queue',
		  consumer_arguments={'x-priority': 10})
)
CELERY_DEFAULT_QUEUE = 'default'
CELERY_DEFAULT_EXCHANGE = 'default'
CELERY_DEFAULT_ROUTING_KEY = 'default'

CELERY_ROUTES = ({
    'app.tasks.UserTask': {
    'queue': 'Opwi_User_Queue',
    'routing_key': 'Opwi_User_Queue'},

    'app.tasks.ToolTask': {
    'queue': 'Opwi_Tool_Queue',
    'routing_key': 'Opwi_Tool_Queue'}
},)
