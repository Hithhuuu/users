import argparse
from sys import argv
from tornado.options import OptionParser, define, Error


class CustomArgsParser(OptionParser):

    # @classmethod
    def parse_command_line(self, args=None, final=True):
        if args is None:
            args = argv
        for i, arg in enumerate(args[1:]):
            if not args[i].startswith("-"):
                    remaining = args[i:]
                    break
            if args[i] == "--":
                remaining = args[i + 1:]
                break
            arg = arg.lstrip('-')
            name, equals, value = arg.partition("=")
            if not name in self._options:
                self.define(name, help="Arbitrary option")
            option = self._options[name]
            if not equals:
                if option.type == bool:
                    value = "true"
                else:
                    raise Error('Option %r requires a value' % name)
            option.parse(value)
        if final:
            self.run_parse_callbacks()
        return remaining


def get_args():
    '''Creates parser.'''
    temp_options = CustomArgsParser()
    temp_options.define("port", default=8000, help="run on the given port", type=int)
    temp_options.define("env", default='dev', help="run on the given port", type=str)
    return temp_options
