import jwt
from functools import wraps

from api.utils.utils import env_config

secret_key = env_config['secret_key']
options = {
    'verify_signature': True,
    'verify_exp': True,
    'verify_nbf': False,
    'verify_iat': True,
    'verify_aud': False
}


def jwtauth(handler_class):
    ''' Handle Tornado JWT Auth '''
    def wrap_execute(handler_execute):
        def require_auth(handler, kwargs):
            message = 'invalid header authorization'
            auth = handler.request.headers.get('Authorization')
            handler._transforms = []
            error_status = 404
            handler.content_type = "application/json"
            method = handler.request.method
            if auth:
                parts = auth.split()

                if (parts[0].lower() != 'bearer' or (len(parts) == 1) or (len(parts) > 2)) and method != 'OPTIONS':
                    handler.set_status(error_status)
                    handler.write({"messge": message})
                    handler.finish()

                token = parts[1]
                try:
                    jwt.decode(token, secret_key, options=options)
                except Exception:
                    handler._transforms = []
                    handler.set_status(401)
                    handler.write('error')
                    handler.finish()
            else:
                handler._transforms = []
                handler.set_status(401)
                handler.write("Missing authorization")
                handler.finish()

            return True

        def _execute(self, transforms, *args, **kwargs):

            if self.request.method == 'OPTIONS':
                return handler_execute(self, transforms, *args, **kwargs)
            try:
                require_auth(self, kwargs)
            except Exception:
                return False

            return handler_execute(self, transforms, *args, **kwargs)

        return _execute

    handler_class._execute = wrap_execute(handler_class._execute)
    return handler_class
