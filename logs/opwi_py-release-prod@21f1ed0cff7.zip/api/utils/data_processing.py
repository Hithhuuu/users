import numpy as np
import pandas as pd
import re
from datetime import datetime
import time
import math
from parsers.csv_parser import csv_parser
from parsers.parser_v7 import parser_v7
from parsers.parser_v8 import parser_v8, check_key_v8
from api.utils.utils import (get_logger, get_env_config, get_dbconnection,
                         get_filter_config, get_alias_config, get_header_columns, columns_info,
                         connection_pool, getdbconnection, queries2)
from api.utils.upload_utils import Upload
from celery import Celery
from celery import states
import os
import math
from tornado.gen import coroutine, Return
from api.utils.common import DeleteError, populate_hasTiff, execute_query, add_map_attachment
from billiard import Pool

env_config = get_env_config()
app_log = get_logger('dataload')
alias_info = get_alias_config()
header_cols = get_header_columns()
default_batch_size = 1000

# -------------------celery config-------------------------#
app = Celery(
    'tasks', broker=env_config['broker'], backend=env_config['backend'])


# -------------------celery config end --------------------#
# Set default variables
DEFAULT_BATCH_SIZE = env_config['DEFAULT_BATCH_SIZE']
MAX_NUM_PROCESSES = env_config['MAX_NUM_PROCESSES']

def start_processes(process_func, iterator, num_chunks, ret_flg=0):
    
    """
    Start processes to process iterator in process functions.

    :param process_func: The process function called for each iterator
    :type process_func: func
    :param iterator: Data iterator
    :type iterator: iter
    :param iterator: The number of chunks to be processed
    :type iterator: int
    """
    # Create the process pool
    if num_chunks > MAX_NUM_PROCESSES:
        num_processes = MAX_NUM_PROCESSES
    else:
        num_processes = num_chunks

    app_log.info(f"Sending {num_chunks} batches to {num_processes} worker processes")
    pdc_pool_object = Pool(num_processes)

    try:
        # Spawn processes to process iterator
        if ret_flg == 0:
            pdc_pool_object.imap(process_func, iterator)
            pdc_pool_object.close()
            pdc_pool_object.join()
        else:
            main_df_split = pd.concat(pdc_pool_object.imap(process_func, iterator))
            pdc_pool_object.close()
            pdc_pool_object.join()
            return main_df_split
        app_log.debug("Multiprocessing workers closed and joined")
    except Exception as err:
        # Terminate the processes if failed
        pdc_pool_object.close()
        pdc_pool_object.join()
        raise RuntimeError(f"Multiprocessing workers terminated: {err}") from err

    app_log.info(f"Total {num_chunks} batches processed and sent")

def load_radial_wip(df, orientation, mapid):
    try:
        conn = getdbconnection()
        if df.loc[f'{orientation}'].wafersize == 300:
            wafer_size = df.loc[f'{orientation}'].wafersize * 10 ** 6
        else:
            wafer_size = df.loc[f'{orientation}'].wafersize

        radius = wafer_size / 2
        diepitch_x = df.loc[f'{orientation}'].diepitch_x
        diepitch_y = df.loc[f'{orientation}'].diepitch_y

        max_xindex = min_xindex = max_yindex = min_yindex = 0

        if radius % diepitch_x:
            max_xindex = math.ceil(radius / diepitch_x) + 2
            min_xindex = math.floor(-radius / diepitch_x) - 2

        if radius % diepitch_y:
            max_yindex = math.ceil(radius / diepitch_y) + 2
            min_yindex = math.floor(-radius / diepitch_y) - 2

        app_log.info(
            f'Min and max range of xindex and yindex {min_xindex} {max_xindex} {min_yindex} {max_yindex}')

        rangex = list(range(min_xindex, max_xindex))
        rangey = list(range(min_yindex, max_yindex))

        combs = []
        for i in rangex:
            for j in rangey:
                combs.append((i, j))

        temp = pd.DataFrame(combs, columns=['xindex', 'yindex'])
        temp['orientation'] = orientation
        temp['mapid'] = mapid
        temp.to_sql('opwi_radial_index', conn, index=False, if_exists='append')
    except Exception as e:
        app_log.info(f"Error message: {e}")


def radiality(mapid):
    '''function to calculate radiality
        accepts mapid as only parameter
    '''
    try:
        # get the diepitch_x and diepitch_y and samplesize based on orientation
        conn = connection_pool.connect()
        query = queries2['upload']['radiality']
        query1 = queries2['upload']['map_rottation']
        query_to_delete = query['delete_radial_index'].format(
            **{'mapid': mapid})
        app_log.info(f"Radial Index delete query: {query_to_delete}")
        execute_query(conn, query_to_delete, '')
        header_df = execute_query(conn, query['select_diepitch'].format(**{'mapid': mapid}), 'all', 'df')

        header_df.set_index('orientation', inplace=True)
        for i in ['up', 'down', 'right', 'left']:
            load_radial_wip(header_df, i, mapid)

        '''Step to calculate the radiality'''
        delete_query_radial_wip = query['delete_radial_wip'].format(
            **{'mapid': mapid})
        app_log.info(f"delete query for radial wip: {delete_query_radial_wip}")
        execute_query(conn, delete_query_radial_wip, '')
        radiality_query = query['insert_radial_wip'].format(**{'mapid': mapid})
        app_log.info(f"Insert query for radial wip: {radiality_query}")
        execute_query(conn, radiality_query, '')

        '''delete and insert radial data into defect main radial wip '''
        delete_query_main_radial = query['delete_defect_main_radial_wip'].format(
            **{'mapid': mapid})
        app_log.info(f"delete query for defect main radial wip: {delete_query_main_radial}")
        # cursor.execute(delete_query_main_radial)
        execute_query(conn, delete_query_main_radial, '')

        defect_main_radial_insert = query['insert_defect_main_radial_wip'].format(
            **{'mapid': mapid, 'select_query': query1['select_query'].format(**{'mapid': mapid})})
        app_log.info(
            f"insert query for defect main radial wip: {defect_main_radial_insert}")
        # cursor.execute(defect_main_radial_insert)
        execute_query(conn, defect_main_radial_insert, '')

        insert_query = query['insert_defect_main'].format(**{'mapid': mapid})
        app_log.info(f"Insert query: {insert_query}")

        execute_query(conn, insert_query, '')

        execute_query(conn, delete_query_main_radial, '')

        execute_query(conn, delete_query_radial_wip, '')

        app_log.info("Inserted Radiality Data")

    except Exception as e:
        app_log.info("Error while doing radiality")
        app_log.info(f"Error message: {e}")
        raise Exception("Error while doing Radiality")


def add_oriented_col(header_df):
    ''' Adding oriented columns in header dataframe '''
    header_df["diepitch_x_up"] = np.select(
        [(header_df.orientationmarklocation == 'RIGHT') | (header_df.orientationmarklocation == 'LEFT')],
        [header_df['diepitch_y']], default=header_df['diepitch_x'])
    header_df["diepitch_y_up"] = np.select(
        [(header_df.orientationmarklocation == 'RIGHT') | (header_df.orientationmarklocation == 'LEFT')],
        [header_df['diepitch_x']], default=header_df['diepitch_y'])

    header_df['scl_x_up'] = np.select(
        [header_df.orientationmarklocation == 'RIGHT', header_df.orientationmarklocation == 'LEFT',
         header_df.orientationmarklocation == 'UP', header_df.orientationmarklocation == 'DOWN'],
        [(header_df['scl_x'] * round(math.cos(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.sin(-90 * math.pi / 180), 0)), (
                     header_df['scl_x'] * round(math.cos(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
                 math.sin(90 * math.pi / 180), 0)), header_df['scl_x'],
         (header_df['scl_x'] * round(math.cos(math.pi), 0) + header_df['scl_y'] * round(math.sin(math.pi), 0))],
        default=header_df['scl_x'])

    header_df['scl_y_up'] = np.select(
        [header_df.orientationmarklocation == 'RIGHT', header_df.orientationmarklocation == 'LEFT',
         header_df.orientationmarklocation == 'UP', header_df.orientationmarklocation == 'DOWN'],
        [-header_df['scl_x'] * round(math.sin(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.cos(-90 * math.pi / 180), 0),
         -header_df['scl_x'] * round(math.sin(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
             math.cos(90 * math.pi / 180), 0), header_df['scl_y'],
         -header_df['scl_x'] * round(math.sin(math.pi), 0) + header_df['scl_y'] * round(math.cos(math.pi), 0)],
        default=header_df['scl_y'])

    header_df["diepitch_x_down"] = np.select(
        [(header_df.orientationmarklocation == 'RIGHT') | (header_df.orientationmarklocation == 'LEFT')],
        [header_df['diepitch_y']], default=header_df['diepitch_x'])
    header_df["diepitch_y_down"] = np.select(
        [(header_df.orientationmarklocation == 'RIGHT') | (header_df.orientationmarklocation == 'LEFT')],
        [header_df['diepitch_x']], default=header_df['diepitch_y'])

    header_df['scl_x_down'] = np.select(
        [header_df.orientationmarklocation == 'LEFT', header_df.orientationmarklocation == 'RIGHT',
         header_df.orientationmarklocation == 'DOWN', header_df.orientationmarklocation == 'UP'],
        [(header_df['scl_x'] * round(math.cos(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.sin(-90 * math.pi / 180), 0)), (
                     header_df['scl_x'] * round(math.cos(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
                 math.sin(90 * math.pi / 180), 0)),
         header_df['scl_x'],
         (header_df['scl_x'] * round(math.cos(math.pi), 0) + header_df['scl_y'] * round(math.sin(math.pi), 0))],
        default=header_df['scl_x'])

    header_df['scl_y_down'] = np.select(
        [header_df.orientationmarklocation == 'LEFT', header_df.orientationmarklocation == 'RIGHT',
         header_df.orientationmarklocation == 'DOWN', header_df.orientationmarklocation == 'UP'],
        [-header_df['scl_x'] * round(math.sin(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.cos(-90 * math.pi / 180), 0),
         -header_df['scl_x'] * round(math.sin(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
             math.cos(90 * math.pi / 180), 0), header_df['scl_y'],
         -header_df['scl_x'] * round(math.sin(math.pi), 0) + header_df['scl_y'] * round(math.cos(math.pi), 0)],
        default=header_df['scl_y'])

    header_df["diepitch_x_left"] = np.select(
        [(header_df.orientationmarklocation == 'UP') | (header_df.orientationmarklocation == 'DOWN')],
        [header_df['diepitch_y']], default=header_df['diepitch_x'])
    header_df["diepitch_y_left"] = np.select(
        [(header_df.orientationmarklocation == 'UP') | (header_df.orientationmarklocation == 'DOWN')],
        [header_df['diepitch_x']], default=header_df['diepitch_y'])

    header_df['scl_x_left'] = np.select(
        [header_df.orientationmarklocation == 'UP', header_df.orientationmarklocation == 'DOWN',
         header_df.orientationmarklocation == 'LEFT', header_df.orientationmarklocation == 'RIGHT'],
        [(header_df['scl_x'] * round(math.cos(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.sin(-90 * math.pi / 180), 0)), (
                     header_df['scl_x'] * round(math.cos(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
                 math.sin(90 * math.pi / 180), 0)),
         header_df['scl_x'],
         (header_df['scl_x'] * round(math.cos(math.pi), 0) + header_df['scl_y'] * round(math.sin(math.pi), 0))],
        default=header_df['scl_x'])

    header_df['scl_y_left'] = np.select(
        [header_df.orientationmarklocation == 'UP', header_df.orientationmarklocation == 'DOWN',
         header_df.orientationmarklocation == 'LEFT', header_df.orientationmarklocation == 'RIGHT'],
        [-header_df['scl_x'] * round(math.sin(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.cos(-90 * math.pi / 180), 0),
         -header_df['scl_x'] * round(math.sin(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
             math.cos(90 * math.pi / 180), 0),
         header_df['scl_y'],
         -header_df['scl_x'] * round(math.sin(math.pi), 0) + header_df['scl_y'] * round(math.cos(math.pi), 0)],
        default=header_df['scl_y'])

    header_df["diepitch_x_right"] = np.select(
        [(header_df.orientationmarklocation == 'UP') | (header_df.orientationmarklocation == 'DOWN')],
        [header_df['diepitch_y']], default=header_df['diepitch_x'])
    header_df["diepitch_y_right"] = np.select(
        [(header_df.orientationmarklocation == 'UP') | (header_df.orientationmarklocation == 'DOWN')],
        [header_df['diepitch_x']], default=header_df['diepitch_y'])

    header_df['scl_x_right'] = np.select(
        [header_df.orientationmarklocation == 'DOWN', header_df.orientationmarklocation == 'UP',
         header_df.orientationmarklocation == 'RIGHT', header_df.orientationmarklocation == 'LEFT'],
        [(header_df['scl_x'] * round(math.cos(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.sin(-90 * math.pi / 180), 0)), (
                     header_df['scl_x'] * round(math.cos(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
                 math.sin(90 * math.pi / 180), 0)), header_df['scl_x'],
         (header_df['scl_x'] * round(math.cos(math.pi), 0) + header_df['scl_y'] * round(math.sin(math.pi), 0))],
        default=header_df['scl_x'])
    header_df['scl_y_right'] = np.select(
        [header_df.orientationmarklocation == 'DOWN', header_df.orientationmarklocation == 'UP',
         header_df.orientationmarklocation == 'RIGHT', header_df.orientationmarklocation == 'LEFT'],
        [-header_df['scl_x'] * round(math.sin(-90 * math.pi / 180), 0) + header_df['scl_y'] * round(
            math.cos(-90 * math.pi / 180), 0),
         -header_df['scl_x'] * round(math.sin(90 * math.pi / 180), 0) + header_df['scl_y'] * round(
             math.cos(90 * math.pi / 180), 0),
         header_df['scl_y'],
         -header_df['scl_x'] * round(math.sin(math.pi), 0) + header_df['scl_y'] * round(math.cos(math.pi), 0)],
        default=header_df['scl_y'])

    return header_df


def process_header_df(head_df):
    head_df.columns = head_df.columns.str.lower()
    head_df[['diepitch_x', 'diepitch_y']
            ] = head_df['diepitch'].str.split(',', expand=True)
    head_df[['dieorigin_x', 'dieorigin_y']
            ] = head_df['dieorigin'].str.split(',', expand=True)
    head_df[['scl_x', 'scl_y']] = head_df['samplecenterlocation'].str.split(
        ',', expand=True)
    head_df = head_df.drop(
        ['diepitch', 'dieorigin', 'samplecenterlocation'], axis=1)
    head_df = head_df.rename(columns=alias_info)
    diff_cols = set(columns_info['header_cols'].keys()
                    ).difference(head_df.columns)
    for col in diff_cols:
        if columns_info['header_cols'][col] == np.int64:
            head_df[col] = -999999999
        else:
            head_df[col] = pd.Series(dtype=columns_info['header_cols'][col])
    head_df = head_df.astype(columns_info['header_cols'])

    if not head_df.at[0, 'orientationmarklocation'] in ['TOP', 'RIGHT', 'DOWN', 'LEFT']:
        head_df['orientationmarklocation'] = head_df.at[0,
                                                        'orientationmarklocation'].split('.')[0]
    head_df['orientationmarklocation'] = head_df['orientationmarklocation'].replace(
        columns_info['orientation_data'])

    if head_df.at[0, 'tifffilename'].lower().endswith(('tiff', 'tif', 'i01')):
        tiff_file_name_split, ext = os.path.splitext(head_df.at[0, 'tifffilename'])
        tiff_file_name_split = re.sub(r'[^a-zA-Z0-9]', '_', tiff_file_name_split)
        head_df['tifffilename'] = f"{tiff_file_name_split}{ext}"

    return head_df


def generate_random_number(size, np_type):
    imin = np.iinfo(np_type).min
    imax = np.iinfo(np_type).max
    return np.random.randint(imin, imax, size=size, dtype=np_type)


def gen_mapid():
    ''' genrate new mapid '''
    conn = connection_pool.connect()
    query = "select toInt32(rand32())"
    app_log.info(f"Query for mapid : {query}")
    is_new = False
    while not is_new:
        data = execute_query(conn, query, 'one')
        check_query = f" select count(1) from opwi_map_header final where rfg=1 and mapid = {data[0]}"
        count = execute_query(conn, check_query, 'one')
        if count[0] == 0:
            is_new = True
    return data[0]


def process_main_df(main_df, header_df):
    main_df.columns = [col.lower() for col in main_df.columns]
    main_df = main_df.apply(pd.to_numeric, errors='ignore')

    main_df['xsite'] = (header_df['diepitch_x'][0].astype(np.float64) * main_df['xindex'].astype(np.int32) +
                        main_df['xrel'].astype(np.float64))

    main_df['ysite'] = (header_df['diepitch_y'][0].astype(np.float64) * main_df['yindex'].astype(np.int32) +
                        main_df['yrel'].astype(np.float64))
    
    main_df.loc[main_df['xsite'] < 0, 'xsite_prep0'] = (main_df.loc[main_df['xsite'] < 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] < 0, 'xsite'].abs().mod(3000000)) * -1
    main_df.loc[main_df['xsite'] >= 0, 'xsite_prep0'] = (main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs().mod(3000000))
    main_df.loc[main_df['ysite'] < 0, 'ysite_prep0'] = (main_df.loc[main_df['ysite'] < 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] < 0, 'ysite'].abs().mod(3000000)) * -1
    main_df.loc[main_df['ysite'] >= 0, 'ysite_prep0'] = (main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs().mod(3000000))

    # Prepareing xsite, ysite prep1 data
    main_df.loc[main_df['xsite'] < 0, 'xsite_prep1'] = (main_df.loc[main_df['xsite'] < 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] < 0, 'xsite'].abs().mod(2000000)) * -1
    main_df.loc[main_df['xsite'] >= 0, 'xsite_prep1'] = (main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs().mod(2000000))

    main_df.loc[main_df['ysite'] < 0, 'ysite_prep1'] = (main_df.loc[main_df['ysite'] < 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] < 0, 'ysite'].abs().mod(2000000)) * -1
    main_df.loc[main_df['ysite'] >= 0, 'ysite_prep1'] = (main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs().mod(2000000))

    # Prepareing xsite, ysite prep2 data
    main_df.loc[main_df['xsite'] < 0, 'xsite_prep2'] = (main_df.loc[main_df['xsite'] < 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] < 0, 'xsite'].abs().mod(15000)) * -1
    main_df.loc[main_df['xsite'] >= 0, 'xsite_prep2'] = (main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs().mod(15000))

    main_df.loc[main_df['ysite'] < 0, 'ysite_prep2'] = (main_df.loc[main_df['ysite'] < 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] < 0, 'ysite'].abs().mod(15000)) * -1
    main_df.loc[main_df['ysite'] >= 0, 'ysite_prep2'] = (main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs().mod(15000))

    # Prepareing xsite, ysite prep_cm data
    main_df.loc[main_df['xsite'] < 0, 'xsite_prep_cm'] = (main_df.loc[main_df['xsite'] < 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] < 0, 'xsite'].abs().mod(150000)) * -1
    main_df.loc[main_df['xsite'] >= 0, 'xsite_prep_cm'] = (main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs(
    ) - main_df.loc[main_df['xsite'] >= 0, 'xsite'].abs().mod(150000))

    main_df.loc[main_df['ysite'] < 0, 'ysite_prep_cm'] = (main_df.loc[main_df['ysite'] < 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] < 0, 'ysite'].abs().mod(150000)) * -1
    main_df.loc[main_df['ysite'] >= 0, 'ysite_prep_cm'] = (main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs(
    ) - main_df.loc[main_df['ysite'] >= 0, 'ysite'].abs().mod(150000))
    main_df['dm_id'] = -1
    main_df.rename(columns_info['alias_dict'], inplace=True)
    for i in main_df.columns:
        if i in columns_info['main_cols'].keys():
            if columns_info['main_cols'][i] in [np.int64,np.float64]:
                main_df[i] = pd.to_numeric(main_df[i], errors='coerce')
            else:
                main_df[i] = main_df[i].astype(columns_info['main_cols'][i])
    app_log.info(main_df['dm_id'].head())
    diff_cols = set(columns_info['main_cols'].keys()
                    ).difference(main_df.columns)
    diff_cols.remove('mapid')
    for col in diff_cols:
        if columns_info['main_cols'][col] == np.int64:
            main_df[col] = np.nan
        else:
            main_df[col] = pd.Series(dtype=columns_info['main_cols'][col])
    return main_df, diff_cols


def get_defect_count(mapid):
    ''' Check header defectcnt is equal total cnt from opwi_defect_main '''
    main_query = f"select count(1) from opwi_defect_main_wip final where mapid={mapid}"
    con = connection_pool.connect()
    count = execute_query(con, main_query, 'one')
    app_log.info(f"{'*' * 100} {main_query}")
    app_log.info(f"{'*' * 100} {mapid} {count}")
    if count:
        count = count[0]
    else:
        count = 0
    return {'main_table': count}


def delete_data(mapid):
    lst = ['opwi_defect_main', 'opwi_defect_main_wip', 'opwi_map_header', 'opwi_map_class',
           'opwi_export_metadata', 'opwi_radial_wip', 'opwi_defect_main_radial_wip']
    app_log.info(f"START: Deleting data for : {mapid}")
    con = connection_pool.connect()
    for table in lst:
        ''' deleting map data from tables '''
        query = f"ALTER TABLE {table} DELETE where mapid ={mapid};"
        app_log.info(f"Query for {table} delete is: {query}")
        execute_query(con, query, '')
    app_log.info(f"END: Deleting data for: {mapid}")


def merge_df(df, lst):
    ''' Merge the main data of klarf and Scan set of corrosponding csv '''
    df_list = []
    for i in lst:
        diff_cols = list(set(df.columns).difference(i.columns))
        diff_cols.append('defectid')
        df_list.append(pd.merge(df[diff_cols], i, on='defectid', how='inner'))
    return df_list

def push_main_data(df_to_push):	
    con = getdbconnection()	
    df_to_push = df_to_push.append(pd.Series(dtype=object), ignore_index=True)	
    df_to_push.to_sql('opwi_defect_main_wip', con,	
                          if_exists='append', index=False)


def match_data(con, orientation, mapid):
    query = f"SELECT m.mapid, m.diepitch_x, m.diepitch_y, m.diepitch_x_{orientation}, m.diepitch_y_{orientation} FROM raw.opwi_map_header m final where m.rfg=1 and m.mapid = {mapid}"
    app_log.info(f"Data Match Query: {query}")
    for _ in range(30):
        data = execute_query(con, query, 'all')
        
        if len(data) > 0:
            diepitch_x = data[0][1]
            diepitch_y = data[0][2]
            diepitch_x_o = data[0][3]
            diepitch_y_o = data[0][4]
            app_log.info(f"Diepitch_x: {diepitch_x}, Diepitch_y: {diepitch_y}, Diepitch_x_{orientation}: {diepitch_x_o},"
                        f"Diepitch_y_{orientation}: {diepitch_y_o}")
            if diepitch_x == diepitch_x_o and diepitch_y == diepitch_y_o:
                break
        time.sleep(1)


def push_data(main_df, header_df=None, class_df=None, mapid=None, ext=None, diff_cols=None, export_df=None):
    '''Uploads the Data to DB.'''
    try:
        
        con = getdbconnection()
        main_df = main_df[columns_info['main_cols'].keys()]
        app_log.info(f"Loading Data into Header Table now. {header_df.loc[0, 'mapname']}")
        ''' Inserting Header Data to opwi_map_header '''
        if isinstance(header_df, pd.DataFrame):
            header_df.to_sql('opwi_map_header', con, if_exists='append',
                            index=False)
        app_log.info(f"Loading Data into Main Table now.")

        ''' Processing to Inserting main_df into opwi_defect_main_wip(temp_table)'''
        ''' We will delete the mapid after the data inserted into opwi_defect_main table '''
        # Insert Data into opwi_defect_main_wip
        splits = round(1 if main_df.shape[0] < int(
            default_batch_size) else main_df.shape[0] / int(default_batch_size))
        app_log.info(f"The Main DF is splited into : {splits} batch")
        for record in np.array_split(main_df, splits):
            record = record.append(pd.Series(), ignore_index=True)
            record.to_sql('opwi_defect_main_wip', con,
                          if_exists='append', index=False)
        app_log.info(f"END push data into main table.")

        if ext != '.csv':
            export_df.columns = export_df.columns.str.lower()
            export_df = export_df.append(pd.Series(), ignore_index=True)
            app_log.info(f"Loading Data into export Table now.")
            export_df.to_sql('opwi_export_metadata', con, if_exists='append',
                         index=False)
            app_log.info(f"END push data into export table.")

        ''' Insert classnumber, classnames for the mapid to the opwi_map_class'''
        # Insert Data into opwi_map_class
        if isinstance(class_df, pd.DataFrame):
            class_df.columns = class_df.columns.str.lower()
            class_df.to_sql('opwi_map_class', con, if_exists='append',
                            index=False, chunksize=20000)

        # Update Header table
        conn = connection_pool.connect()
       
        app_log.info(
            f"Updating Header table is completed: Begin rotation insertion")

        ''' Get the data from the opwi_defect_main_wip and insert into opwi_defect_main '''
        # Start the radiality process
        app_log.info("Starting the Radiality process")
        radiality(mapid)
        app_log.info("Completed the Radiality process")
        # end radiality process

        # Update Search id
        app_log.info(
            f"Inserting rottation data is completed Begin Update Search id")
        '''
        app_log.info(f"START: Update Search ID")
        cursor = conn.cursor()
        search_id_update_query = queries['upload']['update_search_id']
        app_log.info(f"Srch_id column update query: {search_id_update_query}")
        cursor.execute(search_id_update_query)
        cursor.close()
        app_log.info(f"END: Updated Search id is completed")
        '''
        app_log.info('Pushing Data Completed.')

        # Checking the defectcount
        defect_count = get_defect_count(mapid)
        app_log.info(f"DEFECT COUNT: {defect_count}, {mapid}")
        app_log.info(f"dataframes defect count, main_df: {main_df.shape[0]}, header_df: {header_df['defectcnt']}")
        app_log.info(f'shape of dataframes : {main_df.shape}, {header_df.shape}')

        ''' The rotation data processed and delete the data from the opwi_defect_main_wip '''
        # Delete map from opwi_defect_main_wip table
        app_log.info(f'Deleting {mapid} from opwi_defect_main_wip STARTED')
        trunc_query = f"alter table opwi_defect_main_wip delete where  mapid={mapid};"
        app_log.info(f"opwi_defect_main_wip delete query: {trunc_query}")
    
        execute_query(conn, trunc_query, '')
        app_log.info('Deleting {mapid} from opwi_defect_main_wip END')
        app_log.info('Open connections has been closed.')
    except Exception as e:
        import traceback
        app_log.error(e)
        app_log.error(f"File Upload Error: {traceback.format_exc()}")
        raise Exception("File Upload error in while pushing data in WIP table")

def file_removal_function(file_path):
    """
    Trying to delete a file from Staging area.
    :param file_path: Absolute file path.
    :return:
    """
    try:
        """remove a file after successful completion/execution"""
        app_log.info(f"trying to delete file from {file_path}")
        os.remove(file_path)
        app_log.info("Deleted file from execution folder after processing.")
    except Exception as e:
        app_log.error("Error, while trying to delete the file from the execution location {0}".format(repr(e)))


def get_filename(filename_string):
    '''
    Get the filename from filename string
    filename_string: 2707_ADC_1602651722411.001
    output: 2707_ADC
    '''
    filename, ext = os.path.splitext(filename_string)
    filename_list = filename.rsplit('_')
    filename = "_".join(filename_list[:-1])
    return filename, ext


def process_csv(file_path, klarf_filename, username, mapid_lst, filesize, filename, map_filename):
    '''Process csv and returns df list for scansets'''
    conn = connection_pool.connect()
    query = f"select mapid from opwi_map_header final where rfg=1 and cby = '{username}' and filename like'%{klarf_filename}%' and  filename like'%.00%' limit 1"
    app_log.info(f"Query : {query}")
    klarf_header_df = execute_query(conn, query, 'all', 'df')
    datetime_format = '%Y-%m-%d %H:%M-%S'

    if klarf_header_df.shape[0] == 0:
        raise Return("Klarf file is missing")
    else:
        parent_mapid = klarf_header_df.iloc[0]['mapid']
        scansets_list = csv_parser(file_path, parent_mapid)


        query = f"select * from opwi_defect_main final where mapid={parent_mapid}"
        klarf_df = execute_query(conn, query, 'all', 'df')
        app_log.info(f'mapid_lst: {mapid_lst}')
        for index, scanset in enumerate(scansets_list):
            app_log.info(f'scanset: {index} and {scanset.shape[0]}')

        for index, scanset in enumerate(scansets_list):
            '''
            1. generate new mapid
            2. Insert class data in opwi_map_class
            3. insert export data in opwi_export_metadata
            4. insert header data in opwi_map_header
            '''

            if not isinstance(mapid_lst, list):
                mapid = gen_mapid()
                app_log.info(f"mapid not exists creating new: {mapid}")
            else:
                mapid = mapid_lst[index]

            class_insert_query = f"Insert into opwi_map_class select {mapid}, classnumber, classname, 1 as rfg from opwi_map_class final where mapid = {parent_mapid}"
            app_log.info(f'Inserting into class table : {class_insert_query}')
            execute_query(conn, class_insert_query, '')

            export_insert_query = f"Insert into opwi_export_metadata select fileversion, prefixdata, suffixdata, columnsname, filename, {mapid}  \
                from opwi_export_metadata where mapid = {parent_mapid}"
            app_log.info(f'Inserting into export table : {export_insert_query}')
            execute_query(conn, export_insert_query, '')

            header_df = execute_query(conn, f'select * from opwi_map_header FINAL where rfg=1 and mapid={parent_mapid}', 'all', 'df')
            if not isinstance(mapid_lst, list):
                header_df['cdt'] = pd.to_datetime(str(datetime.now()))
                header_df['mapalias'] = None
            else:
                # Fetching cdt and mapalis
                extra_header_df = execute_query(conn, f'select cdt, mapalias from opwi_map_header FINAL where rfg=1 and mapid={mapid}', 'all', 'df')
                header_df['cdt'] = extra_header_df['cdt']
                header_df['mapalias'] = extra_header_df['mapalias']
            header_df['cby'] = username
            header_df['filesize'] = filesize
            header_df['filename'] = filename
            header_df['cdt'] = header_df['cdt'].dt.strftime(datetime_format)
            header_df['filetimestamp'] = pd.to_datetime(header_df['filetimestamp'])
            header_df['filetimestamp'] = header_df['filetimestamp'].dt.strftime(datetime_format)
            header_df['resulttimestamp'] = pd.to_datetime(header_df['resulttimestamp'])
            header_df['resulttimestamp'] = header_df['resulttimestamp'].dt.strftime(datetime_format)
            header_df['mapid'] = mapid
            header_df['parent'] = parent_mapid

            header_df = header_df.append(pd.Series(), ignore_index=True)

            mapelements = map(str, [username, header_df['product'][0], header_df['layer'][0],
                                    header_df['carrierid'][0], map_filename.rsplit('_',1)[0]+f'_ss{index + 1}',
                                    header_df['resulttimestamp'][0]])
            mapname = '|'.join(mapelements)
            app_log.info(f"Processing Data processing with mapname: {mapname}")

            header_df['mapid'] = mapid
            header_df['mapname'] = mapname
            header_df['ss_flag'] = 0
            header_df['parent'] = parent_mapid
            scanset['mapid'] = mapid
            scanset['resulttimestamp'] = header_df['resulttimestamp']
            scanset = scanset.merge(klarf_df, on='defectid', how='inner', suffixes=('', '_righttable'))
            null_cols = [ col for col in scanset.columns[~scanset.isnull().any()].tolist() 
                                if not col.endswith('_righttable')]
            header_df['null_cols'] = ",".join(null_cols)
            header_df['defectcnt'] = scanset.shape[0]
            push_data(scanset, header_df, class_df=None, mapid=mapid, ext='.csv')
        app_log.info(f"Queries2 keys after psuh_data: {queries2['upload'].keys()}")
        query = queries2['upload']['update_header_ssflag'].format(**{'parent_mapid': parent_mapid})
        execute_query(conn, query, '')
        app_log.info(f"Adding {filename} to attachment.")
        add_map_attachment(conn, filename, ftype='csv')


@app.task(bind=True)
def dataload(self, file_path, username, timestamp, filesize, filename, unique_id, mapid=None):
    app_log.info(f"Processing Data processing with mapid: {unique_id}")
    map_filename, ext = get_filename(filename)
    job_file_name = f"{map_filename}{ext}"
    try:
        mapid_lst = mapid
        temp_filename = map_filename.replace("_attributes", "").split(".")[0]
        app_log.info(f"*******************Processing filename *****************: {job_file_name}")
        upload_data = {
            'tool_name': "NA", 'file_name': job_file_name,
            'job_status': "picked", 'file_path': file_path,
            'unique_header_id': unique_id
        }
        if not isinstance(unique_id, list):
            upload_data.update({'unique_id': unique_id})
            if username == 'pvadmin':
                upload_service = Upload()
                app_log.info('Executing query to update SQL with status picked as username is pvadmin.')
                upload_service.update_job_status(upload_data, status_type='picked')
                app_log.info("Entry has been created successfully in DB username: pvadmin")
            else:
                upload_service = Upload()
                app_log.info( f'Upload Handler start processing for UI file upload with username: {username}')
                upload_service.create(upload_data)
                app_log.info("Entry has been created successfully in DB")

        else:
            for unique_id in unique_id:
                upload_data.update({'unique_id': unique_id})
                if username == 'pvadmin':
                    upload_service = Upload()
                    app_log.info(
                        'Executing query to update SQL with status picked as username is pvadmin.')
                    upload_service.update_job_status(upload_data, status_type='picked')
                    app_log.info(
                        "Entry has been created sucessfully in DB username: pvadmin")
                else:
                    upload_service = Upload()
                    app_log.info(
                        f'Upload Handler start processing for UI file upload with username: {username}')
                    app_log.info(
                        "Db connection has been created successfully for Opwi.")
                    upload_service.create(upload_data)
                    app_log.info("Entry has been created sucessfully in DB")

        app_log.info(f"Processing of file {file_path.split('/')[-1]} started.")
        if ext == '.csv':
            '''Process csv'''
            process_csv(file_path, temp_filename, username, mapid_lst, filesize, filename, map_filename)
        else:
            app_log.info(f"Checking version of file..")
            with open(file_path, 'r') as f:
                first_statement = f.readline()

            if '1.8' in first_statement:
                app_log.info("Processing file for 1.8 version")
                main_df, header_df, class_df, export_dict = parser_v8(file_path)

            elif '1 7' in first_statement or '1 1' in first_statement or '1 2' in first_statement:
                app_log.info("Processing file for 1.7 version")
                main_df, header_df, class_df, export_dict = parser_v7(file_path)

            '''Processing parsed klarf file and upload the data into the db '''
            app_log.info('Creating header.')
            header_df['defectcnt'] = main_df.shape[0]
            header_df['filename'] = filename
            export_dict["filename"] = map_filename+ext
            header_df['filesize'] = filesize
            header_df['cby'] = username
            # added tifffilename as a column
            # header_df['tifffilename'] = 'NA'  # Change this accordingly.
            header_df['cdt'] = str(datetime.now())
            header_df['tool'] = 'NA'
            final_header_df = process_header_df(header_df)

            datetime_format = '%Y-%m-%d %H:%M-%S'
            final_header_df['cdt'] = pd.to_datetime(header_df['cdt'])
            final_header_df['filetimestamp'] = pd.to_datetime(
                final_header_df['filetimestamp'])
            final_header_df['filetimestamp'] = final_header_df['filetimestamp'].dt.strftime(
                datetime_format)
            final_header_df['resulttimestamp'] = pd.to_datetime(
                final_header_df['resulttimestamp'])
            final_header_df['resulttimestamp'] = final_header_df['resulttimestamp'].dt.strftime(
                datetime_format)
            final_header_df['cdt'] = final_header_df['cdt'].dt.strftime(
                datetime_format)

            final_header_df = final_header_df.append(
                pd.Series(), ignore_index=True)

            app_log.info('Processing main DF.')
            final_main_df, diff_cols = process_main_df(main_df, final_header_df)
            mapelements = map(str, [username, final_header_df['product'][0], final_header_df['layer'][0],
                                    final_header_df['carrierid'][0], map_filename, final_header_df['resulttimestamp'][0]])
            mapname = '|'.join(mapelements)
            app_log.info(f"Processing Data processing with mapname: {mapname}")

            if not mapid:
                mapid = gen_mapid()
                app_log.info(f"mapid not exists creating new: {mapid}")
            app_log.info(f"mapid: {mapid}")
            final_header_df['mapid'] = mapid
            final_header_df['mapname'] = mapname
            final_main_df['mapid'] = mapid
            final_main_df['resulttimestamp'] = final_header_df['resulttimestamp']
            final_header_df['ss_flag'] = 0
            final_header_df['null_cols'] = ",".join(main_df.columns)
            final_header_df['parent'] = 'NA'
            # Fetching existing mapalias
            conn = connection_pool.connect()
            map_alias = execute_query(conn, f'SELECT mapalias FROM opwi_map_header FINAL WHERE mapid = {mapid}', '')
            final_header_df['mapalias'] = map_alias[0] if len(map_alias) else None

            class_df['mapid'] = mapid
            export_dict["mapid"] = mapid
            class_df.columns = class_df.columns.str.lower()
            class_main_df = final_main_df[['mapid', 'classnumber']]
            class_main_df = class_main_df.drop_duplicates()
            class_main_df.columns = class_main_df.columns.str.lower()
            class_main_df['classnumber'] = class_main_df['classnumber'].astype(str)
            class_main_df = class_main_df.merge(
                class_df, on=['classnumber', 'mapid'], how='left')
            class_main_df['classname'] = class_main_df['classname'].fillna(
                class_main_df['classnumber'])
            class_df = class_main_df.drop_duplicates(subset='classnumber')

            # Adding default class to class_df
            # Default Classes: Unclassified (0), True (1), False (2), unknown (3), Nuisance (4)
            default_class = {
                "0": "Unclassified",
                "1": "True",
                "2": "False",
                "3": "Unknown",
                "4": "Nuisance"
            }

            for cnum, cname in default_class.items():
                if cnum not in class_df['classnumber'].values:
                    class_df = class_df.append({
                        'mapid': mapid,
                        'classnumber': cnum,
                        'classname': cname
                    }, ignore_index = True)

            class_df = class_df.append(pd.Series(), ignore_index=True)
            export_df = pd.DataFrame.from_records([export_dict])
            app_log.info("Creating the map ID.")
            final_header_df = add_oriented_col(final_header_df)
            app_log.info(f'Preparing to push data into clickhouse DataBase. {unique_id}')
            # #===========================================================#  
            push_data(final_main_df, final_header_df,
                        class_df, mapid, ext, diff_cols, export_df)
            app_log.info('Map data updated successfully')
            populate_hasTiff(connection=conn,filename=header_df['filename'][0],file_type="klarf")
        try:
            '''Update the status for file parsing: success/failed'''
            upload_service = Upload()
            app_log.info(
                "Db connection has been created successfully for Opwi.")
            upload_service.update_job_status(data={'job_status': 'successful', 'file_name': job_file_name}, status_type='successful')
            app_log.info("Successfully saved the data")
            resp_json = {'status': 'success', 'msg': 'upload for {0} completed'.format(job_file_name)}
            app_log.info(f"Returned JSON response is: {resp_json}")
            return

        except Exception as e:
            msg = "Upload is completed but something went wrong"
            app_log.info(f"msg: {repr(e)}")
            import traceback
            app_log.info(traceback.format_exc())
            upload_service = Upload()
            upload_service.update_job_status(data={'job_status': 'failure','file_name': job_file_name, 'error_msg': msg}, status_type='failure')
    except Exception as e:
        if str(e) == "Invalid File Format":
            msg = str(e)
        else:
            msg = "Something went wrong inside dataload"
        app_log.info(msg)
        upload_service = Upload()
        import traceback
        app_log.info(traceback.format_exc())
        app_log.info('This is in except block for dataload.')
        upload_service.update_job_status(data={'job_status': 'failure', 'file_name': job_file_name, 'error_msg': e}, status_type='failure')
    finally:
        """ Removing file from upload folder """
        app_log.info(f"File upload process has been executed successfully: {filename}")


@coroutine
def verify_mapname(file_path, username, filename):
    connection = connection_pool.connect()
    filename, ext = get_filename(filename)

    if ext != '.csv':
        with open(file_path, 'r') as f:
            first_statement = f.readline()
        if '1.8' in first_statement:
            app_log.info("Processing file for 1.8 version")
            main_df, header_df, class_df, export_dict = parser_v8(file_path)
        elif '1 7' in first_statement or '1 1' in first_statement or '1 2' in first_statement:
            app_log.info("Processing file for 1.7 version")
            main_df, header_df, class_df, export_dict = parser_v7(file_path)
        header_df['resulttimestamp'] = pd.to_datetime(header_df['resulttimestamp'])
        header_df['resulttimestamp'] = header_df['resulttimestamp'].dt.strftime(
            '%Y-%m-%d %H:%M-%S')
        final_header_df = process_header_df(header_df)
        mapelements = map(str, [username, final_header_df['product'][0], final_header_df['layer'][0],
                                final_header_df['carrierid'][0], filename, final_header_df['resulttimestamp'][0]])
        mapname = '|'.join(mapelements)
        query = f"SELECT mapid FROM opwi_map_header final WHERE rfg=1 and mapname = '{mapname}'"
        header_data = execute_query(connection, query, 'all', 'df').to_dict(orient='records')
        exists = False if len(header_data) == 0 else True
        raise Return({'exists': exists, 'mapname': mapname,
                      'mapid': header_data[0]['mapid'] if header_data else ""})
    else:
        query = f"select mapid,mapname from opwi_map_header final where rfg=1 and cby ='{username}' and filename like '%{filename}%' order by splitByChar('|', mapname)[5]"
        header_data = execute_query(connection, query, 'all', 'df')
        exists = False if header_data.empty else True
        raise Return({'exists': exists, 'mapname': header_data['mapname'].tolist() if not header_data.empty else 0,
                      'mapid': header_data['mapid'].tolist() if not header_data.empty else 0})
