from api.utils.utils import create_connection_pool
from itertools import zip_longest as zip
import itertools
from tornado.gen import coroutine, Return
from api.utils.common import execute_query
from api.utils.utils import queries2, connection_pool


class DataStore(object):

    def __init__(self, conn):
        self.connection = connection_pool.connect()

    @coroutine
    def prepare(self, columns, query_data, fetch='all'):
        if fetch == 'one':
            return dict(zip(list(columns), list(query_data)))
        return list(map(lambda row: dict(zip(list(columns), row)), query_data))

    @coroutine
    def fetch(self, query, fetch='all'):
        
        
        if fetch == 'all':
            data = execute_query(self.connection, query, 'all', 'list')
            raise Return(data)

        if fetch == 'one':
            data = execute_query(self.connection, query,'one', 'fetchonelist')
            raise Return(data)
