import tornado
from api.export.export_api.exporthandler import ExportHandler

services = {
    'export': [
        tornado.web.url(r"/export", ExportHandler)
    ],
}