import os
import pandas as pd
import tornado
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.export.export_api.exportmodel import Export
from tornado import web, iostream, gen
from api.utils.common import BaseHandler

class ExportHandler(BaseHandler):

    async def post(self):
        export = Export()
        chunk_size = 1024 * 1024 * 1
        self.set_header("Content-Type", self.content_type)
        file = export.get(data=json_decode(self.request.body))
        self.set_header('Content-Disposition', 'attachment; filename='+file)
        with open(f"export/{file}", "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                try:
                    self.write(chunk)
                    await self.flush()
                except iostream.StreamClosedError:
                    break
                finally:
                    del chunk
                    await gen.sleep(0.000000001)

        if os.path.exists(f"export/{file}"):
            os.remove(f"export/{file}")

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
