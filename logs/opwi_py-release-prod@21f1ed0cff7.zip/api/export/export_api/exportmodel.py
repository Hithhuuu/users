import os
import io
import csv
import pandas as pd
from datetime import datetime
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger, get_columns_info, get_env_config
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, execute_query

app_log = get_logger('export')


class Export():
    def __init__(self):
        '''Initialize Export process.'''
        self.connection = connection_pool.connect()
        self.queries = queries2['export']
        self.cursor = self.connection.cursor()
        self.query_data = {}
        self.prefixdata = ""
        self.cols1, self.cols2, self.cols3 = [], [], []
        self.columns = get_columns_info()
        self.config = get_env_config()

    def prepare_search(self, defecttable, type='column'):
        '''Prepare search query for defect table'''
        if type == 'column':
            if defecttable['column_search']:
                column_search = mapname_srch = other_col_srch = otyp_srch = ""

                if 'mapname' in defecttable['column_search'].keys():
                    value = defecttable['column_search']['mapname'].replace('|', '')
                    if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'"):
                        mapname_srch = f" AND upper(splitByChar('|',mapname)[5]) = upper('{value[1:-1]}')"
                    else:
                        mapname_srch = f" AND upper(splitByChar('|',mapname)[5]) like upper('%{value}%')"

                if 'otype' in defecttable['column_search'].keys():
                    value = defecttable['column_search']['otype']
                    if (value[0] == '"' and value[-1] == '"') or (value[0] == "'" and value[-1] == "'"):
                        otyp_srch = f" AND case when defects.otype = 17 then 'VV' when defects.otype = 16 then 'VM' when defects.otype = 15 then 'V0' when defects.otype = 14 then 'MV' when defects.otype = 13 then 'MM' when defects.otype = 12 then 'M0' when defects.otype = 11 then '0V' when defects.otype = 10 then '0M' when defects.otype = 9 then 'EOA' else '' end =upper('{value[1:-1]}')"
                    else:
                        otyp_srch = f" AND case when defects.otype = 17 then 'VV' when defects.otype = 16 then 'VM' when defects.otype = 15 then 'V0' when defects.otype = 14 then 'MV' when defects.otype = 13 then 'MM' when defects.otype = 12 then 'M0' when defects.otype = 11 then '0V' when defects.otype = 10 then '0M' when defects.otype = 9 then 'EOA' else '' end like upper('%{value}%')"

                other_col_srch = " AND ".join(
                    [f"toString({key})='{value[1:-1]}'" if (value[0] == '"' and value[-1] == '"') or (
                                value[0] == "'" and value[-1] == "'") else f"toString({key}) ilike '%{value}%'"
                     for key, value in {i: j for i, j in defecttable['column_search'].items()
                                        if i not in ['mapname', "otype"]}.items()
                     ])

                column_search = f"{f'AND {other_col_srch}' if other_col_srch != '' else ''} {mapname_srch}"
                column_search += otyp_srch
                return f"  {column_search}"

            return ""

        if type == 'overall':
            from string import punctuation
            search_string = ""
            if defecttable.get('search_text'):
                for i in defecttable.get('search_text'):
                    if i in list(punctuation):
                        search_string += f"\\{i}"
                    else:
                        search_string += i
                overall_search = f" AND lower(defects.srch_id||'!'||coalesce(toString(class.classname),'')||'!'||coalesce(toString(defects.classnumber),'')||'!'||coalesce(" \
                                 f"toString(header.mapname),'')||'!'||coalesce(toString(xrel),'')||'!'||coalesce(toString(" \
                                 f"yrel),'')||'!'||coalesce(toString(xindex),'')||'!'||coalesce(toString(yindex)," \
                                 f"'')) like '%{search_string}%' "
                return overall_search
            return ""

    def prepare_column_sort(self, defecttable, orientation):
        ''' Preparing query string for column sorting '''
        if defecttable.get('column_sort'):
            columns_sort_query = [f"{key} {value} " for key, value in defecttable['column_sort'].items(
            ) if defecttable['column_sort'][key]]
            sort_query = update_query(
                f' ORDER BY {column_sort_query}', orientation)
            return sort_query
        return " ORDER BY defects.defectid DESC"

    def prepare_query_inputs(self, inputs, values, count_condition, condition, orientation):
        '''prepare query inputs'''

        data = {
            'mapid': tuple(values.get('mapid')),
            'fieldx': inputs.get('fieldx', 1),
            'fieldy': inputs.get('fieldy', 1),
            'diepitch_x': inputs.get('diepitch_x', 1),
            'diepitch_y': inputs.get('diepitch_y', 1),
            "xsite": f'xsite_{orientation}',
            "ysite": f'ysite_{orientation}',
            "condition": update_query(condition, orientation),
            "orientation": orientation,
            "prep_column": inputs.get('prep_column', None),
            "count_condition": update_query(count_condition, orientation),
            "offset_mapid": tuple(inputs['selectedMaps']) if len(inputs.get('selectedMaps', '')) > 0
            else tuple(values.get('mapid'))
        }
        return data

    def get(self, data):
        '''Get data from table'''

        try:
            orient_col = ["xrel", "yrel", "xindex", "yindex"]
            orientationmarklocation = {"down": "0.0",
                                       "left": "-90.0",
                                       "up": "-180.0",
                                       "right": "-270.0"
                                       }
            inputs = data['inputs']
            filters = data['filters']
            values = data['values']
            defect_query = ""
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            defecttable = inputs['defecttable']
            commonality_filter = get_commonality_filter(data)
            FIELD_DIEPITCH_2="Field DiePitch 2 {"
            FEILD_SAMPLE_CENTER="Field SampleCenterLocation 2 {"
            FIELD_ORIENTATION="Field OrientationMarkLocation 1 {"

            '''for ctrl + click single defect selection'''
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN {tuple(values['defectid'])}"
            query_data = make_query(data, alias='defects.')

            '''prepare search query'''
            column_search = self.prepare_search(defecttable, type='column')
            overall_search = self.prepare_search(defecttable, type='overall')

            '''prepping inputs'''
            count_condition = f"{query_data}{defect_query}"
            condition = f"{count_condition}{column_search}{overall_search}"
            self.query_data = self.prepare_query_inputs(inputs, values, count_condition, condition, orientation)
            commonality_query(data, commonality_filter, self.query_data)

            query1 = self.queries['read_export'].format(**self.query_data)
            app_log.info(f"Read export table: {query1}")
            
            df1 = execute_query(self.connection, query1,'all', 'df')
            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi':
                query2 = self.queries['read_main_offset'].format(**self.query_data)
            else:
                query2 = self.queries['read_main'].format(**self.query_data)

            app_log.info(f"Read main defect table: {query2}")
            
            main_df = execute_query(self.connection, query2, 'all', 'df')
            filename = f"{values.get('mapname')}.001" if values.get('mapname', None) else df1.at[0, 'filename']
            export_path = f"export/{filename}"

            query_to_execute = self.queries['fetch_main_class'].format(**self.query_data)
            used_class = execute_query(self.connection, query_to_execute, 'all')

            if df1.at[0, 'fileversion'] in ["1.7", "1.1"] :
                ls = [i.replace("defects.", "") for i in main_df.columns]
                main_df.columns = ls
                columns = df1.at[0, 'columnsname'].lower().strip().strip(';').split(' ')[2:]
                for i in columns:
                    if i in ls:
                        self.cols1.append(i)
                    else:
                        for key, value in self.columns['alias_dict'].items():
                            if i == key:
                                self.cols1.append(value)
                                self.cols3.append(key)
                            else:
                                self.cols2.append(i)
                self.prefixdata = df1.at[0, 'prefixdata']

                # Adding class mapping from main data to klarf
                split_data = self.prefixdata.split('\n')
                class_lookup_start = 0
                class_lookup_stop = 0
                for index, line in enumerate(split_data):
                    if 'classlookup' in line.lower():
                        class_lookup_start = index
                        for line_no in range(class_lookup_start+1, len(split_data)):
                            if ';' in split_data[line_no]:
                                class_lookup_stop = line_no
                                break
                        if class_lookup_stop !=0:
                            break

                class_data = dict(map(self.clean_list, split_data[class_lookup_start+1:class_lookup_stop+1]))

                for key, value in used_class:
                    class_data[str(key)] = value

                class_lookup = ""
                for key, value in class_data.items():
                    class_lookup += f' {key} "{value}"\n'
                class_lookup += ";"
                class_lookup = class_lookup.replace("\n;", ";")

                prefixdata = split_data[:class_lookup_start+1]+[class_lookup]+split_data[class_lookup_stop+1:]
                self.prefixdata = "\n".join(prefixdata)
                # -------

                for i in self.cols2:
                    if i not in self.cols3 and i != "":
                        self.prefixdata = self.prefixdata.replace(" " + i.upper(), "")

                self.prefixdata = self.prefixdata.replace(' CN_'.upper(), "")
                self.prefixdata = self.prefixdata.replace('DefectRecordSpec ' + str(len(columns)),
                                                          'DefectRecordSpec ' + str(len(self.cols1)))

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index("OrientationMarkLocation")
                                    :self.prefixdata.index("OrientationMarkLocation") +
                                     self.prefixdata[self.prefixdata.index("OrientationMarkLocation"):].index(";")],
                    "OrientationMarkLocation " + orientation.upper())

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index("DiePitch")
                                    :self.prefixdata.index("DiePitch") +
                                     self.prefixdata[self.prefixdata.index("DiePitch"):].index(";")],
                    f"DiePitch {main_df.loc[0, f'diepitch_x_{orientation}'] / 1000} {main_df.loc[0, f'diepitch_y_{orientation}'] / 1000}")

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index("SampleCenterLocation")
                                    :self.prefixdata.index("SampleCenterLocation") +
                                     self.prefixdata[self.prefixdata.index("SampleCenterLocation"):].index(";")],
                    f"SampleCenterLocation {main_df.loc[0, f'scl_x_{orientation}'] / 1000} {main_df.loc[0, f'scl_y_{orientation}'] / 1000}")

                main_data = main_df[[col if col not in orient_col else f"{col}_{orientation}" for col in self.cols1]]
                m = self.prefixdata.split("\n")
                s = "\n".join(m)
                if 'xrel' in self.cols1:
                    main_data.loc[:, f"xrel_{orientation}"] = main_data[f"xrel_{orientation}"].apply(lambda x: x / 1000)

                if 'yrel' in self.cols1:
                    main_data.loc[:, f"yrel_{orientation}"] = main_data[f"yrel_{orientation}"].apply(lambda x: x / 1000)

                if 'dsize' in self.cols1:
                    main_data.loc[:, 'dsize'] = main_data['dsize'].apply(lambda x: x / 1000)

                main_data[f'xindex_{orientation}'] = main_data[f'xindex_{orientation}'].astype(int)
                main_data[f'yindex_{orientation}'] = main_data[f'yindex_{orientation}'].astype(int)
                csv_obj = main_data.to_csv(sep=' ', index=False, header=False, quoting=csv.QUOTE_NONE, quotechar="",  escapechar="\\")

                csv_lst = [i.strip() for i in csv_obj.split("\n")]
                f = open(export_path, 'w')
                f.write(s)
                for i in range(len(csv_lst) - 1):
                    if i < len(csv_lst) - 2:
                        f.write(csv_lst[i].replace('\\', '') + "\n")
                    elif i == len(csv_lst) - 2:
                        f.write(csv_lst[i].replace('\\', '') + ";\n")
                f.write(df1.at[0, 'suffixdata'])
                f.close()

            elif df1.at[0, 'fileversion'] == "1.8":
                main_df.drop(['imageinfo'], axis=1, inplace=True)
                main_df.rename(columns = {'imagelist':'imageinfo'}, inplace = True)
                ls = [i.replace("defects.", "") for i in main_df.columns]
                main_df.columns = ls
                columns = df1.at[0, 'columnsname'].split("{")[-1].split(",")
                columns = list(map(lambda x: x.split(" ")[-1].lower(), columns))
                for i in columns:
                    if i in ls:
                        self.cols1.append(i)
                    else:
                        for key, value in self.columns['alias_dict'].items():
                            if i == key:
                                self.cols1.append(value)
                                self.cols3.append(key)
                            elif i not in self.cols2:
                                self.cols2.append(i)
                self.prefixdata = df1.at[0, 'prefixdata']

                # Adding class mapping from main data to klarf
                class_lookup_start = 0
                class_lookup_stop = 0
                split_data = self.prefixdata.split('\n')
                lines = list(map(str.strip, split_data))
                for index, data in enumerate(lines):
                    if 'int32 CLASSNUMBER, string CLASSNAME, string CLASSCODE' in data:
                        class_lookup_start = index + 3
                        class_lookup_stop = class_lookup_start + lines[class_lookup_start:].index('}') - 1
                        break

                class_data = list(map(self.clean_list, lines[class_lookup_start+1:class_lookup_stop+1]))
                class_data = {x: [x,y,z] for x,y,z in class_data}

                for key, value in used_class:
                    class_data[str(key)] = [str(key), value, 'NA']

                no_space = len(split_data[class_lookup_start+1]) - len(split_data[class_lookup_start+1].lstrip())

                class_lookup = []
                for no, name, code in list(class_data.values()):
                    class_lookup.append(f'{no_space*" "}{no} "{name}" "{"" if code=="NA" else code}";')
                class_lookup = "\n".join(class_lookup)

                prefixdata = split_data[:class_lookup_start+1]+[class_lookup]+split_data[class_lookup_stop+1:]
                self.prefixdata = "\n".join(prefixdata)
                # ------

                for i in self.cols2:
                    if i not in self.cols3 and i != "":
                        self.prefixdata = self.prefixdata.replace(
                            self.prefixdata[self.prefixdata[:self.prefixdata.index(
                                i.upper())].rindex(","):self.prefixdata.index(i.upper())] + i.upper(), "")

                self.prefixdata = self.prefixdata.replace('Columns ' + str(len(columns)),
                                                          'Columns ' + str(len(self.cols1)))

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index(FIELD_DIEPITCH_2)
                                    :self.prefixdata.index(FIELD_DIEPITCH_2) +
                                     self.prefixdata[self.prefixdata.index(FIELD_DIEPITCH_2):].index("}")],
                    FIELD_DIEPITCH_2 + str(int(main_df.loc[0, f'diepitch_x_{orientation}'])) + ', ' + str(
                        int(main_df.loc[0, f"diepitch_y_{orientation}"])))

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index(FEILD_SAMPLE_CENTER)
                                    :self.prefixdata.index(FEILD_SAMPLE_CENTER) +
                                     self.prefixdata[self.prefixdata.index(FEILD_SAMPLE_CENTER):].index(
                                         "}")],
                    FEILD_SAMPLE_CENTER + str(int(main_df.loc[0, f'scl_x_{orientation}'])) + ', ' + str(
                        int(main_df.loc[0, f"scl_y_{orientation}"])))

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.index(FIELD_ORIENTATION)
                                    :self.prefixdata.index(FIELD_ORIENTATION) +
                                     self.prefixdata[self.prefixdata.index(FIELD_ORIENTATION):].index(
                                         "}")],
                    FIELD_ORIENTATION + orientationmarklocation[orientation])

                # if self.prefixdata.rindex("}") < self.prefixdata.rindex("{"):
                #     self.prefixdata = self.prefixdata.replace(
                #         self.prefixdata[self.prefixdata.rindex("}") + 1:self.prefixdata.rindex("{")],
                #         f"\n    Data {main_df.shape[0]}\n")
                # else:

                self.prefixdata = self.prefixdata.replace(
                    self.prefixdata[self.prefixdata.rindex("}") + 1:],
                    f"\n    Data {main_df.shape[0]}\n {'{'}\n")

                main_data = main_df[[col if col not in orient_col else f"{col}_{orientation}" for col in self.cols1]]
                main_data.loc[:, self.cols1[-1]] = main_data[self.cols1[-1]]
                m = self.prefixdata.split("\n")
                s = "\n".join(m)

                main_data[f'xindex_{orientation}'] = main_data[f'xindex_{orientation}'].astype(int)
                main_data[f'yindex_{orientation}'] = main_data[f'yindex_{orientation}'].astype(int)

                csv_obj = main_data.to_csv(sep=' ', index=False, header=False, quoting=csv.QUOTE_NONE, quotechar="",  escapechar="\\")
                csv_lst = [i.strip() for i in csv_obj.split("\n")]
                f = open(export_path, 'w')
                f.write(s)
                for i in range(len(csv_lst) - 1):
                    f.write(csv_lst[i].replace('\\', '') + ';\n')
                f.write(df1.at[0, 'suffixdata'])
                f.close()

        except Exception as e:
            app_log.exception(f"error: {str(e)}")
            import traceback
            app_log.info(traceback.format_exc())
            return {"error": str(e)}

        return filename


    def clean_list(self, data):
        data = data.strip().replace('""', "NA").replace(
            ";", "").strip().replace('\n', '').split(" ")
        out = []
        flag = None
        for i in data:
            if '"' in i:
                if '"' == i[-1] and '"' == i[0]:
                    out.append(i.replace('"', ''))
                elif flag:
                    out.append(flag + ' ' + i.replace('"', ''))
                    flag = None
                else:
                    flag = i.replace('"', '')
            elif flag:
                flag = flag + ' ' + i
            else:
                out.append(i)
        return out

    def __del__(self):
        '''on connection close'''
        self.connection.close()
