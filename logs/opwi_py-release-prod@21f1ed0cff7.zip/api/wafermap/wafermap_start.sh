nohup python3 api\wafermap\server.py --port=8070 --env=dev --service=wafermap
nohup python3 api\wafermap\server.py --port=8071 --env=dev --service=wafermap
nohup python3 api\wafermap\server.py --port=8072 --env=dev --service=wafermap
nohup python3 api\wafermap\server.py --port=8073 --env=dev --service=wafermap
nohup python3 api\wafermap\server.py --port=8075 --env=dev --service=wafermap