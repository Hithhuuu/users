
import tornado
from api.wafermap.wafermap_api.wafermaphandler import WaferMapHandler
from api.wafermap.wafermap_api.wafermapdetailshandler import WaferMapDetailsHandler
from api.wafermap.wafermap_api.legendhandler import LegendHandler

services = {
    'wafermap': [
        tornado.web.url(r"/wafermap", WaferMapHandler),
        tornado.web.url(r"/waferdetails", WaferMapDetailsHandler),
        tornado.web.url(r"/wafermap/legends", LegendHandler),
    ],
}