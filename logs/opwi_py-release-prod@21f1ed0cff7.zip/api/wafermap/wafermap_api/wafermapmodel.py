import json
import itertools
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger, columns_info
from api.utils.common import make_query, update_query, get_prep_level, get_commonality_filter, prep_attribute_filter_query, commonality_query, execute_query
app_log = get_logger("wafermap")

class WaferMap:
    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2["wafermap"]
        self.defectlimit = 5000
        self.commonality_mapping = columns_info['commonality_attr_mapping']

    def commonality_query(self, data, commonality_filter, query_data):
        if commonality_filter:
            query_data['commonality'] = self.queries['commonality'].format(**{
                "projectid": data['projectid'],
                "rmapid": data['inputs']['ref_mapid']
            })
            value_c = tuple([self.commonality_mapping[i] for i in commonality_filter])
            query_data['count_condition_commonality'] = f"  AND cm.refcm in {value_c}"
        else:
            query_data['commonality'] = ""
            query_data['count_condition_commonality'] = ""

    def get_condition_cols(self, data):
        condition_columns = []
        for attr in data['values'].get('attribute_filters', {}).keys():
            if attr == 'refcm':
                continue
            attr = update_query(attr, data['inputs'].get('orientationmarklocation', '').lower())
            condition_columns.append(attr)
        if len(condition_columns) > 0:
            return f"{','.join(condition_columns)},"
        return ''

    def prepare_query_inputs(self, data):
        """ Prepare Query inputs with inputs data """
        inputs = data["inputs"]

        condition_columns = self.get_condition_cols(data)

        query_c = ''
        wafermap = inputs["wafermap"]
        query = make_query(data, alias="defects.")
        if data['inputs'].get('isCallSplit'):
            import copy
            data_c = copy.deepcopy(data)
            data_c['filters']['range'].remove('xsite')
            data_c['filters']['range'].remove('ysite')
            data_c['values'].pop('xsite')
            data_c['values'].pop('ysite')
            query_c = make_query(data_c, alias="defects.")
        orientation = inputs.get("orientationmarklocation", "down").lower()
        if "mapid" in data["filters"]["multiDropdown"]:
            mapid = tuple(data.get("values").get("mapid"))
        else:
            mapid = f"(select mapid from opwi_myproject_maps final where rfg=1 and projectid = {data['projectid']})"

        query_inputs = {
            "query_c": query_c,
            "mapid": mapid,
            "xsite": f"xsite_{orientation}",
            "ysite": f"ysite_{orientation}",
            "shape_by": wafermap["shape_by"],
            "volume_by": wafermap["volume_by"],
            "issmall": inputs.get("issmall"),
            "fieldx": inputs.get("field_stacking").get('fieldx',1) if inputs.get("field_stacking", None) else 1,
            "fieldy": inputs.get("field_stacking").get("fieldy", 1) if inputs.get("field_stacking", None) else 1,
            "diepitch_x": inputs.get("diepitch_x", 1),
            "diepitch_y": inputs.get("diepitch_y", 1),
            "query": update_query(query, orientation),
            "orientation": orientation,
            "condition_columns": condition_columns,
            "waferView": inputs.get('waferView', 'stack')
        }
        return query_inputs

    def get_selected_maps(self, data, query):
        query_count = query
        if data['inputs'].get('selectedMaps', None):
            selected_maps = str(tuple(data['inputs']['selectedMaps']))
            maps = str(tuple(data['values']['mapid']))
            query_count = query.replace(maps, selected_maps)
                          #+ ' group by mapid order by count(1) desc limit 1'

        return query_count

    def get_offset_columns(self, query_data):
        if 'xindex' in query_data['condition']:
            query_data['condition'] = query_data['condition'].replace('xindex', 'xindex_offset')
        if 'yindex' in query_data['condition']:
            query_data['condition'] = query_data['condition'].replace('yindex', 'yindex_offset')

    @coroutine
    def get(self, data):
        try:
            """Returns wafer map data on query"""
            commonality_filter = get_commonality_filter(data)
            import copy
            attribute_values = copy.deepcopy(data)
            query_data = self.prepare_query_inputs(data)
            """ Make Query string with requested parameters """
            """ Based on the Zoomlevel updating defect limit """

            """ Prepare / Update query string on query_data condition """
            orientation = query_data["orientation"]
            query = query_data["query"]
            _query = query.replace("defects", "m")
            query_data.update({"condition": _query})
            count_condition_query = _query
            query_data.update({"count_condition": count_condition_query.replace('m.', 'defects.')})
            query_data["condition"] = query_data["condition"][4:]

            app_log.info("Query Processsing for Wafer map")
            query_count = self.get_selected_maps(data, query)
            attribute_filters = prep_attribute_filter_query(attribute_values, 'defects.')
            query_data_count = query_data
            commonality_query(data, commonality_filter, query_data_count)
            query_data_count['count_condition'] = f" {query_count} {attribute_filters}"
            query_data_count['query_c'] += attribute_filters
            query_data_count['query_count'] = query_count
            query_data_count['mapid'] = str(tuple(data['inputs']['selectedMaps'])) if data['inputs'].get('selectedMaps', None) else query_data['mapid']
            query_data_count['offset'] = self.queries['offset_join'].format(
                **{"mapid": query_data_count['mapid'], "orientation": orientation}) if data['inputs'].get('waferView', 'stack') and data['inputs'].get(
                'waferView', 'stack') != 'multi1' else ''
            query_data['isCallSplit'] = data['inputs'].get('isCallSplit', None)

            prep_columns = get_prep_level(self.connection, query_data_count, self.defectlimit)

            query_data["xsite"] = prep_columns['xsite']
            query_data["ysite"] = prep_columns['ysite']
            query_data["commonality"] = query_data_count['commonality']
            query_data['count_condition_commonality'] = query_data_count['count_condition_commonality']
            query_data['value_mapid'] = tuple(data['values'].get('mapid'))
            query_data['offset'] = self.queries['offset_join'].format(
                **{"mapid": query_data_count['mapid'], "orientation": orientation}) if data['inputs'].get(
                'waferView', 'stack') and data['inputs'].get(
                'waferView', 'stack') != 'multi1' else ''

            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
            else:
                query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
            self.get_offset_columns(query_data)

            if query_data['xsite'] == f'xsite_{orientation}':
                query_data['commonality'] = query_data['commonality'].replace('defects', 'm')
                query_to_execute = self.queries["read_defects_level0"].format(
                    **query_data
                )
            else:
                query_to_execute = self.queries["read_defects"].format(
                    **query_data
                )

            self.get_offset_columns(query_data)
            app_log.info(f"WAFER MAP FINAL QUERY: {query_to_execute}")
            
            key2=execute_query(self.connection,query_to_execute,'all','list')
          
            resp = dict()
            for i in key2:
                if i["mapid"] in resp:
                    resp[i["mapid"]].append(
                        {
                            "defectid": i["defectid"],
                            "classnumber": i["classnumber"],
                            "xsite": i["xsite"],
                            "ysite": i["ysite"],
                            "shape_by": i["shape_by"],
                            "volume_by": i["volume_by"],
                        }
                    )
                else:
                    resp[i["mapid"]] = [
                        {
                            "defectid": i["defectid"],
                            "classnumber": i["classnumber"],
                            "xsite": i["xsite"],
                            "ysite": i["ysite"],
                            "shape_by": i["shape_by"],
                            "volume_by": i["volume_by"],
                        }
                    ]
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            return {"error": str(e)}
        raise Return(
            {"data": resp, "prep_column": [query_data["xsite"], query_data["ysite"]]}
        )

    @coroutine
    def get_waferdetails(self, data):
        """ Get wafermap details based on the requested data """
        try:
            data["orientation"] = (
                data["inputs"].get("orientationmarklocation", "down").lower()
            )
            data['input_mapid'] = tuple(data['values'].get('mapid'))
            data['mapid'] = tuple(data['inputs'].get('selectedMaps', '')) if len(data['inputs'].get('selectedMaps', '')) > 0 else tuple(data['values'].get('mapid'))
            wafer_detail_query = self.queries["read_waferdetails"].format(
                **data
            )
            app_log.info(f"WAFER MAP DETAIL QUERY: {wafer_detail_query}")
            df = execute_query(self.connection, wafer_detail_query, 'all', 'df').drop_duplicates()
            degree_mapping = {"0": "down", "90": "left", "180": "top", "270": "right"}
            df["orientationmarklocation"] = (
                df["orientationmarklocation"].str.split(".", expand=True)[0].str.upper()
            )
            df.replace(degree_mapping, inplace=True)
            df = df[df["diearea"].isin([df["diearea"].max()])]
            df.drop(["diearea"], axis=1, inplace=True)
            resp = df.iloc[0].to_json()
            resp = json.loads(resp)

        except Exception as e:
            return {"error": str(e)}
        raise Return(resp)

    @coroutine
    def get_legends(self, data):
        try:
            """Returns map legend data"""
            """ Generate query_data from requested data """
            commonality_filter = get_commonality_filter(data)
            query_data = self.prepare_query_inputs(data)
            commonality_query(data, commonality_filter, query_data)
            query = self.queries["read_legends"].format(**query_data)
            app_log.info(f"WAFER MAP LEGENDS QUERY: {query}")
            key=execute_query(self.connection,query)
            data = dict()
            data["legends"] = [i[0] for i in key]
        except Exception as e:
            return {"error": str(e)}
        raise Return(data)

    def __del__(self):
        """Closing the DB connection"""
        self.connection.close()
