import json
from uuid import uuid1
from datetime import datetime

from tornado.escape import json_encode
from tornado.gen import coroutine
from api.utils.utils import queries2, connection_pool
from api.utils.datastore import DataStore


class Flow():
    '''Flow Model'''

    def __init__(self):
        '''Initialize flow model.'''
        self.conn = connection_pool.connect()
        self.cursor = self.conn.cursor()
        self.queries = queries2['flow']

    @coroutine
    def get(self, flowid=None):
        '''Get list of all models.'''
        if flowid:
            query = self.queries['select'].format(
                **{'flowid': flowid})
        else:
            query = self.queries['select_all']
        self.cursor.execute(query)
        resp = parse_data(self.cursor)
        for index, res in enumerate(resp):
            resp[index]['flowjson'] = json.loads(res['flowjson'])
        return resp

    @coroutine
    def insert(self, data):
        '''Get list of all models.'''
        data['flowid'] = str(uuid1())
        data['flowjson'] = json_encode(data['flowjson'])
        self.cursor.execute(self.queries['insert'].format(**data))
        return self.get(flowid=data['flowid'])._result

    @coroutine
    def update(self, data):
        '''Get list of all models.'''
        if 'flowid' not in data:
            raise Exception('flowid missing')
        data['flowjson'] = json_encode(data['flowjson'])
        data['cdt'] = datetime.strptime(data['cdt'], '%Y-%m-%d %H:%M:%S')
        self.cursor.execute(self.queries['update'].format(**data))
        return self.get(flowid=data['flowid'])._result

    def __del__(self):
        self.cursor.close()
        self.conn.close()
