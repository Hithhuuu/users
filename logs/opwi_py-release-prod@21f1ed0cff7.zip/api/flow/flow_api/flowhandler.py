import tornado
from tornado.gen import coroutine
from api.flow.flow_api import flowmodel
import json
from tornado.escape import json_decode
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class FlowHandler(BaseHandler):

    @coroutine
    def get(self):
        '''get flow data'''
        model = flowmodel.Flow()
        flowid = self.request.arguments.get(
            'flowid', None)[0].decode() if 'flowid' in self.request.arguments else None
        resp = model.get(flowid=flowid)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp, default=str))

    @coroutine
    def post(self):
        model = flowmodel.Flow()
        resp = model.insert(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp, default=str))

    @coroutine
    def put(self):
        model = flowmodel.Flow()
        resp = model.update(
            json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp, default=str))

    def options(self):
        self.set_status(204)
        self.finish()
