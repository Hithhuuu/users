import tornado
from api.flow.flow_api.flowhandler import FlowHandler

services = {
    'flow': [
        tornado.web.url(r"/flow", FlowHandler)
    ]
}