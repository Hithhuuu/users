import os
import sys
import json
import signal
import asyncio
import tornado
import tornado.web
import tornado.ioloop
import tornado.options
from tornado import autoreload
import tornado.websocket
from tornado import gen, log
from tornado_swagger.setup import setup_swagger
from tornado.options import parse_command_line, define, options

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from api.utils.argparser import get_args, CustomArgsParser
from api.utils.utils import get_logger, get_config, connection_pool
from api.flow.services import services


options.define("port", default=9999,
               help="run on the given port", type=int)
options.define("env", default='dev',
               help="defining env", type=str)
options.define("service", default=None,
               help="defining service", type=str)
options.parse_command_line()

port_number = options._options['port'].value()
env = options._options['env'].value()
service_name = options._options['service'].value()


app_log = get_logger('server')


class Application(tornado.web.Application):
    is_closing = False

    def signal_handler(self, signum, frame):
        app_log.info('exiting...')
        self.is_closing = True

    def try_exit(self):
        if self.is_closing:
            tornado.ioloop.IOLoop.instance().stop()
            app_log.info('exit success')

    _routes = list()

    if service_name == 'all':
        _routes = []
        for service in services.items():
            _routes.extend(service[1])
    elif service_name not in services:
        app_log.info('Sevice does not exist')
        sys.exit()
    else:
        _routes = services[service_name]

    def __init__(self):
        setup_swagger(self._routes)
        super(Application, self).__init__(self._routes, compress_response=True)


if __name__ == "__main__":
    port_number = options._options['port'].value()
    env = options._options['env'].value()
    service_name = options._options['service'].value()

    os.environ['env'] = env

    application = Application()

    config = get_config()

    tornado.options.parse_command_line()
    signal.signal(signal.SIGINT, application.signal_handler)
    server = tornado.httpserver.HTTPServer(
        application, max_buffer_size=10485760000)

    app_log.info(
        f'Running on port {port_number} for {service_name} service...')
    app_log.info(f'For {env} env')
    server.listen(port_number)
    tornado.ioloop.PeriodicCallback(application.try_exit, 100).start()
    tornado.ioloop.IOLoop.instance().start()
