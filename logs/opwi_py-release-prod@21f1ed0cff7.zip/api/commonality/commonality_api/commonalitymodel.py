import itertools
from os import abort
import pandas as pd
from datetime import datetime
from tornado.gen import coroutine, Return
from tornado.escape import json_decode, json_encode
from api.utils.utils import queries, connection_pool, getdbconnection, queries2
from api.utils.common import make_query, update_query, get_prep_level, commonality_query, get_commonality_filter, execute_query
from api.utils.utils import get_logger
from time import  sleep

app_log = get_logger("commonality")

class DeleteError(Exception):
    def __init__(self, msg):
        self.msg = msg
        super().__init__(self.msg)
class Commonality():
    def __init__(self):
        """Initialize Reclassification"""
        self.connection = connection_pool.connect()
        self.queries = queries2['commonality']
        self.query_data = dict()
        self.defect_attr_mapping = {
            'adders': 'CMA', 'common': 'CM', 'missing': 'CMM'}

    def create_commonality_table(self, projectid, tbl_type='main'):
        try:
            app_log.info(f"Creating the Commonality table for projectid: {projectid}")
            #check whether table already exists
            app_log.info(f"Checking if table already exists")
            table_exists_query = self.queries[f'table_exists_{tbl_type}'].format(**{'projectid': projectid})
            
            app_log.info(f"Table Exists Query: {table_exists_query}")
            status = execute_query(self.connection, table_exists_query, 'one')[0]
            app_log.debug(f"status ============================={status}")
            if status == 1:
                app_log.info(f"Table exists")
                truncate_query =  self.queries[f"truncate_{tbl_type}"].format(**{'projectid': projectid})
                app_log.info(f"truncating the table: {truncate_query}")
                execute_query(self.connection, truncate_query,'')
                if tbl_type == 'wip':
                    wip_table_delete_query = f"truncate rawcm.opwi_defect_cm_wip_{projectid}"
                    execute_query(self.connection, wip_table_delete_query, '')
                    create_query = self.queries[f"create_table_{tbl_type}"].format(**{'projectid': projectid})
                    app_log.info(f"Table creation query is {create_query}")
                    execute_query(self.connection, create_query,'')
            else:
                create_query = self.queries[f"create_table_{tbl_type}"].format(**{'projectid': projectid})
                app_log.info(f"Table creation query is {create_query}")
                # cursor.execute(create_query)
                execute_query(self.connection, create_query,'')

        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info("Error while creating the table")
            raise RuntimeError(e)

    def prepare_query_inputs(self, input_data, inputs, values, condition, orientation, commonality_filter):
        '''prepare query inputs'''
        data = {
            'mapid': tuple(values.get('mapid')),
            'fieldx': inputs.get('fieldx', 1),
            'fieldy': inputs.get('fieldy', 1),
            'diepitch_x': inputs.get('diepitch_x', 1),
            'diepitch_y': inputs.get('diepitch_y', 1),
            "xsite": f'xsite_{orientation}',
            "ysite": f'ysite_{orientation}',
            "condition": update_query(condition, orientation),
            "selected_maps": tuple(inputs.get('selectedMaps', '')),
            "orientation": orientation,
            "count_condition": update_query(condition, orientation),
            "prep_column": inputs.get('prep_column', None),
            "offset_mapid": tuple(inputs.get('selectedMaps', '')) if len(inputs.get('selectedMaps', '')) > 0 else tuple(values.get('mapid'))

        }

        data['offset'] = self.queries['offset_join'].format(
                **{"offset_mapid": data['offset_mapid'],
                   "orientation": orientation}) if inputs.get('waferView', 'stack') \
                                                    and inputs.get('waferView', 'stack') != 'multi1' else ''
        data_count = data
        data_count['count_condition'] = data_count['count_condition'].replace(str(data['mapid']),
                                                                              str(data['selected_maps'])) \
            if len(data['selected_maps']) != 0 else data['count_condition']
        commonality_query(input_data,commonality_filter, data_count)
        prep_data = get_prep_level(
            self.connection, data_count, limit=5000)
        data['xsite'] = prep_data['xsite']
        data['ysite'] = prep_data['ysite']
        if inputs.get('waferView') and inputs.get('waferView') != 'multi1':
            data['offset_columns'] = self.queries['offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation,
                "fieldx": data['fieldx'],
                "fieldy": data['fieldy'],
                "diepitch_x": data['diepitch_x'],
                "diepitch_y": data['diepitch_y']
            })
        else:
            data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation,
                "fieldx": data['fieldx'],
                "fieldy": data['fieldy'],
                "diepitch_x": data['diepitch_x'],
                "diepitch_y": data['diepitch_y']
            })
        return data

    @coroutine
    def get_commonality(self, data):
        axis_clm = {
            'xaxis': {
                'site': 'xsite', # wafer
                'fieldrel': 'fieldrelx', # Field
                'rel': 'xrel' # Die
            },
            'yaxis': {
                'site': 'ysite',
                'fieldrel': 'fieldrely',
                'rel': 'yrel'
            }
        }

        inputs = data['inputs']
        values = data['values']
        commonality_filter = get_commonality_filter(data)

        self.query_data['projectid'] = data['projectid']
        self.query_data['ref_mapid'] = data['inputs']['ref_mapid']
        self.query_data['smapid'] = tuple(values['mapid'])
        orientation = data['inputs'].get('orientationmarklocation', 'DOWN').lower()
        self.query_data['orientation'] = orientation
        issmall = data['inputs'].get('issmall', False)
        self.query_data['xsite'] = 'xsite'
        self.query_data['ysite'] = 'ysite'
        self.query_data['ref_type'] = tuple(
            [self.defect_attr_mapping[i.lower()] for i in data['inputs']['ref_type']])

        coordinatetype = inputs.get('coordinatetype', 'site').lower()
        var_xaxis = axis_clm['xaxis'][coordinatetype]
        var_yaxis = axis_clm['yaxis'][coordinatetype]
        self.query_data['xaxis'] = var_xaxis
        self.query_data['yaxis'] = var_yaxis

        data['values']['mapid'].append(data['inputs']['ref_mapid'])
        query_d = make_query(data=data, alias='defects.')

        if 'mapid' in data['filters']['multiDropdown'] and data.get('values').get('mapid'):
            self.query_data['mapid'] = tuple(data.get('values').get('mapid'))
        else:
            self.query_data['mapid'] = '(select mapid from opwi_myproject_maps final where rfg=1 and projectid = {projectid})'.format(
                **data)

        query_inputs = self.prepare_query_inputs(data, inputs, values, query_d,
                                                 orientation, commonality_filter)

        self.query_data['xsite'] = query_inputs['xsite']
        self.query_data['ysite'] = query_inputs['ysite']
        self.query_data['wafermap_condition'] = query_inputs['condition']
        self.query_data['offset_columns'] = query_inputs['offset_columns']
        self.query_data['offset'] = query_inputs['offset']

        for key, value in self.defect_attr_mapping.items():
            if value in self.query_data['ref_type']:
                self.query_data[key] = value

            else:
                self.query_data[key] = 'XX'

        commonality_query(data, commonality_filter, self.query_data)

        self.query_data['count_condition_commonality'] = self.query_data['count_condition_commonality'].replace('cm.', '')
        get_commonality = None
        if self.query_data['ref_mapid'] in self.query_data['smapid']:
            get_commonality = self.queries['read_commonality_ref'].format(
                **self.query_data)
        else:
            get_commonality = self.queries['read_commonality_sec'].format(
                **self.query_data)

        if issmall == 9999:
            get_commonality = self.queries['read_commonality_small'].format(
                **self.query_data)

        app_log.info(f"Commonality Get Query: {get_commonality}")

        val1 = execute_query(self.connection, get_commonality, 'all', 'list')

        resp = dict()

        for i in val1:
            if i['refcm'] in resp:
                resp[i['refcm']].append(
                    {
                        var_xaxis: i[var_xaxis],
                        var_yaxis: i[var_yaxis]
                    }
                )
            else:
                resp[i['refcm']] = [
                    {
                        var_xaxis: i[var_xaxis],
                        var_yaxis: i[var_yaxis]
                    }
                ]

        raise Return(resp)

    @coroutine
    def update_commonality(self, data):
        """delete and insert the commonality data into clickhouse table"""
        try:
            print("*"*100)
            print(data)
            self.query_data['projectid'] = data['projectid']
            self.query_data['radius'] = data['inputs'].get('radius', 5000)
            self.query_data['secondary_mapids'] = tuple(data['secondary_mapids'])
            #create the table for commonality
            for mp in ['ref_mapid','master_mapid']:
                mapids = data['secondary_mapids']
                if data.get(f'{mp}'):
                    app_log.info(f'===commonality calculation for {mp}===')
                    self.query_data['ref_mapid'] = data.get(f'{mp}','')
                    # mapids.append(data.get('ref_mapid',''))
                    mapids.append(data.get(f'{mp}',''))
                elif not data.get('ref_mapid') and not data.get('master_mapid'):
                    return {'msg': 'ref_mapid or master_mapid is removed'}
                else:
                    continue
                self.query_data['mapid'] = tuple(mapids)
                if mp == 'ref_mapid':
                    self.create_commonality_table(self.query_data['projectid'])
                    self.create_commonality_table(self.query_data['projectid'], 'wip')
                self.query_data['offset_mapid'] = tuple(data['inputs'].get('selectedMaps')) \
                    if len(data['inputs'].get('selectedMaps', '')) > 0 else tuple(mapids)

                orientation = data['inputs'].get('orientationmarklocation', 'DOWN').lower()
                self.query_data['orientation'] = orientation
                    
                '''
                app_log.info(f"Deleting projectid {self.query_data['projectid']} from opwi_defect_cm")
                # Adding condition for failing the API if delete does not happen
                delete_status = self.delete_records("opwi_defect_cm", self.query_data['projectid'], cursor)
                if delete_status:
                    raise DeleteError(f"Unable to delete records from opwi_defect_cm")
                '''
                
                

                app_log.info(f"Checking if table already exists")
                table_exists_query = self.queries[f'table_exists_wip'].format(**{'projectid': self.query_data['projectid']})
                app_log.info(f"Table Exists Query: {table_exists_query}")
                status = execute_query(self.connection, table_exists_query, 'one')[0]
                app_log.debug(f"Exists ============================={status}")

                app_log.info(f"Inserting commonality data into opwi_defect_cm_wip")
                insert_wip = self.queries['insert_wip'].format(**self.query_data)
                app_log.info(f"Insert wip query: {insert_wip}")
                execute_query(self.connection, insert_wip,'')

                app_log.info(f"Checking if table already exists")
                table_exists_query = self.queries[f'table_exists_wip'].format(**{'projectid': self.query_data['projectid']})
                app_log.info(f"Table Exists Query: {table_exists_query}")
                status = execute_query(self.connection, table_exists_query, 'one')[0]
                app_log.debug(f"Exists ============================={status}")

                app_log.info(f"Inserting commonality data into opwi_defect_cm")
                insert_cm = self.queries['insert_cm'].format(**self.query_data)
                app_log.info(f"Insert cm query: {insert_cm}")
                execute_query(self.connection, insert_cm,'')

                app_log.info(f"Checking if table already exists")
                table_exists_query = self.queries[f'table_exists_wip'].format(**{'projectid': self.query_data['projectid']})
                app_log.info(f"Table Exists Query: {table_exists_query}")
                status = execute_query(self.connection, table_exists_query, 'one')[0]
                app_log.debug(f"Exists ============================={status}")
                app_log.info(
                    "Inserting commonality missing and adders data into opwi_defect_cm")
                insert_cm_missing_adders = self.queries['insert_cm_missing_adders'].format(
                    **self.query_data)
                app_log.info(
                    f"Insert CM missing and adders query: {insert_cm_missing_adders}")
                execute_query(self.connection, insert_cm_missing_adders,'')
                
                try:
                    # delete wip table 
                    # wip_table_delete_query = f"drop table rawcm.opwi_defect_cm_wip_{self.query_data['projectid']}"
                    wip_table_delete_query = f"truncate rawcm.opwi_defect_cm_wip_{self.query_data['projectid']}"
                    execute_query(self.connection, wip_table_delete_query, '')
                except Exception as e:
                    app_log.info(f"while deleting wip table -- opwi_defect_cm_wip_{self.query_data['projectid']}")
                
            status = {'msg': 'commonality updated'}
        except Exception as e:
            app_log.info(
                f"Exception while calculating commonality: {e.__class__.__name__} {e}")
            status = {
                'msg': f"Exception while calculating commonality: {e.__class__.__name__} {e}"}

        raise Return(status)

    def __del__(self):
        """Closing the connection."""
        self.connection.close()
