import tornado, json
from tornado.gen import coroutine
from tornado.escape import json_decode

from api.commonality.commonality_api.commonalitymodel import Commonality
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class CommonalityHandler(BaseHandler):

    @coroutine
    def post(self):
        '''return the commonality data'''
        commonality = Commonality()
        resp = commonality.get_commonality(json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        '''Updates the commonality data'''
        commonality = Commonality()
        resp = commonality.update_commonality(json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
