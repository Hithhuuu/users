nohup python3 api\commonality\server.py --port=8120 --env=dev --service=commonality
nohup python3 api\commonality\server.py --port=8121 --env=dev --service=commonality
nohup python3 api\commonality\server.py --port=8122 --env=dev --service=commonality

