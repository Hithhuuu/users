import tornado
from api.commonality.commonality_api.commonalityhandler import CommonalityHandler
from api.copyclassification.copyclassification_api.copyclassificationhandler import CopyClassificationHandler

services = {
    'commonality': [
        tornado.web.url(r"/commonality", CommonalityHandler),
        tornado.web.url(r"/copyclassification", CopyClassificationHandler)
    ],
}