import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode

from tornado.escape import json_decode
from tornado.gen import coroutine
from api.share.share_api.sharemodel import Shared
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()


class ShareHandler(BaseHandler):

 
    def get(self):
        cby = self.get_argument('cby', None)
        projectid = self.get_argument('projectid', None)
        shared_obj = Shared()
        resp = shared_obj.get(
            data={'projectid': projectid, 'cby': cby})._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def post(self):
        shared_obj = Shared()
        resp = shared_obj.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        shared_obj = Shared()
        resp = shared_obj.update(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        '''
        sample json
        {
            'projectid': '',
            'userid': ''
        }
        '''
        shared_obj = Shared()
        shared_obj.delete(data=json_decode(self.request.body))
        self.set_header("Content-Type", self.content_type)
        self.write({'msg': 'deleted'})

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
