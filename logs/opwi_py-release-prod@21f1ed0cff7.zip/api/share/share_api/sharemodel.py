import pandas as pd
import time
from tornado.gen import coroutine, Return

from api.utils.utils import queries2, get_dbconnection, get_logger
from api.utils.common import execute_query

app_log = get_logger("share")
class Shared:
    def __init__(self):
        self.connection = get_dbconnection()
        self.queries = queries2['share']

    @coroutine
    def get(self, data):
        df = execute_query(self.connection, self.queries['read'].format(
            **data), 'all', 'df')
        raise Return(df.to_json(orient='records'))

    @coroutine
    def create(self, data):
        df = execute_query(self.connection, self.queries['fetch_shared_count'].format(**data), 'all', 'df')
        if df.shape[0] > 0:
            """Delete shared accesses if any"""
            self.delete(data)
        """Insertion of shared project"""
        execute_query(self.connection,self.queries['insert'].format(**data),'')
        raise Return(self.get(data)._result)

    @coroutine
    def update(self, data):
        """update RoleShare for specific projectId"""
        execute_query(self.connection,self.queries['update'].format(**data),'')
        raise Return(self.get(data)._result)

    @coroutine
    def delete(self, data):
        """Deletion of shared project"""
        data['powner'] = data['userid']
        app_log.info(f"shared delete query: {self.queries['delete'].format(**data)}")
        execute_query(self.connection,self.queries['delete'].format(**data),'')
        execute_query(self.connection,self.queries['user_activity_delete'].format(**data),'')

    def __del__(self):
        self.connection.close()
