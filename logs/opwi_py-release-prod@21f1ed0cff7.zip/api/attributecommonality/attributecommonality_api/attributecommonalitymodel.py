from itertools import permutations
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger
from api.utils.common import execute_query

app_log = get_logger("attributecommonality")

class DeleteError(Exception):
    def __init__(self, msg):
        self.msg = msg
        super().__init__(self.msg)
class AttributeCommonality():
    def __init__(self):
        """Initialize Reclassification"""
        self.connection = connection_pool.connect()
        self.queries = queries2['attributecommonality']
        self.query_data = dict()
        self.qlist, self.qlist1 =[], []

    def create_attributecommonality_table(self, projectid, tbl_type='main'):
        try:
            app_log.info(f"Creating the Attribute Commonality table for projectid: {projectid}")
            #check whether table already exists
            app_log.info(f"Checking if table already exists")
            table_exists_query = self.queries[f'table_exists_{tbl_type}'].format(**{'projectid': projectid})
            
            app_log.info(f"Table Exists Query: {table_exists_query}")
            status = execute_query(self.connection, table_exists_query, 'one')[0]
            if status == 1:
                app_log.info(f"Table exists")
                truncate_query =  self.queries[f"truncate_{tbl_type}"].format(**{'projectid': projectid})
                app_log.info(f"truncating the table: {truncate_query}")
                # cursor.execute(truncate_query)
                execute_query(self.connection, truncate_query,'')
            else:
                create_query = self.queries[f"create_table_{tbl_type}"].format(**{'projectid': projectid})
                app_log.info(f"Table creation query is {create_query}")
                # cursor.execute(create_query)
                execute_query(self.connection, create_query,'')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info("Error while creating the table")
            raise RuntimeError(e)


    @coroutine
    def update_commonality(self, data):
        """delete and insert the attributecommonality data into clickhouse table"""
        try:
            self.query_data['projectid'] = data['projectid']
            self.query_data['radius'] = data['inputs'].get('radius', 5000)
            self.query_data['mapid'] = tuple(data['mapids'])
            mapids = list(permutations(data['mapids'], 2))
            orientation = data['inputs'].get('orientationmarklocation', 'DOWN').lower()
            self.query_data['orientation'] = orientation
            self.query_data['offset_mapid'] = tuple(data['inputs'].get('selectedMaps')) if len(data['inputs'].get('selectedMaps', '')) > 0 else tuple(data['values']['mapid'])

            self.create_attributecommonality_table(self.query_data['projectid'])
            self.create_attributecommonality_table(self.query_data['projectid'], 'wip')

            app_log.info(f"Inserting attributecommonality data into opwi_defect_scm_wip_{self.query_data['projectid']}")
            for i in mapids:
                self.query_data['mapid1'] = str(i[0])
                self.query_data['mapid2'] = str(i[1])
                select_wip = self.queries['select_wip'].format(**self.query_data)
                if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                    select_qry = self.queries['select_qry'].format(**self.query_data)
                    self.qlist1.append(select_qry)
                self.query_data['select_wip'] = select_wip
                insert_wip_query = self.queries['insert_wip'].format(**self.query_data)
                app_log.info(f"Insert wip query: {insert_wip_query}")
                execute_query(self.connection, insert_wip_query,'')
                insert_scm_query = self.queries['insert_scm'].format(**{
                    'select_qry': select_qry,
                    'projectid': self.query_data['projectid']})
                
                app_log.info(f"Insert_scm query: {insert_scm_query}")
                execute_query(self.connection, insert_scm_query, self.query_data['projectid'])

            try:
                # delete wip table 
                wip_table_delete_query = f"drop table rawcm.opwi_defect_scm_wip_{self.query_data['projectid']}"
                execute_query(self.connection, wip_table_delete_query, '')
            except Exception as e:
                app_log.info(f"while deleting wip table -- opwi_defect_scm_wip_{self.query_data['projectid']}")


            status = {'msg': 'attributecommonality updated'}
        except Exception as e:
            app_log.info(
                f"Exception while calculating attributecommonality: {e.__class__.__name__} {e}")
            status = {
                'msg': f"Exception while calculating attributecommonality: {e.__class__.__name__} {e}"}

        raise Return(status)

    def __del__(self):
        """Closing the connection."""
        self.connection.close()
