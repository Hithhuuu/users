from tornado.gen import coroutine
from tornado.escape import json_decode
from api.attributecommonality.attributecommonality_api.attributecommonalitymodel import AttributeCommonality
from api.utils.common import  zlib1,BaseHandler
import json
zlib_obj = zlib1()

class AttributeCommonalityHandler(BaseHandler):

    @coroutine
    def put(self):
        '''Updates the attributecommonality data'''
        attributecommonality = AttributeCommonality()
        resp = attributecommonality.update_commonality(json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
