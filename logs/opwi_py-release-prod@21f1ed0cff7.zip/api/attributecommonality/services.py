import tornado
from api.attributecommonality.attributecommonality_api.attributecommonalityhandler import AttributeCommonalityHandler


services = {
'attributecommonality': [
        tornado.web.url(r"/attributecommonality", AttributeCommonalityHandler)
    ],
}