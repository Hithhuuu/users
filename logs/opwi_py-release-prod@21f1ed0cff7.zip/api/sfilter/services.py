import tornado
from api.sfilter.sfilter_api.sfilterhandler import SecondaryFilterHandler, ClassificationFilterHandler,saveclasscolorHandler

services = {
    'sfilter': [
        tornado.web.url(r"/sfilter", SecondaryFilterHandler),
        tornado.web.url(r"/sfilter/saveclasscolor", saveclasscolorHandler),
        tornado.web.url(r"/sfilter/classifications", ClassificationFilterHandler),
    ],
}
