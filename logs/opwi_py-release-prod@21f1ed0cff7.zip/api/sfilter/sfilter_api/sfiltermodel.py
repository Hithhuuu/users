import json
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import (queries2, get_logger, connection_pool, get_columns_info,
                         columns_info, getdbconnection as con)
from api.utils.common import execute_query, get_rmapid

app_log = get_logger('sfilter')


class Sfilter():
    '''User operations base class'''

    def __init__(self):
        '''Initializaing User instance'''
        self.connection = connection_pool.connect()
        self.queries = queries2['sfilter']
        self.attribute_cols = columns_info['attribute_fields']
        self.sfilter_config = get_columns_info()['s_filter_attrs']
        self.attribute_chart_config = get_columns_info()[
            'attribute_chart_filters']
        self.histogram_config = get_columns_info()[
            'histogram_filters']['xaxis']
        self.not_null_cols = []
        self.mapids_tuple = None
        self.mapping_data = None
        self.fields = None
    
    def get_pareto_type(self):
        return self.sfilter_config['pareto_type']

    @coroutine
    def get_maps(self, projectid):
        """ Returns the maps for the given project """
        app_log.info("START: get_maps function")
        query = self.queries['filter_map'].format(**{'projectid': projectid})
        app_log.info(f"Get Maps Query: {query}")
        
        maps = execute_query(self.connection, query, 'all', 'df')
        maps['diepitch'] = maps.pop("diepitch_x").astype(
            str) + ", " + maps.pop("diepitch_y").astype(str)
        app_log.info("END: get_maps function")
        raise Return(maps.to_dict(orient='records'))

    @coroutine
    def get_classifications(self, projectid):
        """ 
        Get the classnumber and group relationship for the given projectid and selected maps.
        """
        from collections import defaultdict
        if self.mapids_tuple is None:
            maps = self.get_maps(projectid)._result
            self.get_mapids(maps)

        query = self.queries['classifications'].format(
            **{'projectid': projectid, 'mapid': self.mapids_tuple})
        """ Fetch the class and group relationship data for the given project and selected maps"""
        app_log.info(f"Classification Query: {query}")
        classification_data = execute_query(self.connection, query, 'all', 'df').to_dict(orient='records')
        default_data = defaultdict(list)
        for data in classification_data:
            di = {k: v for (k, v) in data.items() if k != 'groupname'}
            default_data[data['groupname']].append(di)
        classification_dict = dict(default_data)
        """ Make final classification data """
        final_classification_data = []
        for key, value in classification_dict.items():
            di = {'groupname': key, 'classes': value, 'count': sum(
                [i['cnt'] for i in value if i.get('cnt', 0)])}
            final_classification_data.append(di)
        app_log.info("END: get_classifications function")
        raise Return(final_classification_data)

    def get_appearances(self, projectid):
        """ 
        Get the appearances of defects in the defects for given project id 
        """
        from collections import defaultdict
        rmapid = get_rmapid(self.connection, projectid) 
        mapids = self.mapids_tuple
        smapid = [i for i in mapids if i != rmapid]
        smapid = tuple(smapid + [0]) if len(smapid) > 0 else "null"
        query = self.queries['appearances'].format(
            **{'projectid': projectid, 'rmapid': rmapid, 'smapid': smapid})
        app_log.info(f"Appearances Query: {query}")
        appearances_data = execute_query(self.connection, query, 'all', 'df')['appearances'].to_list()
        app_log.info("END: get_appearances function")
        return(appearances_data)

    def get_pareto_attributes(self):
        """ Get Pareto attributes from  config file """
        return self.sfilter_config['pareto_filters']

    def check_null_columns(self, projectid):
        null_cols_query = f"select null_cols from opwi_map_header final where rfg=1 and mapid in (select mapid from " \
                          f"opwi_myproject_maps final where rfg=1 and projectid = {projectid})"
        app_log.info(f"Null cols query: {null_cols_query}")
        
        key=execute_query(self.connection,null_cols_query)
        null_cols = []
        
        for i in key:
            if i[0] != '':
                null_cols.extend(i[0].split(","))

        selected_columns = [
            key for key in columns_info["attribute_fields"] if key.lower() in null_cols]
        selected_columns.extend(["defectid", "mapid", "refcm", "mapname"])
        return selected_columns

    def get_scatterplot_attributes(self, projectid):
        """ Get the scatterplot attributes from config file """
        not_null_cols = self.not_null_cols
        scatterplot_attributes = {
            "x_axis":  [i for i in columns_info['scatter_plot_attr'] if i['value'].lower() in not_null_cols],
            "y_axis": [i for i in columns_info['scatter_plot_attr'] if i['value'].lower() in not_null_cols]
        }
        return scatterplot_attributes

    def get_defect_attributes(self):
        """ Get the defect attributes from the config file """
        return self.sfilter_config['defect_attributes']

    def get_grouping_attributes(self, data):
        shape_by = self.sfilter_config['grouping']['shape_by']
        volume_by = self.sfilter_config['grouping']['volume_by']
        
        '''
        shape_by_query = " union all ".join([self.queries['null_columns'].format(**{'col': i['value'], 'projectid':data.get('projectid')})
                                             for i in [item for item in shape_by if item['value'] in list(columns_info['main_cols'].keys())]])
        volume_by_query = " union all ".join([self.queries['null_columns'].format(**{'col': i['value'], 'projectid':data.get('projectid')})
                                              for i in [item for item in volume_by if item['value'] in list(columns_info['main_cols'].keys())]])
        app_log.info(f"Shape Query: {shape_by_query}")
        app_log.info(f"Volume Query: {volume_by_query}")
        #cursor.execute(shape_by_query)
        #shape_by_output = [i[0] for i in cursor.fetchall()]
        #app_log.info(f"Shape Output: {shape_by_output}")
        #cursor.execute(volume_by_query)
        #volume_by_output = [i[0] for i in cursor.fetchall()]
        #app_log.info(f"Volume Output: {volume_by_output}")
        '''

        shape_by_output = [i['value']
                           for i in shape_by if i['value'] in self.not_null_cols]
        app_log.info(f"Shape Output: {shape_by_output}")
        volume_by_output = [i['value']
                            for i in volume_by if i['value'] in self.not_null_cols]
        app_log.info(f"Volume Output: {volume_by_output}")

        self.sfilter_config['grouping']['shape_by'] = [
            i for i in shape_by if i['value'] in shape_by_output]
        self.sfilter_config['grouping']['volume_by'] = [
            i for i in volume_by if i['value'] in volume_by_output]

        return self.sfilter_config['grouping']

    @coroutine
    def get_distinct_data(self, attr, data):
        query = self.queries['attribute_filters'].format(**data)
        resp = {"values": execute_query(self.connection, query, 'all', 'df')[attr].to_list(),
                'type': 'range'}
            
        raise Return(resp)

    @coroutine
    def get_fieldstacking_values(self, project_id):
        query = f"select fieldx, fieldy, fieldoriginx, fieldoriginy from opwi_myprojects final where projectid={project_id};"
        app_log.info(f"field stacking values: {query}")
        df = execute_query(self.connection, query, 'all', 'df')
        if df.shape[0] <= 0:
            raise Return({})
        raise Return(df.to_dict(orient='records')[0])

    @coroutine
    def get_attribute_filters(self, data):
        """ Get Attribute Filters parameters
        1. Get the attribute filters params from config
        2. Return the values as per the type of parameter
        3. Update the type in the response
        """
        response = {}
        response_final = {}
        commonality_filter = columns_info['attributes_fields_commonality']
        for item in commonality_filter:
            response_final.update(
                {
                    item['value']: {
                        "values": item['values'],
                        "type": item['type'],
                        "label": item['label']
                    }
                }
            )
        # Range Item
        attribute_range_items = [
            key for key, value in self.attribute_cols.items() if value == 'range' and (key in list(columns_info['main_cols'].keys()) or key == 'appearances')]
        '''
        attribute_fillter_query = " union all ".join([self.queries['null_columns'].format(**{'col': i, 'projectid': data.get('projectid')})
                                                      for i in attribute_range_items])
        app_log.info(f"attribute_fillter_query: {attribute_fillter_query}")

        
        
        print(f"New Attributes: {new_attribute_by_output}")
        cursor = self.connection.cursor()
        cursor.execute(attribute_fillter_query)
        attribute_by_output = [i[0] for i in cursor.fetchall()]
        '''
        # Modifying here to optimize the sfilter taking the data from header table
        app_log.info(attribute_range_items)
        attribute_by_output = [
            i for i in self.not_null_cols if i in attribute_range_items]
        attribute_by_output.append("appearances")
        app_log.info(attribute_by_output)

        # Using the variable instead of calling the function
        mapping = self.mapping_data  # self.get_mapping(data)

        attrs = {i['value']: i['label']
                 for i in columns_info['attribute_fields_wip']}
        for key in attribute_by_output:
            response.update({key: {
                "values": {"min": 0, "max": 0},
                "type": "range",
                "label": attrs.get(key, "")
            }})

        # Dropdown
        
        attr_query = "select '{0}' as colname, toString({0}) as data from opwi_defect_main final where mapid in {1} group" \
                     " by {0} order by {0} asc"

        dropdown_list = [
            key for key, value in self.attribute_cols.items() if value == "multidropdown"]
        drop_down_items = [attr_query.format(
            key, self.mapids_tuple) for key in dropdown_list]

        union_query = " union all ".join(drop_down_items)
        app_log.info(f"Drop Down list Query: {union_query}")
        
        df = execute_query(self.connection, union_query, 'all', 'df')
        df = df.dropna()
        fg = {key: {"values": "", "type": "multidropdown", "label": attrs.get(key, "")}
              for key in df.colname.unique()}
        for key in fg.keys():
            fg[key]['values'] = df.loc[df['colname'] == key]['data'].astype(
                columns_info['main_cols'][key]).to_list()

            if key == 'classnumber':
                fg[key]['mapping'] = mapping[key]
            if key == 'otype':
                fg[key]['mapping'] = mapping[key]
        
        response.update(fg)
        response_final.update({i: response[i] for i in list(
            columns_info['attribute_fields'].keys()) if response.get(i)})
        raise Return(response_final)

    def get_attribute_chart_filters(self, data, maps):
        """ Get the attribute chart filters paramters for the project """
        attribute_filters = self.attribute_chart_config
        '''
        cursor = self.connection.cursor()
        attribute_filters_query = " union all ".join(
            [self.queries['null_columns'].format(**{'col': i['value'], 'projectid': data.get('projectid')})
             for i in [item for item in attribute_filters if item['value'] in list(columns_info['main_cols'].keys())]])
        cursor.execute(attribute_filters_query)
        attribute_filters_output = [i[0] for i in cursor.fetchall()]
        '''
        attribute_filters_output = [
            item['value'] for item in attribute_filters if item['value'] in self.not_null_cols]
        self.attribute_chart_config = [
            i for i in attribute_filters if i['value'] in attribute_filters_output]
        resp = {
            'attribute': self.attribute_chart_config,
            'primary': maps,
            'secondary': maps
        }
        return resp

    def get_defualt_otf_config(self, projectid):
        image_list = {
            'cur_bf': 300,
            'cur_gf': 301,
            'cur_unknown': 30
        }

        for key,code in image_list.items():
            read_query = self.queries['read_imagelist'].format(**{'projectid':projectid ,'code':code})
            result =  execute_query(self.connection, read_query,resptype='df')
            if not result.empty:
                return {'code': code, 'key': key}

        return {'code': 300, 'key': 'cur_bf'}

    def get_histogram_filters(self, data):
        """ Get Histogram filter parameters """
        histogram = self.histogram_config
        '''
        cursor = self.connection.cursor()
        histogram_query = " union all ".join([self.queries['null_columns'].format(**{'col': i['value'], 'projectid':data.get('projectid')})
                                              for i in [item for item in histogram if item['value'] in list(columns_info['main_cols'].keys())]])
        app_log.info(f"Histogram Query: {histogram_query}")
        cursor.execute(histogram_query)
        histogram_output = [i[0] for i in cursor.fetchall()]
        '''
        histogram_output = [item['value']
                            for item in histogram if item['value'] in self.not_null_cols]
        self.histogram_config = [
            i for i in histogram if i['value'] in histogram_output]
        return {'x_axis': self.histogram_config}

    def get_binning_attr(self):
        """ Get binning attribute filter parameters. """
        binning_data = self.sfilter_config['binning']
        attributes = [item for item in self.sfilter_config['binning']['attributes']
                      if columns_info['binning_config'].get(item['value']) != 'None']
        binning_data['attributes'] = attributes
        return binning_data

    def get_far_cnt(self, data):
        '''Return FAR calculation for all maps'''
        app_log.info("START: get_far_count function")
        app_log.info(
            f"GET FAR count query: {self.queries['far_cnt'].format(**{'projectid': data['projectid'], 'mapid': self.mapids_tuple})}")
        
        df = execute_query(self.connection, self.queries['far_cnt'].format(
            **{'projectid': data['projectid'], 'mapid': self.mapids_tuple}), 'all', 'df')
        app_log.info("END: get_far_count function")
        return df.set_index('mapid').to_dict(orient='index')

    def get_mapping(self, data):
        '''Returns mapping data for class and types'''
        if data['projectid'] == 0:
            data['projectid'] = "Null"
        app_log.info(
            f"class mapping: {self.queries['class_mapping'].format(**data)}")
        data =execute_query(self.connection,self.queries['class_mapping'].format(**data))
        class_mapping = data
        class_mapping = {k: v for k, v in class_mapping}
        return {
            'classnumber': class_mapping,
            'otype': columns_info['Histogram']['Attribute header']
        }

    def get_mapids(self, maps):
        mapids = []
        null_cols = []
        fields = dict()
        for row in maps:
            mapids.append(row['mapid'])
            null_cols.extend(row.pop('null_cols', None).split(','))
            fields = {
                'fieldx': row.pop('fieldx', None),
                'fieldy': row.pop('fieldy', None),
                'fieldoriginx': row.pop('fieldoriginx', None),
                'fieldoriginy': row.pop('fieldoriginy', None)
            }

        print(null_cols)
        self.mapids_tuple = tuple(mapids)
        self.not_null_cols = set(null_cols)
        self.fields = fields
        app_log.info(self.mapids_tuple)
        app_log.info(self.not_null_cols)
        app_log.info("**"*10)
        app_log.info(fields)
        app_log.info(maps)
        app_log.info("**" * 10)

    def get_class_colormapping(self, data):
        project_id = dict()
        resp  = {}
        project_id['projectid'] =  data.get('projectid')
        classcolormap =execute_query(self.connection,self.queries['classcolormap'].format(**project_id),resptype='list')
        classcolormap = json.loads(tuple(classcolormap[0].values())[0] if len(classcolormap[0].values())>0 else '') if len(classcolormap)>0 else {}
        if len(classcolormap)>0:
            classnumber =execute_query(self.connection,self.queries['classnumber'].format(**project_id),resptype='df')
            classnumber = classnumber['classnumber'].to_list()
            for i ,k in classcolormap.items():
                if int(i) in classnumber:
                    resp.update({i:k})
        return resp

    @coroutine
    def get_filters(self, data):
        '''
            Returns list of attributes and parameters for secondary filtering 

            1. maps
            2. classifications
            3. attribute filters
            4. field stacking values
            5. grouping
            6. pareto 
            7. scatter plot 
            8. defect attributes 
            9. binning  
            10. attribute_chart filters
            11. histogram
        '''
        p_id = data.get('projectid')
        if p_id != 0:
            self.mapping_data = self.get_mapping(data)
            maps = self.get_maps(projectid=p_id)._result
            self.get_mapids(maps)

            response = {
                'maps': maps,
                'classifications': self.get_classifications(projectid=p_id)._result,
                'attribute_filters': self.get_attribute_filters(data)._result,
                # self.get_fieldstacking_values(p_id)._result,
                'field_stacking_values': self.fields,
                # Using the variable instead of calling the function
                'mapping': self.mapping_data
            }
            # originalmapname, alias
            maps = [{
                "label": m['mapname'].split('|')[4],
                "value": m['mapid'],
                "originalmapname": m['mapname'].split('|')[4],
                "alias": m['alias']
            } for m in response.get('maps')]

            response.update({
                "grouping": self.get_grouping_attributes(data),
                "pareto": self.get_pareto_attributes(),
                "scatter_plot": self.get_scatterplot_attributes(p_id),
                "defect_attributes": self.get_defect_attributes(),
                "binning": self.get_binning_attr(),
                "attribute_chart": self.get_attribute_chart_filters(data, maps),
                "histogram": self.get_histogram_filters(data),
                "mapname": maps,
                "far": self.get_far_cnt(data),
                "pareto_type": self.get_pareto_type(),
                "classcolormapping": self.get_class_colormapping(data),
                "otf_default_config": self.get_defualt_otf_config(p_id)
            })
        else:
            response = {
                'maps': [],
                'classifications': [],
                'attribute_filters': None,
                # self.get_fieldstacking_values(p_id)._result,
                'field_stacking_values': {},
                # Using the variable instead of calling the function
                'mapping': self.mapping_data,
                'classcolormapping': {}
            }
            response.update({
                "grouping": self.get_grouping_attributes(data),
                "pareto": self.get_pareto_attributes(),
                "scatter_plot": {"x_axis": [], "y_axis": []},
                "defect_attributes": self.get_defect_attributes(),
                "binning": self.get_binning_attr(),
                "attribute_chart": {"attribute": [], "primary": [], "secondary": []},
                "histogram": {"x_axis": []},
                "mapname": [],
                "far": {},
                "pareto_type": [],
                "otf_default_config": {}
            })

        raise Return(response)

    @coroutine
    def get_class_count(self, data):
        response = []
        try:
            projectid = data.get('projectid')
            self.mapids_tuple = tuple(data.get('mapid', []))
            response = self.get_classifications(projectid)._result
        except Exception as e:
            app_log.error("Error while fetching the classifications")
            app_log.exception(e)
        raise Return(response)

    def __del__(self):
        self.connection.close()
