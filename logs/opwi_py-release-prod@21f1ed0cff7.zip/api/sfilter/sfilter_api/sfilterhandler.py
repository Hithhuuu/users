import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.sfilter.sfilter_api.sfiltermodel import Sfilter
from api.sfilter.sfilter_api.saveclasscolour import Classcolor
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class SecondaryFilterHandler(BaseHandler):
    @coroutine
    def post(self):
        sfilter = Sfilter()
        resp = sfilter.get_filters(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()


class ClassificationFilterHandler(BaseHandler):
    @coroutine
    def post(self):
        sfilter = Sfilter()
        resp = sfilter.get_class_count(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()


class saveclasscolorHandler(BaseHandler):


    @coroutine
    def put(self):
        """Add new class to opwi_map_class table"""
        color = Classcolor()
        data = json_decode(self.request.body)
        self.set_header("Content-Type", self.content_type)
        resp=color.save_class_color(data)._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
    def options(self):
        self.set_status(204)
        self.finish()