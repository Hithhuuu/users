import pandas as pd
import json
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool
from api.utils.utils import get_logger, getdbconnection
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, execute_query

app_log = get_logger("reclassification")


class Classcolor:
    def __init__(self):
        """Initialize save class color"""
        self.connection = connection_pool.connect()
        self.queries = queries2['sfilter']
        self.dbconn = getdbconnection()
    
    @coroutine
    def save_class_color(self,data):
        try:
            resp = dict()
            query_data = {
                'projectid' : data.get('projectid') if data.get('projectid') else '',
                'classnumbercolormapping' : json.dumps(data.get('classcolormapping')) if data.get('classcolormapping') else '',
            }
            query_to_execute = self.queries['rfg_class_color'].format(**query_data)
            app_log.info(query_to_execute)
            execute_query(self.connection,query_to_execute,'')
            
            query1 = self.queries['class_color'].format(**query_data)
            app_log.info(query1)
            execute_query(self.connection,query1,'')
            resp  = data.get('classcolormapping')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f"Error: {e}")
            resp = {"error": str(e)}
        raise Return(resp)

    def __del__(self):
        """Closing the connection."""
        self.connection.close()