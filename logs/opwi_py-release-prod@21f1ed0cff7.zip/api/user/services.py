
import tornado
from api.user.user_api.userhandler import UserHandler
from api.user.user_api.authhandler import AuthHandler
from api.user.user_api.activityhandler import ActivityHandler
from api.generic.generic_api.refreshhandler import RefreshHandler
from api.user.user_api.changepasswordhandler import ChangePasswordHandler

services = {
    'user_authentication': [
        tornado.web.url(r"/auth", AuthHandler),
        tornado.web.url(r"/auth/refresh", RefreshHandler),
        tornado.web.url(r"/user", UserHandler),
        tornado.web.url(r"/user/changepassword",ChangePasswordHandler),
        tornado.web.url(r"/activity", ActivityHandler)
    ],
}