nohup python3 api\user\server.py --port=8000 --env=dev --service=user_authentication
nohup python3 api\user\server.py --port=8001 --env=dev --service=user_authentication