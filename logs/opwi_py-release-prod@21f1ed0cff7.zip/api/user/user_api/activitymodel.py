import time
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger
from api.utils.common import execute_query

app_log = get_logger('activity')
class Activity():

    def __init__(self):
        '''Initialize Project.'''
        self.connection = connection_pool.connect()
        self.queries = queries2['user']

    @coroutine
    def create(self, data):
        '''Create new activity'''
        try:
            data['action'] = 'created'
            data['reftype'] = 'project'
            self.delete(data)
            execute_query(self.connection,self.queries['create_activity'].format(**data),'')
        except  Exception as e:
            return {"error": str(e)}
        raise Return({'msg': 'Activity created'})

    @coroutine
    def update(self, data):
        '''update an activity'''
        try:
            df = execute_query(self.connection, self.queries['read_activity'].format(**data), 'all', 'df')
            
            if df.shape[0] > 0:
                data['action'] = 'created'
                data['refid'] = data['projectid']
                app_log.info(f"Update Query: {self.queries['update_activity'].format(**data)}")
                execute_query(self.connection,self.queries['update_activity'].format(**data),'')
            else:
                self.create(data)
        except Exception as e:
            return {"error": str(e)}
        raise Return({'msg': 'Activity updated'})

    @coroutine
    def delete(self, data):
        '''Delete an activity'''
        try:
            app_log.info(f"delete_activity query :{self.queries['delete_activity'].format(**data)}")
            execute_query(self.connection,self.queries['delete_activity'].format(**data),'')
            self.connection.commit()
        except Exception as e:
            return {"error": str(e)}
        raise Return({'msg': 'Activity deleted'})

    def __del__(self):
        '''Closing the DB connection'''
        self.connection.close()
