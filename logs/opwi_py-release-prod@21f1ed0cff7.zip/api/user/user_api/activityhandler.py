import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.user.user_api.activitymodel import Activity
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class ActivityHandler(BaseHandler):
 

    @coroutine
    def get(self):
        """
        Read User Project Activity
        Sample request data:
        userid = powner
        projectid = Project id
        """
        activity = Activity()
        filter_type = self.get_argument("filter_type", None)
        resp = activity.get(
            data={"powner": self.get_argument("powner")}, filter_type=filter_type
        )._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def post(self):
        """
        Create new activity for user actions
        Sample request data: 
            1. userid = powner
            2. action = created
            3. refid = projectid
            4. reftype = project
            5. udt = Now()
        """
        activity = Activity()
        resp = activity.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        """
        Update user activity
        Sample request data:
            1. userid = powner
            2. action = updated
            3. refid = projectid
            4. reftype = project
            5. udt = Now()
        """
        activity = Activity()
        data = json_decode(self.request.body)
        resp = activity.update(data=data)._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        """
        Delete user activity
        Sample request data:
            1. userid = powner
            2. refid = projectid
        """
        activity = Activity()
        resp = activity.delete(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
