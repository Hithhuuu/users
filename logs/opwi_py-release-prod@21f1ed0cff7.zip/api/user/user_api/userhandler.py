import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.user.user_api.usermodel import Users
from api.utils.utils import get_logger
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()
app_log = get_logger('user')

class UserHandler(BaseHandler):
  
    @coroutine
    def get(self):
        ''' Get all Users '''
        user = Users()
        self.set_header("Content-Type", self.content_type)
        resp=user.get()._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    @coroutine
    def post(self):
        ''' Create new User '''
        user = Users()
        resp = user.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        ''' Update User Details '''
        user = Users()
        resp = user.update(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        ''' Delete User from the application '''
        user = Users()
        user.delete(data=json_decode(self.request.body))
        self.set_header("Content-Type", self.content_type)
        self.write(user.get()._result)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
