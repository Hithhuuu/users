import time
import json
import bcrypt
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, get_logger, connection_pool, decrypt, env_config
from api.utils.common import execute_query

app_log = get_logger('user')


class Users():

    def __init__(self):
        '''Initializing User instance'''
        self.connection = connection_pool.connect()
        self.queries = queries2['user']

    @coroutine
    def get(self):
        '''Get list of users'''
        try:
            app_log.info('Get list of users')
            app_log.info(self.queries['read'])
            data = execute_query(self.connection, self.queries['read'], 'all', 'df')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return(data.to_json(orient='records'))

    def get_password(self, password):
        ''' Decode the Users password '''
        salt = bcrypt.gensalt()
        password = bcrypt.hashpw(password.encode(), salt)
        return password.decode()

    @coroutine
    def create(self, data):
        '''creates new user'''
        try:
            app_log.info('Create user')
            ''' Check user exists '''
            user_exists_query = self.queries['user_exists'].format(**data)
            app_log.info(f'USER EXISTS QUERY: {user_exists_query}')
            
            users = execute_query(self.connection, user_exists_query, 'one')
            exists = False if len(users) == 0 else True
            if exists:
                return ({'msg': 'user exists'})
            ''' Encrypt user password '''
            data['password'] = self.get_password(data['password'])
            ''' Create new user '''
            user_create_query = self.queries['create'].format(**data)
            app_log.info(f'USER CREATE QUERY: {user_create_query}')
            execute_query(self.connection, user_create_query, '')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return({'msg': 'user created'})

    def prepare_query(self, data):
        query_data = {
            'userid':data.get('userid'),
            'preferedname': data.get('preferedname', 'preferedname'),
            'firstname': data.get('firstname', 'firstname'),
            'lastname': data.get('lastname', 'lastname'),
            'email': data.get('email', 'email'),
            'assignedrole': data.get('assignedrole', 'assignedrole'),
            'uby': data.get('uby', 'uby'),
        }
        return query_data

    @coroutine
    def update(self, data):
        '''Update user record'''
        try:
            app_log.info('Update User Record')
            
            query_data = self.prepare_query(data)
            query_data.update({
                'password': f"'{self.get_password(data['password'])}' as password" if data.get('password') else 'password'
            })
            user_update_query = self.queries['update'].format(**query_data)
            app_log.info(f"USER UPDATE QUERY: {user_update_query}")
            execute_query(self.connection,user_update_query,'')
            self.connection.commit()
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return(self.get()._result)

    def prepare_query_changepassword(self, data):
        query_data = []

        for key, value in data.items():
            if key == "isactive":
                rfg = 1 if data.get('isactive') == "Y" else 2
                query_data.append(f"rfg = '{rfg}'")
            elif key == "isadmin":
                assignedrole = "normal user" if data.get(
                    'isadmin') == "N" else "admin"
                query_data.append(f"assignedrole = '{assignedrole}'")
            elif key != "userid" and key != "udt" and key != "cdt" and key != "currentPassword":
                query_data.append(
                    f"{key} = '{value}'"
                )
        return " , ".join(query_data)

    @coroutine
    def changepassword(self, data):
        '''Update user record'''
        try:
            app_log.info('Update User Record')
            data = json.loads(decrypt(data['encryptedData'], bytes(env_config["password_secret_key"], 'utf-8')).
                              decode("utf-8"))
            cursor = self.connection.cursor()
            app_log.info('Authenticating users')
            user_auth_query = self.queries['authenticate'].format(**data)
            app_log.info(f"USER AUTH QUERY: {user_auth_query}")
            user_data = pd.read_sql(
                user_auth_query, self.connection).to_dict(orient='records')
            if len(user_data) <= 0 or user_data[0]['rfg'] != 1:
                self.set_status(401)
                self.write({"error": "UserID not valid"})
                raise Return({"msg": f"UserID not valid"})
            user_data = user_data[0]
            if data.get("currentPassword", '') != '':
                pass_word = decrypt(data["currentPassword"], bytes(
                    env_config["password_secret_key"], 'utf-8')).decode("utf-8")
                ''' Verify user input password and user data password are equal or not '''
                if not bcrypt.checkpw(pass_word.encode(), user_data["password"].encode()):
                    raise Return(
                        {"msg": f"Current password is incorrect for user {data['userid']}."})
            if data.get('password'):
                pass_word = decrypt(data["password"], bytes(
                    env_config["password_secret_key"], 'utf-8')).decode("utf-8")
                data['password'] = self.get_password(pass_word)
            # TODO update active/inactive user
            query_data = self.prepare_query_changepassword(data)

            data['select_param'] = query_data
            user_update_query = self.queries['update_password'].format(**data)
            app_log.info(f"USER UPDATE QUERY: {user_update_query}")
            cursor.execute(user_update_query)
            self.connection.commit()
        except Exception as e:
            import traceback
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return{'error': str(e)}
        raise Return({"msg": f"user {data['userid']} updated successfully"})

    @coroutine
    def delete(self, data):
        '''Delete User'''
        try:
            app_log.info('Delete users')
            data['userid'] = "', '".join(data['userid'])
            user_delete_query = self.queries['delete'].format(**data)
            app_log.info(f'USER DELETE QUERY: {user_delete_query}')
            execute_query(self.connection,user_delete_query,'')
            self.connection.commit()
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}

    @coroutine
    def data(self, data):
        ''' Get the User details for Authentication '''
        try:
            app_log.info('Authenticating users')
            user_auth_query = self.queries['authenticate'].format(**data)
            app_log.info(f"USER AUTH QUERY: {user_auth_query}")
            user_data = execute_query(self.connection, user_auth_query, 'all', 'df').to_dict(orient='records')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return(user_data)

    @coroutine
    def check_password(self, user_password, requested_password):
        '''Check User password'''
        raise Return(bcrypt.checkpw(
            requested_password.encode(), user_password.encode()))

    @coroutine
    def __del__(self):
        '''On User Instance deletion'''
        self.connection.close()
