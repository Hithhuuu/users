import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.user.user_api.usermodel import Users
from api.utils.utils import get_logger
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()
app_log = get_logger('user')


class ChangePasswordHandler(BaseHandler):
   

    @coroutine
    def put(self):
        ''' Update User Password'''
        changepwd = Users()
        resp = changepwd.changepassword(data=json_decode(self.request.body))._result
        if 'error' in resp:
            self.set_status(400)
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
