import tornado
from jwt import encode
from tornado.gen import coroutine
from tornado.escape import json_decode
from datetime import datetime, timedelta
import binascii
import base64
from Crypto.Cipher import AES
from hashlib import md5
import json


from api.user.user_api.usermodel import Users
from api.utils.utils import env_config, encrypt


class AuthHandler(tornado.web.RequestHandler):
    ''' User Authentication Handler '''

    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header(
            "Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Authorization, Accept",
        )
        self.set_header(
            "Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS"
        )
        self.content_type = "application/json"
        self.key = 'c2VjcmV0cGFzc3dvcmRwaHJhc2U='

    def bytes_to_key(self, data, salt, output=48):
        '''converts bytes to key'''
        assert len(salt) == 8, len(salt)
        data += salt
        key = md5(data).digest()
        final_key = key
        while len(final_key) < output:
            key = md5(key + data).digest()
            final_key += key
        return final_key[:output]

    @staticmethod
    def unpad(data):
        '''unpad'''
        return data[:-(data[-1] if type(data[-1]) == int else ord(data[-1]))]

    def decrypt(self, password, key):
        '''Decrypts password'''
        password = base64.b64decode(password)
        assert password[0:8] == b"Salted__"
        salt = password[8:16]
        key_iv = self.bytes_to_key(key, salt, 32+16)
        key = key_iv[:32]
        iv = key_iv[32:]
        aes = AES.new(key, AES.MODE_CBC, iv)
        return self.unpad(aes.decrypt(password[16:]))

    @coroutine
    def post(self):
        """ Authentication Users with username and password """
        # try:
        user = Users()
        payload = json_decode(self.request.body)

        ''' Get the User data '''
        user_data = user.data(payload)._result
        if len(user_data) <= 0 or user_data[0]['rfg'] != 1:
            self.set_status(401)
            self.write({"error": "UserID not valid"})
            return
        user_data = user_data[0]
        pass_word = self.decrypt(payload["password"], bytes(env_config["password_secret_key"], 'utf-8')).decode("utf-8")
        
        ''' Verify user input password and user data password are equal or not '''
        if user.check_password(user_data["password"], pass_word)._result:
            self.to_encode = {
                "some": "payload",
                "userid": payload["userid"],
                "a": {2: True},
                "exp": datetime.utcnow() + timedelta(minutes=480),
            }
            self.encoded = encode(
                self.to_encode, env_config["secret_key"], algorithm="HS256"
            )
            jwt_key = self.encoded.decode(
                'utf-8') if (type(self.encoded) == bytes) else self.encoded
            response_data = dict(
                jwt=jwt_key,
                userid=user_data["userid"],
                username=user_data["email"],
                firstname=user_data["firstname"],
                isadmin="Y" if user_data["assignedrole"] == "admin" else "N",
                displayName=user_data["firstname"]+" "+user_data["lastname"],
                expiredAt= str(self.to_encode["exp"]),
            )
            response = {'encryptedData': encrypt(f'{response_data}'.replace('\'','\"'), bytes(env_config["password_secret_key"], 'utf-8')).decode('ascii')}
            self.write(response)
        else:
            self.set_status(401)
            self.write({"msg": "Authentication failed"})

    @coroutine
    def options(self):
        self.set_status(200)
        self.finish()
