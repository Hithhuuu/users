import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger, columns_info
from api.utils.common import commonality_query, execute_query, make_query, update_query, get_prep_level, prep_range_query_selectedmaps, get_commonality_filter

app_log = get_logger("Scatter_Plot")


class ScatterPlot():

    def __init__(self):
        '''Initialize Project.'''
        self.connection = connection_pool.connect()
        self.queries = queries2['scatterplot']
        self.defectlimit = 5000
        self.axis_columns = ('xrel', 'yrel', 'xindex', 'yindex')
        self.scatter_count = 20000

    def prepare_query_inputs(self, input_data, inputs, values, condition, orientation, commonality_filter):
        '''prepare query inputs'''
        scatterplot = inputs['scatter_plot']
        xaxis, yaxis = scatterplot['xaxis'], scatterplot['yaxis']
        xaxis_offset = xaxis
        yaxis_offset = yaxis
        if xaxis == 'xsite' and (inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1'):
            xaxis_offset = f"defects.xsite_{orientation}+rtn.offset_x"
        if yaxis == 'ysite' and (inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1'):
            yaxis_offset = f"defects.ysite_{orientation}+rtn.offset_y"

        if xaxis in self.axis_columns:
            if xaxis == 'xindex' and (inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1'):
                xaxis_offset = f"ROUND(((defects.xsite_{orientation} + rtn.offset_x) - defects.xrel_{orientation}) / rtn.diepitch_x_{orientation})"
                xaxis = f"{xaxis}_{orientation}"
            else:
                xaxis = f"{xaxis}_{orientation}"
                xaxis_offset = xaxis
        if yaxis in self.axis_columns:
            if yaxis == 'yindex' and (inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1'):
                yaxis_offset = f"ROUND(((defects.ysite_{orientation} + rtn.offset_y) - defects.yrel_{orientation}) / rtn.diepitch_y_{orientation})"
                yaxis = f"{yaxis}_{orientation}"
            else:
                yaxis = f"{yaxis}_{orientation}"
                yaxis_offset = yaxis

        data = {
            'mapid': tuple(values.get('mapid')),
            'fieldx': inputs.get('fieldx', 1),
            'fieldy': inputs.get('fieldy', 1),
            'diepitch_x': inputs.get('diepitch_x', 1),
            'diepitch_y': inputs.get('diepitch_y', 1),
            "xsite": f'xsite_{orientation}',
            "ysite": f'ysite_{orientation}',
            "condition": update_query(condition, orientation),
            "orientation": orientation,
            "prep_column": inputs.get('prep_column', None),
            "selected_maps": tuple(inputs.get('selectedMaps', '')),
            "count_condition": update_query(condition, orientation),
            "xaxis": xaxis,
            "yaxis": yaxis,
            "yaxis_offset": yaxis_offset,
            "xaxis_offset": xaxis_offset,
            "waferView": inputs.get('waferView', 'stack'),
            "offset": self.queries['offset_join'].format(
                **{"mapid": tuple(inputs.get('selectedMaps', '')), "orientation": orientation}) if inputs.get(
                'waferView', 'stack') != 'multi1' else '',
        }
        ''' Calculate Prep level '''

        data_count = data
        data_count['count_condition'] = data_count['count_condition'].replace(str(data['mapid']), str(
            data['selected_maps'])) if len(data['selected_maps']) != 0 else data['count_condition']


        commonality_query(input_data, commonality_filter, data_count)

        prep_data = get_prep_level(
            self.connection, data_count, limit=self.defectlimit)
        data['xsite'] = prep_data['xsite']
        data['ysite'] = prep_data['ysite']
        if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
            data['offset_columns'] = self.queries['offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation,
                "fieldx": data['fieldx'],
                "fieldy": data['fieldy'],
                "diepitch_x": data['diepitch_x'],
                "diepitch_y": data['diepitch_y']
            })
        else:
            data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation,
                "fieldx": data['fieldx'],
                "fieldy": data['fieldy'],
                "diepitch_x": data['diepitch_x'],
                "diepitch_y": data['diepitch_y']
            })

        return data

    def get_singlemapselection(self, data, query_inputs, orientation):
        range_query_dict = prep_range_query_selectedmaps(data, '')
        query_list = []
        for key, values in range_query_dict.items():
            input_data = {
                "mapid": (int(key.split("_")[0]),),
                "range_condition": update_query(values, orientation),
                "orientation": orientation,
                "xsite": query_inputs['xsite'],
                "ysite": query_inputs['ysite'],
                "fieldx": query_inputs['fieldx'],
                "fieldy": query_inputs['fieldy'],
                'diepitch_x': query_inputs.get('diepitch_x', 1),
                'diepitch_y': query_inputs.get('diepitch_y', 1)
            }
            query_list.append(self.queries['defect_main'].format(**input_data))

        query_inputs["union_all"] = " union all ".join(query_list)
        return query_inputs

    @coroutine
    def get(self, data):
        '''Return data for scatter plot.'''
        try:
            resp = dict()
            inputs = data['inputs']
            values = data['values']
            filters = data['filters']
            commonality_filter = get_commonality_filter(data)
            '''for ctrl + click single defect selection'''
            defect_query = ""
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN {tuple(values['defectid'])}"
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            condition = make_query(data, alias='defects.')
            condition = f"{defect_query} {condition}"

            '''prepping inputs'''
            query_inputs = self.prepare_query_inputs(
                data, inputs, values, condition, orientation, commonality_filter)
            query_inputs['condition'] = f"{query_inputs['condition']} limit 60000"

            if inputs.get('singleMapSelection', None):
                query_inputs = self.get_singlemapselection(
                    data, query_inputs, orientation)

            ''' scatterplot count calculation '''
            if inputs.get('singleMapSelection', None):
                count_query = f"select count(1) from ({self.queries['read_level0_rect'].format(**query_inputs)})"
            else:
                count_query = f"select count(1) from ({self.queries['read_level0'].format(**query_inputs)})"

            app_log.info(f"Count Query: {count_query}")
            
            val=execute_query(self.connection,count_query,'one')
            ''' Checking Scatterplot count '''
            #if cursor.fetchone()[0] < self.scatter_count:
            if val[0] < self.scatter_count:
                if inputs.get('singleMapSelection', None):
                    query = self.queries['read_level0_rect'].format(
                        **query_inputs)
                else:
                    query = self.queries['read_level0'].format(
                        **query_inputs)
            else:
                if inputs.get('singleMapSelection', None):
                    query = self.queries['read_rect'].format(
                        **query_inputs)
                else:
                    query = self.queries['read'].format(
                        **query_inputs)
            ''' Fetching Scatter Plot Data '''
            app_log.info(f'ScatterPlot Query: {query}')
            
            df = execute_query(self.connection, query, 'all', 'df')
            scatter_data = dict(tuple(df.groupby(['mapid'], as_index=False)))
            ''' Convert response into desired format '''
            for key, value in scatter_data.items():
                resp[key] = {
                    'data': value[['xaxis', 'yaxis', 'xsite', 'ysite', 'classnumber', 'fieldrelx',
                                   'fieldrely', 'xrel', 'yrel']].to_dict(orient='records')
                }
            op = dict()
            op['data'] = resp
            op['type_mapping'] = columns_info['Histogram']['Attribute header']
            app_log.info(f'ScatterPlot data fetching completed')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}
        raise Return(op)

    @coroutine
    def filter(self, data):
        '''Return data for scatter plot.'''
        try:
            resp = dict()
            inputs = data['inputs']
            values = data['values']
            filters = data['filters']
            commonality_filter = get_commonality_filter(data)
            '''for ctrl + click single defect selection'''
            defect_query = ""
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN {tuple(values['defectid'])}"
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            condition = make_query(data, alias='defects.')
            condition = f"{defect_query} {condition}"

            '''prepping inputs'''
            query_inputs = self.prepare_query_inputs(
                data, inputs, values, condition, orientation, commonality_filter)
            query_inputs['condition'] = f"{query_inputs['condition']} limit 60000"

            if inputs.get('singleMapSelection', None):
                query_inputs = self.get_singlemapselection(
                    data, query_inputs, orientation)

            ''' scatterplot count calculation '''
            if inputs.get('singleMapSelection', None):
                count_query = f"select count(1) from ({self.queries['read_filter_level0_rect'].format(**query_inputs)})"
            else:
                count_query = f"select count(1) from ({self.queries['read_filter_level0'].format(**query_inputs)})"

            app_log.info(f"Count Query: {count_query}")
            
            key=execute_query(self.connection,count_query,'one')
            ''' Checking Scatterplot count '''
            #if cursor.fetchone()[0] < self.scatter_count:
            if key[0] < self.scatter_count:
                if inputs.get('singleMapSelection', None):
                    query = self.queries['read_filter_level0_rect'].format(
                        **query_inputs)
                else:
                    query = self.queries['read_filter_level0'].format(
                        **query_inputs)
            else:
                if inputs.get('singleMapSelection', None):
                    query = self.queries['read_filter_rect'].format(
                        **query_inputs)
                else:
                    if 'fieldrelx' in query_inputs['xaxis']:
                        query = self.queries['read_filter_field'].format(
                            **query_inputs)
                    else:
                        query = self.queries['read_filter'].format(
                            **query_inputs)

            ''' Fetching Scatter Plot Data '''
            app_log.info(f'ScatterPlot Query: {query}')
            
            df = execute_query(self.connection, query, 'all', 'df')
            resp = df.to_dict(orient='records')
            app_log.info(f'ScatterPlot data fetching completed')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}
        raise Return(resp)

    def __del__(self):
        '''closing connection'''
        self.connection.close()
