import tornado
import json

from tornado.gen import coroutine
from tornado.escape import json_decode

from api.scatterplot.scatterplot_api.scatterplotmodel import ScatterPlot
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class ScatterPlotHandler(BaseHandler):

   
    @coroutine
    def post(self):
        self.set_header("Content-Type", self.content_type)
        scatterplot = ScatterPlot()
        resp = scatterplot.get(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp))

    def options(self):
        self.set_status(204)
        self.finish()



class ScatterPlotFilterHandler(BaseHandler):


    @coroutine
    def post(self):
        self.set_header("Content-Type", self.content_type)
        scatterplot = ScatterPlot()
        resp = scatterplot.filter(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp))

    def options(self):
        self.set_status(204)
        self.finish()
