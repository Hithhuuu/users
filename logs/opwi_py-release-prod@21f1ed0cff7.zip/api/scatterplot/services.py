import tornado
from api.scatterplot.scatterplot_api.scatterplothandler import ScatterPlotHandler, ScatterPlotFilterHandler




services = {
    'scatterplot': [
        tornado.web.url(r"/scatterplot", ScatterPlotHandler),
        tornado.web.url(r"/scatterplot/filter", ScatterPlotFilterHandler),
    ],
}
