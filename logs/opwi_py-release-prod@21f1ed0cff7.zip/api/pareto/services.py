import tornado
from api.pareto.pareto_api.paretohandler import ParetoHandler, ParetoFilterHandler

services = {
    'pareto': [
        tornado.web.url(r"/pareto", ParetoHandler),
        tornado.web.url(r"/pareto/filter", ParetoFilterHandler)
    ],
}
