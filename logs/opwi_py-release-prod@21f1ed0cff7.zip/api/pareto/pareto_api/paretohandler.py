import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.pareto.pareto_api.paretomodel import Pareto
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class ParetoHandler(BaseHandler):

   
    @coroutine
    def post(self):
        from datetime import  datetime
        start_time = datetime.now()
        print(f"Handler Start time: {start_time}")
        pareto = Pareto()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=pareto.get(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        end_time = datetime.now()
        print(f"Handler End time: {end_time}")
        print(f"Total time:{end_time-start_time}")
    def options(self):
        self.set_status(204)
        self.finish()


class ParetoFilterHandler(BaseHandler):


    @coroutine
    def post(self):
        pareto = Pareto()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=pareto.pareto_filter(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    def options(self):
        self.set_status(204)
        self.finish()
