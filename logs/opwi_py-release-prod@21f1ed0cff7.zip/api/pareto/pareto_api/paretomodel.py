import re
import tornado
import pandas as pd
from tornado.escape import json_decode
from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries, queries2, get_logger, columns_info
from api.utils.common import (get_commonality_filter, make_query, get_prep_level, update_query, prep_classification_query,
                          get_condition_cols, commonality_query, execute_query)

app_log = get_logger("pareto")


class Pareto():

    def __init__(self):
        '''Initializing pareto'''
        self.connection = connection_pool.connect()
        self.queries = queries2["pareto"]
        self.input_type = "pareto"
        self.defectlimit = 5000
        self.cols = ['xaxis', 'groupname', 'mapname', 'capturerate', 'values']

    def commonality_query(self, data, query_data, commonality_filter):

        if commonality_filter:
            query_data['commonality'] = self.queries['commonality'].format(
                **{
                    "projectid": data['projectid'],
                    "rmapid": query_data['rmapid'] if query_data.get('rmapid', None) else data['inputs'].get('ref_mapid'),
                    "smapid": tuple(list(query_data['smapid'])+[0])
                }
            )
            commonality_mapping = columns_info['commonality_attr_mapping']
            value_c = tuple([commonality_mapping[i]
                             for i in commonality_filter])
            if data["inputs"].get("paretoType",None) == "per_map_defectcount":
                query_data['count_condition_commonality'] = f" AND refcm in {value_c}"
            else:
                query_data['count_condition_commonality'] = f" AND cm.refcm in {value_c}"
        else:
            query_data['commonality'] = ''
            query_data['count_condition_commonality'] = ''
            query_data['commonality_column'] = ''
    def prep_level(self, data, query_data):

        if data['inputs'].get('prep_column'):
            query_data['xsite'] = data['inputs'].get('prep_column')[0]
            query_data['ysite'] = data['inputs'].get('prep_column')[1]
        else:
            prep_data = get_prep_level(
                self.connection, query_data, limit=self.defectlimit)
            query_data['xsite'] = prep_data['xsite']
            query_data['ysite'] = prep_data['ysite']

    def cal_offset(self, data, query_data):
        orientation = data['inputs']['orientationmarklocation'].lower()
        if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
            query_data['offset_columns'] = "," + self.queries['offset_columns'].format(**{
                "xsite": query_data['xsite'],
                "ysite": query_data['ysite'],
                "orientation": orientation,
                "fieldx": query_data['fieldx'],
                "fieldy": query_data['fieldy'],
                "diepitch_x": query_data['diepitch_x'],
                "diepitch_y": query_data['diepitch_y'],
                "offset_mapid": tuple(data['inputs'].get('selectedMaps', []))
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            })
            offset_mapid = tuple(data['inputs'].get('selectedMaps', [])) \
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            query_data['offset'] = self.queries['offset_join'].format(**{"offset_mapid": offset_mapid,
                                                                         "orientation": orientation})
        else:
            query_data['offset_columns'] = "," + self.queries['no_offset_columns'].format(**{
                "xsite": query_data['xsite'],
                "ysite": query_data['ysite'],
                "orientation": orientation,
                "fieldx": query_data['fieldx'],
                "fieldy": query_data['fieldy'],
                "diepitch_x": query_data['diepitch_x'],
                "diepitch_y": query_data['diepitch_y'],
                "offset_mapid": tuple(data['inputs'].get('selectedMaps', []))
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            })
            query_data['offset'] = ''

    def get_rmapid(self, projectid= None):
        if projectid is None:
            return None
        query = self.queries['read_rmap'].format(**{'projectid': projectid})
        app_log.info(f"Rmapid get query: {query}")
        
        rmapid = execute_query(self.connection, query, 'one')
        
        if len(rmapid) != 0:
            app_log.info(f"Reference mapid is {len(rmapid)}")
            return rmapid[0]
        else:
            app_log.info("Reference Mapid is not set")
            return None

    @coroutine
    def get(self, data):
        '''Returns data for pareto chart.'''
        commonality_filter = get_commonality_filter(data)
        AND=' and '
        condition_cols = get_condition_cols(data)
        xaxis = data['inputs'].get('pareto', {}).get('xaxis', 'classname')
        query_data = dict()
        query_data['classification'] = prep_classification_query({'values': data['values']}).replace(AND, '')
        conditions = make_query(data)
        orientation = data['inputs']['orientationmarklocation'].lower()
        
        grpby = xaxis
        default_group = data['inputs'].get('pareto', {}).get('view', '')
        query_data['xaxis'] = xaxis
        query_data['condition_columns'] = condition_cols
        query_data['condition'] = conditions
        query_data['orientation'] = orientation
        query_data['xsite'] = f'xsite_{orientation}'
        query_data['ysite'] = f'ysite_{orientation}'
        query_data['selected_maps'] = tuple(data['inputs'].get('selectedMaps', ''))
        query_data['fieldx'] = data['inputs'].get('fieldx', 1)
        query_data['fieldy']= data['inputs'].get('fieldy', 1)
        query_data['diepitch_x'] = data['inputs'].get('diepitch_x', 1)
        query_data['diepitch_y']= data['inputs'].get('diepitch_y', 1)
        query_data['rmapid'] = self.get_rmapid(data.get('projectid'))
        query_data['mapid'] = tuple(data['inputs']['selectedMaps']) if data['inputs'].get('selectedMaps') else \
            tuple(data['values']['mapid'])
        query_data['smapid'] = tuple([i for i in list(query_data['mapid']) if i != query_data['rmapid']])
        cols = ['classnumber', 'defectcnt', 'mapid', 'classname']
        
        # rflag added to check if ref map is selected rflg = True when selected, rflag=False when not selected
        rflag = True if query_data['rmapid'] in query_data['mapid'] else False 

        if xaxis == 'groupname':
            cols = ['defectcnt', 'mapid', 'groupname']
            if default_group == 'reverse':
                query_data['xaxis'] = 'mapid'

            query_data['projectid'] = data.get('projectid')
            if query_data.get('classification'):
                query_data['condition'] += f" AND defects.{query_data.get('classification')}"

            count_condition = query_data['condition']
            query_data['count_condition'] = update_query(count_condition, orientation).replace(str(tuple(data['values']['mapid'])),
                                                    str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)
            query_data['condition'] = update_query(query_data['condition'], orientation)
            self.commonality_query(data, query_data, commonality_filter)
            
            if 'xindex' in query_data['condition_columns'] or 'yindex' in query_data['condition_columns']:
                self.cal_offset(data, query_data)
            else:
                query_data['offset_columns'] = ''
                query_data['offset'] = ''

            query_to_execute = ""
            query_data['capturerate_condition'] = f" and {AND.join(query_data['condition'].split(AND)[2:])} " \
                if len(query_data['condition'].split(AND)[2:]) > 0 else ''

            if query_data['rmapid'] and len(query_data['smapid']) > 0 and rflag:
                if data["inputs"].get("paretoType",None) == "per_map_class":
                    query_to_execute = self.queries["read_grp_per_map_class"].format(
                        **query_data)
                    cols.append('capturerate')
                elif data["inputs"].get("paretoType",None) == "per_map_defectcount":
                    cols.append('refcm')
                    query_to_execute = self.queries["read_grp_defectnt"].format(
                        **query_data)
                else:                 
                    query_to_execute = self.queries["read_grp_capturerate"].format(
                        **query_data)
            else:
                query_to_execute = self.queries["read_grp"].format(
                    **query_data)

            app_log.info(query_to_execute)
            from datetime import datetime
            app_log.info(f"Start time: {datetime.now()}")
            start_time = datetime.now()
            
            df = execute_query(self.connection, query_to_execute, 'all', 'df')
            
        else:
            if default_group == 'reverse':
                query_data['xaxis'] = 'mapid'
            query_data['projectid'] = data.get('projectid')

            if query_data.get('classification'):
                query_data['classification'] = f" and t2.{query_data['classification']}"

            count_condition = query_data['condition']
            query_data['count_condition'] = update_query(count_condition, orientation).replace(str(tuple(data['values']['mapid'])),
                                                    str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)
            query_data['condition'] = update_query(query_data['condition'], orientation)
            self.commonality_query(data, query_data, commonality_filter)
            #self.prep_level(data, query_data)
            if 'xindex' in query_data['condition_columns'] or 'yindex' in query_data['condition_columns']:
                self.cal_offset(data, query_data)
            else:
                query_data['offset_columns'] = ''
                query_data['offset'] = ''

            query_to_execute = ""
            query_data['capturerate_condition'] = f" and {AND.join(query_data['condition'].split(AND)[2:])} " \
                if len(query_data['condition'].split(AND)[2:]) > 0 else ''
            if query_data['rmapid'] and len(query_data['smapid']) > 0 and rflag:
                if data["inputs"].get("paretoType",None) == "per_map_class":
                    query_to_execute = self.queries["read_class_per_map_class"].format(
                        **query_data)
                    cols.append('capturerate')
                elif data["inputs"].get("paretoType",None) == "per_map_defectcount":
                    cols.append('refcm')
                    query_to_execute = self.queries["read_class_defectnt"].format(
                        **query_data)
                else:
                    query_to_execute = self.queries["read_class_capturerate"].format(
                        **query_data)
            else:
                query_to_execute = self.queries["read_class"].format(
                    **query_data)

            app_log.info(query_to_execute)
            from datetime import datetime
            app_log.info(f"Start time: {datetime.now()}")
            start_time = datetime.now()

            
            df = execute_query(self.connection, query_to_execute, 'all', 'df')
            

        if df.shape[0] <= 0:
            raise Return("[]")
        df['defectcnt'] = df['defectcnt'].fillna(0)
        dict_ = dict(
            tuple(df[['xaxis'] + cols].sort_values(by='xaxis').groupby(['xaxis'])))
        for xaxis in df['xaxis'].unique():
            if grpby == 'groupname':
                if default_group == 'reverse':
                    df.loc[df['xaxis'] == xaxis, 'mapid'] = dict_[
                        xaxis][cols].sort_values(by='groupname').to_json(orient='records')
                else:
                    df.loc[df['xaxis'] == xaxis, 'mapid'] = dict_[
                        xaxis][cols].sort_values(by='mapid').to_json(orient='records')
            else:
                if default_group == 'reverse':
                    df.loc[df['xaxis'] == xaxis, 'mapid'] = dict_[
                        xaxis][cols].sort_values(by='classname').to_json(orient='records')
                else:
                    df.loc[df['xaxis'] == xaxis, 'mapid'] = dict_[
                        xaxis][cols].sort_values(by='mapid').to_json(orient='records')
        df = df.drop_duplicates(subset='xaxis')
        df['values'] = df['mapid'].apply(json_decode)
       

        app_log.info(f"End time: {datetime.now() - start_time}")

        raise Return(df[self.cols].to_json(orient='records'))


    @coroutine
    def pareto_filter(self, data):
        '''Returns data for pareto filtering.'''
        try:
            commonality_filter = get_commonality_filter(data)
            # data['inputs']['pareto_sel'] = True
            conditions = make_query(data, alias='defects.')
            count_condition= conditions
            query_data = dict()
            query_data['condition'] = conditions
            inputs = data.get('inputs')
            orientation = inputs['orientationmarklocation'].lower()
            query_data['orientation'] = orientation
            query_data['xsite'] = f'xsite_{orientation}'
            query_data['ysite'] = f'ysite_{orientation}'
            query_data['fieldx'] = inputs.get('fieldx', 1)
            query_data['fieldy']= inputs.get('fieldy', 1)
            query_data['diepitch_x'] = inputs.get('diepitch_x', 1)
            query_data['diepitch_y']= inputs.get('diepitch_y', 1)
            query_data['selected_maps']= tuple(inputs.get('selectedMaps', ''))
            query_data['count_condition']= update_query(count_condition, orientation)
            query_data['waferView'] = inputs.get('waferView', 'stack')
            query_data['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get('selectedMaps') else tuple(data['values']['mapid'])
            query_data['count_condition'] = update_query(count_condition, orientation).replace(str(tuple(data['values']['mapid'])),
                                                    str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)
            query_data['condition'] = update_query(conditions, orientation)



            query_data['offset'] = self.queries['offset_join'].format(
                **{"offset_mapid": query_data['selected_maps'], "orientation": orientation}) if inputs.get(
                'waferView', None) != 'multi1' else ''
            commonality_query(data, commonality_filter, query_data)

            if inputs.get('prep_column'):
                query_data['xsite'] = inputs.get('prep_column')[0]
                query_data['ysite'] = inputs.get('prep_column')[1]
            else:
                prep_data = get_prep_level(
                    self.connection, query_data, limit=self.defectlimit)

                query_data['xsite'] = prep_data['xsite']
                query_data['ysite'] = prep_data['ysite']

            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
                query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset_columns'] = f",{query_data['offset_columns']}"
                query_data['offset'] = self.queries['offset_join'].format(**{"offset_mapid": query_data['selected_maps'],
                                                                             "orientation": orientation})
            else:
                query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset_columns'] = f",{query_data['offset_columns']}"
                query_data['offset'] = ''
            query = self.queries['pareto_filter'].format(**query_data)
            app_log.info(f'pareto filter {query}')
            df = execute_query(self.connection, query, 'all', 'df')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f'{e}')

        raise Return(df.to_json(orient='records'))

    def __del__(self):
        '''on connection close'''
        self.connection.close()
