import tornado
from api.histogram.histogram_api.histogramhandler import HistogramHandler, HistogramFilterHandler

services = {
    'histogram': [
        tornado.web.url(r"/histogram", HistogramHandler),
        tornado.web.url(r"/histogram/filter", HistogramFilterHandler)
    ],
}
