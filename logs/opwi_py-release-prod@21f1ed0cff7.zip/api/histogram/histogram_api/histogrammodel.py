import tornado
import json
import numpy as np
import pandas as pd
from tornado.escape import json_decode
from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_columns_info, get_logger, columns_info
from api.utils.common import make_query, update_query, get_commonality_filter, get_prep_level, commonality_query, execute_query

app_log = get_logger("histogram")

class Histogram():

    def __init__(self):
        '''Initializing histogram'''
        self.connection = connection_pool.connect()
        self.queries = queries2["histogram"]
        self.input_type = "histogram"
        self.dict = dict()
        self.defectlimit = 5000
        self.columns = get_columns_info()
        self.lst = []

    def commonality_query(self, data, query_data, commonality_filter):

        if commonality_filter:
            print(commonality_filter)
            query_data['commonality'] = self.queries['commonality'].format(
                **{
                    "projectid": data['projectid'],
                    "rmapid": data['inputs']['ref_mapid']
                }
            )
            commonality_mapping = columns_info['commonality_attr_mapping']
            value_c = tuple([commonality_mapping[i] for i in commonality_filter])
            query_data['commonality_condition'] = f" AND cm.refcm in {value_c}"
            query_data['count_condition_commonality'] = query_data['commonality_condition']
        else:
            query_data['commonality'] = ''
            query_data['commonality_condition'] = ''
            query_data['count_condition_commonality'] = ''

    @coroutine
    def get(self, data):
        '''Returns data for histogram chart.'''
        try:
            query_data = dict()
            inputs = data['inputs']
            commonality_filter = get_commonality_filter(data)
            orientation = data["inputs"].get("orientationmarklocation", "down").lower()
            query_data['condition'] = update_query(make_query(data, alias="defects."), orientation)
            query_data['grouplevel'] = ",".join(data["grouplevel"])
            query_data['orientation'] = orientation
            query_data['condition'] = query_data['condition'][4:]
            count_condition = f" AND {query_data['condition']}"
            query_data['xsite'] = f'xsite_{orientation}'
            query_data['ysite'] = f'ysite_{orientation}'
            query_data['fieldx'] = inputs.get('fieldx', 1)
            query_data['fieldy'] = inputs.get('fieldy', 1)
            query_data['diepitch_x'] = inputs.get('diepitch_x', 1)
            query_data['diepitch_y'] = inputs.get('diepitch_y', 1)
            query_data['selected_maps'] = tuple(inputs.get('selectedMaps', ''))
            query_data['count_condition']= update_query(count_condition, orientation)
            query_data['condition'] = update_query(query_data['condition'], orientation)
            query_data['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get('selectedMaps') else tuple(
                data['values']['mapid'])
            query_data['count_condition'] = update_query(count_condition, orientation).replace(
                str(tuple(data['values']['mapid'])),
                str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)

            commonality_query(data, commonality_filter, query_data)
            
            if inputs.get('prep_column'):
                query_data['xsite'] = inputs.get('prep_column')[0]
                query_data['ysite'] = inputs.get('prep_column')[1]
            else:
                prep_data = get_prep_level(
                    self.connection, query_data, limit=self.defectlimit)

                query_data['xsite'] = prep_data['xsite']
                query_data['ysite'] = prep_data['ysite']

            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
                query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "orientation": orientation
                })
                query_data['offset'] = self.queries['offset_join'].format(**{"mapid": tuple(data['values']['mapid']),
                                                                             "orientation": orientation})
            else:
                query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "orientation": orientation
                })
                query_data['offset'] = ''
            query = self.queries["read"].format(**query_data)
            
            df = execute_query(self.connection, query, 'all', 'df')

            app_log.info(f"Histogram Get Query: {query}")

            if 'otype' in data['grouplevel']:
                for key, header in self.columns["Histogram"]["Attribute header"].items():
                    df.loc[df['otype'] == key, 'otype'] = header

            if df.shape[0] <= 0:
                raise Return("[]")

            df['defectcnt'] = df['defectcnt'].fillna(0)
            dict_ = dict(tuple(df.groupby(data["grouplevel"])))

            for i, j in dict_.items():
                self.dict = dict()
                self.dict["values"] = [{"defectcnt": i[0], "mapid": i[-1]} for i in j[["defectcnt", "mapid"]].sort_values(by='mapid').to_numpy()]
                for p in range(len(data["grouplevel"])):
                    if len(data["grouplevel"]) > 1:
                        self.dict[data["grouplevel"][p]] = i[p]
                    else:
                        self.dict[data["grouplevel"][p]] = i
                self.lst.append(self.dict)

        except Exception as e:
            app_log.error(e)
            import traceback
            app_log.error(traceback.format_exc())
            return {'error': str(e)}

        '''To dump numpy.int64 into json string'''
        def convert(o):
            if isinstance(o, np.generic): return o.item()
            raise TypeError
        raise Return(json.dumps(self.lst, default=convert))

    def histogram_filter_query(self, data):
        try:
            histogramselection = data['inputs'].get('histogramselections', None)
            select_list = []
            for i, mapid in enumerate(histogramselection['mapid']):
                condition_list = []
                filter_select = self.queries['main_select']
                for key in histogramselection.keys():
                    if key == 'classnumber':
                        class_query = self.queries['class_select']
                        filter_select += f" {class_query} "
                        condition_list.append(f"cls.classname = '{histogramselection[key][i]}'")
                    elif key == 'otype':
                        otype_mapping = get_columns_info()['Histogram']['Attribute header']
                        otype_val = ",".join([str(ele)
                                                for ele, val in otype_mapping.items()
                                                if val == histogramselection[key][i]]
                                            )
                        condition_list.append(f"main.{key} in ({otype_val})")
                    else:
                        if 'field' not in key:
                            condition_list.append(f"main.{key} = {histogramselection[key][i]}")

                filter_select += f" where {' and '.join(condition_list)}"
                select_list.append(filter_select)
            return " union all ".join(select_list)
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f'{e}')

    @coroutine
    def histogram_filter(self, data):
        '''Returns data for histogram filtering.'''
        df = ""
        try:
            commonality_filter = get_commonality_filter(data)
            conditions = make_query(data, alias='defects.')
            count_condition = conditions
            query_data = dict()
            query_data['filter_select'] = self.histogram_filter_query(data)
            query_data['condition'] = conditions
            inputs = data.get('inputs')
            orientation = inputs['orientationmarklocation'].lower()
            query_data['orientation'] = orientation
            query_data['xsite'] = f'xsite_{orientation}'
            query_data['ysite'] = f'ysite_{orientation}'
            query_data['fieldx'] = inputs.get('fieldx', 1)
            query_data['fieldy'] = inputs.get('fieldy', 1)
            query_data['diepitch_x'] = inputs.get('diepitch_x', 1)
            query_data['diepitch_y'] = inputs.get('diepitch_y', 1)
            query_data['selected_maps'] = tuple(inputs.get('selectedMaps', ''))
            query_data['count_condition']= update_query(count_condition, orientation)
            query_data['condition'] = update_query(conditions, orientation)
            query_data['waferView'] = inputs.get('waferView', 'stack')
            query_data['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get('selectedMaps') else tuple(
                data['values']['mapid'])
            query_data['count_condition'] = update_query(count_condition, orientation).replace(
                str(tuple(data['values']['mapid'])),
                str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)

            query_data['offset'] = self.queries['offset_join'].format(
                **{"mapid": tuple(data['values']['mapid']), "orientation": orientation}) if inputs.get(
                'waferView', None) != 'multi1' else ''

            commonality_query(data, commonality_filter, query_data)

            if inputs.get('prep_column'):
                query_data['xsite'] = inputs.get('prep_column')[0]
                query_data['ysite'] = inputs.get('prep_column')[1]
            else:
                prep_data = get_prep_level(
                    self.connection, query_data, limit=self.defectlimit)

                query_data['xsite'] = prep_data['xsite']
                query_data['ysite'] = prep_data['ysite']

            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
                query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset'] = self.queries['offset_join'].format(**{"mapid": tuple(data['values']['mapid']),
                                                                             "orientation": orientation})
            else:
                query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset'] = ''
            # breakpoint()

            query = self.queries['histogram_filter'].format(**query_data)
            app_log.info(f'histogram filter {query}')
            
            df = execute_query(self.connection, query, 'all', 'df')
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f'{e}')

        raise Return(df.to_json(orient='records'))

    def __del__(self):
        '''on connection close'''
        self.connection.close()
