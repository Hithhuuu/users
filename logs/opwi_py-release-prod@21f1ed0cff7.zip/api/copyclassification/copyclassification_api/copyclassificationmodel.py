from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool
from api.utils.utils import get_logger
from time import sleep
from api.utils.common import DeleteError, execute_query

app_log = get_logger("copyclassification")


class CopyClassification():
    def __init__(self):
        """Initialize Reclassification"""
        self.connection = connection_pool.connect()
        self.queries = queries2['copyclassification']
        self.query_data = dict()

    def get_selected_defects(self, defects_list):
        mapid_list = []
        defectid_list = []
        for i in defects_list:
            mapid_list.append(i['mapid'])
            defectid_list.append(i['defectid'])

    @coroutine
    def post(self, data):
        """delete and insert the commonality data into clickhouse table"""
        try:
            self.query_data['projectid'] = data['projectid']
            self.query_data['rmapid'] = data['ref_mapid']
            self.query_data['smapid'] = tuple(data['secondary_mapids'])
            defects_list = data.get('defects', None)
            if defects_list is not None:
                self.get_selected_defects(defects_list)
            insert_query = self.queries['insert_main_'+str(data.get("unclassify","false")).lower()].format(**self.query_data)

            app_log.info(f"Insert query: {insert_query}")
            # cursor.execute(insert_query)
            execute_query(self.connection, insert_query,'')
            '''
            select_data = dict()
            for row in cursor.fetchall():
                if row[0] in select_data.keys():
                    select_data[row[0]].append((row[1]))
                else:
                    select_data[row[0]] = [(row[1])]
            cursor.close()
            select_data_list = [{'mapid': int(key.split("|")[0]), 'defectid': ",".join(select_data[key]),
                                 'classnumber': int(key.split("|")[1])}
                                for key in select_data.keys()]

            print(select_data_list)
            


            app_log.info(
                f"Updating classnumber for smapid with rmapid classnumber in opwi_defect_main table")
            update_query = self.queries['update']
            app_log.info(f"Update query: {update_query}")
            cursor = self.connection.cursor()
            for i in select_data_list:
                if len(i['defectid'].split(",")) > 30000:
                    import numpy as np
                    arr = np.array_split(np.array(i['defectid'].split(
                        ",")), len(i['defectid'].split(","))/30000)
                    for a in arr:
                        d = {
                            "mapid": i['mapid'], "classnumber": i['classnumber'], "defectid": ",".join(a)}
                        app_log.info(
                            f"update query : {self.queries['update'].format(**d)}")
                        cursor.execute(self.queries['update'].format(**d))
                        flag_count = True
                        for j in range(30):
                            count_query = f"select count(1) from opwi_defect_main where mapid={d['mapid']} and " \
                                          f" defectid in ({d['defectid']}) and classnumber = {d['classnumber']}"
                            app_log.info(f"count query : {count_query}")
                            cursor.execute(count_query)
                            count = cursor.fetchone()
                            app_log.info(f"count is {count[0]}")
                            if count[0] > 0:
                                flag_count = False
                                break
                                
                            sleep(1)
                        if flag_count:
                            raise DeleteError("Unable to update the opwi_defect_main after multiple attempts")
                        
                else:
                    app_log.info(self.queries['update'].format(**i))
                    cursor.execute(self.queries['update'].format(**i))
                    flag_count=True
                    for j in range(30):
                        count_query = f"select count(1) from opwi_defect_main where mapid={i['mapid']} and " \
                                      f" defectid in ({i['defectid']}) and classnumber = {i['classnumber']}"
                        app_log.info(f"count query : {count_query}")
                        cursor.execute(count_query)
                        count = cursor.fetchone()
                        app_log.info(f"count is {count[0]}")
                        if count[0] > 0:
                            flag_count = False
                            break
                        sleep(1)
                    if flag_count:
                        raise DeleteError("Unable to update the opwi_defect_main after multiple attempts")
                '''


            '''updating secondary mapid classnumber and classname with respect to reference mapid
            classnumber and classname in opwi_map_class'''

            app_log.info(
                self.queries['select_mapclass'].format(**self.query_data))
            val1 = execute_query(self.connection, self.queries['select_mapclass'].format(**self.query_data))
            record_exist = {}
            # for row in cursor.fetchall():
            for row in val1:
                datadict = {
                    "mapid": row[0],
                    "newclassnumber": row[1],
                    "newclassname": row[2],
                    "classnumber": row[4],
                    "classname": row[5]
                }
                rec = "|".join([str(datadict['mapid']), str(
                    datadict['newclassnumber']), datadict['newclassname']])
                if rec in record_exist.keys():
                    continue

                if row[6] == "No Action":
                    record_exist["|".join(
                        [str(datadict['mapid']), str(datadict['newclassnumber']), datadict['newclassname']])] = 1

                elif row[6] == "Insert":
                    # check if the record already exists
                    rec = "|".join([str(datadict['mapid']), str(
                        datadict['newclassnumber']), datadict['newclassname']])
                    if rec not in record_exist.keys():
                        record_exists = self.queries['record_exists'].format(
                            **datadict)
                        app_log.info(f"Record exists query: {record_exists}")
                        # cursor.execute(record_exists)
                        val2 = execute_query(self.connection, record_exists,'one')
                        app_log.info(f"row count {len(val2)}")
                        if len(val2) == 0:
                            app_log.info(
                                f"OPWI_MAP_CLASS Insery Query: {self.queries['insert_mapclass'].format(**datadict)}")
                            execute_query(self.connection, self.queries['insert_mapclass'].format(**datadict),'')
                        else:
                            app_log.info(
                                f"record exists {'|'.join([str(datadict['mapid']), str(datadict['newclassnumber']), datadict['newclassname']])}")
                            record_exist["|".join([str(datadict['mapid']), str(datadict['newclassnumber']),
                                                   datadict['newclassname']])] = 1
                elif row[6] == "Update":
                    app_log.info(
                        f"OPWI_MAP_CLASS Update Query: {self.queries['update_mapclass'].format(**datadict)}")
                    
                    execute_query(self.connection, self.queries['update_mapclass'].format(**datadict),'')

        except Exception as e:
            app_log.info(f"Error while copying classification: {e}")
            raise Return(
                {'msg': f"Copy Classification Exception: {e.__class__.__name__}"})
        raise Return({'msg': 'Copy Classification completed'})

    def __del__(self):
        """Closing the connection."""
        self.connection.close()
