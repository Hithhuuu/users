import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode

from api.copyclassification.copyclassification_api.copyclassificationmodel import  CopyClassification
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class CopyClassificationHandler(BaseHandler):

    @coroutine
    def post(self):
        '''Return wafer map data for sites and dies'''
        copy_class= CopyClassification()
        resp = copy_class.post(json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
