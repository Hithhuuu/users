nohup python3 api\generic\server.py --port=8170 --env=dev --service=upload
nohup python3 api\generic\server.py --port=8171 --env=dev --service=upload
nohup python3 api\generic\server.py --port=8172 --env=dev --service=upload
nohup python3 api\generic\server.py --port=8173 --env=dev --service=upload