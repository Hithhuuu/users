import tornado
from tornado.gen import coroutine
from api.upload.upload_api.uploadmodel import UploadModel
from tornado.escape import json_decode
import json
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class ProgressHandler(BaseHandler):

    @coroutine
    def post(self):
        ''' 
        desc: Get the progress of the file upload
        params: [{"filename": ""}, ]
        response: {"percentage":""}
        '''
        upload = UploadModel()
        self.set_header("Content-Type", self.content_type)
        resp=upload.get_progress_status(request_data=json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
        except:
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)


    def options(self):
        self.set_status(204)
        self.finish()