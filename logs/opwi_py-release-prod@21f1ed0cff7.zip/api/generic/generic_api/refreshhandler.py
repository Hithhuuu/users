import tornado
from jwt import encode
from json import JSONDecodeError
from tornado.gen import coroutine
from tornado.escape import json_decode
from datetime import datetime, timedelta
from api.utils.common import BaseHandler

from api.utils.utils import env_config
from api.user.user_api.usermodel import Users

class RefreshHandler(BaseHandler):

    def prepare(self):
        self.to_encode = {
            'some': 'payload',
            'a': {2: True},
            'exp': datetime.utcnow() + timedelta(minutes=60)}
        self.encoded = encode(self.to_encode,
                              env_config['secret_key'],
                              algorithm='HS256'
                              )

    @ coroutine
    def post(self):
        try:
            request_data = json_decode(self.request.body)
            user = Users()
            user_data = yield user.data(request_data)
            if len(user_data) <= 0:
                self.set_status(401)
                self.write({'msg': 'userid not valid'})
                return
            user_data = user_data[0]
            response = dict(jwt=self.encoded.decode('utf-8'),
                            userid=user_data['userid'],
                            username=user_data['email'],
                            firstname=user_data['firstname'],
                            isAdmin=True if user_data['assignedrole'] == 'admin' else False,
                            displayName=user_data['firstname'],
                            expiredAt=self.to_encode['exp']
                            )
        except JSONDecodeError:
            self.set_status(500)
            response = {'error': 'not a valid JSON'}
        except Exception:
            self.set_status(500)
            response = {'error': 'some error'}
        self.write(response)

    @ coroutine
    def options(self):
        self.set_status(204)
        self.finish()
