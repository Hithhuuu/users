import os
import json
import sqlite3
import tornado
from tornado.gen import coroutine
from sre_constants import SUCCESS
from api.utils.common import  zlib1, BaseHandler
from datetime import  datetime
zlib_obj = zlib1()


class StatusHandler(BaseHandler):
    '''Returns status of task files'''

    @coroutine
    def post(self):
        self.set_header("Content-Type", "application/json")
        files = json.loads(self.request.body)['filename']
        if len(files) <= 0:
            self.write(json.dumps({'message': 'No Files selected'}))
        tiff_file = [i for i in files if os.path.splitext(i)[1] in  ['.tiff','.I01','.tif']]
        conn = sqlite3.connect('results.sqlite')
        filelist = "', '".join(files)
        query = f"select id, task_id, status, date_done, traceback from celery_taskmeta where task_id in ('{filelist}')"
        cursor = conn.execute(query)
        resp = []
        for row in cursor:
            resp.append({
                'id': row[0],
                'task_id': row[1],
                'status': row[2],
                'date_done': row[3],
                'traceback': row[4]
            })

        if tiff_file:
            tiff_progress_data = [
                {
                    'id': None,
                    'task_id': i,
                    'status': "SUCCESS",
                    'date_done': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'traceback': None
                } for i in tiff_file]
            resp = resp + tiff_progress_data

        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(json.dumps(resp))

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
