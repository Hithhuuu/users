import tornado
from api.upload.upload_api.uploadhandler import UploadHandler
from api.generic.generic_api.statushandler import  StatusHandler
from api.generic.generic_api.progresshandler import ProgressHandler

services = {
    'upload': [
        tornado.web.url(r"/upload", UploadHandler),
        tornado.web.url(r"/status", StatusHandler),
        tornado.web.url(r"/progress", ProgressHandler)
    ],
}