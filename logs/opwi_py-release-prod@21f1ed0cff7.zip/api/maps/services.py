import tornado
from api.maps.maps_api.maphandler import MapHandler, MapAliasHandler
from api.maps.maps_api.mapfilterhandler import MapFilterHandler
from api.scanset.scanset_api.scansethandler import ScansetHandler




services = {
    'maps': [
        tornado.web.url(r"/map", MapHandler),
        tornado.web.url(r"/mapfilter", MapFilterHandler),
        tornado.web.url(r"/map/scanset", ScansetHandler),
        tornado.web.url(r"/map/addalias", MapAliasHandler),
    ],
}
