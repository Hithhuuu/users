from api.utils.common import DeleteError, execute_query
from numpy.core.numeric import flatnonzero
import pandas as pd
import time
from tornado.gen import coroutine, Return
from api.utils.utils import queries, queries2, get_logger, connection_pool
from api.sfilter.sfilter_api.sfiltermodel import Sfilter
from api.copyclassification.copyclassification_api.copyclassificationmodel import CopyClassification
from api.commonality.commonality_api.commonalitymodel import Commonality


app_log = get_logger("map")


class Map:
    """User operations base class"""

    def __init__(self):
        """Initializing Map instance"""
        self.connection = connection_pool.connect()
        self.queries = queries2["maps"]
        self.search_fields = [
            "mapname",
            "mapid",
            "product",
            "layer",
            "resulttimestamp",
            "recipeid",
            "carrierid",
            "slotnumber",
            "waferid",
            "orientationmarklocation",
            "defectcnt",
            "imagename",
            "diepitch_x",
            "diepitch_y",
        ]

    def get_columnar_search_str(self, column_search_data):
        """ Generate a query string for column search """
        column_search_string = ""
        if column_search_data:
            search_string = []
            for key, value in column_search_data.items():
                if column_search_data.get(key):
                    if key.lower() == "diepitch":
                        search_string.append(
                            f" (coalesce(toString(diepitch_x_up),'')||', '||coalesce(toString(diepitch_y_up),"
                            f"'')||', '||coalesce(toString(diepitch_x_right),'')||', '||coalesce(toString("
                            f"diepitch_y_right),'')||', '||coalesce(toString(diepitch_x_left),'')||', '||coalesce("
                            f"toString(diepitch_y_left),'')||', '||coalesce(toString(diepitch_x_down),"
                            f"'')||', '||coalesce(toString(diepitch_y_down),'')||', '||coalesce(toString(diepitch_x),"
                            f"'')||', '||coalesce(toString(diepitch_y),'')) ilike '%{value.strip()}%'"
                        )
                    elif key.lower() == 'mapname':
                        search_string.append(f" upper(splitByChar('|',mapname)[5]) like upper('%{value}%')")
                    else:
                        search_string.append(
                            f"cast ({key} as String) ilike '%{value}%'"
                        )
            column_search_string = f" AND {' AND '.join(search_string)}"
        return column_search_string

    def get_columnar_sort_str(self, column_sort_data):
        """ Generate a Query string for Columnar sort"""
        sort_list = []
        if column_sort_data:
            for key, value in column_sort_data.items():
                if column_sort_data.get(key):
                    if key.lower() == "mapname":
                        sort_list.append(
                            f"reverse(substr(reverse(filename), positionCaseInsensitive(reverse(filename), '_') + 1)) {value}"
                        )
                    elif key.lower() == 'diepitch':
                        sort_list.append(f"{key}_x {value}")
                        sort_list.append(f"{key}_y {value}")
                    elif  key.lower() in ['has_attributes','klarf_file_path','recently_opened','attachment']:
                        continue
                    else:
                        sort_list.append(f"{key} {value}")
        if sort_list:
            return f" order by {' , '.join(sort_list)}"
        else:
            return " order by resulttimestamp desc"

    @coroutine
    def get_selected_maps(self, projectid):
        """ Get the selected maps for the project[projectid] """
        maps = []
        if projectid:
            selected_maps = execute_query(self.connection, self.queries["selected"].format(**{"projectid": projectid}), 'all', 'df')
            selected_maps["resulttimestamp"] = selected_maps["resulttimestamp"].apply(
                lambda x: x.strftime("%Y-%m-%d %H:%M:%S")
            )
            selected_maps["diepitch"] = (
                selected_maps.pop("diepitch_x").astype(str)
                + ", "
                + selected_maps.pop("diepitch_y").astype(str)
            )

            selected_maps['attachment'] = None
            if not selected_maps.empty:
                selected_maps['attachment'] = selected_maps.apply(
                    lambda x: {'csv': x.csv_filename, 'otf': x.tiff_filename}, axis=1
                )
            selected_maps = selected_maps.drop(columns=['csv_filename', 'tiff_filename'])

            maps = selected_maps.to_dict(orient="records")
        raise Return(maps)

    def calculate_commonality(self, data):
        """ Calculate Commonality """

        data["ref_mapid"] = data["mapid"]
        comm = Commonality()
        status = comm.update_commonality(data)._result
        app_log.debug(f"status +++++++++++++++++++++++++ {status}")
        return status

    def copy_classifications(self, data):
        """ Copy classifications """
        data["rmapid"] = data["mapid"]
        copy_class = CopyClassification()
        ret_msg = copy_class.post(data)._result
        if "Exception" in ret_msg["msg"]:
            app_log.info(
                f"Error while performing copy classification: {ret_msg['msg']}"
            )
        else:
            app_log.info(f"Copy classification completed")
        return ret_msg

    def get_search_text_query(self, search_text):
        """ Generate Query string for Search Text """
        search_query = ""
        if search_text:
            search_query = " AND ({0})".format(
                "OR ".join(
                    [
                        f" cast ({i} as String) ILIKE '%{search_text}%' "
                        for i in self.search_fields
                    ]
                )
            )
            search_query = (
                f" {search_query[:-1]} OR (coalesce(toString(diepitch_x),"
                f"'')||', '||coalesce(toString(diepitch_y),'')) ILIKE '%{search_text.strip()}%')"
            )
        return search_query

    def get_date_query(self, from_date, to_date):
        """ Generate date between query string """
        date_string = ""
        if from_date and to_date:
            date_string = f" AND resulttimestamp between '{from_date}' and '{to_date}'"
        return date_string

    def get_filter_query(self, request_data):
        """ Generate query string for filter columns """
        username = request_data.pop("username", "pvadmin")
        if 'filename' not in request_data:
            username_string = f"cby= '{username}'"
        filter_colum_lst = [
            f"{key} = '{value}'"
            for key, value in request_data.items()
            if request_data.get(key)
        ]
        if 'filename' not in request_data:
            filter_colum_lst.append(username_string)
        return f"({' and '.join(filter_colum_lst)})"

    @coroutine
    def get(self, request_data):
        """
        Get the maps for the perticular user(username)
        default username = pvadmin
        """
        try:
            data = {}
            # Processing Payload
            request_data.pop("request_type", None)
            search_text = request_data.pop("search_text", None)
            column_search_data = request_data.pop("column_search", {})
            column_sort_data = request_data.pop("column_sort", {})
            from_date = request_data.pop("from_date", None)
            to_date = request_data.pop("to_date", None)
            project_id = request_data.pop("projectid", None)
            """ set offset, limit if it's not already set"""
            limit, offset = request_data.pop("limit", 20), request_data.pop("offset", 0)
            """ Generate query string for filter columns"""
            filter_query = self.get_filter_query(request_data)
            """ Generate query string for search parameters [complete search] """
            search_query = self.get_search_text_query(search_text)
            """ Generate query string for columnar search text """
            column_search_query = self.get_columnar_search_str(column_search_data)
            """ Generate query string for columnar sort """
            column_sort_query = self.get_columnar_sort_str(column_sort_data)
            """ Generate between query string for resulttimestamp """
            date_query = self.get_date_query(from_date, to_date)
            """ Generate Condition with above query strings """
            condition = (
                f"{filter_query} {search_query} {column_search_query} {date_query}"
            )

            """ Maps count query """
            total_count_query = (
                f"SELECT Count(1) as t_count FROM opwi_map_header final where rfg=1 and {condition}"
            )
           
            map_count = execute_query(self.connection, total_count_query, 'all', 'df').to_dict(
                orient="records"
            )

            app_log.info(f"MAP TOTAL COUNT QUERY: {total_count_query}")
            app_log.info(f"MAP TOTAL COUNT: {map_count[0]['t_count']}")
            """ Ends count query """

            """ Adding column_sort_query and limit, offset into the condition """
            condition = f"{condition} {column_sort_query} limit {offset}, {limit}"

            app_log.info({"condition": condition})

            """ Maps fetch query """
            data.update({"condition": condition})
            map_query = self.queries["headers"].format(**data)
            app_log.info(map_query)
            df = execute_query(self.connection, map_query, 'all', 'df')
            
            app_log.info(f"MAPS QUERY: {map_query}")
            """ Updating diepitch and resulttimestamp """
            df["diepitch"] = (
                df.pop("diepitch_x")
                + ", "
                + df.pop("diepitch_y")
            )
            df["resulttimestamp"] = df["resulttimestamp"].apply(
                lambda x: x.strftime("%Y-%m-%d %H:%M:%S")
            )
            df['attachment'] = None
            if not df.empty:
                df['attachment'] = df.apply(
                    lambda x: {'csv': x.csv_filename, 'otf': x.tiff_filename}, axis=1
                )
            df = df.drop(columns=['csv_filename', 'tiff_filename'])
            """ Ends maps query """

            """ Get already selected maps for the project """
            selected_maps = self.get_selected_maps(project_id)._result
            response = {
                "limit": limit,
                "offset": offset,
                "total": map_count[0]["t_count"],
                "data": df.to_dict(orient="records"),
                "selected_maps": selected_maps,
            }
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        raise Return(response)

    def get_filter_date_query(self, data):
        """
        Generate date between query for map filters.
        if dates not there in payload, the function will
        get the from_date and to_date from opwi_map_header table
        """
        if not data.get("from_date") and not data.get("to_date"):
            query = "select min(resulttimestamp) as from_date, now() as to_date from opwi_map_header final where rfg=1;"
            
            filter_date = execute_query(self.connection, query, 'all', 'df')
            filter_date = filter_date.apply(
                lambda x: x.dt.strftime("%Y-%m-%d %H:%M:%S")
            ).to_dict(orient="records")
            data.update(filter_date[0])
        return f"resulttimestamp between '{data['from_date']}' and '{data['to_date']}'"

    @coroutine
    def get_filter_value(self, column, condition):
        """ Fetch the filters from opwi_map_header table """
        filter_type = {"filter_type": column}
        filter_query = f"{self.queries['filters'].format(**filter_type)} {condition} and rfg=1 ORDER BY lower({column})"
        filter_data = [
            query_data[column]
            
            for query_data in execute_query(self.connection, filter_query, 'all', 'df').to_dict(
                orient="records"
            )
        ]
        raise Return(filter_data)

    @coroutine
    def get_filters(self, data):
        """
        Get the filters for the maps.
        default filter set is ['product', 'layer']
        """
        try:
            req_type = data.pop("request_type", "db")
            diff_list, resp = [], {}
            username_query = (
                "cby= 'pvadmin'" if req_type == "db" else "cby != 'pvadmin'"
            )
            date_query = self.get_filter_date_query(data)
            resp.update(
                {"from_date": data.pop("from_date"), "to_date": data.pop("to_date")}
            )
            condition = f" where {username_query} and {date_query}"
            filter_items = ["product", "layer"]
            if data.get("product") or data.get("layer"):
                type_list_keys = [item for item in data if data[item]]
                diff_list = set(filter_items) ^ set(type_list_keys)
                filter_items = type_list_keys
            """ Get the filters for map headers : default filters [product, layer]"""
            for item in filter_items:
                resp.update({item: self.get_filter_value(item, condition)._result})
            """ End map filters """
            if diff_list:
                for column in diff_list:
                    q_list = " and ".join(
                        [f"({item}='{data[item]}')" for item in filter_items]
                    )
                    condition = f"{condition} AND {q_list}"
                    resp.update(
                        {column: self.get_filter_value(column, condition)._result}
                    )
        except Exception as e:
            return {"error": str(e)}
        raise Return(resp)

    def get_maps(self, projectid):
        import time

        time.sleep(0.5)
        query = self.queries["filter_map"].format(**{"projectid": projectid})
        
        maps = execute_query(self.connection, query, 'all', 'df')
        maps["diepitch"] = (
            maps.pop("diepitch_x").astype(str)
            + ", "
            + maps.pop("diepitch_y").astype(str)
        )
        return maps.to_dict(orient="records")

    @coroutine
    def set_reference_map(self, data):
        sfilter = Sfilter()
        ret_msg = dict(msg="")
        defect_attributes = []
        maps = []
        try:
            if data["mapid"]:
                for query in [
                    self.queries["update_false"],
                    self.queries["update_true"],
                ]:
                    
                    app_log.info("Processing set reference map")
                    app_log.info(query.format(**data))
                   
                    execute_query(self.connection, query.format(**data),'')
                
                """ Calculating Commonality """
                if "Exception" not in self.calculate_commonality(data)["msg"]:
                    if data["classifications"] is True:
                        ret_msg = self.copy_classifications(data)
                        if "Exception" in ret_msg["msg"]:
                            app_log.info("Copy Classification Failed")
                            ret_msg["msg"] = " & Copy Classification Failed"
                        else:
                            app_log.info(
                                "Commonality Calculation and Copy Classification Completed"
                            )
                            ret_msg[
                                "msg"
                            ] = " & Commonality Calculation and Copy Classification Completed"
                    else:
                        ret_msg["msg"] = " & Commonality Calculation Completed"
                        app_log.info("Commonality Calculation Completed")

                    if "radius" in data.get("inputs").keys():
                        query = self.queries['Update_radius'].format(**{"radius": data["inputs"].get("radius"),
                                                                        "projectid": data["projectid"]})
                        app_log.info(f"Query to update radius : {query}")
                        execute_query(self.connection, query,'')
                else:
                    app_log.info(f"Error while calculating commonality")
                    ret_msg["msg"] = " & Commonality Calculation Failed"
                defect_attributes = sfilter.get_defect_attributes()
            else:
                execute_query(self.connection, self.queries["update_false"].format(**data),'')
            maps = self.get_maps(projectid=data.get("projectid"))
        except Exception as e:
            import traceback
            app_log.error(traceback.format_exc())
            return {"error": f"{e}"}

        raise Return(
            {
                "msg": "Reference Map updated" + ret_msg["msg"],
                "maps": maps,
                "defect_attributes": defect_attributes,
            }
        )

    @coroutine
    def delete(self, data):
        """Deletes a map"""
        try:
            delete = data["del_flag"]
            mapid = data["mapid"]
            if delete:
                lst = [
                    "opwi_map_header",
                    "opwi_map_class",
                    "opwi_myproject_maps",
                ]
                app_log.info(f"START: Deleting data for : {mapid}")
                for table in lst:
                    ''' deleting map data from tables '''
                    query = self.queries['maps'][f'delete_{table}'].format(**{'mapid':mapid})
                    app_log.info(f"Query for {table} delete is: {query}")
                    # cursor.execute(query)
                    execute_query(self.connection, query,'')


                app_log.info(f"END: Deleting data for: {mapid}")
                flag = 'Y'
            else:
                df = execute_query(self.connection, self.queries["project_details"].format(**{"mapid": mapid}), 'all', 'df')
                flag = 'N'
        except Exception as e:
            return {"error": f"{e}"}
        if flag == 'Y':
            raise Return({"msg": "deleted"})
        else:
            raise Return(df.to_json(orient="records"))


    @coroutine
    def add_map_alias(self, data):
        try:
            for i in data["maps"]:
                map_data = {
                    'mapid': i['mapid'],
                    'mapalias': f"'{i['alias']}'" if i['alias'] else 'null'
                }
                query = self.queries["insert_map_alias"].format(**map_data)
                app_log.info(f"Add map alias query: {query}")
                execute_query(self.connection,query,'')
                app_log.info(f"Added {i['alias']} as an alias for {i['mapid']}")
            sfilter = Sfilter()
            resp = sfilter.get_filters(data={'projectid' : data.get('projectid')})._result
            return resp
        except Exception as e:
            app_log.exception(f"Failed to add alias: {e}")
            return {"error": f"{e}"}

    @coroutine
    def __del__(self):
        """On Maps Instance deletion"""
        self.connection.close()
