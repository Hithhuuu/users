import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.maps.maps_api.mapmodel import Map
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()


class MapFilterHandler(BaseHandler):


    @coroutine
    def post(self):
        ''' 
        desc: List out Map filters
        params: {"product": "", "layer": "", "from_date": "", "to_date":""}
        response: {"product": [], "layers": []}
        '''
        maps = Map()
        self.set_header("Content-Type", self.content_type)
        resp = maps.get_filters(data=json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
    
    def options(self):
        self.set_status(204)
        self.finish()
