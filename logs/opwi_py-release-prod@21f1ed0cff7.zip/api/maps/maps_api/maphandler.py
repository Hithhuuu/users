import tornado,json
from tornado.gen import coroutine
from api.maps.maps_api.mapmodel import Map
from tornado.escape import json_decode
from api.utils.utils import get_logger
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()
app_log = get_logger("map")


class MapHandler(BaseHandler):
    

    @coroutine
    def post(self):
        """
        desc: List Map headers
        request params: {"request_type": "db|file", "layer": "", 
                        "product": "", "from_date": "", "to_date": ""
                        "search_text": ""
                    }
        response: [{map1}, {map2}]
        """
        maps = Map()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        if not data.get("request_type") or data.get("request_type") not in [
            "db",
            "file",
        ]:
            self.write({"msg": "Please provide valid request type"})
            return
        resp=maps.get(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit((json.dumps(resp)))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    @coroutine
    def put(self):
        """
        desc: set referance map
        request params: {"projectid": "", "mapid": ""}
        """
        map_p = Map()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=map_p.set_reference_map(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    @coroutine
    def delete(self):
        map_d = Map()
        resp = map_d.delete(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        # self.writejson.dumps(resp)

    def options(self):
        self.set_status(204)
        self.finish()


class MapAliasHandler(BaseHandler):
    @coroutine
    def put(self):
        """
        desc: set alias for map
        request params: {"projectid": "", "maps": [{},{}]}
        """
        mapobj = Map()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp = mapobj.add_map_alias(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)


    def options(self):
        self.set_status(204)
        self.finish()