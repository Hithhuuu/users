from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_logger
from api.utils.datastore import DataStore
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, execute_query
from tornado.escape import json_encode
import itertools

app_log = get_logger("binning")

class Binning():

    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2['binning']
        self.ds = DataStore(self.connection)

    def cal_offset(self, data, prepare_data):
        inputs = data['inputs']
        orientation = data['inputs']['orientationmarklocation'].lower()
        if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
            prepare_data['offset_columns'] = "," + self.queries['offset_columns'].format(**{
                "xsite": prepare_data['xsite'],
                "ysite": prepare_data['ysite'],
                "orientation": orientation,
                "fieldx": inputs.get('fieldx', 1),
                "fieldy": inputs.get('fieldy', 1),
                "diepitch_x": inputs.get('fieldy', 1),
                "diepitch_y": inputs.get('fieldy', 1),
                "offset_mapid": tuple(data['inputs'].get('selectedMaps', []))
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            })
            offset_mapid = tuple(data['inputs'].get('selectedMaps', [])) \
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            prepare_data['offset'] = self.queries['offset_join'].format(**{"offset_mapid": offset_mapid,
                                                                         "orientation": orientation})
        else:
            prepare_data['offset_columns'] = "," + self.queries['no_offset_columns'].format(**{
                "xsite": prepare_data['xsite'],
                "ysite": prepare_data['ysite'],
                "orientation": orientation,
                "fieldx": prepare_data['fieldx'],
                "fieldy": prepare_data['fieldy'],
                "diepitch_x": prepare_data['diepitch_x'],
                "diepitch_y": prepare_data['diepitch_y'],
                "offset_mapid": tuple(data['inputs'].get('selectedMaps', []))
                if len(data['inputs'].get('selectedMaps', [])) > 0 else tuple(data['values'].get('maps'))
            })
            prepare_data['offset'] = ''

    def get_prep_level(self, data, prepare_data):
        
        inputs = data['inputs']
        if inputs.get('prep_column'):
                prepare_data['xsite'] = inputs.get('prep_column')[0]
                prepare_data['ysite'] = inputs.get('prep_column')[1]
        else:
            prepare_data['xsite'] = f"xsite_{inputs.get('orientationmarklocation').lower()}"
            prepare_data['ysite'] = f"ysite_{inputs.get('orientationmarklocation').lower()}"
    @coroutine
    def get(self, data):
        '''Returns Binning Details'''
        try:
            commonality_filter = get_commonality_filter(data)
            orientation = data['inputs'].get('orientationmarklocation', 'down').lower()
            # Get Binning data from inputs
            binning_data = data.get('inputs', {}).get('binning', {})
            values = data['values']
            query_data = make_query(data, alias='defects.')

            """ Prepare data for binning detail query """
            prepare_data = {
                'condition': update_query(query_data, orientation),
                'orientation': orientation,
                'mapid': tuple(values.get('mapid')),
                'filter_attr': binning_data['filter_attr'],

            }
            self.get_prep_level(data, prepare_data)
            commonality_query(data, commonality_filter, prepare_data)
            self.cal_offset(data, prepare_data)
            binning_detail_query = self.queries['read_binningdetails'].format(**prepare_data)
            app_log.info(f"Binning Detail Query: {binning_detail_query}")
            import time
            app_log.info(time.time())
            data = execute_query(self.connection, binning_detail_query, 'all', 'list')
            app_log.info(time.time())
            app_log.info(time.time())
        except Exception as e:
            app_log.info(f" ERROR Binning : {repr(e)}")
            import traceback
            app_log.error(f"Error is {traceback.format_exc()}")
            return{'error': str(e)}
        
        raise Return(json_encode(data))

    def __del__(self):
        '''on connection close'''
        self.connection.close()
