
import tornado
from api.binning.binning_api.binninghandler  import BinningHandler

services = {
    'binning': [
            tornado.web.url(r"/binning", BinningHandler),
        ],
}