import tornado
import pandas as pd

from api.utils.auth import jwtauth
from tornado.gen import coroutine, Return
from api.utils.common import execute_query
from api.utils.utils import get_logger, env_config, connection_pool
from api.utils.data_processing import dataload, verify_mapname
from api.utils.auth import jwtauth

app_log = get_logger('UploadHandler')


def get_upload_handler_data(kwargs):

    """Post request for uploading file."""
    app_log.info(f"data of kwargs in upload fun file -- {kwargs}")
    overwrite = kwargs.get('overwrite', None)
    filename = kwargs.get('filename')
    username = kwargs.get('username')
    timestamp = kwargs.get('timestamp')
    filesize = kwargs.get('filesize')
    file_type = kwargs.get('file_type', None)
    save_to_local = kwargs.get('save_local', None)
    abs_path = kwargs.get('file_path')
    app_log.info(f"file is overwriting or not..: {overwrite}")

    unique_data = verify_mapname(
        file_path=abs_path, username=username, filename=filename)._result
    app_log.info(f"unique_data: {unique_data}")
    if unique_data['exists'] and not overwrite:
        resp = {"status": f'The file already exists'}
        return resp

    app_log.info(
        f"Upload activity Processing with id {unique_data['mapname']}")
    try:
        ''' Checking Klarf file is parsent or not for csv '''
        if file_type == 'csv':
            temp_filename = filename.split('_attributes')[0]
            con = connection_pool.connect()
            query = f" select mapid from opwi_map_header final where rfg=1 and cby = '{username}' and  filename like'%{temp_filename}%' and  filename like'%.00%' limit 1"
            app_log.info(f"Query : {query}")
            count = execute_query(con, query)
            if count == []:
                raise Return("Klarf file is missing")

        ''' If the file is not exists on db, send to dataload function to parse and pushe data to db '''
        # Celery config
        celery_config = env_config['celery_settings']
        queue = celery_config['from_db']['queue']
        routing_key = celery_config['from_db']['routing_key']
        # Celery config
        # dataload(abs_path, username, timestamp, filesize,
        #          filename, unique_data['mapname'], unique_data['mapid'])
        dataload.apply_async((abs_path, username, timestamp, filesize, filename,
                                unique_data['mapname'], unique_data['mapid']), task_id=filename, queue=queue, routing_key=routing_key)
        resp_json = {'status': 'upload started'}
        app_log.info(f"Returned response is: {resp_json}")

    except Exception as e:
        app_log.exception(e)
        resp_json = {'upload': 'failed', 'error': str(e)}
        if resp_json['error'] == 'Klarf file is missing':
            resp_json['klarf'] = False
        app_log.exception(f'Returned response is: {resp_json}')

    return resp_json