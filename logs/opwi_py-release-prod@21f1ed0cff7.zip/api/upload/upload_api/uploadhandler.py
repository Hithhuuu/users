import tornado
import os
from tornado.gen import coroutine, Return
from api.utils.common import execute_query, extract_tif_file
from api.utils.utils import get_logger, env_config, connection_pool
from api.utils.data_processing import dataload, verify_mapname
from .uploadmodel import UploadModel


app_log = get_logger('upload')

# @jwtauth : Disabling for Tool Upload


class UploadHandler(tornado.web.RequestHandler):

    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Headers",
                        "Origin, X-Requested-With, Content-Type, Authorization, Accept")
        self.set_header('Access-Control-Allow-Methods',
                        'POST, GET, OPTIONS, DELETE, OPTIONS')
        self.content_type = "application/json"

    @coroutine
    def post(self):
        self.set_header("Content-Type", "application/json")
        """Post request for uploading file."""
        data = {
            "overwrite": self.get_argument('overwrite', None),
            "filename": self.get_argument('filename'),
            "username": self.get_argument('username'),
            "timestamp": self.get_argument('timestamp'),
            "filesize": self.get_argument('filesize'),
            "file_type": self.get_argument('file_type', None),
            "save_to_local": self.get_argument('save_local', None),
            "tif_file": self.get_argument("tif_file_name", None),
            "fileinfo":self.request.files.get('file')[0] if self.request.files.get('file') else ''
        }
        upload = UploadModel()
        resp = upload.post(data)._result
        self.finish(resp)

    def options(self):
        self.set_status(200)
        self.finish()
