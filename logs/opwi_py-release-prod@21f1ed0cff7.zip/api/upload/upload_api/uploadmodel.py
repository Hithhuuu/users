import os
import json
from tornado.gen import coroutine, Return
from api.utils.utils import queries, queries2, connection_pool, get_logger, env_config
from api.utils.common import execute_query, extract_tif_file, add_map_attachment,populate_hasTiff
from api.utils.data_processing import dataload, verify_mapname
from datetime import datetime


app_log = get_logger("upload")


class UploadModel():

    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2['upload']
        self.upload_queries = queries['upload']

    @coroutine
    def post(self, data):
        '''
        TODO UI upload with klarf, csv and tiff file 
        '''
        overwrite = data.get('overwrite', None)
        filename = data.get('filename')
        username = data.get('username')
        timestamp = data.get('timestamp')
        filesize = data.get('filesize')
        file_type = data.get('file_type', None)
        save_to_local = data.get('save_local', None)
        abs_path = f"{env_config['directories']['upload_folder_name']}/{filename}"
        app_log.info(f"Queries2 keys: {queries2['upload'].keys()}")
        app_log.info(f"self.queries keys: {self.queries.keys()}")
        app_log.info(f"file is overwriting or not..: {overwrite}")
        if save_to_local == 'yes' and username == 'pvadmin':
            self.finish(
                {"status": f'No permission to do save_to_local with {username}'})
            return
        if overwrite is None and save_to_local is None:
            fileinfo = data.get("fileinfo")
            with open(abs_path, 'wb') as output_file:
                output_file.write(fileinfo['body'])

        # TODO check tif file and save on dir
        if file_type.lower() in ['tif','tiff','i01']:
            abs_tif_path = f"{env_config['directories']['upload_folder_name']}/{filename}"
            tif_file_path = env_config['directories']['upload_folder_name']

            dest_images_path = self.get_images_path(filename)
            tif_fileinfo = data.get("fileinfo")
            with open(abs_tif_path, 'wb') as output_file:
                output_file.write(tif_fileinfo['body'])
            # extract tif files
            n_frames = extract_tif_file(tif_file_path, dest_images_path, filename, file_type)
            app_log.info('Tiff Image extration is completed')
            resp_json = {'status': 'upload started', 'file_type':file_type.lower()}
            add_map_attachment(self.connection, filename,ftype='otf', n_frames = n_frames)
            populate_hasTiff(self.connection,filename)
            return resp_json

        # tif file extration is done
        unique_data = verify_mapname(
            file_path=abs_path, username=username, filename=filename)._result
        app_log.info(f"unique_data: {unique_data}")
        if unique_data['exists'] and not overwrite:
            resp = {"status": f'The file already exists'}
            return resp
 
        app_log.info(
            f"Upload activity Processing with id {unique_data['mapname']}")
        try:
            ''' Checking Klarf file is parsent or not for csv '''
            if file_type == 'csv':
                temp_filename = filename.split('_attributes')[0]
                con = connection_pool.connect()
                query = f" select mapid from opwi_map_header final where rfg=1 and cby = '{username}' and  filename like'%{temp_filename}%' and  filename like'%.00%' limit 1"
                app_log.info(f"Query : {query}")
                count = execute_query(con, query)
                if count == []:
                    raise Exception("Klarf file is missing")

            ''' If the file is not exists on db, send to dataload function to parse and pushe data to db '''
            # Celery config
            celery_config = env_config['celery_settings']
            queue = celery_config['from_ui']['queue']
            routing_key = celery_config['from_ui']['routing_key']
            if username == 'pvadmin':
                queue = celery_config['from_db']['queue']
                routing_key = celery_config['from_db']['routing_key']
            # Celery config
            # dataload(abs_path, username, timestamp, filesize,
            #          filename, unique_data['mapname'], unique_data['mapid'])
            dataload.apply_async((abs_path, username, timestamp, filesize, filename,
                                  unique_data['mapname'], unique_data['mapid']), task_id=filename, queue=queue, routing_key=routing_key)
            resp_json = {'status': 'upload started'}
            app_log.info(f"Returned JSON response is: {resp_json}")
        except Exception as e:
            app_log.exception(e)
            resp_json = {'upload': 'failed', 'error': str(e)}
            if resp_json['error'] == 'Klarf file is missing':
                resp_json['klarf'] = False
            app_log.exception(f'Returned JSON response is: {resp_json}')
        return resp_json

    def get_images_path(self, tiff_file_name):
        """
        TODO
        This function will create tiff file named folder if not exists
        and return the complete path
        """
        tiff_file_name_split, ext = os.path.splitext(tiff_file_name)
        app_log.info(f"image_folder_creation_unix: process start")
        base_path = env_config['watchdog_pick_location']['src']
        forward_path = os.path.join('images', tiff_file_name_split)
        complete_report_path = os.path.join(base_path, forward_path)
        try:
            if os.path.exists(complete_report_path):
                app_log.info('Image Path already exists in the this location : {0}'.format(
                    complete_report_path))
                return complete_report_path
            else:
                os.makedirs(complete_report_path, mode=0o777)
                app_log.info('Image Path is created in the this location')
            return complete_report_path
        except Exception as e:
            app_log.exception(
                "Command to create the tiff image folder Failed : {0}".format(repr(e)))

    @coroutine
    def get_progress_status(self, request_data):
        import os
        filename = request_data['filename']
        klarfcsv = [i for i in filename if os.path.splitext(i)[1] not in ['.tiff','.I01','.tif']]
        tiff_file = [i for i in filename if os.path.splitext(i)[1] in  ['.tiff','.I01','.tif']]
        filelist = "', '".join(klarfcsv)
        data = {"filenames": filelist}
        app_log.info(f"Progress Query: {self.upload_queries['upload_progress'].format(**data)}")
        progress_data = json.loads(execute_query(
                    self.connection,
                    self.upload_queries['upload_progress'].format(**data),
                    'all', 'df'
                ).to_json(orient='records'))

        if tiff_file:
            tiff_progress_data = [{"percentage": 100.0, "filename": i} for i in tiff_file]
            progress_data = progress_data + tiff_progress_data
        return progress_data
