import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.templateshare.templateshare_api.templatesharemodel import TemplateShared
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class TemplateshareHandler(BaseHandler):


    def get(self):
        cby = self.get_argument('cby', None)
        template_id = self.get_argument('template_id', None)
        shared_obj = TemplateShared()
        resp = shared_obj.get(
            data={'template_id': template_id, 'cby': cby})._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def post(self):
        shared_obj = TemplateShared()
        resp = shared_obj.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        '''
        sample json
        {
            'template_id': '',
            'template_user': ''
        }
        '''
        shared_obj = TemplateShared()
        shared_obj.delete(data=json_decode(self.request.body))
        self.set_header("Content-Type", self.content_type)
        self.write({'msg': 'deleted'})

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
