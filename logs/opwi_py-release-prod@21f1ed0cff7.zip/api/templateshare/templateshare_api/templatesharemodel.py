import pandas as pd
import time
from datetime import datetime
from tornado.gen import coroutine, Return
from tornado.escape import json_decode, json_encode
from api.utils.utils import queries2, connection_pool, get_dbconnection, get_logger
from api.utils.common import execute_query

app_log = get_logger('templateshare')
class TemplateShared:
    def __init__(self):
        self.connection = get_dbconnection()
        self.queries = queries2['templateshared']

    @coroutine
    def get(self, data):
        ''' Getting shared templates details '''
        try:
            query = self.queries['read'].format(**data)
            app_log.info(f"Templateshare Get Query: {query}")
            df = execute_query(self.connection, query, 'all', 'df')
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}
        raise Return(df.to_json(orient='records'))

    @coroutine
    def create(self, data):
        """Insertion of shared template"""
        try:
            query = self.queries['insert'].format(**data)
            app_log.info(f"Templateshare Create Query: {query}")
            #cursor.execute(query)
            execute_query(self.connection,query,'')
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}
        raise Return(self.get(data)._result)

    @coroutine
    def delete(self, data):
        """Deletion of shared template"""
        try:
            query = self.queries['delete'].format(**data)
            app_log.info(f"Templateshare Delete Query: {query}")
            #cursor.execute(query)
            execute_query(self.connection,query,'')
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}
        raise Return({"msg": "Deleted shared template successfully"})


    def __del__(self):
        '''Closing the DB connection'''
        self.connection.close()
