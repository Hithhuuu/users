import pandas as pd
import time
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, get_logger, connection_pool
from api.utils.common import execute_query

app_log = get_logger("scanset")


class Scanset:
    """User operations base class"""

    def __init__(self):
        """Initializing scanset instance"""
        self.connection = connection_pool.connect()
        self.queries = queries2["scanset"]

    @coroutine
    def get(self, data):
        """
        Get the scansets for the perticular parent
        """
        try:
            scanset_query = self.queries["headers"].format(**data)
            
            df = execute_query(self.connection, scanset_query, 'all', 'df')
            app_log.info(f"Scanset QUERY: {scanset_query}")
            """ Updating diepitch and resulttimestamp """
            df["diepitch"] = (
                df.pop("diepitch_x")
                + ", "
                + df.pop("diepitch_y")
            )
            df["resulttimestamp"] = df["resulttimestamp"].apply(
                lambda x: x.strftime("%Y-%m-%d %H:%M:%S")
            )
            """ Ends scanset query """

        except Exception as e:
            return {"error": str(e)}
        raise Return(df.to_json(orient="records"))

    @coroutine
    def __del__(self):
        """On Scansets Instance deletion"""
        self.connection.close()
