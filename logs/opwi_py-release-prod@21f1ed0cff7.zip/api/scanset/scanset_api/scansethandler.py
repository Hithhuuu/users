import tornado,json
from tornado.gen import coroutine
from api.scanset.scanset_api.scansetmodel import Scanset
from tornado.escape import json_decode
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()


class ScansetHandler(BaseHandler):
    
    @coroutine
    def post(self):
        """
        desc: List Scanset headers
        request params: {"parent": ""}}
        response: [{scanset1}, {scanset2}]
        """
        scanset = Scanset()
        self.set_header("Content-Type", self.content_type)
        resp = scanset.get(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
