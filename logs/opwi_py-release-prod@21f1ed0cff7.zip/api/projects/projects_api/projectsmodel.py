from api.utils.common import DeleteError,execute_query
import pandas as pd
import time
from datetime import datetime
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, getdbconnection, get_logger
from tornado.escape import json_decode
from api.saveasmap.saveasmap_api.saveasmapmodel import  SaveAsMap
from api.user.user_api.activitymodel import Activity

app_log = get_logger("projects")


class Project:
    def __init__(self):
        """Initialize Project."""
        self.connection = connection_pool.connect()
        self.queries = queries2["projects"]
        self.cols = [
            "projectid",
            "projectname",
            "powner",
            "shares",
            "roleshared",
            "orientationmarklocation",
            "radius",
            "status",
            "cdt",
            "uby",
            "udt",
            "maps",
            "diepitch_x",
            "diepitch_y",
        ]

    def create_classnumber_map(self, mapids, projectid):
        """
        Updating  opwi_class_groups with maps classnumbers with groupname as null
        """
        class_number_query = f"select classnumber from opwi_defect_main final where mapid in {tuple(mapids)} group by classnumber"
        
        df = execute_query(self.connection, class_number_query, 'all', 'df')
        df["groupname"] = ""
        df["projectid"] = projectid
        df = df.append(pd.Series(), ignore_index=True)
        con = getdbconnection()
        df.to_sql(
            "opwi_class_groups", con, if_exists="append", index=False, chunksize=10000
        )


    def update_classnumber_map(self, mapids, projectid):
        """
        Updating  opwi_class_groups with maps classnumbers with groupname as null
        """
        class_number_query = f"""
            select
                classnumber
            from
                opwi_defect_main final
            where
                mapid in {tuple(mapids)}
                and classnumber not in (
                    select
                        classnumber
                    from
                        opwi_class_groups
                    where
                        projectid = {projectid})
            group by classnumber"""

        df = execute_query(self.connection, class_number_query, 'all', 'df')
        if df.shape[0]:
            df["groupname"] = ""
            df["projectid"] = projectid
            df = df.append(pd.Series(), ignore_index=True)
            con = getdbconnection()
            df.to_sql(
                "opwi_class_groups", con, if_exists="append", index=False, chunksize=10000
            )

    @coroutine
    def get(self, data, filter_type=None):
        """Returns list of all projects.
        1. Returns single project details if project id is provided.
        2. Returns recent type if recent filter_type is provided.
        3. Returns all if None filter_type is provided.
        """
        app_log.info("START: GET Projects ")
        try:
            if "projectid" in data:
                project_detail_query = self.queries["detail"].format(**data)
                app_log.info(f"PROJECT DETAILED QUERY: {project_detail_query}")
                
                df = execute_query(self.connection, project_detail_query, 'all', 'df')
            elif filter_type == "recent":
                recent_project_query = self.queries["recent_projects"].format(**data)
                app_log.info(f"RECENT PROJECTs QUERY: {recent_project_query}")
                
                df = execute_query(self.connection, recent_project_query, 'all', 'df')
            elif filter_type == "shared":
                shared_projects_query = self.queries["shared"].format(**data)
                app_log.info(f"SHARED PROJECTs QUERY: {shared_projects_query}")
                
                df = execute_query(self.connection, shared_projects_query, 'all', 'df')
                df["shares"] = None
            else:
                self.cols.remove("roleshared")
                my_project_query = self.queries["read"].format(**data)
                app_log.info(f"MY PROJECTs QUERY: {my_project_query}")
                
                df = execute_query(self.connection, my_project_query, 'all', 'df')

        except Exception as e:
            app_log.info(f"Project GET function failed: {str(e)}")
            return {"error": str(e)}

        if df.shape[0] <= 0:
            app_log.info(f"Empty project data")
            raise Return("[]")
        dict_ = dict(
            tuple(
                df[
                    [
                        "projectid",
                        "mapid",
                        "product",
                        "carrierid",
                        "color",
                        "filename",
                        "mapname",
                        "defectcnt",
                        "layer",
                        "map_cby",
                        "uby",
                        "udt",
                    ]
                ].groupby(["projectid"])
            )
        )
        for projectid in df["projectid"].unique():
            df.loc[df["projectid"] == projectid, "maps"] = dict_[projectid].to_json(
                orient="records"
            )
        df = df.drop_duplicates(subset=["projectid"])
        df["maps"] = df["maps"].apply(json_decode)
        app_log.info("END: GET Projects ")
        raise Return(df[self.cols].to_json(orient="records"))

    def create_map_data(self, mapid, color, data):
        """ generate a map dict data """
        return {
            "projectid": data["projectid"],
            "powner": data["powner"],
            "mapid": mapid,
            "refmap": 0,
            "color": color

        }

    @coroutine
    def create(self, data):
        """Creates a project
        function will do follows
        1. create entry in opwi_projects table
        2. create entry for selected maps
        3. create entry for groups
        4. Set fieldx, fieldy values into 1
        5. Set orientation for the project
        """
        # try:
        data["projectid"] = int(datetime.now().timestamp())
        data["orientationmarklocation"] = data.get("orientationmarklocation", "")
        data["radius"] = data.get("radius", 5000)
        
        project_create_query = self.queries["create"].format(**data)
        app_log.info(f"PROJECT CREATE QUERY: {project_create_query}")
        
        execute_query(self.connection,project_create_query, '')
        """ Updating mapid with projects """
        # for mapid in data["maps"]:
        lst = []
        for i in data["maps"]:
            lst.append(i['mapid'])
            map_data = self.create_map_data(i['mapid'], i['color'], data)
            query = self.queries["insert_map"].format(**map_data)
            app_log.info(f"INSERT MAP TO PROJECT: {query}")
            #cursor.execute(query)
            execute_query(self.connection,query,'')

        self.create_classnumber_map(lst, data["projectid"])
        # except Exception as e:
        #     return {"error": str(e)}
        raise Return(data)

    def add_maps_project(self, data):
        """
        Adding Map id's to the ProjectMap table [update project]
        """
        app_log.info("START: add_maps_project function")
        for i in data.get("addedmaps"):
            
            map_data = self.create_map_data(i['mapid'], i['color'], data)
            add_map_query = self.queries["insert_map"].format(**map_data)
            app_log.info(f"INSERT MAP TO PROJECT: {add_map_query}")
            #cursor.execute(add_map_query)
            execute_query(self.connection,add_map_query,'')
        app_log.info("END: add_maps_project function")

    def delete_maps_project(self, data):
        """
        Remove/Delete maps from the Project
        """
        app_log.info("START: delete_maps_project function")
        
        delete_map_query = self.queries["delete_map"].format(
            **{"projectid": data["projectid"], "maplist": tuple([i['mapid'] for i in data["deletedmaps"]])}
        )
        app_log.info(f"PROJECT DELETE MAP QUERY: {delete_map_query}")
        #cursor.execute(delete_map_query)
        execute_query(self.connection,delete_map_query,'')
        
        app_log.info("END: delete_maps_project function")

    @coroutine
    def update(self, data):
        """
        The function will do follows
        1. Updating Project Details
        2. Updating orientationmarklocation
        """
        try:
            
            """ Updating Project Details """
            if data.get("projectname"):
                query_string = f"projectname = '{data.get('projectname')}'"
                if data.get("status"):
                    query_string += f", status='{data.get('status')}'"
                data.update({"condition": query_string})
                import json
                data_dict={
                    "projectid": data.get('projectid'),
                    "projectname": f"'{data.get('projectname')}'" if data.get('projectname') else 'projectname',
                    "status": f"'{data.get('status')}'" if data.get('status') else 'status',
                    "orientationmarklocation": 'orientationmarklocation',
                    "radius":f"'{data.get('radius')}'" if data.get('radius') else 'radius'
                    
                } 
                project_update_query = self.queries["update"].format(**data_dict)
                app_log.info(f"PROJECT UPDATE QUERY: {project_update_query}")
                #cursor.execute(project_update_query)
                execute_query(self.connection,project_update_query,'')                   
            """ Adding the maps to the project """
            if data.get("addedmaps") and data.get("powner"):
                self.add_maps_project(data)
                added_mapids = [m['mapid'] for m in data.get("addedmaps", [])]
                self.update_classnumber_map(added_mapids, data["projectid"])
            """ Remove the maps from the project """
            if data.get("deletedmaps") and data.get("projectid"):
                self.delete_maps_project(data)
            """ Update the orientationmarklocation """
            if data.get("projectid") and data.get("orientationmarklocation"):
                query_string = (
                    f"orientationmarklocation = '{data.get('orientationmarklocation')}'"
                )
                data.update({"condition": query_string})
                data_dict={
                    "projectid": data.get('projectid'),
                    "projectname": f"'{data.get('projectname')}'" if data.get('projectname') else 'projectname',
                    "status": f"'{data.get('status')}'" if data.get('status') else 'status',
                    "orientationmarklocation":f"'{data.get('orientationmarklocation')}'" if data.get('orientationmarklocation') else 'orientationmarklocation',
                    "radius":f"'{data.get('radius')}'" if data.get('radius') else 'radius'

                } 
                orientation_query = self.queries["update"].format(**data_dict)
                app_log.info(f"UPDATE PROJECT ORIENTATION: {orientation_query}")
                #cursor.execute(orientation_query)
                execute_query(self.connection,orientation_query,'')
                self.connection.commit()
                

            """ Update the radius """
            if data.get("projectid") and data.get("radius"):
                
                data_dict={
                    "projectid": data.get('projectid'),
                    "projectname": f"'{data.get('projectname')}'" if data.get('projectname') else 'projectname',
                    "status": f"'{data.get('status')}'" if data.get('status') else 'status',
                    "orientationmarklocation":f"'{data.get('orientationmarklocation')}'" if data.get('orientationmarklocation') else 'orientationmarklocation',
                    "radius":f"'{data.get('radius')}'" if data.get('radius') else 'radius'
                } 
                radius_query = self.queries["update"].format(**data_dict)
                app_log.info(f"UPDATE PROJECT RADIUS: {radius_query}")
                #cursor.execute(radius_query)
                execute_query(self.connection,radius_query,'')
                self.connection.commit()

            """ Update the color """
            if data.get("projectid") and data.get("maps") and data.get("maps")[0].get('color'):
                for object in data.get("maps"):
                    color_query = self.queries["update_color"].format(
                        **{"projectid": data['projectid'], "mapid": object["mapid"], "color": object["color"]})
                    app_log.info(f"UPDATE MAP COLOR: {color_query}")
                    #cursor.execute(color_query)
                    execute_query(self.connection,color_query,'')
                    
                self.connection.commit()

        except Exception as e:
            return {"error": str(e)}
        raise Return({"msg": "project updated"})

    def mapname_exists(self, mapname, cby):
        query = self.queries['mapname_exists'].format(**{"mapname": mapname, 'cby': cby})
        app_log.info(f"Map name exists query: {query}")

        val = execute_query(self.connection, query)

        if len(val) != 0:
            return True
        else:
            return False


    @coroutine
    def saveAsProject(self, data):
        """Clone project"""
        try:
            maps = data.get("maps", [])
            useremail = data.get("email", None)
            powner = data.get("powner", None)
            orientation = data.get("orientationmarklocation", "down").lower()
            data["uby"] = data.pop("userid", None)
            filter_type = None if data.get("filter_type", None) not in ['recent', 'shared'] else data.get("filter_type")

            # check if map is empty
            if len(maps) == 0:
                return {
                        "status": "Error",
                        "errormsg": f"No map has been selected."
                    }

            # check if map already exists
            existing_maps = []
            for map in maps:
                if map['mapname'] in existing_maps:
                    return {
                        "status": "Error",
                        "errormsg": f"Duplicate mapname found: {map['mapname']}"
                    }
                if self.mapname_exists(map['mapname'], useremail):
                    existing_maps.append(map['mapname'])

            if len(existing_maps):
                return {
                        "status": "Error",
                        "errormsg": f"Map {','.join(existing_maps)} already exists"
                    }

            updated_maps = []

            for map in maps:
                header_query = self.queries["fetch_header_data"].format(**{"mapid": map['mapid']})
                header_data = execute_query(self.connection, header_query, 'all', 'df')

                map_data = {
                    "inputs": {
                        "defecttable": {
                            "search_text": "",
                            "column_search": {}
                        },
                        "issmall": False,
                        "diepitch_x": header_data.iloc[0]['diepitch_x'],
                        "diepitch_y": header_data.iloc[0]['diepitch_y'],
                        "userid": useremail,
                        "orientationmarklocation": orientation,
                        "selectedMaps": [
                            map['mapid']
                        ]
                    },
                    "values": {
                        "mapname": map['mapname'],
                        "mapid": [
                            f"{map['mapid']}"
                        ]
                    },
                    "filters": {
                        "multiDropdown": [
                            "mapid",
                        ],
                        "range": []
                    }
                }

                savemapas = SaveAsMap()
                resp = savemapas.savemap(map_data)._result
                if "mapid" in resp.keys():
                    updated_maps.append(
                        {
                            "mapid": resp['mapid'],
                            "mapname": map['mapname'],
                            "color": map['color']
                        }
                    )
                else:
                    raise Exception(resp['msg'])

            data['maps'] = updated_maps
            project = Project()

            resp = project.create(data)._result

            # Add cloned project to recent
            activity_data = {
                "powner": powner,
                "action": "created",
                "projectid": resp['projectid'],
                "reftype": "project"
            }
            activity = Activity()
            activity.create(activity_data)._result

            resp = {
                "status": "Success",
                "data": json_decode(self.get({"powner": data["powner"]}, filter_type= filter_type)._result)
            }
        except Exception as e:
            app_log.exception(str(e))
            resp =  {
                "status": "Error",
                "errormsg": str(e)
            }
        raise Return(resp)


    @coroutine
    def delete(self, data):
        """Delete a project"""
        try:
            app_log.info("START: Deleting project")
            
            delete_query = self.queries["delete"].format(**data)
            app_log.info(f"PROJECT DELETE QUERY: {delete_query}")
            #cursor.execute(delete_query)
            execute_query(self.connection,delete_query,'')

            cm_wip_exist_query = f"EXISTS rawcm.opwi_defect_cm_wip_{data['projectid']}"
            cm_wip_exist = execute_query(self.connection, cm_wip_exist_query, 'one')[0]

            if cm_wip_exist:
                # delete wip table 
                cm_wip_delete_query = f"drop table if exists rawcm.opwi_defect_cm_wip_{data['projectid']}"
                execute_query(self.connection, cm_wip_delete_query, '')

            cm_exist_query = f"EXISTS rawcm.opwi_defect_cm_{data['projectid']}"
            cm_exist = execute_query(self.connection, cm_exist_query, 'one')[0]

            if cm_exist:
                # delete cm table 
                cm_table_delete_query = f"drop table if exists rawcm.opwi_defect_cm_{data['projectid']}"
                execute_query(self.connection, cm_table_delete_query, '')

            scm_exist_query = f"EXISTS rawcm.opwi_defect_scm_{data['projectid']}"
            scm_exist = execute_query(self.connection, scm_exist_query, 'one')[0]

            if scm_exist:
                # delete cm table 
                scm_table_delete_query = f"drop table if exists rawcm.opwi_defect_scm_{data['projectid']}"
                execute_query(self.connection, scm_table_delete_query, '')

            scm_wip_exist_query = f"EXISTS rawcm.opwi_defect_scm_{data['projectid']}"
            scm_wip_exist = execute_query(self.connection, scm_wip_exist_query, 'one')[0]

            if scm_wip_exist:
                # delete cm table 
                scm_wip_table_delete_query = f"drop table if exists rawcm.opwi_defect_scm_wip_{data['projectid']}"
                execute_query(self.connection, scm_wip_table_delete_query, '')

            app_log.info("END: Deleting project")
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        raise Return(self.get({"powner": data["powner"]})._result)


    def __del__(self):
        """Closing the DB connection"""
        self.connection.close()
