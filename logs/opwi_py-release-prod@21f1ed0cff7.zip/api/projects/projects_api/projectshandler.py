import json 
from tornado.gen import coroutine
from tornado.escape import json_decode

from api.projects.projects_api.projectsmodel import Project
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class ProjectHandler(BaseHandler):
   
    @coroutine
    def get(self):
        '''
        The method will do follows
        1. Details for the project:
        2. Recents projects
        3. my projects
        4. shared projects
        filter_type -> ['recent', 'shared']
        '''
        project = Project()
        filter_type = self.get_argument("filter_type", None)
        resp = project.get(
            data={"powner": self.get_argument("powner")}, filter_type=filter_type
        )._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def post(self):
        '''
        Create a new Project
        '''
        project = Project()
        resp = project.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        '''
        Update Project Details
        '''
        project = Project()
        data = json_decode(self.request.body)
        resp = project.update(data=data)._result
        self.set_header("Content-Type", self.content_type)
        # self.write({"msg": "updated"})
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        ''' Delete Project '''
        project = Project()
        resp = project.delete(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        # self.write(resp._result)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()


class SaveAsProjectHandler(BaseHandler):

    @coroutine
    def post(self):
        '''
        Create a new Project
        '''
        project = Project()
        resp = project.saveAsProject(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()