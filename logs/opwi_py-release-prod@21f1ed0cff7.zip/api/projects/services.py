import tornado
from api.projects.projects_api.projectshandler import ProjectHandler, SaveAsProjectHandler
from api.share.share_api.sharehandler import ShareHandler
from api.templates.templates_api.templatehandler import TemplateHandler
from api.templateshare.templateshare_api.templatesharehandler import TemplateshareHandler


services = {
    'projects': [
        tornado.web.url(r"/project", ProjectHandler),
        tornado.web.url(r"/project/saveas", SaveAsProjectHandler),
        tornado.web.url(r"/share", ShareHandler),
        tornado.web.url(r"/template", TemplateHandler),
        tornado.web.url(r"/templateshare", TemplateshareHandler)
    ],
}
