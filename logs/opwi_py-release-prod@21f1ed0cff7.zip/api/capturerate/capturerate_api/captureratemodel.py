import tornado
import json
import pandas as pd
import numpy as np
from tornado.escape import json_decode
from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_logger
from api.utils.common import make_query, update_query, execute_query

app_log = get_logger('capturerate')

class Capturerate():

    def __init__(self):
        '''Initializing pareto'''
        self.connection = connection_pool.connect()
        self.queries = queries2["capturerate"]
        self.query_data = dict()

    @coroutine
    def get(self, data):
        '''Returns data for capturerate for pareto chart.'''
        try:
            data['filters']['multiDropdown'].remove('mapid')
            orientation = data["inputs"].get("orientationmarklocation", "down").lower()
            self.query_data['condition'] = update_query(make_query(data, alias="defects."), orientation)
            self.query_data['xaxis'] = data['inputs'].get('capturerate', {}).get('xaxis', 'classname')
            self.query_data['rmapid'] = data['inputs'].get('capturerate', {}).get('rmapid')
            self.query_data['projectid'] = data.get('projectid')
            self.query_data['smapid'] = tuple(data['values'].get('mapid'))
            self.query_data['sec_mapid'] = tuple([i for i in self.query_data['smapid'] if i != self.query_data['rmapid']])

            if self.query_data['xaxis'] == 'classname':
                query = self.queries['read_class'].format(**self.query_data)
                app_log.info(f"Query for capturerate based on classname: {query}")
                df = execute_query(self.connection, query, 'all', 'df')
                cols = ['classname', 'capturerate']

            elif self.query_data['xaxis'] == 'groupname':
                query = self.queries['read_grp'].format(**self.query_data)
                app_log.info(f"Query for capturerate based on groupname: {query}")
                df = execute_query(self.connection, query, 'all', 'df')
                cols = ['groupname', 'capturerate']

            if df.shape[0] <= 0:
                raise Return("[]")

        except Exception as e:
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}
        raise Return(df[cols].to_json(orient='records'))

    def __del__(self):
        '''on connection close'''
        self.connection.close()
