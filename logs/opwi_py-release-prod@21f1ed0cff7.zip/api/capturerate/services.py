import tornado
from api.capturerate.capturerate_api.captureratehandler import CaptureRateHandler

services = {
    'capturerate': [
        tornado.web.url(r"/capturerate", CaptureRateHandler)
    ],
}