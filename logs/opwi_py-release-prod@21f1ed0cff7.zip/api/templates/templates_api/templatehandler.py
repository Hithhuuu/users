import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.templates.templates_api.templatesmodel import Template
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()


class TemplateHandler(BaseHandler):

    @coroutine
    def get(self):
        template = Template()
        resp = template.get(data={'template_owner': self.get_argument(
               'template_owner')})._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def post(self):
        template = Template()
        resp = template.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        template = Template()
        data = json_decode(self.request.body)
        template.update(data=data)
        self.set_header("Content-Type", self.content_type)
        self.write({'msg': 'updated'})

    @coroutine
    def delete(self):
        template = Template()
        resp = template.delete(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
