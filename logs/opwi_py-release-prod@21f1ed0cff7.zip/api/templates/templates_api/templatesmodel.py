import pandas as pd
import time
from datetime import datetime
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, getdbconnection, get_logger, get_env_config
from api.utils.common import execute_query

app_log = get_logger('template')
class Template():

    def __init__(self):
        '''Initialize template.'''
        self.connection = connection_pool.connect()
        self.queries = queries2['templates']


    @coroutine
    def get(self, data):
        '''
        Returns list of all templates.
        '''
        try:
            app_log.info('getting list of all templates')
            app_log.info(f"Query to get list of all templates: {self.queries['read']}")
            data = execute_query(self.connection, self.queries['read'].format(**data), 'all', 'df')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return(data.to_json(orient='records'))

    @coroutine
    def create(self, data):
        '''
        Creates a template
        '''
        try:
            data['template_id'] = int(datetime.now().timestamp())
            if data['template_access'].lower() == 'global':
                data['tfg'] = 1
            else:
                data['tfg'] = 0
            query = self.queries['create'].format(**data)
            app_log.info(f"templates Create Query: {query}")
            execute_query(self.connection,query,'')

        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return("msg : data inserted")

    @coroutine
    def update(self, data):
        '''Update a template'''
        try:
            if data.get('template_json'):
                query_string = data.get('template_json')
                data.update({'condition': query_string})
                query = self.queries['update'].format(**data)
                app_log.info(f"templates Update Query: {query}")
                #cursor.execute(query)
                execute_query(self.connection,query,'')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return({'msg': 'template updated'})

    @coroutine
    def delete(self, data):
        '''Deletes a template'''
        try:
            query = self.queries['delete'].format(**data)
            app_log.info(f"templates Delete Query: {query}")
            #cursor.execute(query)
            execute_query(self.connection,query,'')
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        raise Return(self.get({'template_owner': data['template_owner']})._result)

    def __del__(self):
        '''Closing the DB connection'''
        self.connection.close()

