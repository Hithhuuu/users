import tornado
from api.stacking.stacking_api.diestackinghandler import DieStackingHandler
from api.stacking.stacking_api.fieldstackinghandler import FieldStackingHandler

services = {
    'stacking': [
        tornado.web.url(r"/diestacking", DieStackingHandler),
        tornado.web.url(r"/fieldstacking", FieldStackingHandler),
    ],
}
