nohup python3 api\stacking\server.py --port=8050 --env=dev --service=stacking
nohup python3 api\stacking\server.py --port=8051 --env=dev --service=stacking
nohup python3 api\stacking\server.py --port=8052 --env=dev --service=stacking
nohup python3 api\stacking\server.py --port=8053 --env=dev --service=stacking