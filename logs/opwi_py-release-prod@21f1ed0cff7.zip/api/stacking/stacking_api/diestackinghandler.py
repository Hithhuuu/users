import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.stacking.stacking_api.stackingmodel import Stacking
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class DieStackingHandler(BaseHandler):

    @coroutine
    def post(self):
        self.set_header("Content-Type", self.content_type)
        stacking = Stacking()
        resp = stacking.get_diestacking(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
