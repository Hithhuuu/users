
import pandas as pd
import time
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool, get_logger, columns_info
from api.utils.common import make_query, update_query, get_commonality_filter, DeleteError, commonality_query, execute_query
from api.utils.datastore import DataStore

app_log = get_logger("stacking")


class Stacking:
    def __init__(self):
        """ Initialize stacking instance """
        self.connection = connection_pool.connect()
        self.queries = queries2["stacking"]
        self.pixel = 120
        self.stacking_limit = 20000
        self.ds = DataStore(self.connection)

    def commonality_query(self, data, query_data, commonality_filter):
        if commonality_filter:
            query_data['commonality'] = self.queries['commonality'].format(
                **{
                    "projectid": data['projectid'],
                    "rmapid": data['inputs']['ref_mapid']
                }
            )
            commonality_mapping = columns_info['commonality_attr_mapping']
            value_c = tuple([commonality_mapping[i] for i in commonality_filter])
            query_data['commonality_condition'] = f" AND cm.refcm in {value_c}"
        else:
            query_data['commonality'] = ''
            query_data['commonality_condition'] = ''

    def get_offset(self, type, data, stacking_inputs):
        if type == 'diestacking':
            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                stacking_inputs['offset_columns'] = self.queries['offset_columns_die'].format(**{
                    "xsite": f"xsite_{stacking_inputs['orientation']}",
                    "ysite": f"ysite_{stacking_inputs['orientation']}",
                    "orientation": stacking_inputs['orientation']
                })
                stacking_inputs['offset'] = self.queries['offset_join'].format(
                    **{
                        "mapid": tuple(data['values']['mapid']),
                        "orientation": stacking_inputs['orientation']
                    }
                )
            else:
                stacking_inputs['offset_columns'] = self.queries['no_offset_columns_die'].format(**{
                    "xsite": f"xsite_{stacking_inputs['orientation']}",
                    "ysite": f"ysite_{stacking_inputs['orientation']}",
                    "orientation": stacking_inputs['orientation']
                })
                stacking_inputs['offset'] = ''
        elif type == 'fieldstacking':
            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                stacking_inputs['offset_columns'] = self.queries['offset_columns_field'].format(**{
                    "xsite": f"xsite_{stacking_inputs['orientation']}",
                    "ysite": f"ysite_{stacking_inputs['orientation']}",
                    "orientation": stacking_inputs['orientation'],
                    "fieldx": stacking_inputs['fieldx'],
                    "fieldy": stacking_inputs['fieldy'],
                    "diepitch_x": stacking_inputs['diepitch_x'],
                    "diepitch_y": stacking_inputs['diepitch_y']
                })
                stacking_inputs['offset'] = self.queries['offset_join'].format(
                    **{
                        "mapid": tuple(data['values']['mapid']),
                        "orientation": stacking_inputs['orientation']
                    }
                )
            else:
                stacking_inputs['offset_columns'] = self.queries['no_offset_columns_field'].format(**{
                    "xsite": f"xsite_{stacking_inputs['orientation']}",
                    "ysite": f"ysite_{stacking_inputs['orientation']}",
                    "orientation": stacking_inputs['orientation'],
                    "fieldx": stacking_inputs['fieldx'],
                    "fieldy": stacking_inputs['fieldy'],
                    "diepitch_x": stacking_inputs['diepitch_x'],
                    "diepitch_y": stacking_inputs['diepitch_y']
                })
                stacking_inputs['offset'] = ''


    def prepare_query_inputs(self, condition, data, func_name=None):
        """
            Preparing diestacking inputs for fetching diestacking data,
            Updating query string with orientation.
        """
        inputs = data["inputs"]
        orientation = inputs.get("orientationmarklocation", "down").lower()
        mapid = []
        """ Check if mapid is set or not. """
        if "mapid" in data["filters"]["multiDropdown"]:
            mapid = tuple(data["values"]["mapid"])
        else:
            mapid = "(select mapid from opwi_myproject_maps final where rfg=1 and projectid = {projectid})".format(
                **data
            )
        stacking_inputs = {
            "orientation": orientation,
            "condition": update_query(condition, orientation),
            "shape_by": inputs["shape_by"],
            "volume_by": inputs["volume_by"],
            "mapid": mapid,
            "waferView": inputs.get("waferView", 'stack')
        }

        """ Updating Input Data only for diestacking """
        if func_name == "diestacking":
            stacking_inputs.update({"pixel": self.pixel})
            self.get_offset('diestacking', data, stacking_inputs)
            if 'xindex' in stacking_inputs['condition']:
                stacking_inputs['condition'] = stacking_inputs['condition'].replace('xindex', 'xindex_offset')
            if 'yindex' in stacking_inputs['condition']:
                stacking_inputs['condition'] = stacking_inputs['condition'].replace('yindex', 'yindex_offset')

        """ Updating Input Data only for fieldstacking """
        if func_name == "fieldstacking":
            field_inputs = inputs.get("field_stacking", {})
            stacking_inputs.update(field_inputs)
            stacking_inputs["diepitch_x"] = inputs["diepitch_x"]
            stacking_inputs["diepitch_y"] = inputs["diepitch_y"]
            self.get_offset('fieldstacking', data, stacking_inputs)
            if 'xindex' in stacking_inputs['condition']:
                stacking_inputs['condition'] = stacking_inputs['condition'].replace('xindex', 'xindex_offset')
            if 'yindex' in stacking_inputs['condition']:
                stacking_inputs['condition'] = stacking_inputs['condition'].replace('yindex', 'yindex_offset')

        return stacking_inputs

    @coroutine
    def get_diestacking(self, data):
        """ Get the diestacking data based on the given inputs data """
        try:
            """ Generating query string with input data """
            commonality_filter = get_commonality_filter(data)
            condition = make_query(data, alias="defects.")
            """ Generating query inputs for making query """
            query_data = self.prepare_query_inputs(
                condition, data, func_name="diestacking"
            )
            commonality_query(data, commonality_filter, query_data)

            """ Calculating data count for diestacking """

            query = self.queries["read_diestacking_level0"].format(**query_data)
            count_query = f"select count(1) from ({query})"
            app_log.info(f"DIE STACKING COUNT QUERY: {count_query}")
            
            key = execute_query(self.connection,count_query,'one')
            """ Selecting query based on the data count """
            
            if key[0] > self.stacking_limit:
                query = self.queries["read_diestacking"].format(**query_data)
            """ Fetching diestacking data start """
            app_log.info(f"DIE STACKING QUERY: {query}")
           
            df = execute_query(self.connection, query, 'all', 'df')
            """ Fetching diestacking data complete """
        except Exception as e: 
            return {"error": str(e)}
        raise Return(df.to_json(orient="records"))

    @coroutine
    def get_fieldstacking(self, data):
        """ Get the fieldstacking data based on the given inputs data """
        try:
            """ Generating query string with input data"""
            commonality_filter = get_commonality_filter(data)
            condition = make_query(data, alias="defects.")
            """ Generating query inputs for making query """
            query_data = self.prepare_query_inputs(
                condition, data, func_name="fieldstacking"
            )

            commonality_query(data, commonality_filter, query_data)

            print(query_data)

            """ Calculating count for fieldstacking data """
            query = self.queries["read_fieldstacking_level0"].format(**query_data)
            count_query = f"select count(1) from ({query})"
            
            app_log.info(f"FIELD STACKING COUNT QUERY: {count_query}")
            
            data=execute_query(self.connection,count_query,'one')

            """ Selecting query based on the data count """
            
            if data[0] > self.stacking_limit:
                query = self.queries["read_fieldstacking"].format(**query_data)
            """ Fetching fieldstacking data start """
            app_log.info(f"FIELD STACKING QUERY: {query}")
            data = self.ds.fetch(query=query, fetch="all")._result
            """ Fetching fieldstacking data end """
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            return {"error": str(e)}
        raise Return(data)

    @coroutine
    def update_field_values(self, data):
        """
        This function will update the fieldx, fieldy, fieldoriginx, fieldoriginy values
        for the project
        args : fieldx, fieldy, fieldoriginx, fieldoriginy projectid
        """
        try:
            app_log.info(
                "Processing Update fieldx, fieldy, fieldoriginx and fieldoriginy values for the project"
            )
            
            field_query = self.queries["update_stacking"].format(**data)
            app_log.info(f"FIELD STACKING VALUES UPDATE QUERY: {field_query}")
            
            execute_query(self.connection,field_query,'')
            app_log.info(
                f"Fieldstacking values got updated for the project {data['projectid']}"
            )
        except Exception as e:
            app_log.info(f"ERROR:{str(e)}")
            return {"error": str(e)}
        raise Return({"msg": "Field stack values updated for the project"})

    def __del__(self):
        self.connection.close()

