import tornado
from api.otf.otf_api.otfhandler import OTFHandler, OTFSingleViewHandler, OTFHistogramHandler


services = {
    'otf': [
        tornado.web.url(r"/otf/images", OTFHandler),
        tornado.web.url(r"/otf/singleview", OTFSingleViewHandler),
        tornado.web.url(r"/otf/histogram", OTFHistogramHandler)
    ],
}