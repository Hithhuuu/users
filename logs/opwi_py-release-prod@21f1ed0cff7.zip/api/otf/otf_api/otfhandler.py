from distutils.log import error
import tornado,json
from tornado.escape import json_decode
from tornado.gen import coroutine

from api.otf.otf_api.otfmodel import OTFModel, OTFSingleViewModel
import json
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class OTFHandler(BaseHandler):

   
    @coroutine
    def post(self):
        otf = OTFModel()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=json.dumps(otf.get(data)._result)
        if "error" in resp:
            self.set_status(400)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    def options(self):
        self.set_status(200)
        self.finish()


class OTFSingleViewHandler(BaseHandler):

    @coroutine
    def post(self):
        otf = OTFSingleViewModel()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=json.dumps(otf.get(data)._result)
        if "error" in resp:
            self.set_status(400)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    def options(self):
        self.set_status(200)
        self.finish()

class OTFHistogramHandler(BaseHandler):

    @coroutine
    def post(self):
        otf = OTFSingleViewModel()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=json.dumps(otf.get_histogram_data(data)._result)
        if "error" in resp:
            self.set_status(400)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    def options(self):
        self.set_status(200)
        self.finish()