import os
import re
import copy
import numpy as np
from PIL import Image
from itertools import count
from sqlalchemy import false
from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_logger, get_columns_info, columns_info, env_config
from api.utils.common import execute_query, make_query, prep_multidropdown_query, prep_classification_query, prep_attribute_filter_query, get_commonality_filter, commonality_query


app_log = get_logger('otf')


class OTFModel():
    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2['otf']

    def get_range_condition(self, data, orientation, alias=''):
        range_query_list = []
        values = data.get('values')
        filters = data.get('filters')
        if 'attribute_filters' in filters:
            filters.remove('attribute_filters')
        if filters.get('range'):
            for range_item in filters.get('range'):
                if isinstance(values[range_item], dict):
                    if range_item in ['xsite', 'ysite']:
                        if range_item == 'xsite':
                            range_query_list.append(
                                f" ({alias}{range_item}_{orientation}) {' BETWEEN ' if values[range_item][0].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                        else:
                            range_query_list.append(
                                f" ({alias}{range_item}_{orientation}) {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                    elif range_item in ['fieldrelx', 'fieldrely']:
                        range_query_list.append(
                            f"{range_item} {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")
                    elif range_item not in ['attribute_filters']:
                        range_query_list.append(
                            f" {alias}{range_item} {' BETWEEN ' if values[range_item].get('include', True) else ' Not BETWEEN ' } {values[range_item]['min']} and {values[range_item]['max']}")

            if isinstance(values.get('xindex'), list) and isinstance(values.get('yindex'), list):
                query_4 = " or ".join(
                    [f"(xindex {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xindex'][i]['min']} and {values['xindex'][i]['max']} and yindex {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['yindex'][i]['min']} and {values['yindex'][i]['max']})"
                    for i in range(len(values['xindex']))])
                range_query_list.append(f"({query_4})")
            if isinstance(values.get('xsite'), list) and isinstance(values.get('ysite'), list):
                query_1 = " or ".join(
                    [f"(({alias}xsite_{orientation}) {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xsite'][i]['min']} and {values['xsite'][i]['max']} and ({alias}ysite_{orientation}) {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['ysite'][i]['min']} and {values['ysite'][i]['max']})"
                    for i in range(len(values['xsite']))])
                range_query_list.append(f"({query_1})")
            if isinstance(values.get('xrel'), list) and isinstance(values.get('yrel'), list):
                query_2 = " or ".join(
                    [f"({alias}xrel {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['xrel'][i]['min']} and {values['xrel'][i]['max']} and {alias}yrel {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['yrel'][i]['min']} and {values['yrel'][i]['max']})"
                    for i in range(len(values['xrel']))])
                range_query_list.append(f"({query_2})")
            if isinstance(values.get('fieldrelx'), list) and isinstance(values.get('fieldrely'), list):
                query_3 = " or ".join(
                    [f"(fieldrelx {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['fieldrelx'][i]['min']} and {values['fieldrelx'][i]['max']} and fieldrely {' BETWEEN ' if values[range_item][i].get('include', True) else ' Not BETWEEN ' } {values['fieldrely'][i]['min']} and {values['fieldrely'][i]['max']})"
                    for i in range(len(values['fieldrelx']))])
                range_query_list.append(f"({query_3})")
        
        query_string = f' and ({" and ".join(range_query_list)})' if range_query_list else ''
        return query_string


    def get_query_condition(self, data, orientation):
        inputs = data.get('inputs')
        orientation_lower = orientation.lower()
        # defect_dict = {
        #     "orientation_side": orientation,
        # }
        range_condition = self.get_range_condition(data, orientation_lower, alias = 'df.')
        multi_drop_down_query = prep_multidropdown_query(data, alias = 'df.')
        classification_query = prep_classification_query(data, alias = 'df.')
        attribute_query = prep_attribute_filter_query(data, alias = 'df.')

        map_dict = {
            f"diepitch_x_{orientation_lower}": inputs['diepitch_x'],
            f"diepitch_y_{orientation_lower}": inputs['diepitch_y'],
            # "diepitch_x": inputs['diepitch_x'],
            # "diepitch_y": inputs['diepitch_y'],
            # "orientationmarklocation": f"'{orientation}'"
        }

        query_map_condition = 'and ' + \
            ' and '.join(f"rtn.{key}={val}" for key, val in map_dict.items())

        return f"{query_map_condition}{range_condition}{multi_drop_down_query}{classification_query}{attribute_query}"


    def get_select_cols(self, data, orientation):
        # create select statement
        inputs = data.get('inputs')
        fieldx = inputs.get('fieldx',1)
        fieldy = inputs.get('fieldy',1)
        diepitch_y = inputs.get('diepitch_y', 1)
        diepitch_x = inputs.get('diepitch_x', 1)
        single_select = {
            'xsite': f'df.xsite_{orientation}',
            'ysite': f'df.ysite_{orientation}',
            'fieldrelx': f'floor((abs(xindex_{orientation} % {fieldx}) * {diepitch_x}) + xrel_{orientation})',
            'fieldrely': f'floor((abs(yindex_{orientation} % {fieldy}) * {diepitch_y}) + yrel_{orientation})',
            'xsize': 'df.xsize',
            'ysize': 'df.ysize',
            'grade': 'df.grade',
            "classname": "cl.classname"
        }
        columns = " , ".join(
            ['df.mapid as mapid', 'df.defectid as defectid', 'df.imagelist as imagelist', 'rtn.tifffilename as tifffilename'])
        single_cols = " , " + \
            " , ".join([f'{val} as {key}' for key,
                       val in single_select.items()])
        orientation_cols = " , " + \
            " , ".join([f'{colm}_{orientation} as {colm}' for colm in [
                       'xrel', 'xindex', 'yrel', 'yindex']])
        columns = columns + orientation_cols+single_cols
        return columns


    def get_common_images(self, data, ref_data, select_cols):
        try:         
            inputs = data.get('inputs')
            image_data = data.get("inputs").get("images")
            rmapid = inputs.get("ref_mapid", None)
            projectid = data.get("projectid", None)
            mapid = data.get("values").get('mapid')

            get_smapids_query = self.queries['get_smapids'].format(**{'rmapid': rmapid, 'mapid': mapid})
            smapid = execute_query(self.connection, get_smapids_query, 'all', 'list')
            smapid = [ i['mapid'] for i in smapid]

            selected_column = image_data.get("filteredImageDisplay") if tuple(image_data.get(
                "filteredImageDisplay")) else columns_info['image_code'].values()

            img_code_condition = ''
            if len(selected_column)==1:
                if str(selected_column[0]).startswith(('33', '34')):
                    ref_code = 32 if str(selected_column[0]).startswith('33') else 32
                    img_code_condition += (
                        f" and (((imagelist LIKE '%-30%') and (imagelist LIKE '%-{ref_code}%'))"
                        f" or ((imagelist LIKE '%-{selected_column[0]},%') OR (imagelist LIKE '%-{selected_column[0]}')))"
                    )
                else:
                    img_code_condition += f" AND ((imagelist LIKE '%-{selected_column[0]},%') OR (imagelist LIKE '%-{selected_column[0]}'))"

            rdefectids = [d['defectid'] for d in ref_data if d['refcm'] == 'Common']
            query = self.queries['read_sec_tifffile'].format(
                        **{'select_cols': select_cols,'projectid': projectid, 'rmapid': rmapid, 'img_code_condition': img_code_condition, 'mapid': mapid, 'rdefectids': rdefectids})
            secondary_data = execute_query(self.connection, query, 'all', 'list')
            secondary_data = get_image_link(secondary_data, [], selected_column) 
            sec_default_sorted_dict = {}
            secondary_dict = {}

            for id in smapid:
                sec_default_sorted_dict[f"{id}"] = {
                    "defectId": '',
                    "imageUrl": '',
                    "mapId": f"{id}",
                    "isref": '0',
                    "rmapid": f"{rmapid}",
                    "rdefectid": ''
                }


            for d in secondary_data:
                if d['smapid'] not in sec_default_sorted_dict.keys():
                    sec_default_sorted_dict[f"{d['smapid']}"] = {
                        "defectId": '',
                        "imageUrl": '',
                        "mapId": f"{d['smapid']}",
                        "isref": '0',
                        "rmapid": f"{d['rmapid']}",
                        "rdefectid": ''
                    }

                if f"{d['rdefectid']}" not in secondary_dict.keys():
                    secondary_dict[f"{d['rdefectid']}"] = {}

                secondary_dict[f"{d['rdefectid']}"][f"{d['smapid']}"] = {
                            "defectId": f"{d['sdefectid']}",
                            "imageUrl": f"{d['image']}",
                            "mapId": f"{d['smapid']}",
                            "isref": '0',
                            "xrel":f"{d['xrel']}",
                            "xindex": f"{d['xindex']}",
                            "yrel": f"{d['yrel']}",
                            "yindex":f"{d['yindex']}",
                            "xsite":f"{d['xsite']}",
                            "ysite":f"{d['ysite']}",
                            "fieldrelx":f"{d['fieldrelx']}",
                            "fieldrely":f"{d['fieldrely']}",
                            "xsize":f"{d['xsize']}",
                            "ysize":f"{d['ysize']}",
                            "grade":f"{d['grade']}",
                            "rmapid": f"{d['rmapid']}",
                            "rdefectid": f"{d['rdefectid']}"
                        }

            sec_default_sorted_dict = dict(sorted(sec_default_sorted_dict.items()))
            resp = []
            for d in ref_data:
                if d['isref']:
                    tmp = {
                            f"{d['mapid']}": {
                                "defectId": f"{d['defectid']}",
                                "imageUrl": f"{d['image']}",
                                "mapId": f"{d['mapid']}",
                                "isref": '1',
                                "xrel": f"{d['xrel']}",
                                "xindex": f"{d['xindex']}",
                                "yrel": f"{d['yrel']}",
                                "yindex":f"{d['yindex']}",
                                "xsite":f"{d['xsite']}",
                                "ysite":f"{d['ysite']}",
                                "fieldrelx":f"{d['fieldrelx']}",
                                "fieldrely":f"{d['fieldrely']}",
                                "xsize":f"{d['xsize']}",
                                "ysize":f"{d['ysize']}",
                                "grade":f"{d['grade']}",
                                "rmapid": f"{d['rmapid']}",
                                "rdefectid": f"{d['defectid']}"
                            }
                        }
                    tmp.update(sec_default_sorted_dict)
                    for key, val in secondary_dict.get(f"{d['defectid']}", {}).items():
                        tmp[key] = val
                else:
                    tmp = {
                            f"{rmapid}": {
                                "defectId": '',
                                "imageUrl": '',
                                "mapId": f"{rmapid}",
                                "isref": '1',
                                "rmapid": f"{rmapid}",
                                "rdefectid": ''
                            }
                        }

                    tmp.update(sec_default_sorted_dict)

                    tmp[f"{d['mapid']}"] = {
                        "defectId": f"{d['defectid']}",
                        "imageUrl": f"{d['image']}",
                        "mapId": f"{d['mapid']}",
                        "isref": '0',
                        "xrel": f"{d['xrel']}",
                        "xindex": f"{d['xindex']}",
                        "yrel": f"{d['yrel']}",
                        "yindex":f"{d['yindex']}",
                        "xsite":f"{d['xsite']}",
                        "ysite":f"{d['ysite']}",
                        "fieldrelx":f"{d['fieldrelx']}",
                        "fieldrely":f"{d['fieldrely']}",
                        "xsize":f"{d['xsize']}",
                        "ysize":f"{d['ysize']}",
                        "grade":f"{d['grade']}",
                        "rmapid": f"{d['rmapid']}",
                        "rdefectid": ""
                    }

                tmp = {
                    "refDefectId": f"{d['defectid']}",
                    "refDefectClass": d['classname'],
                    "otfImageList": list(tmp.values())
                }

                resp.append(tmp)

            return resp
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}


    def update_query(self, query, orientation):
        ''' Updating columns with orientation '''
        columns = ['xsite_prep0', 'ysite_prep0', 'xsite', 'ysite', 'xsite_prep1', 'ysite_prep1',
                'xsite_prep2', 'xrel', 'yrel', 'xsite_prep_cm', 'ysite_prep_cm']
        for col in columns:
            if col in query:
                query = query.replace(col, f'{col}_{orientation.lower()}')
        return query


    def prepare_column_sort(self, image_data, orientation='DOWN'):
        ''' Preparing query string for column sorting '''
        if image_data.get('column_sort'):
            columns_sort_query = [f"{key.lower()} {value} " for key, value in image_data['column_sort'].items(
            ) if image_data['column_sort'][key]]
            column_sort_query = " , ".join(columns_sort_query)
            sort_query = self.update_query(f' ORDER BY {column_sort_query}', orientation)

            return sort_query
        return " ORDER BY df.defectid ASC"


    @coroutine
    def get(self, data):
        '''
        TODO get image based on mapid and defectid
        '''
        try:
            if data['values']['mapid'][0] == 0:
                raise Return({
                    'total': 0,
                    'limit': 0,
                    'offset': 0,
                    'data': []
                })
            resp = []
            query_params = {}

            inputs = data.get('inputs')
            orientation = inputs.get('orientationmarklocation', 'DOWN')
            image_data = data.get("inputs").get("images")
            query_params['rmapid'] = inputs.get("ref_mapid", None)
            query_params['projectid'] = data.get("projectid", None)
            query_params['orderby'] = self.prepare_column_sort(image_data, orientation)

            commonality_filter = get_commonality_filter(data)
            commonality_query(data, commonality_filter, query_params, alias='df')

            selected_column = image_data.get("filteredImageDisplay") if tuple(image_data.get(
                "filteredImageDisplay")) else columns_info['image_code'].values()
            
            query_params['mapid'] = data.get("values").get('mapid') if data.get(
                "values") and data.get("values").get('mapid') else False
            defectid_list = data.get("values").get('defectid') if data.get(
                "values") and data.get("values").get('defectid') else False

            if defectid_list:
                data.get("values").pop('defectid')
                data.get("filters").get('multiDropdown').remove('defectid')

            if query_params['mapid']:
                query_params['select_cols'] = self.get_select_cols(data, orientation.lower())
                limit, offset = image_data.get(
                    'limit', 10), image_data.get('offset', 10)
                query_params['selected_filter'] = f" LIMIT {offset}, {limit}"
                query_params['condition'] = self.get_query_condition(data, orientation)

                # fetching tiff file name and image list with respect defectid and mapid
                ids_condition = f" and df.mapid in {query_params['mapid']}"
                if len(selected_column)==1:
                    if str(selected_column[0]).startswith(('33', '34')):
                        ref_code = {
                            340: ("300", "310"),
                            341: ("301", "311"),
                            34: ("30", "31"),
                            330: ("300", "320"),
                            331: ("301", "321"),
                            33: ("30", "32")
                        }

                        ids_condition += (
                            f" and (((CONCAT(df.imagelist, ',') LIKE '%-{ref_code[selected_column[0]][0]},%') and (CONCAT(df.imagelist, ',') LIKE '%-{ref_code[selected_column[0]][1]},%'))"
                            f" or ((df.imagelist LIKE '%-{selected_column[0]},%') OR (df.imagelist LIKE '%-{selected_column[0]}')))"
                        )
                    else:
                        ids_condition += f" and ((df.imagelist LIKE '%-{selected_column[0]},%') OR (df.imagelist LIKE '%-{selected_column[0]}'))"

                if defectid_list:
                    defectid_list = tuple(defectid_list) if type(defectid_list) == 'list' else (defectid_list,)
                    ids_condition = ids_condition + \
                        f" and df.defectid in {defectid_list}"
                query_params['ids_condition'] = ids_condition

                if not(query_params['rmapid']):
                    query = self.queries['read_tifffile_name'].format(**query_params)
                    query_result = execute_query(self.connection, query, 'all', 'list')

                    resp = get_image_link(query_result, resp, selected_column)

                    # fetching count of all images entry
                    count_query = self.queries['count'].format(**query_params)
                    count_query_result = execute_query(self.connection, count_query, '')
                else:
                    smapid = [ i for i in query_params['mapid'] if i != query_params['rmapid']]
                    query_params['smapid'] = tuple(smapid + [0])
                    query = self.queries['read_ref_tifffile'].format(**query_params)

                    query_result = execute_query(self.connection, query, 'all', 'list')
                    ref_data = get_image_link(query_result, resp, selected_column)
                    resp = self.get_common_images(data, ref_data, query_params['select_cols'])

                    count_query = self.queries['count_ref_tifffile'].format(**query_params)
                    count_query_result = execute_query(self.connection, count_query, '')

                resp_data = {
                    'data': resp,
                    'limit': limit,
                    'offset': offset,
                    'total': int(count_query_result[0])
                }
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        raise Return(resp_data)


class OTFSingleViewModel():
    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = queries2['otf']
        self.defectid = ''
        self.mapid = ''
        self.tiff_file_name = ''
        self.hover_singleview = False


    def get_pixel_data(self, imgsrc):
        try:
            img_stats = {}

            # Open the image
            im = Image.open(imgsrc)

            if im.mode != 'L':
                im = im.convert('L')

            # Get the size of the image
            width, height = im.size

            pixel_data = {}
            # Iterate over all the pixels
            for y in range(height):
                for x in range(width):
                    # Get the pixel value at position (x, y)
                    pixel_data[f"{x}-{y}"] = im.getpixel((x, y))

            im_np_array = np.asarray(im)

            img_stats = {
                "pixel_data": pixel_data,
                "min": int(im_np_array.min()),
                "max": int(im_np_array.max()),
                "avg": int(im_np_array.mean()),
                "median": int(np.median(im_np_array)),
                "standardDeviation": int(im_np_array.std())
            }
        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
        return img_stats


    def get_diff_image(self, cur_img, ref_img, prefix):
        image_codes = copy.copy(columns_info['image_code'])

        image_type = prefix.split('_', 1)[1] if 'gf' in prefix or 'bf' in prefix else prefix
        image_perspective = prefix.split('_', 1)[0] if 'gf' in prefix or 'bf' in prefix else 'unknown'

        filename, ext = os.path.splitext(self.tiff_file_name)
        filename = re.sub(r'[^a-zA-Z0-9]', '_', filename)
        base_path = os.path.join(env_config['watchdog_pick_location']['src'], 'images')
        dest_path = os.path.join(base_path, filename)
        diff_image_name = f"{filename}_{prefix}_{self.defectid}.jpg"
        complete_tiff_path = os.path.join(dest_path, diff_image_name)

        if not(os.path.exists(complete_tiff_path)):
            cur_img = Image.open(cur_img)
            ref_img = Image.open(ref_img)

            # Convert both images to 8-bit grayscale
            if cur_img.mode != 'L':
                cur_img = cur_img.convert('L')
            
            if ref_img.mode != 'L':
                ref_img = ref_img.convert('L')
            
            # Create a new image to hold the difference image
            difference_image = Image.new('L', cur_img.size)

            # # Iterate over the pixels in both images
            for x in range(cur_img.width):
                for y in range(cur_img.height):
                    # Calculate the difference between the pixel values
                    cur_pixel = cur_img.getpixel((x, y))
                    ref_pixel = ref_img.getpixel((x, y))
                    difference = cur_pixel - ref_pixel
                    # Set the pixel value of the difference image to the calculated difference
                    difference_image.putpixel((x, y), difference if difference > 0 else 0)

            difference_image.save(complete_tiff_path, 'JPEG', subsampling=0 , quality = 95)
            app_log.info(f"Diff image has been created at: {complete_tiff_path}")
        
        diff_details = {
                "mapid": self.mapid,
                "defectid": self.defectid,
                "image": f"{env_config['image_location']}/{filename}/{diff_image_name}",
                "image_code": image_codes[prefix],
                "image_path": complete_tiff_path,
                "imageType": image_type,
                "imagePerspective": image_perspective,
         }
        if(not self.hover_singleview):
            img_stats = self.get_pixel_data(complete_tiff_path)
            diff_details["min"]= img_stats["min"]
            diff_details["max"]= img_stats["max"]
            diff_details["avg"]= img_stats["avg"]
            diff_details["median"]= img_stats["median"]
            diff_details["standardDeviation"]= img_stats["standardDeviation"]
            diff_details["pixelData"]= img_stats["pixel_data"]

        return diff_details


    def grayscale_stretch(self, image_src, prefix):
        image_type = prefix.split('_', 1)[1] if 'gf' in prefix or 'bf' in prefix else prefix
        image_perspective = prefix.split('_', 1)[0] if 'gf' in prefix or 'bf' in prefix else 'unknown'

        filename, ext = os.path.splitext(self.tiff_file_name)
        filename = re.sub(r'[^a-zA-Z0-9]', '_', filename)
        base_path = os.path.join(env_config['watchdog_pick_location']['src'], 'images')
        dest_path = os.path.join(base_path, filename)
        image_name = f"{filename}_{prefix}_{self.defectid}.jpg"
        image_path = os.path.join(dest_path, image_name)

        if not(os.path.exists(image_path)):
            im = Image.open(image_src)
            if im.mode != 'L':
                im = im.convert('L')

            minimum = im.getextrema()[0]
            maximum = im.getextrema()[1]
            factor = 0

            if maximum != minimum:
                factor = 255 / (maximum - minimum)
            stretched_image = Image.new('L', im.size)

            for x in range(im.width):
                for y in range(im.height):
                    value = im.getpixel((x, y))
                    stretched_value = int((value - minimum) * factor)
                    stretched_image.putpixel((x, y), stretched_value)

            stretched_image.save(image_path, 'JPEG', subsampling=0 , quality = 95)
            app_log.info(f"Diff stretched image has been created at: {image_path}")
        
        image_details = {
                "mapid": self.mapid,
                "defectid": self.defectid,
                "image": f"{env_config['image_location']}/{filename}/{image_name}",
                "image_code": None,
                "image_path": image_path,
                "imageType": image_type,
                "imagePerspective": image_perspective
        }

        if(not self.hover_singleview):
            img_stats = self.get_pixel_data(image_path)
            image_details["min"] = img_stats["min"]
            image_details["max"] = img_stats["max"]
            image_details["avg"] = img_stats["avg"]
            image_details["median"] = img_stats["median"]
            image_details["standardDeviation"] = img_stats["standardDeviation"]
            image_details["pixelData"] = img_stats["pixel_data"]


        return image_details


    @coroutine
    def get(self, data):
        '''
            get image based on mapid and defectid
        '''
        try:
            resp_data = {}
            self.defectid = data.get('defectid', False)
            self.mapid = data.get('mapid', False)
            self.hover_singleview = data.get('hoverSingleView', False)

            image_codes = copy.copy(columns_info['image_code'])
            image_codes.pop('ref')
            image_codes = dict((v,k) for k,v in image_codes.items())

            image_combos = {
                1 : ('cur', 'prev', 'prev_diff', 'prev_diff_stretch'),
                2 : ('bf_cur', 'bf_prev', 'bf_prev_diff', 'bf_prev_diff_stretch'),
                3 : ('gf_cur', 'gf_prev', 'gf_prev_diff', 'gf_prev_diff_stretch'),
                4 : ('cur', 'next', 'next_diff', 'next_diff_stretch'),
                5 : ('bf_cur', 'bf_next', 'bf_next_diff', 'bf_next_diff_stretch'),
                6 : ('gf_cur', 'gf_next', 'gf_next_diff', 'gf_next_diff_stretch'),
                # 7 : ('cur', 'ref', 'diff'),
            }

            if not(self.mapid) and not(self.defectid):
                raise Exception("mapid and defectid are must.")

            read_img_detatils = self.queries['read_image_details'].format(
                    **{'mapid': self.mapid, 'defectid': self.defectid})
            img_data = execute_query(self.connection, read_img_detatils, 'one', 'fetchonelist')
            app_log.info(f"Read image details query: {read_img_detatils}")

            if len(img_data) == 0:
                raise Exception("No image data found")

            self.tiff_file_name = img_data['tifffilename']
            image_list = get_image_link([img_data], [], image_codes.keys())

            image_dict = {}
            image_count = len(image_list)
            base_path = os.path.join(env_config['watchdog_pick_location']['src'], 'images')
            for img in image_list:
                complete_tiff_path = os.path.join(base_path, img['image_path'])
                if os.path.exists(complete_tiff_path):
                    img_data = copy.copy(img)
                    img_data["image_path"] = complete_tiff_path
                    img_type_pr = image_codes[img_data['image_code']]
                    img_data["imageType"] = img_type_pr.split('_', 1)[1] if 'gf' in img_type_pr or 'bf' in img_type_pr else img_type_pr
                    img_data["imagePerspective"] = img_type_pr.split('_', 1)[0] if 'gf' in img_type_pr or 'bf' in img_type_pr else 'unknown'

                    if not self.hover_singleview:
                        img_stats = self.get_pixel_data(complete_tiff_path)
                        img_data["min"] = img_stats["min"]
                        img_data["max"] = img_stats["max"]
                        img_data["avg"] = img_stats["avg"]
                        img_data["median"] = img_stats["median"]
                        img_data["standardDeviation"] = img_stats["standardDeviation"]
                        img_data["pixelData"] = img_stats["pixel_data"]

                    img_data.pop('imagelist')
                    img_data.pop('tifffilename')
                    image_dict[img_type_pr] = img_data
                else:
                    image_count -= 1

            if image_count == 0:
                raise Exception("No image found. Please upload tiff.")

            image_list = {}
            pushed_img = []
            available_refs = []
            for k, v in image_combos.items():
                if image_dict.get(v[0], False) and image_dict.get(v[1], False):
                    cur_img = copy.copy(image_dict[v[0]])
                    ref_img = copy.copy(image_dict[v[1]])

                    if image_dict.get(v[2], False) == False:
                        # Create diff images
                        image_dict[v[2]] = self.get_diff_image(cur_img["image_path"], ref_img["image_path"], prefix = v[2])
                    diff_img = copy.copy(image_dict[v[2]])

                    # Create stretch image
                    if(not self.hover_singleview):
                        diff_img_stretch = self.grayscale_stretch(image_dict[v[2]]["image_path"], prefix = v[3])

                    if v[0] not in pushed_img:
                        pushed_img.append(v[0])
                        cur_img.pop("image_path")
                        img_type = f"{cur_img['imageType']}_{cur_img['imagePerspective']}"
                        image_list[img_type] = cur_img

                    if v[1] not in pushed_img:
                        pushed_img.append(v[1])
                        ref_img.pop("image_path")
                        img_type = f"{ref_img['imageType']}_{ref_img['imagePerspective']}"
                        image_list[img_type] = ref_img
                        available_refs.append('next' if 'next' in v[1] else 'prev')

                    diff_img.pop("image_path")
                    img_type = f"{diff_img['imageType']}_{diff_img['imagePerspective']}"
                    image_list[img_type] = diff_img
                    if(not self.hover_singleview):
                        diff_img_stretch.pop("image_path")
                        img_type = f"{diff_img_stretch['imageType']}_{diff_img_stretch['imagePerspective']}"
                        image_list[img_type] = diff_img_stretch
          
            if "prev" in available_refs and "next" in available_refs and self.hover_singleview:
                image_list = {x:image_list[x]  for x in image_list.keys() if "next" not in x}

            resp_data = {
                "defectId": self.defectid,
                "mapid": self.mapid,
                "availablePrevNextRef": list(set(available_refs)),
                "selectedPrevNextRef": "prev" if "prev" in available_refs else available_refs[0],
                "imageList": image_list
            }

        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
            return {"error": str(e)}
        raise Return(resp_data)


    @coroutine
    def get_histogram_data(self, data):
        try:
            '''
                This method will fetch data for histogram and cross section graphs
            '''
            resp_data = {}
            line_coords = data.get('lineCoords', None)
            line_direction = data.get('lineDirection', 'x').lower()
            selections = data.get('selections', ["cur_bf", "prev_bf", "prev_diff_bf", "prev_diff_stretch_bf", "next_bf", "next_diff_bf", "next_diff_stretch_bf", "cur_gf", "prev_gf", "prev_diff_gf", "prev_diff_stretch_gf", "next_gf", "next_diff_gf", "next_diff_stretch_gf", "cur_unknown", "prev_unknown", "prev_diff_unknown", "prev_diff_stretch_unknown", "next_unknown", "next_diff_unknown", "next_diff_stretch_unknown"])
            image_data = self.get(data)._result

            if line_coords:
                x_from = min(line_coords["x1"],line_coords["x2"]) 
                x_to = max(line_coords["x1"],line_coords["x2"])
                y_from = min(line_coords["y1"],line_coords["y2"])
                y_to = max(line_coords["y1"],line_coords["y2"])
                for im, val in image_data["imageList"].items():
                    if(im in selections):
                        resp_data[im] = []
                        for x in range(x_from, x_to+1):
                            for y in range(y_from, y_to+1):
                                x_axis = x if line_direction == 'x' else y
                                resp_data[im].append({'x': int(x_axis), 'y': int(val['pixelData'][f'{x}-{y}'])})
            else:
                for im, val in image_data["imageList"].items():
                    if(im in selections):    
                        histogram, bin_edges = np.histogram(list(val['pixelData'].values()), bins=256, range=(0, 255))
                        resp_data[im] = []
                        for i, v in np.ndenumerate(histogram):
                            resp_data[im].append({'x': int(i[0]), 'y': int(v)})

            resp_data = {
                'data': resp_data,
                'selections': selections       
            }
        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
            return {"error": str(e)}
        raise Return(resp_data)


def get_image_link(query_result, resp, selected_column):
    # TODO generating image url with image index
    diff_img_code = {
        330: ('300', '320', 'bf_next_diff'),
        331: ('301', '321', 'gf_next_diff'),
        33: ('30', '32', 'next_diff'),
        340: ('300', '310', 'bf_prev_diff'),
        341: ('301', '311', 'gf_prev_diff'),
        34: ('30', '31', 'prev_diff')
    }

    for result in query_result:
        tiff_file_name = result.get('tifffilename')
        image_list = result.get('imagelist')
        image_count = image_list.split('|')[1].split(',')
        image_codes = [i.split('-')[1] for i in image_count]
        tiff_file_name_split, ext = os.path.splitext(tiff_file_name)
        tiff_file_name_split = re.sub(r'[^a-zA-Z0-9]', '_', tiff_file_name_split)

        if (
            len(selected_column) == 1
            and str(selected_column[0]).startswith(('33', '34'))
            and str(selected_column[0]) not in image_codes
        ):
            var_cur = diff_img_code[selected_column[0]][0]
            var_ref = diff_img_code[selected_column[0]][1]
            var_prefix = diff_img_code[selected_column[0]][2]
            base_path = os.path.join(env_config['watchdog_pick_location']['src'], 'images')
            if var_cur in image_codes and var_ref in image_codes:
                otf = OTFSingleViewModel()
                otf.defectid = result['defectid']
                otf.tiff_file_name = tiff_file_name
                for img in image_count:
                    index_info = img.split("-")
                    if index_info[1] == var_cur:
                        cur_img = os.path.join(base_path, f'{tiff_file_name_split}/{tiff_file_name_split}_{index_info[0]}.jpg')
                    if index_info[1] == var_ref:
                        ref_img = os.path.join(base_path, f'{tiff_file_name_split}/{tiff_file_name_split}_{index_info[0]}.jpg')

                diff_img = otf.get_diff_image(cur_img, ref_img, prefix=var_prefix)

                results = copy.copy(result)
                results.update({
                    "image": diff_img["image"],
                    "image_code": int(index_info[1]),
                    "image_path": diff_img["image_path"]
                })
                resp.append(results)
        else:
            for img in image_count:
                index_info = img.split("-")
                if int(index_info[1]) in selected_column:
                    image_name = f'{tiff_file_name_split}_{index_info[0]}.jpg'
                    results = copy.copy(result)
                    results.update({
                        "image": f"{env_config['image_location']}/{tiff_file_name_split}/{image_name}",
                        "image_code": int(index_info[1]),
                        "image_path": f"{tiff_file_name_split}/{image_name}"
                    })
                    resp.append(results)
    return resp
