nohup python3 api\otf\server.py --port=8200 --env=dev --service=otf
nohup python3 api\otf\server.py --port=8201 --env=dev --service=otf
nohup python3 api\otf\server.py --port=8202 --env=dev --service=otf
nohup python3 api\otf\server.py --port=8203 --env=dev --service=otf