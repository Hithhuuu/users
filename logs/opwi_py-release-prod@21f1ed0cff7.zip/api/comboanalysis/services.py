import tornado
from api.comboanalysis.comboanalysis_api.comboanalysishandler import ComboAnalysisHandler

services = {
    'comboanalysis': [
        tornado.web.url(r"/comboanalysis", ComboAnalysisHandler)
        # tornado.web.url(r"/comboanalysis", ComboAnalysisHandler)
    ]
}