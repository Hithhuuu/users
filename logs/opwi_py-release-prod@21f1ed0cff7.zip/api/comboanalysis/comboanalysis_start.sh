nohup python3 api\comboanalysis\server.py --port=8130 --env=dev --service=comboanalysis
nohup python3 api\comboanalysis\server.py --port=8131 --env=dev --service=comboanalysis
nohup python3 api\comboanalysis\server.py --port=8132 --env=dev --service=comboanalysis
nohup python3 api\comboanalysis\server.py --port=8133 --env=dev --service=comboanalysis
nohup python3 api\comboanalysis\server.py --port=8134 --env=dev --service=comboanalysis