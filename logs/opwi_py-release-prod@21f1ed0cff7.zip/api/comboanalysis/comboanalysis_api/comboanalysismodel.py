from itertools import count
from tornado.gen import coroutine, Return
import pandas as pd
from tornado.escape import json_encode
from uuid import uuid1
from api.utils.utils import queries2, connection_pool, get_logger, getdbconnection
from api.utils.common import execute_query
from api.utils.datastore import DataStore
from api.utils.data_processing import gen_mapid
from datetime import datetime

app_log = get_logger("comboanalysis")


class ComboAnalysis():

    def __init__(self):
        self.connection = connection_pool.connect()
        self.dbconn = getdbconnection()
        self.queries = queries2['comboanalysis']
        self.ds = DataStore(self.connection)

    def insert_header(self, newmapid, comboname, combo, defect_cnt=None):
        df = execute_query(self.connection, self.queries['select_header'].format(
            **{'mapid': combo}), 'all', 'df')

        df['mapid'] = newmapid
        oldmapname = df.loc[0, 'mapname'].split('|')
        oldmapname[-2] = comboname
        df['mapname'] = '|'.join(oldmapname)
        df['filename'] = f'{comboname}.001'
        format_date='%Y-%m-%d %H:%M-%S'
        df['cdt'] = datetime.now().strftime(format_date)
        df['filetimestamp'] = df['filetimestamp'].dt.strftime(
            format_date)
        df['resulttimestamp'] = df['resulttimestamp'].dt.strftime(
            format_date)
        df['is_combo'] = 1

        if defect_cnt:
            df['defectcnt'] = defect_cnt
        else:
            df['defectcnt'] = df['defectcnt'].sum()

        df.head(2).to_sql('opwi_map_header', self.dbconn,
                          if_exists='append', index=False)
        execute_query(
            self.connection,
            self.queries['insert_into_map_class'].format(
                **{'newmapid': newmapid, 'mapid': combo}),
            ''
        )
        return df.iloc[0]['mapname']

    def insert_into_temp_table(self, newmapid, comboname, combo, newtablename):
        query = self.queries['insert_into_new_table'].format(**{
            'newmapid': newmapid,
            'mapid': combo,
            'tablename': newtablename
        })
        # cursor.execute(query)
        execute_query(self.connection, query, '', '', 16)
        app_log.info(f'{comboname} {query}')
        return {'id': newmapid}

    def insert_into_combos(self, new_combos, data, rfg=1):
        '''Insert into combos table'''

        # check of pid exists
        # df = execute_query(self.connection, self.queries['select_opwi_combos'].format(
        #     **data), 'all', 'df')
        # if not df.empty:
        #     df['rfg'] = 0
        #     df = df.append({}, ignore_index=True)
        #     df.to_sql('opwi_combos', self.dbconn,
        #               if_exists='append', index=False)

        app_log.info('Insert into combos table')
        insert_data = [{'projectid': data['projectid'],
                        'mapid': combo['id'],
                        'mmap': data.get('mmap', pd.NA),
                        'rmap': data['rmap'],
                        'comboname': ', '.join(data['comboname'][comboname]),
                        'rfg': rfg} for comboname, combo in new_combos.items()]
        df = pd.DataFrame(insert_data).append({}, ignore_index=True)
        df.to_sql('opwi_combos', self.dbconn, if_exists='append', index=False)
        app_log.info('Inserted into combos table')

    def combo_commonality(self, data, combo):
        '''combo by commonality'''
        self.query_data = {}
        self.query_data['projectid'] = data['projectid']
        self.query_data['ref_mapid'] = combo[0]
        self.query_data['radius'] = data.get('radius', 5000)
        self.query_data['secondary_mapids'] = combo[1]
        mapids = combo
        self.query_data['mapid'] = tuple(mapids)
        self.query_data['offset_mapid'] = tuple(combo) \
            if len(combo) > 0 else tuple(mapids)

        orientation = data.get('orientationmarklocation', 'DOWN').lower()
        self.query_data['orientation'] = orientation

        execute_query(self.connection,
                      self.queries['create_combo_cm_wip_table'].format(**self.query_data), '', '', 10)
        for index in range(len(combo) - 1):
            query = self.queries['combo_insert_wip']
            self.query_data['ref_mapid'] = str(tuple(combo[0:index+1] + [0]))
            self.query_data['secondary_mapids'] = combo[index+1]
            query = query.format(**self.query_data)
            app_log.info(f'combo commonality query : {query}')
            query = f'INSERT INTO rawcm.opwi_defect_combo_cm_wip_{self.query_data["projectid"]} {query}'
            execute_query(
                self.connection, query, '', '', 10
            )
            self.query_data['rmapid'] = combo[0]
            self.query_data['smapid'] = combo[index]
            query = self.queries['combo_insert_adders_missing_wip'].format(
                **self.query_data)
            app_log.info(f'combo adders missing query : {query}')
            execute_query(self.connection,
                          self.queries['combo_insert_adders_missing_wip'].format(**self.query_data), '', '', 10)
        '''Insert into main cm table'''
        app_log.info('Inserting into main cm table')
        execute_query(
            self.connection,
            self.queries['create_combo_cm_table'].format(**self.query_data), '','',10)
        app_log.info(
            f"combo_insert_cm : {self.queries['combo_insert_cm'].format(**self.query_data)}")
        execute_query(self.connection,
                      self.queries['combo_insert_cm'].format(**self.query_data), '','',10)
        app_log.info(
            f"combo_insert_cm_rest : {self.queries['combo_insert_cm_rest'].format(**self.query_data)}")
        execute_query(self.connection,
                      self.queries['combo_insert_cm_rest'].format(**self.query_data), '','',10)
        app_log.info('Inserting into main cm table completed')

    @coroutine
    def get_charts_data(self, data):
        '''Return FAR and CR values'''
        try:
            df = execute_query(self.connection, self.queries['select_opwi_combos'].format(
                **data), 'all', 'df')

            if df.empty:
                raise Exception("No combos found")

            data['refmapid'] = df['rmap'].iloc[0]
            data['mastermapid'] = df['mmap'].iloc[0] if df['mmap'].iloc[0] else 'Null'
            data['combos'] = df['mapid'].tolist()
            data['mapid'] = data['combos'] + [data['refmapid']]

            count_data = data.copy()

            if df['mmap'].iloc[0]:
                data['mapid'] = data['mapid'] + [df['mmap'].iloc[0]]

            resp = {}
            data['mapid'] = str(tuple(data['mapid']))
            data['combos'] = str(tuple(data['combos']))

            count_data['mapid'] = str(tuple(count_data['mapid']))
            count_data['combos'] = str(tuple(count_data['combos']))
            count_data['xaxis'] = data.get('xaxis', 'groupname')
            query = self.queries['count'].format(**count_data)
            resp['count'] = self.ds.fetch(query)._result

            query = self.queries['far'].format(**data)
            resp['far'] = self.ds.fetch(query)._result

            query = self.queries['cr'].format(**data)
            resp['cr'] = self.ds.fetch(query)._result

            query = self.queries['select_comboname'].format(**data)
            resp['comboname'] = self.ds.fetch(query)._result
        except Exception as e:
            app_log.exception(e)
            resp = {
                "msg": "Error",
                "Error": str(e)
            }
        raise Return(json_encode(resp))

    def insert_into_export_meta(self, comboname, combo, newmapid):
        '''Insert into meta data'''
        app_log.info(f'Insert into export metadata {newmapid}')
        query = self.queries['insert_into_export_metadata'].format(**{
            'mapid': combo[0],
            'newmapid': newmapid,
            'comboname': comboname
        })
        app_log.info(f'Inserted into export metadata {query}')
        # cursor.execute(query)
        execute_query(self.connection, query, '')

    def update_mastermap_in_projects(self, data):
        '''Update maps in opwi_my_projectmaps'''
        if data.get('mmap', None):
            query = self.queries['update_into_project_maps'].format(**data)
            app_log.info(f'Updated memory map : {query}')
            execute_query(self.connection, query)

    @coroutine
    def create(self, data):
        '''create combos
            1. create new table with new map/combo id
            2. insert data into new table
            3. insert data from new table to defectmain table
            4. insert data into map header table
            5. delete temp table
        '''

        # combo creation started for main table
        # newtablename = str(uuid1()).replace('-', '')
        newtablename = f"combo_{data['projectid']}_{str(uuid1()).replace('-', '')}"
        app_log.info(f'new table name - {newtablename}')
        execute_query(
            self.connection,
            self.queries['create_new_table'].format(
                **{'tablename': newtablename}), ''
        )
        new_combos = {}

        try:
            for comboname, combo in data['combo'].items():
                newmapid = gen_mapid()
                if data['commonality']:
                    # for combo by commonality
                    self.combo_commonality(data, combo)
                    insert_query_cm = self.queries['insert_into_defect_main_cm'].format(**{
                        'tablename': newtablename,
                        'projectid': data['projectid'],
                        'newmapid': newmapid,
                        'mapid': str(tuple(combo)),
                        'attrpriority': data['attrpriority']})
                    app_log.info(insert_query_cm)
                    execute_query(
                        self.connection,
                        insert_query_cm,
                        '', '', 16
                    )

                    max_defectid_query = f'SELECT MAX(defectid) + 1 FROM {newtablename} FINAL;'
                    max_defectid = execute_query(self.connection, max_defectid_query, fetch='one')[0]

                    insert_query_rest = self.queries['insert_into_defect_main_rest'].format(**{
                        'tablename': newtablename,
                        'projectid': data['projectid'],
                        'newmapid': newmapid,
                        'mapid': str(tuple(combo)),
                        'max_defectid': max_defectid
                    })
                    app_log.info(insert_query_rest)
                    # cursor.execute(insert_query_rest)
                    execute_query(self.connection, insert_query_rest, '')

                    defect_cnt_query = f'SELECT COUNT(1) FROM {newtablename} FINAL;'
                    defect_cnt = execute_query(self.connection, defect_cnt_query, fetch='one')[0]

                    mapname = self.insert_header(
                        newmapid, comboname, combo, defect_cnt)
                    new_combo = {'id': newmapid}
                    new_combo['mapname'] = mapname
                    new_combos.update({comboname: new_combo})

                else:
                    combo = str(tuple(combo))
                    app_log.info(f'id for {combo} {comboname} - {newmapid}')
                    new_combo = self.insert_into_temp_table(
                        newmapid, comboname, combo, newtablename)
                    # combo creation started for header table
                    mapname = self.insert_header(
                        newmapid, comboname, combo)
                    new_combo['mapname'] = mapname
                    new_combos.update({comboname: new_combo})
                # combo creation ended for header table
                self.insert_into_combos(new_combos, data)
                self.update_mastermap_in_projects(data)
                self.insert_into_export_meta(
                    comboname, data['combo'][comboname], newmapid)
                execute_query(self.connection, self.queries['insert_into_main_table'].format(
                    **{'tablename': newtablename}), '')
            execute_query(self.connection, self.queries['drop_temp_table'].format(**{
                'tablename': newtablename}), '')

        except Exception as e:
            app_log.error(e)
            execute_query(self.connection, self.queries['drop_temp_table'].format(**{
                'tablename': newtablename}), '')

        # combo creation ended for main table
        raise Return(new_combos)

    @coroutine
    def delete(self, data):
        '''Delete map from combo table.'''
        try:
            data['mapid'] = tuple(data['mapid'])
            delete_combo_query = '''INSERT into raw.opwi_combos
                select projectid, mapid, rmap, mmap, comboname, 0 from raw.opwi_combos final
                where projectid={projectid} and mapid in ({mapid});
            '''.format(**data)
            execute_query(self.connection, delete_combo_query)
            resp = {'msg': 'combo deleted'}
        except Exception as e:
            app_log.error(f'{e}')
            resp = {'error': f'{e}'}
        raise Return(resp)

    def __del__(self):
        '''on connection close'''
        self.connection.close()
