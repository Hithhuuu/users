import tornado
import pandas as pd
from string import punctuation
from tornado.escape import json_decode
from tornado.gen import coroutine, Return
from api.utils.utils import connection_pool, queries2, get_columns_info, get_logger
from api.utils.common import make_query, update_query, get_prep_level, get_commonality_filter, commonality_query, execute_query

app_log = get_logger("hitmap")


class Hitmap():

    def __init__(self):
        '''Initializing histogram'''
        self.connection = connection_pool.connect()
        self.queries = queries2["hitmap"]
        self.dict1, self.query_data = dict(), dict()

    def prepare_query_inputs(self, input_data, inputs, values, count_condition, condition, orientation, commonality_filter):
        '''prepare query inputs'''
        data = {'mapid': tuple(values.get('mapid')), 'fieldx': inputs.get('fieldx', 1),
                'fieldy': inputs.get('fieldy', 1), 'diepitch_x': inputs.get('diepitch_x', 1),
                'diepitch_y': inputs.get('diepitch_y', 1), "xsite": f'xsite_{orientation}',
                "ysite": f'ysite_{orientation}', "condition": condition,
                "orientation": orientation, "selected_maps": tuple(inputs.get('selectedMaps', '')),
                "prep_column": inputs.get('prep_column', None),
                "count_condition": count_condition,
                "waferView": inputs.get('waferView', 'stack')
                }
        data_count = data
        data_count['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get(
            'selectedMaps') else data['mapid']
        data_count['count_condition'] = data_count['count_condition'].replace(str(data['mapid']), str(
            data['selected_maps'])) if len(data['selected_maps']) != 0 else data['count_condition']
        data_count['count_condition'] = data_count['count_condition'].replace(
            'mapid', 'defects.mapid')
        data_count['offset'] = self.queries['offset_join'].format(**{"mapid": data['mapid'], "orientation": orientation}) if inputs.get(
            'waferView', 'stack') != 'multi1' and inputs.get('waferView', 'stack') else ''
        commonality_query(input_data, commonality_filter, data_count)
        prep_data = get_prep_level(
            self.connection, data_count)
        data['xsite'] = prep_data['xsite']
        data['ysite'] = prep_data['ysite']
        if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
            data['offset_columns'] = self.queries['offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation
            })
        else:
            data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                "xsite": prep_data['xsite'],
                "ysite": prep_data['ysite'],
                "orientation": orientation
            })
        return data

    @coroutine
    def get(self, data):
        '''Returns data for hitmap .'''
        try:
            resp = {}
            commonality_filter = get_commonality_filter(data)
            orientation = data["inputs"].get(
                "orientationmarklocation", "down").lower()
            self.query_data['orientation'] = orientation
            self.query_data['condition'] = update_query(
                make_query(data, alias=""), orientation)
            self.query_data['projectid'] = data['projectid']
            self.query_data['mapid'] = data['inputs']['hitmap']['rmapid']
            self.query_data['fieldx'] = data['inputs']['hitmap'].get('fieldx', 1)
            self.query_data['fieldy'] = data['inputs']['hitmap'].get('fieldy', 1)
            self.query_data['query_offset'] = data['inputs']['hitmap'].get('offset', 0)
            self.query_data['query_limit'] = data['inputs']['hitmap'].get('limit', 100)
            search_text = data['inputs']['hitmap'].get('search_text', "")
            search_string = ""
            if search_text:
                for i in search_text:
                    if i in list(punctuation):
                        search_string += f"\\{i}"
                    else:
                        search_string += i
                search_string = f"AND (toString(rdefectid)='{search_string}' or toString(sdefectid)='{search_string}')"
            self.query_data['search_string'] = search_string
            
            smapid = data['inputs']['hitmap']['smapids']
            
            query_inputs = self.prepare_query_inputs(data, data['inputs'], data['values'], self.query_data['condition'],
                                                     self.query_data['condition'],
                                                     orientation, commonality_filter)

            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                self.query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_inputs['xsite'],
                    "ysite": query_inputs['ysite'],
                    "orientation": orientation
                })
                self.query_data['offset'] = self.queries['offset_join'].format(**{"mapid": tuple(data['values']['mapid']),
                                                                                  "orientation": orientation})
            else:
                self.query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_inputs['xsite'],
                    "ysite": query_inputs['ysite'],
                    "orientation": orientation

                })
                self.query_data['offset'] = ''

            if 'xsite' in self.query_data['condition']:
                self.query_data['condition'] = self.query_data['condition'].replace(
                    'xsite', 'xsite_offset')
                self.query_data['condition'] = self.query_data['condition'].replace(
                    'ysite', 'ysite_offset')

            query = self.queries["read"].format(**self.query_data)
            
            df = execute_query(self.connection, query, 'all', 'df')
            app_log.info(f"Hitmap Query: {query}")
            a = df[["rdefectid", "rclassname", "xsite", "ysite", "xsite_prep0", "ysite_prep0", "xsite_prep1", "ysite_prep1", "xsite_prep2", "ysite_prep2", "xrel", "yrel", "fieldrelx", "fieldrely"]].rename(
                columns={"rdefectid": "defectid", "rclassname": "classname"}).drop_duplicates().to_dict(orient='records')
            self.dict1[self.query_data['mapid']] = a
            for i in smapid:
                b = df[df['smapid'] == i]
                c = b[["sdefectid", "sclassname", "rclassname", "xsite", "ysite", "xsite_prep0", "ysite_prep0", "xsite_prep1", "ysite_prep1", "xsite_prep2",
                       "ysite_prep2", "xrel", "yrel", "fieldrelx", "fieldrely"]].rename(columns={"sdefectid": "defectid", "sclassname": "classname"}).to_dict(orient='records')
                self.dict1[i] = c

            query = self.queries["total_defect_count"].format(**self.query_data)
            app_log.info(f"Total Defect Query: {query}")
            total_defect_count = execute_query(self.connection, query, fetch='one', resptype='fetchonelist')

            resp = {
                "data": self.dict1,
                "total": total_defect_count['count'],
                "offset": self.query_data['query_offset'],
                "limit": self.query_data['query_limit']
            }
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}
        raise Return(resp)

    @coroutine
    def export(self, data):
        '''For hitmap export'''
        try:
            commonality_filter = get_commonality_filter(data)
            orientation = data["inputs"].get(
                "orientationmarklocation", "down").lower()
            self.query_data['orientation'] = orientation
            self.query_data['condition'] = update_query(
                make_query(data, alias=""), orientation)
            self.query_data['projectid'] = data['projectid']
            self.query_data['mapid'] = data['inputs']['hitmap']['rmapid']
            rmapid = data['inputs']['hitmap']['rmapid']
            smapid = data['inputs']['hitmap']['smapids']
            self.query_data['smapid'] = smapid
            self.query_data['rmapid'] = rmapid
            query_inputs = self.prepare_query_inputs(data, data['inputs'], data['values'], self.query_data['condition'],
                                                     self.query_data['condition'],
                                                     orientation, commonality_filter)

            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                self.query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_inputs['xsite'],
                    "ysite": query_inputs['ysite'],
                    "orientation": orientation
                })
                self.query_data['offset'] = self.queries['offset_join'].format(**{"mapid": tuple(data['values']['mapid']),
                                                                                  "orientation": orientation})
            else:
                self.query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_inputs['xsite'],
                    "ysite": query_inputs['ysite'],
                    "orientation": orientation

                })
                self.query_data['offset'] = ''

            if 'xsite' in self.query_data['condition']:
                self.query_data['condition'] = self.query_data['condition'].replace(
                    'xsite', 'xsite_offset')
                self.query_data['condition'] = self.query_data['condition'].replace(
                    'ysite', 'ysite_offset')
            query = self.queries["export"].format(**self.query_data)
            app_log.info(f"Hitmap Query: {query}")

            df = execute_query(self.connection, query, 'all', 'df')

            smapids = ',' .join([str(mapid) for mapid in smapid])
            map_names = execute_query(self.connection, self.queries['mapnames'].format(**{'rmapid': rmapid, 'smapids': smapids}), 'all', 'df')
            
            df = df.merge(map_names, left_on='reference_map', right_on='mapid').drop(columns=['reference_map', 'mapid']).rename({'mapname': 'reference_map'}, axis=1)
            df = df.merge(map_names, left_on='secondary_map', right_on='mapid').drop(columns=['secondary_map', 'mapid']).rename({'mapname': 'secondary_map'}, axis=1)
            df = df[['reference_map', 'secondary_map', 'reference_defectid',
                    'secondary_defectid', 'reference_classnumber','secondary_classnumber',
                    'reference_classname', 'secondary_classname']]
            filename = f"{self.query_data['projectid']}.csv"
            df.to_csv(f"export/{filename}", index=False)
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}
        return filename

    def __del__(self):
        '''on connection close'''
        self.connection.close()
