import os
import tornado
from tornado import iostream, gen
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.hitmap.hitmap_api.hitmapmodel import Hitmap
from api.utils.common import  zlib1,BaseHandler
import json
zlib_obj = zlib1()


class HitMapHandler(BaseHandler):

    @coroutine
    def post(self):
        hitmap = Hitmap()
        self.set_header("Content-Type", self.content_type)
        resp = hitmap.get(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()


class HitMapExportHandler(BaseHandler):


    async def post(self):
        hitmap = Hitmap()
        chunk_size = 1024 * 1024 * 1
        self.set_header("Content-Type", self.content_type)
        file = hitmap.export(data=json_decode(self.request.body))._result
        self.set_header('Content-Disposition', 'attachment; filename='+file)
        with open(f"export/{file}", "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                try:
                    self.write(chunk)
                    await self.flush()
                except iostream.StreamClosedError:
                    break
                finally:
                    del chunk
                    await gen.sleep(0.000000001)

        if os.path.exists(f"export/{file}"):
            os.remove(f"export/{file}")


    def options(self):
        self.set_status(204)
        self.finish()
