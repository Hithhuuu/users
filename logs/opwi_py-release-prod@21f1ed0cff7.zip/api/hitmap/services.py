import tornado
from api.hitmap.hitmap_api.hitmaphandler import HitMapHandler, HitMapExportHandler

services = {
    'hitmap': [
        tornado.web.url(r"/hitmap", HitMapHandler),
        tornado.web.url(r"/hitmap/export", HitMapExportHandler)
    ],
}