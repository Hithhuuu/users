import json
from tornado.gen import coroutine
from tornado.escape import json_decode

from api.attributechart.attributechart_api.attributechartmodel import AttributeChart
from api.utils.utils import get_logger
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()
app_log = get_logger("attributechart")

class AttributeChartHandler(BaseHandler):

    @coroutine
    def post(self):
        self.set_header("Content-Type", self.content_type)
        attributechart = AttributeChart()
        resp = attributechart.get(json_decode(self.request.body))._result
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()

class AttributeChartFilterHandler(BaseHandler):

    @coroutine
    def post(self):
        attributechart = AttributeChart()
        self.set_header("Content-Type", self.content_type)
        data = json_decode(self.request.body)
        resp=attributechart.attribute_filter(data)._result
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(resp)
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)

    def options(self):
        self.set_status(204)
        self.finish()

