import pandas as pd
import json
from tornado.gen import coroutine, Return
from tornado.escape import json_decode, json_encode
from api.utils.utils import queries2, connection_pool, columns_info, get_logger, get_columns_info
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, get_prep_level, execute_query

app_log = get_logger("attributechart")
class AttributeChart():

    def __init__(self):
        '''Initialize Project.'''
        self.connection = connection_pool.connect()
        self.queries = queries2['attributechart']
        self.query_data = dict()
        self.columns = get_columns_info()
        self.cursor = self.connection.cursor()
        self.defectlimit = 1000
        self.grid_flag = False

    @coroutine
    def get(self, data):
        '''Return data for attribute chart type one.'''
        try:
            '''Return data for attribute chart.'''
            commonality_filter = get_commonality_filter(data)
            data['filters']['multiDropdown'].remove('mapid')
            orientation = data["inputs"].get("orientationmarklocation", "down").lower()
            self.query_data['condition'] = update_query(make_query(data, alias=""), orientation)
            self.query_data['projectid'] = data['projectid']
            self.query_data['mapid_x'] = data['inputs']['attribute_chart']['mapid_x']
            self.query_data['mapid_y'] = data['inputs']['attribute_chart']['mapid_y']
            self.query_data['xinput'] = data['inputs']['attribute_chart']['xinput']
            self.query_data['waferView'] = data['inputs'].get('waferView', 'stack')
            if self.query_data['xinput'] in ['xrel', 'yrel', 'xindex', 'yindex']:
                self.query_data['xinput'] = f"{self.query_data['xinput']}_{orientation}"
            self.query_data['mapids'] = (self.query_data['mapid_x'], self.query_data['mapid_y'])
            flag_type = data['inputs']['attribute_chart']['flag_type']
            self.query_data['smapid'] = tuple(data['inputs']['selectedMaps']) \
                    if len(data['inputs'].get('selectedMaps', '')) > 0 else tuple(data['values']['mapid'])

            commonality_query(data, commonality_filter, self.query_data)

            if data['inputs'].get('waferView', 'stack') and data['inputs'].get('waferView', 'stack') != 'multi1':
                self.query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": f"xsite_{orientation}",
                    "ysite": f"ysite_{orientation}",
                    "orientation": orientation
                })
                self.query_data['offset_mapid'] = str(tuple(data['inputs']['selectedMaps'])) \
                    if len(data['inputs'].get('selectedMaps', '')) > 0 else tuple(data['values']['mapid'])
                self.query_data['offset'] = self.queries['offset_join'].format(**{"offset_mapid": self.query_data['offset_mapid'],
                                                                                  "orientation": orientation})
            else:
                self.query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": f"xsite_{orientation}",
                    "ysite": f"ysite_{orientation}",
                    "orientation": orientation
                })
                self.query_data['offset'] = ''

            if flag_type.lower() == 'scatter':
                self.query_data['input_bins'] = data['inputs']['attribute_chart']['input_bins']
                query = self.queries['read_scatter'].format(**self.query_data)
                df = execute_query(self.connection, query, 'all', 'df')

            elif flag_type.lower() == 'bin':
                self.query_data['input_bins'] = data['inputs']['attribute_chart']['input_bins']
                # self.cursor.execute(self.queries['grid_flag'].format(**self.query_data))
                app_log.info(f"Grid flag query : {self.queries['grid_flag'].format(**self.query_data)}")
                val = execute_query(self.connection, self.queries['grid_flag'].format(**self.query_data),'one')
                if len(val) != 0:
                    self.grid_flag = True
                query = self.queries['read_bin'].format(**self.query_data)
                app_log.info(f"Bin Query: {query}")
                df = execute_query(self.connection, query, 'all', 'df')

                query = self.queries['attribute_ratio'].format(**self.query_data)
                app_log.info(f"attribute ratio query : {query}")
                value = execute_query(self.connection, query, 'one')

            elif flag_type.lower() == 'type_two':
                query = self.queries['type_two'].format(**self.query_data)
                app_log.info(f"Type two query: {query}")
                df = execute_query(self.connection, query, 'all', 'df')

                if self.query_data['xinput'].lower()=='otype':
                    for key, header in self.columns["Histogram"]["Attribute header"].items():
                        df.loc[df['x_axis'] == key, 'x_axis'] = header
                        df.loc[df['y_axis'] == key, 'y_axis'] = header

            else:
                raise Exception("Incorrect flag_type")

            app_log.info(f"{flag_type} Query: {query}")

        except Exception as e:
            app_log.info(f"error: {str(e)}")
            return {"error": str(e)}

        if flag_type.lower() == 'bin':
            raise Return({'grids': self.grid_flag, 'attr_ratio': value[0], 'data': df.to_dict(orient='records')})
        else:
            raise Return(df.to_json(orient='records'))

    @coroutine
    def attribute_filter(self, data):
        '''Return data for attribute chart.'''
        try:
            commonality_filter = get_commonality_filter(data)
            conditions = make_query(data, alias='defects.')
            count_condition = conditions
            query_data = dict()
            query_data['condition'] = conditions
            inputs = data.get('inputs')
            orientation = inputs['orientationmarklocation'].lower()
            query_data['orientation'] = orientation
            query_data['xsite'] = f'xsite_{orientation}'
            query_data['ysite'] = f'ysite_{orientation}'
            query_data['fieldx'] = inputs.get('fieldx', 1)
            query_data['fieldy'] = inputs.get('fieldy', 1)
            query_data['diepitch_x'] = inputs.get('diepitch_x', 1)
            query_data['diepitch_y'] = inputs.get('diepitch_y', 1)
            query_data['selected_maps'] = tuple(inputs.get('selectedMaps', ''))
            query_data['count_condition']= update_query(count_condition, orientation)
            query_data['condition'] = update_query(conditions, orientation)
            query_data['commonality_condition'] = update_query(conditions, orientation)
            query_data['mapid'] = str(tuple(inputs['selectedMaps'])) if inputs.get('selectedMaps') else tuple(
                data['values']['mapid'])
            query_data["selectedMapId"] = data['values'].get('selectedMapId')
            query_data['count_condition'] = update_query(count_condition, orientation).replace(
                str(tuple(data['values']['mapid'])),
                str(query_data['selected_maps'])) if len(
                query_data['selected_maps']) != 0 else update_query(count_condition, orientation)

            commonality_query(data, commonality_filter,  query_data)

            if inputs.get('prep_column'):
                query_data['xsite'] = inputs.get('prep_column')[0]
                query_data['ysite'] = inputs.get('prep_column')[1]
            else:
                prep_data = get_prep_level(
                    self.connection, query_data, limit=self.defectlimit)

                query_data['xsite'] = prep_data['xsite']
                query_data['ysite'] = prep_data['ysite']

            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
                query_data['offset_columns'] = self.queries['offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset_mapid'] = str(tuple(inputs['selectedMaps'])) if len(inputs.get('selectedMaps', '')) > 0 \
                    else tuple(data['values']['mapid'])
                query_data['offset'] = self.queries['offset_join'].format(**{"offset_mapid": query_data['offset_mapid'],
                                                                             "orientation": orientation})
            else:
                query_data['offset_columns'] = self.queries['no_offset_columns'].format(**{
                    "xsite": query_data['xsite'],
                    "ysite": query_data['ysite'],
                    "orientation": orientation,
                    "fieldx": query_data['fieldx'],
                    "fieldy": query_data['fieldy'],
                    "diepitch_x": query_data['diepitch_x'],
                    "diepitch_y": query_data['diepitch_y']
                })
                query_data['offset'] = ''
            query = self.queries['attribute_filter'].format(**query_data)
            app_log.info(f'attribute chart filter {query}')
            df = execute_query(self.connection, query, 'all', 'df')

        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f'{e}')

        raise Return(df.to_json(orient='records'))

    def __del__(self):
        '''closing connection'''
        self.cursor.close()
        self.connection.close()
