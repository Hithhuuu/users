import tornado
from api.attributechart.attributechart_api.attributecharthandler import AttributeChartHandler
from api.attributechart.attributechart_api.attributecharthandler import AttributeChartFilterHandler


services = {
    'attributechart': [
        tornado.web.url(r"/attributechart", AttributeChartHandler),
        tornado.web.url(r"/attributechart/filter", AttributeChartFilterHandler)
    ],
}