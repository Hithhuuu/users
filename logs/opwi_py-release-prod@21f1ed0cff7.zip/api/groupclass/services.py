import tornado
from api.groupclass.groupclass_api.grouphandler import GroupHandler
from api.groupclass.groupclass_api.classhandler import ClassHandler

services = {
    'groupclass': [
        tornado.web.url(r"/group", GroupHandler),
        tornado.web.url(r"/class", ClassHandler),
    ],
}