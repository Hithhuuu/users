from numpy.core.numeric import True_
from api.utils.common import DeleteError, execute_query
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, get_logger, connection_pool

app_log = get_logger("group")


class Groups:
    def __init__(self):
        """Initializaing Group instance"""
        self.connection = connection_pool.connect()
        self.queries = queries2["groupclass"]

    @coroutine
    def get(self, data):
        app_log.info("START: Group fetching start")
        """ Get the groups based on the requested projectid """
        try:
            query = self.queries["group_read"].format(**data)
            app_log.info(f"GROUP GET QUERY: {query}")
           
            df = execute_query(self.connection, query, 'all', 'df')

            """ Set Default Groups """
            default_groups = ["True", "False", "Nuisance", "DOI", "Key DOI"]
            groups = df['groupname'].values.tolist()
            """ Appending default groups with project groups """
            data = list(set([i for i in (groups + default_groups)]))
        except Exception as e:
            app_log.info(f"GROUP GET Error: {str(e)}")
            return {"error": str(e)}
        raise Return({"groups": data})

    @coroutine
    def create(self, data):
        """ Create a new group for specific project """
        try:
            resp = {
                "msg": "Group created successfully"
            }
            app_log.info("START: Group create start")
            """ Checking Groups already exists on requested project """
            query = self.queries["group_read"].format(**data)
            query = f"{query} AND groupname='{data['groupname']}'"
            app_log.info(f"GROUP EXISTS QUERY: {query}")
            
            df = execute_query(self.connection, query, 'all', 'df')

            if df.shape[0] > 0:
                raise Return({"msg": "Group already exists"})
            """ Group already exists completed """

            """ Create new group for the Project """
            group_create_query = self.queries["group_create"].format(**data)
            app_log.info(f"GROUP CREATE QUERY: {group_create_query}")
            
            execute_query(self.connection, group_create_query,'')
            """ Create new group completed """
            app_log.info("END: Group create end")

            """ Fetching the updated list of groups """
            resp.update(self.get(data)._result)

        except Exception as e:
            app_log.info(f"GROUP CREATE: {str(e)}")
            return {"error": str(e)}
        raise Return(resp)

    @coroutine
    def delete(self, data):
        try:
            """ Delete Group from project """
            app_log.info("START: Group Delete start")
            query = self.queries["group_delete"].format(**data)
            app_log.info(f"DELETE GROUP QUERY: {query}")
            
            execute_query(self.connection, query,'')
            flag_count = True
            for _ in range(60):
                delete_check_query = self.queries['check_group_delete'].format(**data)
                
                val1 = execute_query(self.connection, delete_check_query,'one')
                if len(val1) == 0:
                    flag_count = False
                    break
                import time
                time.sleep(1)

            if flag_count:
                raise DeleteError("Unable to delete from opwi_default_groups")
            """ Delete Group from project completed"""
            app_log.info("END: Group Delete end")
        except Exception as e:
            return {"error": str(e)}
        raise Return({"msg": "Deleted Group successfully"})

    def __del__(self):
        """Closing the connection."""
        self.connection.close()
