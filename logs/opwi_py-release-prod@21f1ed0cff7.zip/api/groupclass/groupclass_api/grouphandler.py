import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.groupclass.groupclass_api.groupmodel import Groups
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()
from api.utils.utils import get_logger
app_log = get_logger("group")

class GroupHandler(BaseHandler):
    
    @coroutine
    def get(self):
        """ Get the Groups based on the requested project """
        group = Groups()
        self.set_header("Content-Type", self.content_type)
        """ Fetching projectid from query params """
        projectid = self.get_argument("projectid", None)
        if not projectid:
            self.finish({"error": "Project id required"})
        resp = group.get({"projectid": projectid})._result
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)

    @coroutine
    def post(self):
        """
            Create new group:
            req params: groupname & projectid
        """
        group = Groups()
        resp = group.create(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def delete(self):
        """
            Delete Group:
            req params: groupname & projectid
        """
        group = Groups()
        resp = group.delete(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def options(self):
        self.set_status(204)
        self.finish()
