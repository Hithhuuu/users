from api.utils.common import DeleteError
import pandas as pd
import time
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, get_logger, connection_pool
from api.sfilter.sfilter_api.sfiltermodel import Sfilter
from api.utils.common import execute_query

app_log = get_logger("class")


class ClassModel:
    """get class list for the project and create new class mapping with group """

    def __init__(self):
        """Initializaing Class instance"""
        self.connection = connection_pool.connect()
        self.queries = queries2["groupclass"]

    @coroutine
    def get(self, data):
        """ Get the list of classes for the requested project """
        app_log.info("START: Class get function")
        try:
            query = self.queries["class_read"].format(**data)
            app_log.info(f"CLASS GET QUERY: {query}")
            
            df = execute_query(self.connection, query, 'all', 'df')
            
            class_data = df.to_dict(orient="records")
            app_log.info("END: Class get function")
        except Exception as e:
            app_log.info(f"Error on class get function {str(e)}")
            return {"error": str(e)}
        raise Return({"class": class_data})

    @coroutine
    def put(self, request_data):
        """ Updating class with group [classmapping function] """
        try:
            app_log.info("START: Updating class with group")
            """ Get the project id from first array """
            project_id = request_data[0].get("projectid")
            """ Iterating list of class dict and map the class with group"""
            for data in request_data:
                
                query = self.queries["class_put"].format(**data)
                app_log.info(f"CLASS MAP QUERY: {query}")
                
                execute_query(self.connection, query, '')
                flag_count=True
                for _ in range(30):
                    '''checking updated or not'''
                    count_query = f"select count(1) from opwi_class_groups where projectid = {data['projectid']} and " \
                                  f"classnumber = {data['classnumber']} and groupname = '{data['groupname']}'"
                    app_log.info(f"Count Query: {count_query}")
                    count = execute_query(self.connection,count_query, 'one')
                    
                    app_log.info(f"count is {count[0]}")
                    if count[0] != 0:
                        flag_count=False
                        break
                    time.sleep(1)
                if flag_count:
                    raise DeleteError("Unable top update opwi_class_groups after multiple attempts")

            


            """ Fetching classfication data for the project with help of Sfilter() """
            sfilter = Sfilter()
            classfication_data = sfilter.get_classifications(
                projectid=project_id
            )
            far = sfilter.get_far_cnt({"projectid": data['projectid']})

            app_log.info("END: Updating class with group")
        except Exception as e:
            return {"error": str(e)}

        raise Return(
            {
                "msg": "Class successfully mapped with group",
                "classifications": classfication_data._result,
                "far": far
            }
        )

    def __del__(self):
        '''on connection close'''
        self.connection.close()

