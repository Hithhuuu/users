from api.utils.common import DeleteError
import itertools

import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool
from api.utils.utils import get_logger
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, execute_query
from api.defecttable.defecttable_api.defecttablemodel import Defecttable
import numpy as np
from datetime import datetime
from time import sleep, time

app_log = get_logger("saveasmap")


class SaveAsMap:
    def __init__(self):
        self.tables = ['opwi_defect_main', 'opwi_map_class', 'opwi_map_header', 'opwi_defect_main_saveasmap']

        self.connection = connection_pool.connect()
        self.queries = queries2['saveasmap']
        self.filename = None

    def delete_records(self, tbl, mapid):
        delete_query = self.queries['delete'].format(**{"tablename": tbl, "mapid": mapid})
        app_log.info(f"delete query for {tbl}: {delete_query}")
        record_exists = False
        for _ in range(60):
            #cursor.execute(delete_query)
            execute_query(self.connection,delete_query,'')
            count_query = self.queries['exists'].format(**{"tablename": tbl, "mapid": mapid})
            app_log.info(f"Record exists query: {count_query} ")

            #cursor.execute(count_query)
            val=execute_query(self.connection,count_query)
            #if cursor.rowcount == 0:
            if len(val) != 0:
                record_exists = True
                break
            app_log.info(f"Count query: {len(val)}")

            sleep(1)
        if record_exists:
            raise DeleteError(f"Unable to delter from {tbl}")

    def insert_map_class(self, mapid):
        try:
            # self.delete_records('opwi_map_class', mapid)
            insert_query = self.queries['insert_map_class'].format(**{"mapid": mapid})
            app_log.info(f"Insert Query for opwi_map_class: {insert_query}")
            #cursor.execute(insert_query)
            execute_query(self.connection,insert_query,'')

        except Exception as e:
            app_log.info(f"Error while insertin data into: opwi_map_class:{e.__class__.__name__} {e}")
            raise Exception(f"Insert Error in opwi_map_class {e.__class__.__name__} {e}")

    def generate_random_number(self, size, np_type):
        imin = np.iinfo(np_type).min
        imax = np.iinfo(np_type).max
        return np.random.randint(imin, imax, size=size, dtype=np_type)

    def insert_header_map(self, new_mapid, old_mapid, new_mapname, userid):
        try:
            # self.delete_records('opwi_map_header', new_mapid)
            select_mapname = self.queries['select_header_map'].format(**{"mapid": old_mapid})
            app_log.info(f"select mapname query: {select_mapname}")
            #cursor.execute(select_mapname)
            data = execute_query(self.connection,select_mapname,'all','list')
            
            map_name = data[0]['mapname'].split("|")
            del map_name[4]
            map_name.insert(4, new_mapname)
            del map_name[0]
            map_name.insert(0, userid)

            self.filename = f"{new_mapname}_{int(time())}.{data[0]['filename'].split('.')[-1]}"
            cdt = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            insert_query = self.queries['insert_map_header'].format(**{
                "new_mapid": new_mapid,
                "old_mapid": old_mapid,
                "mapname": "|".join(map_name),
                "filename": self.filename,
                "defectcnt": self.get_count(new_mapid),
                "userid": userid,
                "cdt": cdt
            })
            app_log.info(f"Insert query for opwi_map_header: {insert_query}")
            #cursor.execute(insert_query)
            execute_query(self.connection,insert_query,'')

        except Exception as e:
            app_log.info(f"Error while inserting data in opwi_map_header: {e.__class__.__name__} {e}")
            raise Exception(f"Error while inserting data in opwi_map_header: {e.__class__.__name__} {e}")

    def generate_mapid(self):
        mapid = int(datetime.now().timestamp()) + \
                self.generate_random_number(1, np.int16)[0]

        return mapid

    def prepare_search(self, defecttable, type='column'):
        '''Prepare search query for defect table'''
        if type == 'column':
            if defecttable['column_search']:
                column_search = " AND ".join(
                    [f"toString({key}) ilike '%{value}%'" for key, value in defecttable['column_search'].items()])
                return f"AND {column_search}"
            return ""

        if type == 'overall':
            from string import punctuation
            search_string = ""
            if defecttable.get('search_text'):
                for i in defecttable.get('search_text'):
                    if i in list(punctuation):
                        search_string += f"\\{i}"
                    else:
                        search_string += i
                overall_search = f" AND lower(defects.srch_id||'!'||coalesce(toString(class.classname),'')||'!'||coalesce(toString(defects.classnumber),'')||'!'||coalesce(" \
                                 f"toString(header.mapname),'')||'!'||coalesce(toString(xrel),'')||'!'||coalesce(toString(" \
                                 f"yrel),'')||'!'||coalesce(toString(xindex),'')||'!'||coalesce(toString(yindex)," \
                                 f"'')) like '%{search_string}%' "
                return overall_search
            return ""

    def insert_opwi_export_metadata(self, new_mapid, old_mapid):
        try:
            insert_query = self.queries['insert_opwi_export_metadata'].format(**{'new_mapid': new_mapid,
                                                                                 'old_mapid': old_mapid,
                                                                                 'filename': self.filename
                                                                                 })
            app_log.info(f"Insert Query Opwi_export_metadata: {insert_query}")
            
            execute_query(self.connection,insert_query,'')

        except Exception as e:
            app_log.info(f"Error while inserting data in opwi_export_metadata: {e.__class__.__name__} {e}")
            raise Exception(f"Error while inserting data in opwi_export_metadata: {e.__class__.__name__} {e}")

    def get_count(self, mapid):
        try:
            count_query = self.queries['record_count'].format(**{"mapid": mapid})
            #cursor.execute(count_query)
            data = execute_query(self.connection,count_query,'one')
            return data[0]
        except Exception as e:
            app_log.info(f"Error while getting count: {e.__class__.__name__} {e}")
            raise Exception(f"Error while getting count: {e.__class__.__name__} {e}")

    def prepare_query_inputs(self, inputs, values, condition, orientation):
        '''prepare query inputs'''

        data = {
            'mapid': tuple(values.get('mapid')),
            'mapname': values.get('mapname'),
            'fieldx': inputs.get('fieldx', 1),
            'fieldy': inputs.get('fieldy', 1),
            'diepitch_x': inputs.get('diepitch_x', 1),
            'diepitch_y': inputs.get('diepitch_y', 1),
            "xsite": f'xsite_{orientation}',
            "ysite": f'ysite_{orientation}',
            "condition": update_query(condition, orientation),
            "orientation": orientation,
            "prep_column": inputs.get('prep_column', None),
            "offset_mapid":  tuple(inputs['selectedMaps']) if len(inputs.get('selectedMaps', '')) > 0
            else tuple(values.get('mapid'))
        }

        if 'xindex' in data['condition']:
            data['condition'] = data['condition'].replace('xindex', f"xindex_{orientation}")
        if 'yindex' in data['condition']:
            data['condition'] = data['condition'].replace('yindex', f"yindex_{orientation}")

        return data

    def mapname_exists(self, mapname, cby):
        
        query = self.queries['mapname_exists'].format(**{"mapname": mapname, 'cby': cby})
        app_log.info(f"Mapname exists query: {query}")
        #cursor.execute(query)
        val=execute_query(self.connection,query)
        #if cursor.rowcount == 0:
        if len(val) != 0:
            return True
        else:
            return False

    @coroutine
    def savemap(self, data):
        try:
            inputs = data['inputs']
            filters = data['filters']
            values = data['values']
            defecttable = inputs['defecttable']
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            userid = inputs['userid']
            commonality_filter = get_commonality_filter(data)

            defect_query = ""
            '''for ctrl + click single defect selection'''
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN {tuple(values['defectid'])}"
            query_data = make_query(data, alias='defects.')

            column_search = self.prepare_search(defecttable, type='column')
            overall_search = self.prepare_search(defecttable, type='overall')

            condition = f" {query_data} {defect_query} {column_search} {overall_search}"
            query_inputs = self.prepare_query_inputs(inputs, values, condition, orientation)
            commonality_query(data, commonality_filter, query_inputs)
            new_mapid = self.generate_mapid()
            app_log.info(f"New mapid is: {new_mapid}")

            query_inputs['new_mapid'] = new_mapid
            

            if query_inputs['mapname'] is None or query_inputs['mapname'] == '':
                raise Exception("Mapname Error: Mapname cannot be blank or None")

            # check if map already exists:
            if self.mapname_exists(query_inputs['mapname'], userid):
                status = {"msg": f"Map {query_inputs['mapname']} already exists"}
                return {"msg": f"Map {query_inputs['mapname']} already exists"}

            # Delete the new maps if it exists in any table
            # self.delete_records('opwi_defect_main_saveasmap', new_mapid)

            # insert into temp defect_main table:
            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi':
                insert_temp_query = self.queries['insert_main_offset'].format(**query_inputs)
            else:
                insert_temp_query = self.queries['insert_main'].format(**query_inputs)
            app_log.info(f'insert temp query: {insert_temp_query}')
            #cursor.execute(insert_temp_query)
            execute_query(self.connection,insert_temp_query,'')

            # get the count from temp table:
            defectcnt = self.get_count(new_mapid)

            if defectcnt == 0:
                raise Exception(f"No records present for the given maps")

            # insert into map class:
            self.insert_map_class(new_mapid)
            # insert into opwi_map_header
            self.insert_header_map(new_mapid, query_inputs['mapid'][0], query_inputs['mapname'],
                                   userid)
            self.insert_opwi_export_metadata(new_mapid, query_inputs['mapid'][0])

            # insert into defect main table
            # self.delete_records('opwi_defect_main', new_mapid, cursor)
            insert_defect_main = self.queries['insert_defect_main'].format(**{"mapid": new_mapid})
            app_log.info(f"insert query for opwi_defect_main: {insert_defect_main}")
            #cursor.execute(insert_defect_main)
            execute_query(self.connection,insert_defect_main,'')

            status = {
                "msg": "Map Saved Successfully",
                "mapid": str(new_mapid)
            }

        except Exception as e:
            app_log.exception(e)
            app_log.info(f"Error while saving the map: {e.__class__.__name__} {e}")
            status = {"msg": f"Error while saving the map: {e.__class__.__name__} {e}"}

        finally:
            raise Return(status)

    def __del__(self):
        """Closing the connection."""
        self.connection.close()

