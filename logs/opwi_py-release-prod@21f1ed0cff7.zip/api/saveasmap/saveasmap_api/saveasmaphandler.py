import tornado,json
from tornado.gen import coroutine
from tornado.escape import json_decode

from api.saveasmap.saveasmap_api.saveasmapmodel import  SaveAsMap
from api.utils.common import  zlib1,BaseHandler
zlib_obj = zlib1()

class SaveAsMapHandler(BaseHandler):

  
    @coroutine
    def put(self):
        '''Updates the commonality data'''
        savemapas = SaveAsMap()
        resp = savemapas.savemap(json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
        self.set_header("Content-Length", compressed_content_length)
        self.write(content)
        #self.write(resp)

    def options(self):
        self.set_status(204)
        self.finish()
