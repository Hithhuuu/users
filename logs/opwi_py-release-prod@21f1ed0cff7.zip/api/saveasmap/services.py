import tornado
from api.saveasmap.saveasmap_api.saveasmaphandler import SaveAsMapHandler



services = {
    'saveasmap': [
        tornado.web.url(r"/saveasmap", SaveAsMapHandler)
    ]
}
