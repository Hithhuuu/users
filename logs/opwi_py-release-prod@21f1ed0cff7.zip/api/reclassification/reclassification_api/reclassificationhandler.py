import json
import re
import tornado
from tornado.gen import coroutine
from tornado.escape import json_decode
from api.reclassification.reclassification_api.reclassificationmodel import Reclassification
from api.sfilter.sfilter_api.saveclasscolour import Classcolor
from api.utils.common import  zlib1,BaseHandler
from api.utils.utils import get_logger
zlib_obj = zlib1()
app_log = get_logger("reclassification")

class ReclassificationHandler(BaseHandler):


    @coroutine
    def post(self):
        """returns distinct values for classnumber, classname"""
        reclassification = Reclassification()
        resp = reclassification.get(data=json_decode(self.request.body))._result
        self.set_header("Content-Type", self.content_type)
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        #self.write(resp)

    @coroutine
    def put(self):
        """Return wafer map data for sites and dies"""
        reclassification = Reclassification()
        data = json_decode(self.request.body)
        self.set_header("Content-Type", self.content_type)
        resp=reclassification.update(data)._result
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        
    def options(self):
        self.set_status(204)
        self.finish()

class NewClassHandler(BaseHandler):


    @coroutine
    def put(self):
        """Add new class to opwi_map_class table"""
        reclassification = Reclassification()
        data = json_decode(self.request.body)
        self.set_header("Content-Type", self.content_type)
        resp=reclassification.add_new_class(data)._result
        self.set_header("Content-Encoding", 'gzip')
        try:
            content, compressed_content_length = zlib_obj.zipit(resp)
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)
        except Exception as e:
            app_log.info(e)
            content, compressed_content_length = zlib_obj.zipit(json.dumps(resp))
            self.set_header("Content-Length", compressed_content_length)
            self.write(content)

    def options(self):
        self.set_status(204)
        self.finish()
