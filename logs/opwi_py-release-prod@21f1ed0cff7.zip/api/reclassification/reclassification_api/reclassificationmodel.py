from api.utils.common import DeleteError
import pandas as pd
from tornado.gen import coroutine, Return
from api.utils.utils import queries2, connection_pool
from api.utils.utils import get_logger, getdbconnection
from api.utils.common import make_query, update_query, get_commonality_filter, commonality_query, execute_query
from api.defecttable.defecttable_api.defecttablemodel import Defecttable
from time import sleep
from api.sfilter.sfilter_api.sfiltermodel import Sfilter

app_log = get_logger("reclassification")


class Reclassification:
    def __init__(self):
        """Initialize Reclassification"""
        self.connection = connection_pool.connect()
        self.queries = queries2['reclassification']
        self.dbconn = getdbconnection()

    @coroutine
    def get(self, data):
        """Returns the unique values of classname and classnumber"""
        try:
            query_to_execute = self.queries['reclassification']['read'].format(**{"mapid": tuple(data['mapid'])})
            app_log.info(f"Read map class query: {query_to_execute}")
            df = execute_query(self.connection, query_to_execute, 'all', 'df')
            resp = df.to_json(orient='records')
        except Exception as e:
            app_log.exception(f"Error on class get function {str(e)}")
            return {"error": str(e)}
        raise Return(resp)

    def prepare_query_inputs(self, inputs, values, count_condition, condition, orientation, defect_class):
        '''prepare query inputs'''
        data = {
            'mapid': tuple(values.get('mapid')),
            'fieldx': inputs.get('fieldx', 1),
            'fieldy': inputs.get('fieldy', 1),
            'diepitch_x': inputs.get('diepitch_x', 1),
            'diepitch_y': inputs.get('diepitch_y', 1),
            "xsite": f'xsite_{orientation}',
            "ysite": f'ysite_{orientation}',
            "condition": update_query(condition, orientation),
            "orientation": orientation,
            "prep_column": inputs.get('prep_column', None),
            "count_condition": update_query(count_condition, orientation),
        }
        return data

    def update_all(self, data):
        """Executes the steps for updating all the defects present in defecttable UI
           accepts the payload as data
        """
        try:
            defect_class = Defecttable()
            commonality_filter = get_commonality_filter(data)
            inputs = data['inputs']
            filters = data['filters']
            values = data['values']
            defect_query = ""
            orientation = inputs.get('orientationmarklocation', 'down').lower()
            defecttable = inputs['defecttable']
            status= dict()
            status['msg'] = ''
            '''for ctrl + click single defect selection'''
            if 'defectid' in filters['multiDropdown']:
                filters['multiDropdown'].remove('defectid')
                filters['multiDropdown'].remove('mapid')
                defect_query = f" AND concat(toString(defects.mapid), toString(defects.defectid)) IN " \
                               f"{tuple(values['defectid'])}"
            query_data = make_query(data, alias='defects.')

            '''prepare search query'''
            column_search = defect_class.prepare_search(defecttable, type='column')
            overall_search = defect_class.prepare_search(defecttable, type='overall')

            count_condition = f"{query_data}{defect_query}"
            condition = f"{count_condition}{column_search}{overall_search}"

            query_inputs = self.prepare_query_inputs(inputs, values, count_condition, condition, orientation,
                                                     defect_class)
            query_inputs['condition'] = f"{query_inputs['condition']}"
            commonality_query(data, commonality_filter, query_inputs)
            if inputs.get('waferView', 'stack') and inputs.get('waferView', 'stack') != 'multi1':
                query_inputs['offset'] = self.queries['reclassification']['offset_join'].format(**{"mapid": tuple(data['values']['mapid']),
                                                                             "orientation": orientation})
                query_inputs['offset_columns'] = self.queries['reclassification']['offset_columns'].format(
                    **{
                        "xsite": query_inputs['xsite'],
                        "ysite": query_inputs['ysite'],
                        "orientation": orientation,
                        "fieldx": query_inputs['fieldx'],
                        "fieldy": query_inputs['fieldy'],
                        "diepitch_x": query_inputs['diepitch_x'],
                        "diepitch_y": query_inputs['diepitch_y']
                    }
                )
            else:
                query_inputs['offset'] = ''
                query_inputs['offset_columns'] = self.queries['reclassification']['no_offset_columns'].format(
                    **{
                        "xsite": query_inputs['xsite'],
                        "ysite": query_inputs['ysite'],
                        "orientation": orientation,
                        "fieldx": query_inputs['fieldx'],
                        "fieldy": query_inputs['fieldy'],
                        "diepitch_x": query_inputs['diepitch_x'],
                        "diepitch_y": query_inputs['diepitch_y']
                    }
                )
            query_inputs['classnumber'] = data['inputs']['classnumber']
            query_inputs['select_query'] = self.queries['reclassification']['insert_all'].format(**query_inputs)
            query_to_execute = self.queries['reclassification']['insert_class'].format(**query_inputs)
            app_log.info(f" Defect Query: {query_to_execute}")

            execute_query(self.connection,query_to_execute,'')
            

            app_log.info(f" Class exists query: {self.queries['reclassification']['exists'].format(**query_inputs)}")
           
            val=execute_query(self.connection,self.queries['reclassification']['exists'].format(**query_inputs))

            app_log.info("reclassification opwi_defect_main end")
            mapid_from_tbl = [i[0] for i in val]
            

            query_data = dict()
            query_data['classname'] = data['inputs']['classname']
            query_data['classnumber'] = query_inputs['classnumber']
            query_data['projectid'] = data['projectid']
            for mapid in query_inputs['mapid']:
                if int(mapid) not in mapid_from_tbl:
                    app_log.info(f"reclassification: Mapid {mapid} not present in OPWI_MAP_CLASS")
                    app_log.info("reclassification: create object in opwi_map_class started")
                    query_data['mapid'] = mapid
                    
                    insert_query = self.queries['reclassification']['create'].format(
                        **query_data)
                    app_log.info(f"Insert Query {insert_query}")
                    verify = self.queries['reclassification']['verify_class'].format(**query_data)
                    if self.validation(insert_query, verify):
                        raise DeleteError(f"Error while executing the {insert_query}")
                else:
                    app_log.info(f"reclassification: Mapid {mapid} present in OPWI_MAP_CLASS")
            ''' Set classnumber and projectid with empty group for classfication '''

            grp_count_query = self.queries['reclassification']['group_count'].format(**query_data)
            app_log.info(f"Group count Query: {grp_count_query}")
            
            count_data=execute_query(self.connection,grp_count_query,'one')
            self.connection.commit()
            if count_data[0] == 0:
                insert_query = self.queries['reclassification']['insert_group'].format(**query_data)
                
                if self.validation(insert_query, grp_count_query):
                    raise DeleteError("Unable to update the data in opwi_group table")
                app_log.info("reclassification: end classnumber with group and projectid")
                self.connection.commit()
            return {'msg': 'classnumber updated'}
            
            '''
            defectids_list = [{'mapid':i[0], 'defectids': i[1]} for i in cursor.fetchall()]
            for i in defectids_list:
                mapid = tuple([i['mapid']])
                defectids = i['defectids']

                if len(defectids) >= 30000:
                    import numpy as np
                    arr = np.array_split(np.array(defectids), len(defectids) / 30000)
                    for a in arr:
                        update_data = {'classname': data['inputs']['classname'],
                                       'classnumber': data['inputs']['classnumber'],
                                       'projectid': data['projectid'], 'mapid': mapid,
                                       'defectid': tuple(a)}
                        status = self.execute_update(update_data)
                        if status['msg'] == 'Failed':
                            return status
                else:
                    update_data = {'classname': data['inputs']['classname'], 'classnumber': data['inputs']['classnumber'],
                                   'projectid': data['projectid'], 'mapid': mapid,
                                   'defectid': tuple(defectids)}
                    app_log.info(f"-----{update_data}----------")
                    status = self.execute_update(update_data)
                    if status['msg'] == 'Failed':
                        return status

            return status
            '''
        except Exception as e:
            import traceback
            app_log.info(traceback.format_exc())
            app_log.error(f"Error: {e}")
            return {"error": str(e)}

    def execute_update(self, query_data):
        """executes the query for reclassification accepts query data as parameter"""
        try:
            app_log.info("reclassification started: Update classnumber in opwi_defect_main")
            map_defect= dict()
            for rec in query_data['defects']:
                if rec['mapid'] in map_defect.keys():
                    map_defect[rec['mapid']].append(rec['defectid'])
                else:
                    map_defect[rec['mapid']] = [rec['defectid']]

            condition_query = " or ".join([f"(mapid = {mapid} and defectid in {tuple(defectid)})" for mapid, defectid in map_defect.items()])
            query_data['condition_query'] = condition_query
            query_data['select_query'] = self.queries['reclassification']['insert_selected'].format(**{'condition_query':condition_query})
            
            query = self.queries['reclassification']['insert_class'].format(**query_data)
            app_log.info(f"Opwi_defect_main update query {query}")
            verify = self.queries['reclassification']['verfiy_main'].format(**query_data)
            
            execute_query(self.connection,query,'')
            query_data['mapid'] = tuple(map_defect.keys())
            app_log.info(f" Class exists query: {self.queries['reclassification']['exists'].format(**query_data)}")
            exists_val = execute_query(self.connection,self.queries['reclassification']['exists'].format(**query_data),'all','list')

            app_log.info(f"reclassification opwi_defect_main end{exists_val}")

            mapid_from_tbl = [i.get('mapid') for i in exists_val]

            for mapid in map_defect.keys():
                if int(mapid) not in mapid_from_tbl:
                    app_log.info(f"reclassification: Mapid {mapid} not present in OPWI_MAP_CLASS")
                    app_log.info("reclassification: create object in opwi_map_class started")
                    query_data['mapid'] = mapid
                    insert_query = self.queries['reclassification']['create'].format(
                        **query_data)
                    app_log.info(f"Insert Query {insert_query}")
                    verify = self.queries['reclassification']['verify_class'].format(**query_data)
                    if self.validation(insert_query, verify):
                        raise DeleteError(f"Error while executing the {insert_query}")
                else:
                    app_log.info(f"reclassification: Mapid {mapid} present in OPWI_MAP_CLASS")
            ''' Set classnumber and projectid with empty group for classfication '''
            grp_count_query = self.queries['reclassification']['group_count'].format(**query_data)
            app_log.info(f"Group count Query: {grp_count_query}")
           
            count_data=execute_query(self.connection,grp_count_query,'one')
            self.connection.commit()
            if count_data[0] == 0:
                insert_query = self.queries['reclassification']['insert_group'].format(**query_data)
                
                if self.validation(insert_query, grp_count_query):
                    raise DeleteError("Unable to update the data in opwi_group table")
                app_log.info("reclassification: end classnumber with group and projectid")

            
            return {'msg': 'classnumber updated'}
        except Exception as e:
            import traceback
            app_log.error(traceback.format_exc())
            app_log.info(f"Error while executing reclassification: {e}")
            return {'msg': 'Failed'}

    def validation(self, trns_query, verfication_query):
        flag = True
        #cursor.execute(trns_query)
        execute_query(self.connection,trns_query)
        #while flag:
        for _ in range(30):
            # verfiy whether update happened:
            app_log.info(f"verification query: {verfication_query}")
            #cursor.execute(verfication_query)
            val=execute_query(self.connection,verfication_query)
            #if cursor.rowcount > 0:
            if len(val) != 0:
                app_log.info(f"Record count: {len(val)}")
                flag = False
                break
            else:
                app_log.info(f"Record count: {len(val)}")
                sleep(1)
        return flag

    @coroutine
    def update(self, data):
        sfilter = Sfilter()
        if len(data['inputs'].get('defects')) == 0:
            msg = self.update_all(data)
            far = sfilter.get_far_cnt({"projectid": data['projectid']})
            msg['far'] = far
            raise Return(msg)

        query_data = {'classname': data['inputs']['classname'],
                      'classnumber': data['inputs']['classnumber'],
                      'defects': data['inputs']['defects'],
                      'projectid': data['projectid']
                      }
        """updates the classnumber in owpi_defect_main based on defectid and mapid"""
        app_log.info("reclassification processing started")
        query_data['mapid'] = tuple([i['mapid'] for i in query_data['defects']])
        query_data['defectid'] = tuple([i['defectid'] for i in query_data['defects']])
        app_log.info(f"process reclassification with data: {query_data}")
        msg = self.execute_update(query_data)
        
        far = sfilter.get_far_cnt({"projectid": data['projectid']})
        msg['far'] = far
        raise Return(msg)


    @coroutine
    def add_new_class(self, data):
        """Adds a new class to all the maps in the project"""
        try:
            query = """SELECT
                COUNT(1) AS count
            FROM
                opwi_map_class FINAL
            WHERE
                classnumber = {classnumber}
                AND mapid IN {mapid}"""

            query_to_execute = query.format(**{"classnumber": data.get('classnumber'), "mapid": tuple(data['mapid'])})
            app_log.info(f"class count query: {query_to_execute}")
            class_count = execute_query(self.connection, query_to_execute, 'all', 'df')
            if class_count['count'][0] == 0:
                app_log.info('Insert into opwi_map_class table')
                data_to_insert = [
                    {
                        'classnumber': data.get('classnumber'),
                        'classname': data.get('classname'),
                        'mapid': mapid,
                        'rfg': 1
                    } for mapid in data.get('mapid', [])
                ]

                df = pd.DataFrame(data_to_insert).append({}, ignore_index=True)
                df.to_sql('opwi_map_class', self.dbconn, if_exists='append', index=False)
                app_log.info('Inserted into opwi_map_class table')
                resp = self.get(data)._result
            else:
                resp = {"msg": "Error: Classnumber already exists"}
        except Exception as e:
            app_log.exception(f"Error failed to add class {str(e)}")
            resp = {"msg": "Error: Failed to add class"}
        raise Return(resp)


    def __del__(self):
        """Closing the connection"""
        self.connection.close()

