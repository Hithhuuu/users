import shutil
import argparse
from datetime import datetime

parser = argparse.ArgumentParser()
parser.add_argument('--src')
parser.add_argument('--to')
parser.add_argument('--copies')
parser.add_argument('--prefix')


# python .\watchdog_process\test_copy.py --src=/Application/local/motor/data/wizer/T99010/src_files/1.001 --to=/Application/local/motor/data/wizer/T99010/lz/today/reports --copies=10 --prefix=test

args = parser.parse_args()

original = f'{args.src}'
target = f'{args.to}'
prefix = f'{args.prefix}'
n = int(args.copies)
date_str = datetime.now().strftime('%Y_%m_%d')

for i in range(1, n+1):
    filename = original.split('/', -1)[-1]
    path = f'{target}/{prefix}_{date_str}_{i}_{filename}'
    print(path)
    shutil.copyfile(original, path)
