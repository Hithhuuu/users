import os
import sys
import time
import time
import pandas as pd
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(path)

from api.utils.common import execute_query
from api.utils.utils import connection_pool, get_logger, get_env_config, queries, getdbconnection
from api.upload.upload_api.upload_fun import get_upload_handler_data

app_log = get_logger("process_execution")
env_config = get_env_config()
opwi_table_name = "opwi_job_log"
upload_url = env_config["urls"]["upload_url"]
connection = connection_pool.connect()
engine = getdbconnection()


def check_update_status(filename):
    '''Check file update status.'''
    query = f"select copied_flag from {opwi_table_name} final where file_name = '{filename}' and job_status = 'created'"
    value = execute_query(connection, query, 'one')[0]

    if value == 1:
        return True
    return False


def upload_handler(files):
    '''Upload files to db'''
    for index, file in files.iterrows():
        try:
            filename = file['file_name']
            # TODO: move update outside loop
            # insert_flag_query = f"""insert into {opwi_table_name} select id, tool_name, file_name, job_start_time,
            #     'queued' as job_status, copy_start_time, copy_end_time, copy_duration, no_of_copy_retries, copied_flag, err_message,
            #     process_start_time, process_end_time, process_duration, file_path, arch_path, imported_on, unique_header_id,
            #     re_try from {opwi_table_name} final where file_name = '{filename}'"""
            # app_log.info(
            #     f"upload handler: insert_flag_query : {insert_flag_query}")
            # execute_query(connection, insert_flag_query, '')

            app_log.debug(
                f'*******arch_path is {file.get("arch_path")}********')

            timestamp = str(time.time()).split('.')[0]
            filepath = file['arch_path']
            filename_split, ext = os.path.splitext(filename)
            file_size = os.stat(filepath).st_size
            file_type = "csv" if ext == ".csv" else "klarf"
            app_log.info("Sending request to upload handler")

            payload = {
                "username": "pvadmin",
                "filesize": file_size,
                "timestamp": timestamp,
                "filename": f"{filename_split}_{timestamp}{ext}",
                "file_type": file_type,
                "file_path": filepath
            }

            app_log.info(
                f'upload_handler: data_payload for get_upload_handler_data, {payload}')

            # celery call
            resp = get_upload_handler_data(payload)

            app_log.info(f"Response status code for Pvadmin: {resp}")

            if (file_type == 'csv') and (resp.get("error") == "Klarf file is missing"):
                '''To check if KLARF exist'''
                if (file['re_try'] < 5):
                    app_log.info(resp.get("error"))
                    retry_increment_query = f"""insert into {opwi_table_name} select id, tool_name, file_name, job_start_time, 'failure' as job_status,
                        copy_start_time, copy_end_time, copy_duration, no_of_copy_retries, 0 as copied_flag, err_message,
                        process_start_time,process_end_time,process_duration,file_path,arch_path,imported_on,unique_header_id, {file.re_try + 1} as
                        re_try from {opwi_table_name} final where file_name = '{file.file_name}'"""
                    app_log.info(f'retry_increment_query: {retry_increment_query}')
                    execute_query(connection, retry_increment_query, '')
                else:
                    retry_increment_query = f"""insert into {opwi_table_name} select id, tool_name, file_name, job_start_time, 'failure' as job_status,
                        copy_start_time, copy_end_time, copy_duration, no_of_copy_retries, 1 as copied_flag, 'kalrf file is missing' as err_message, process_start_time,
                        process_end_time,process_duration,file_path,arch_path,imported_on,unique_header_id,
                        {file.re_try + 1} as re_try from {opwi_table_name} final where file_name = '{file.file_name}'"""
                    execute_query(connection, retry_increment_query, '')
                    app_log.info(f'retry_increment_query: {retry_increment_query}')
                    raise Exception('Klarf is missing')

            if "error" in resp:
                app_log.error('Response code from upload is not 200. ERROR!!!')
                if hasattr('content', resp):
                    app_log.info(f"complete response: {resp.content}")

            if "count" in resp:
                app_log.info(
                    f"queued and picked staus files are more than 10: {resp.get('count')}")

            if resp.get('status') == 'The file already exists':
                app_log.info(
                    f'Upload status is file already exists, overwriting file {filename}')
                payload.update({'overwrite': 'yes'})
                resp = get_upload_handler_data(payload)
                if "count" in resp:
                    app_log.info(
                        f"queued and picked staus files are more than 10: {resp.get('count')}")
                app_log.info(f"Response status for overwriting file {resp}")

        except Exception as e:
            app_log.error(f'Error while uploading file {e}')


def opwi_process_execution():
    """
    1. Fetched the data job which having status as 'created' from {opwi_table_name}
    2. Upload the file to the /upload url
    3. Updated the status of the file
    3. Archive the file to the desired location
    """
    create_query = f"select * from {opwi_table_name} final where job_status = 'created' and copied_flag = 1 order by splitByChar('.', file_name)[2] limit 20"
    app_log.info(f"fetch job log of created status : {create_query}")

    created_files = execute_query(connection_pool.connect(), create_query, 'all', 'df')

    app_log.info(f"Files with created status : {created_files.shape[0]}")

    """ Checking failed jobs """
    retrive_failure_obj_query = f"select * from {opwi_table_name} final where job_status = 'failure' and re_try <= 5 and file_path not like '%upload%' order by splitByChar('.', file_name)[2] limit 5"
    app_log.info(f"Query for failure records: {retrive_failure_obj_query}")
    failure_records = execute_query(connection_pool.connect(), retrive_failure_obj_query, 'all', 'df')
    failure_records_dict = failure_records.to_dict(orient="records")

    read_picked_query = f"SELECT * FROM {opwi_table_name} FINAL WHERE ((now() - process_start_time) > 3600) AND (job_status = 'picked') ORDER BY splitByChar('.', file_name)[2]"
    app_log.info(
        f"Query for picked records which are stuck from 1hr: {read_picked_query}")
    picked_records = execute_query(
        connection_pool.connect(), read_picked_query, 'all', 'df')
    picked_records_dict = picked_records.to_dict(orient="records")
    picked_failure_records = picked_records_dict + failure_records_dict

    app_log.info(
        f"********picked and failure records****{picked_failure_records}")

    if len(picked_failure_records) > 0:
        for f in picked_failure_records:
            time.sleep(1)
            connection = connection_pool.connect()
            update_failure_query = f"insert into {opwi_table_name} select id,tool_name,file_name,job_start_time,job_status,copy_start_time,copy_end_time,\
                copy_duration,{f.get('re_try',0)+1} as re_try,copied_flag,err_message,process_start_time,process_end_time,process_duration,file_path,arch_path,\
                imported_on,unique_header_id, re_try from {opwi_table_name} final where file_name = '{f['file_name']}'"
            app_log.info(
                f"Update failure status Query: {update_failure_query}")
            execute_query(connection, update_failure_query, '')

    con = getdbconnection()
    if not created_files.empty:
        try:
            created_files['job_status'] = 'queued'
            created_files['job_start_time'] = created_files['job_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files['copy_start_time'] = created_files['copy_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files['copy_end_time'] = created_files['copy_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files['process_start_time'] = created_files['process_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files['process_end_time'] = created_files['process_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files['imported_on'] = created_files['imported_on'].dt.strftime('%Y-%m-%d %H:%M:%S')
            created_files = created_files.append(pd.Series(), ignore_index=True)
            created_files.to_sql(f'{opwi_table_name}', con, if_exists='append', index=False)
            app_log.info(f"upload handler fun is called.")
            upload_handler(created_files)
        except Exception as e:
            app_log.exception(e)

    if not failure_records.empty:
        try:
            failure_records['job_status'] = 'queued'
            failure_records['job_start_time'] = failure_records['job_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records['copy_start_time'] = failure_records['copy_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records['copy_end_time'] = failure_records['copy_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records['process_start_time'] = failure_records['process_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records['process_end_time'] = failure_records['process_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records['imported_on'] = failure_records['imported_on'].dt.strftime('%Y-%m-%d %H:%M:%S')
            failure_records = failure_records.append(pd.Series(), ignore_index=True)
            failure_records.to_sql(f'{opwi_table_name}', con, if_exists='append', index=False)
            app_log.info(f"upload handler fun is called for failure records.")
            upload_handler(failure_records)
        except Exception as e:
            app_log.exception(e)

    if picked_records.shape[0] > 0:
        try:
            picked_records['job_status'] = 'queued'
            picked_records['job_start_time'] = picked_records['job_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records['copy_start_time'] = picked_records['copy_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records['copy_end_time'] = picked_records['copy_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records['process_start_time'] = picked_records['process_start_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records['process_end_time'] = picked_records['process_end_time'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records['imported_on'] = picked_records['imported_on'].dt.strftime('%Y-%m-%d %H:%M:%S')
            picked_records = picked_records.append(pd.Series(), ignore_index=True)
            picked_records.to_sql(f'{opwi_table_name}', con, if_exists='append', index=False)
            app_log.info(f"upload handler fun is called for picked records.")
            upload_handler(picked_records)
        except Exception as e:
            app_log.exception(e)

if __name__ == '__main__':
    import inspect
    app_log.info(f"common.py path: {inspect.getfile(execute_query)}")
    sys.exit(opwi_process_execution())

