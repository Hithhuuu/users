import os
import sys
import time
from sqlalchemy import engine
import pandas as pd
from glob import glob
from datetime import datetime

path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(path)

from api.utils.utils import getdbconnection, get_logger, get_env_config, connection_pool, queries
from api.utils.common import execute_query

config = get_env_config()
tools = config["tools"]
watch_path = config["watchdog_pick_location"]["src"]
app_log = get_logger('watchdog_cron')
opwi_table_name = "opwi_job_log"
engine = getdbconnection()


def remove_existing_files(df):
    '''check and remove existing entries'''

    filenames = tuple(df['file_name'].to_list())
    files_query = f"select file_name from {opwi_table_name} final where file_name in {filenames} and job_status in ('created', 'picked') and arch_path is not Null"
    app_log.info(f"******remove_existing_files query*********{files_query}")
    files = execute_query(connection_pool.connect(), files_query, 'all', 'df')

    app_log.info(f"******remove_existing_files*********{files}")

    files.replace({r'\x00': ''}, regex=True, inplace=True)
    if not files.empty:
        app_log.info(f"******file shape condition*********{df['file_name']}")
        mount_files = set(df.file_name)
        entries = set(files.file_name)
        files = mount_files - entries
        df = df[df['file_name'].isin(files)]
    return df


def insert_job_log(df):
    '''Insert into job log table.'''
    with engine.connect() as connection:
        df = df.append(pd.Series(dtype=object), ignore_index=True)
        df.to_sql(f'{opwi_table_name}', connection,
                  if_exists='append', index=False)
        return df


def filewatcher():
    '''Watch for new file entries.
    1. Get all files list at location
    2. prepare the data for insertion
    '''
    app_log.info('File watcher STARTED')
    files = 0
    for tool_name in tools:
        app_log.info(f'*******{tool_name}')
        app_log.info(watch_path + '/'+tool_name+'/lz/today/reports/*.001')

        klarf_files = glob(watch_path + '/'+tool_name+'/lz/today/reports/*.001',
                           recursive=True)
        csv_files = glob(watch_path + '/'+tool_name+'/lz/today/reports/*.csv',
                         recursive=True)
        app_log.info(f'number of klarf file : {len(klarf_files)}')
        app_log.info(f'number of csv file : {len(csv_files)}')
        if files:
            files = klarf_files + csv_files + files
        else:
            files = klarf_files + csv_files

    app_log.info(f'*****************{files}')
    date_format = '%Y-%m-%d %H:%M-%S'
    df = pd.DataFrame()
    df['file_path'] = files

    if df.empty:
        sys.exit()

    df['file_name'] = df['file_path'].str.rsplit('/', -1).str[-1]
    df['tool_name'] = df['file_path'].apply(lambda x: x.split('/')[-5])
    df['id'] = 0
    df['job_status'] = 'created'
    df['job_start_time'] = datetime.now().strftime(date_format)
    df['process_start_time'] = datetime.now().strftime(date_format)
    df['process_end_time'] = datetime.now().strftime(date_format)
    df['process_duration'] = 0
    df['copy_start_time'] = 0
    df['copy_end_time'] = 0
    df['copy_duration'] = 0
    df['no_of_copy_retries'] = 0
    df['copied_flag'] = 0
    df['err_message'] = 'None'
    df['arch_path'] = pd.NA
    df['imported_on'] = datetime.now().strftime(date_format)
    df['unique_header_id'] = 'None'
    df['re_try'] = 0

    app_log.info(f'total files in location {df.shape[0]}')

    '''check if entry already exists in db'''
    df = remove_existing_files(df)
    app_log.info(f'new entries : {df.shape[0]}')

    '''Insert into job log table.'''
    if not df.empty:
        app_log.info(f'started creating new entries')
        insert_job_log(df)
    app_log.info(f'ended creating new entries')
    return df.shape[0]


def archive_file():
    try:
        app_log.info(f"archive_file - started archiving process")

        '''Archiving the records.'''
        connection = connection_pool.connect()
        job_to_archive_query = f"""select file_name, tool_name, file_path, no_of_copy_retries,job_start_time,
            process_start_time, process_end_time, arch_path from {opwi_table_name} final
            where job_status in ('created') and file_path not like '%upload%' and arch_path is Null
            order by job_start_time desc limit 50"""

        app_log.info(
            f"archive_file - get job to archive query: {job_to_archive_query}")

        data_output = execute_query(
            connection, job_to_archive_query, 'all', 'list')

        archive_handler(data_output)
    except Exception as e:
        app_log.error(f'Error while archiving the file {e}')


def get_resulttimestamp(filename, job_start_time):
    app_log.info(f'-------------{filename}------------------')
    try:

        with open(filename, 'r') as handle:
            lines = list(map(str.strip, handle.readlines()))

        date_folder = datetime.now()
        date_formated = datetime.strptime(job_start_time, "%Y-%m-%d %H:%M:%S")
        dated_folder = datetime.strftime(date_formated, "%d%b%Y")
        date_name = dated_folder

        for line in lines:
            str_line = str(line).strip().upper()
            try:
                if isinstance(date_name, str):
                    if 'RESULTTIMESTAMP' in str_line:
                        app_log.info(f'***********{str_line}')

                        if "1.8" in lines[0]:
                            app_log.info(f'File version is : 1.8')
                            date_folder = str_line.split(" ")[1].replace(
                                "\"", "").replace("\'", "")

                            date_folder = datetime.datetime.strptime(
                                date_folder, "%m-%d-%Y")
                            return date_folder
                        else:
                            app_log.info(f'File version is : {lines[0]}')
                            date_folder = str_line.split(" ")[1].replace(
                                "\"", "").replace("\'", "")
                            date_folder = datetime.strptime(
                                date_folder, "%m-%d-%y")
                            dated_folder = datetime.strftime(
                                date_folder, "%d%b%Y")
                            return dated_folder
                else:
                    date_folder = date_name

            except Exception as e:
                return dated_folder
        return dated_folder

    except Exception as e:
        app_log.warning(f'Unable to determine file type: {repr(e)}')
        raise RuntimeError('Unable to determine file type.')


def archive_folder_creation_unix(tool_name, job_start_time):
    """
    This function will create Archive folder if not exists
    and return the complete path
    """
    app_log.info(f"archive_folder_creation_unix: process start")
    base_path = config['watchdog_pick_location']['src']
    forward_path = os.path.join(tool_name, job_start_time, 'reports')
    complete_report_path = os.path.join(base_path, forward_path)
    try:
        if os.path.exists(complete_report_path):
            app_log.info('Reports Path already exists in the archive location : {0}'.format(
                complete_report_path))
            return complete_report_path
        else:
            os.makedirs(complete_report_path, mode=0o777)
        return complete_report_path
    except Exception as e:
        app_log.exception(
            "Command to create the archive folder Failed : {0}".format(repr(e)))


def update_archive_status(archived_data):
    """
    This function will update the status of archived file
    """
    update_archive_status_query = queries['upload']['update_status_archived'].format(
        **archived_data)
    app_log.info("Updating status of archived file")
    app_log.info(
        f"Query for updating Archived File Status: {update_archive_status_query}")
    try:
        connection = connection_pool.connect()
        execute_query(connection, update_archive_status_query)
        app_log.info(
            f"Update the status for the file {archived_data['file_name']} with data {archived_data}")
    except Exception as e:
        app_log.info(
            f"Error: while updating archiving status for the file: {repr(e)}")


def archive_handler(archived_records):
    """
    This function will archive the files
    1. Archive file with Unix Platform
    2. Archive file with Windows Platform [Local Usage only]
    """
    format_date='%Y-%m-%d %H:%M:%S'
    for archive_record in archived_records:
        copy_start_time = datetime.now()
        file_name = archive_record['file_name']
        job_start_time = datetime.strftime(
            archive_record['job_start_time'], format_date)
        process_start_time = datetime.strftime(
            archive_record['process_start_time'], format_date)
        process_end_time = datetime.strftime(
            archive_record['process_end_time'], format_date)
        file_path = archive_record['file_path']
        tool_name = archive_record['tool_name']
        copied_flag = 1

        try:
            """ Archiveing Files """
            app_log.info("Detected system is Unix.")
            archive_path = archive_record['arch_path'] or '-'

            if not os.path.exists(archive_path):
                app_log.info(
                    f"archive folder creation data --> {tool_name}, {job_start_time}")
                job_start_time = get_resulttimestamp(file_path, job_start_time)
                archive_path = archive_folder_creation_unix(
                    tool_name, job_start_time)

            abs_path = os.path.join(archive_path)
            filename_split, ext = os.path.splitext(file_name)
            archive_filename = f"{filename_split}_{str(int(os.stat(abs_path).st_ctime))}{ext}"
            archive_path_file_name = f"{os.path.join(archive_path,archive_filename)}"

            # for windows
            # cmd_to_mv = f"""move "{file_path}" "{archive_path_file_name}" """
            # for unix
            cmd_to_mv = f"""mv -f "{file_path}" "{archive_path_file_name}" """

            app_log.info("cmd to move the file : {0}".format(cmd_to_mv))
            app_log.info(
                f"Archive file moved already: {os.path.exists(archive_path)}")
            res = os.system(cmd_to_mv)
            if res != 0:
                app_log.warning(
                    f"Unable to move this file to archive location: {file_name}")
                archive_path = 'NA'
                copied_flag = 0
            else:
                app_log.info(
                    f"File has been moved to Archive location: {file_name}")
            copy_end_time = datetime.now()
            copy_duration = copy_end_time - copy_start_time
            process_duration = datetime.strptime(
                process_end_time, format_date) - datetime.strptime(process_start_time, format_date)
            """ Updating status for the archived files """

            archive_data = {
                'opwi_table_name': opwi_table_name,
                'arch_path': archive_path_file_name,
                'job_status': "created",
                'start_time': copy_start_time.strftime("%Y-%m-%d %H:%M:%S"),
                'end_time': copy_end_time.strftime("%Y-%m-%d %H:%M:%S"),
                'file_name': file_name,
                'copied_flag': copied_flag,
                'duration': copy_duration.seconds,
                'process_duration': process_duration.seconds,
                'process_end_time': process_end_time
            }
            app_log.info(
                f"**********************Archive data********************************")
            app_log.info(f"{archive_data}")
            time.sleep(1)
            update_archive_status(archive_data)
        except Exception as e:
            app_log.info(
                f"Error: While Processing Archiveing {file_name} to Archive location: {repr(e)}")


if __name__ == '__main__':
    file_count = filewatcher()
    app_log.info(
        f"file_count - file count from file watcher: {file_count}, {file_count > 0}")

    if file_count > 0:
        archive_file()
