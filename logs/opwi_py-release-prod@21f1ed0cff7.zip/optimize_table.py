from api.utils.utils import connection_pool, get_logger

app_log = get_logger("optimizetables")

def optimize_defect_main(cursor, table_name):
    query = f"select distinct partition from system.parts where database = 'raw' and table='{table_name}' and modification_time >= date_sub(DAY, 1, toDate(now()))"
    print(query)
    cursor.execute(query)
    for partition in cursor.fetchall():
        app_log.info(f"Starting to Optimize partition {partition[0]}")
        optimize_query = f"OPTIMIZE table raw.{table_name} PARTITION tuple({partition[0]}) FINAL"
        cursor.execute(optimize_query)
        app_log.info(f"Completed Optimizing partition {partition[0]}")
try:
    tableList = ['opwi_defect_cm', 'opwi_defect_cm_wip', 'opwi_defect_scm_wip', 'opwi_defect_scm', 'opwi_defect_main',
     'opwi_job_log']

    
    connection = connection_pool.connect()
    cursor = connection.cursor()
    for tbl in tableList:
        if tbl == 'opwi_defect_main':
            optimize_defect_main(cursor, 'opwi_defect_main')
        else:
            app_log.info(f"Optimizing Table {tbl}")
            cursor.execute(f"OPTIMIZE table {tbl} final")
            app_log.info("Table Optimized")

    cursor.close()
    connection.close()

except Exception as e:
    import traceback
    app_log.info("Error while optiimizing the table")
    app_log.error(traceback.format_exc())
