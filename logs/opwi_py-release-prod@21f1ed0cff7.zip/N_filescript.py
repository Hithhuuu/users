import shutil
import argparse
from datetime import datetime
import copy
import fileinput
import re

parser = argparse.ArgumentParser()
parser.add_argument('--src')
parser.add_argument('--to')
parser.add_argument('--copies')
parser.add_argument('--prefix')


# python .\watchdog_process\test_copy.py --src=/Application/local/motor/data/wizer/T99010/src_files/1.001 --to=/Application/local/motor/data/wizer/T99010/lz/today/reports --copies=10 --prefix=test

args = parser.parse_args()

original = f'{args.src}'
target = f'{args.to}'
prefix = f'{args.prefix}'
n = int(args.copies)
date_str = datetime.now().strftime('%Y_%m_%d')
count=0

for i in range(1, n+1):
    path = f'{target}\{prefix}_{date_str}_{i}.001'
    print(path)
    # shutil.copyfile(original, path)
    with open(original,'r') as file:
        file_contents=file.readlines()

    #breakpoint()
    #file_contents_copy = file_contents.copy()
    for i in range (len(file_contents)):
        if "Record LotRecord" in file_contents[i]:
            file_contents[i]=f'Record LotRecord "{prefix}_{count}"' 
            count=count+1
        elif "LotID" in file_contents[i]:
            file_contents[i]=f'LotID "{prefix}_{count}"' 
            count=count+1
            
    with open(path,'w') as file:
        for line in file_contents:
            file.write(line)

    
