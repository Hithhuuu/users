CREATE TABLE raw.opwi_export_file
(
    `fileversion` FixedString(32),
    `prefixdata` String,
    `suffixdata` String,
    `columnsname` String,
    `filename` String,
    `mapid` Int32
)
ENGINE = MergeTree()
PRIMARY KEY (mapid, filename)
ORDER BY (mapid, filename)
SETTINGS index_granularity = 8192