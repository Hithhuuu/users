CREATE TABLE raw.opwi_user_activities
(
    `userid` String,
    `action` String,
    `refid` Int32,
    `reftype` String,
    `udt` DateTime
)
ENGINE = MergeTree()
PRIMARY KEY userid
ORDER BY userid
SETTINGS index_granularity = 8192