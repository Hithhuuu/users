CREATE TABLE raw.opwi_class_groups
(
    `projectid` Int32,
    `classnumber` Int32,
    `groupname` FixedString(32)
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, classnumber)
ORDER BY (projectid, classnumber)
SETTINGS index_granularity = 8192