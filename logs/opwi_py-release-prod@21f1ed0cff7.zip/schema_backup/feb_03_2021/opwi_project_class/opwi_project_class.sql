CREATE TABLE raw.opwi_project_class
(
    `projectid` Int32,
    `classnumber` Int32,
    `classname` FixedString(32)
)
ENGINE = MergeTree()
PRIMARY KEY projectid
ORDER BY projectid
SETTINGS index_granularity = 8192