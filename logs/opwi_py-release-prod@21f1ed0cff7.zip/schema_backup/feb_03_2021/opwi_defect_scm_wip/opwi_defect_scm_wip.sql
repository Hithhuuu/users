CREATE TABLE raw.opwi_defect_scm_wip
(
    `projectid` Int32,
    `rmapid` Int32,
    `smapid` Int32,
    `rdefectid` Int32,
    `sdefectid` Int32,
    `dbp` Nullable(Float32)
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, rmapid, smapid, rdefectid, sdefectid)
ORDER BY (projectid, rmapid, smapid, rdefectid, sdefectid)
SETTINGS index_granularity = 8192