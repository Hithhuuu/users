CREATE TABLE raw.opwi_user_templates
(
    `template_id` Int32,
    `templatename` FixedString(128),
    `template_owner` FixedString(32),
    `template_json` String,
    `cdt` DateTime,
    `udt` DateTime,
    `uby` FixedString(32),
    `rfg` Int16,
    `tfg` Int16
)
ENGINE = MergeTree()
PRIMARY KEY template_id
ORDER BY template_id
SETTINGS index_granularity = 8192