CREATE TABLE raw.opwi_myproject_maps
(
    `projectid` Int32,
    `mapid` Int32,
    `userid` FixedString(32),
    `refmap` Int8
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, mapid)
ORDER BY (projectid, mapid)
SETTINGS index_granularity = 8192