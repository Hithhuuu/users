CREATE TABLE raw.opwi_project_defect_main_1223
(
    `projectid` Int32,
    `mapid` Int32,
    `defectid` Int32,
    `xrel` Nullable(Float32),
    `yrel` Nullable(Float32),
    `xindex` Nullable(Int32),
    `yindex` Nullable(Int32),
    `classnumber` Nullable(Int32),
    `xsite` Nullable(Int32),
    `ysite` Nullable(Int32),
    `site_distance` Nullable(Float32),
    `die_distance` Nullable(Float32),
    `field_distance` Nullable(Float32),
    `on_border_field` Nullable(Int32),
    `on_border_die` Nullable(Int32),
    `xsite_acord` Nullable(Float32),
    `ysite_acord` Nullable(Float32),
    `xsite_prep1` Float32,
    `ysite_prep1` Float32,
    `xsite_prep2` Float32,
    `ysite_prep2` Float32,
    `xsite_prep_cm` Nullable(Float32),
    `ysite_prep_cm` Nullable(Float32),
    `dm_id` Int64
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, mapid, defectid, dm_id)
ORDER BY (projectid, mapid, defectid, dm_id)
SAMPLE BY mapid
SETTINGS index_granularity = 8192