CREATE TABLE raw.opwi_defect_cm
(
    `projectid` Int32,
    `refcm` FixedString(8),
    `rmapid` Int32,
    `smapid` Int32,
    `rdefectid` Int32,
    `sdefectid` Int32,
    `xsite_prep1` Nullable(Float32),
    `ysite_prep1` Nullable(Float32),
    `xsite_prep2` Nullable(Float32),
    `ysite_prep2` Nullable(Float32),
    `xsite` Nullable(Float32),
    `ysite` Nullable(Float32)
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, refcm, rmapid, smapid, rdefectid, sdefectid)
ORDER BY (projectid, refcm, rmapid, smapid, rdefectid, sdefectid)
SETTINGS index_granularity = 8192