CREATE TABLE raw.opwi_user_templateshares
(
    `template_id` Int32,
    `template_user` FixedString(32),
    `roleshared` FixedString(32),
    `cdt` DateTime,
    `udt` DateTime,
    `uby` FixedString(32),
    `rfg` Int8,
    `cby` FixedString(32)
)
ENGINE = MergeTree()
PRIMARY KEY cdt
ORDER BY cdt
SETTINGS index_granularity = 8192