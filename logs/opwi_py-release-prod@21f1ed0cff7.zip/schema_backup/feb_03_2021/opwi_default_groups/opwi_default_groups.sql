CREATE TABLE raw.opwi_default_groups
(
    `groupname` FixedString(32),
    `cdt` DateTime,
    `udt` DateTime,
    `lby` FixedString(32),
    `rfg` Int8,
    `projectid` Nullable(Int32)
)
ENGINE = MergeTree()
PRIMARY KEY groupname
ORDER BY groupname
SETTINGS index_granularity = 8192