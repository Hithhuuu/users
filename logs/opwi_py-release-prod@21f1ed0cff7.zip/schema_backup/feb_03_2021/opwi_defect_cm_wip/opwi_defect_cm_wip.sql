CREATE TABLE raw.opwi_defect_cm_wip
(
    `projectid` Int32,
    `cm_type` FixedString(8),
    `rmapid` Int32,
    `smapid` Int32,
    `rdefectid` Int32,
    `sdefectid` Int32,
    `dbp` Nullable(Float32)
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, cm_type, rmapid, smapid, rdefectid, sdefectid)
ORDER BY (projectid, cm_type, rmapid, smapid, rdefectid, sdefectid)
SETTINGS index_granularity = 8192