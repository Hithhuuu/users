CREATE TABLE raw.opwi_myproject_maps_0108
(
    `projectid` Int32,
    `mapid` Int32,
    `userid` FixedString(32),
    `refmap` Int8,
    `diepitch_x_up` Float32,
    `diepitch_y_up` Float32,
    `scl_x_up` Float32,
    `scl_y_up` Float32,
    `diepitch_x_down` Float32,
    `diepitch_y_down` Float32,
    `scl_x_down` Float32,
    `scl_y_down` Float32,
    `diepitch_x_left` Float32,
    `diepitch_y_left` Float32,
    `scl_x_left` Float32,
    `scl_y_left` Float32,
    `diepitch_x_right` Float32,
    `diepitch_y_right` Float32,
    `scl_x_right` Float32,
    `scl_y_right` Float32,
    `orientation_side` String
)
ENGINE = MergeTree()
PRIMARY KEY (projectid, mapid)
ORDER BY (projectid, mapid)
SETTINGS index_granularity = 8192