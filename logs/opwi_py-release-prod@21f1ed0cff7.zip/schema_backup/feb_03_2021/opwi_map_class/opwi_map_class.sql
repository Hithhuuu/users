CREATE TABLE raw.opwi_map_class
(
    `mapid` Int32,
    `classnumber` Int32,
    `classname` FixedString(256)
)
ENGINE = MergeTree()
PRIMARY KEY mapid
ORDER BY mapid
SETTINGS index_granularity = 8192