CREATE TABLE raw.opwi_myprojects
(
    `projectid` Int32,
    `projectname` String,
    `status` String,
    `powner` String,
    `cdt` DateTime,
    `udt` DateTime,
    `uby` String,
    `rfg` Int8,
    `fieldx` Int32,
    `fieldy` Int32,
    `fieldoriginx` Int32,
    `fieldoriginy` Int32,
    `orientationmarklocation` Nullable(String)
)
ENGINE = MergeTree()
PRIMARY KEY projectid
ORDER BY projectid
SETTINGS index_granularity = 8192