CREATE TABLE raw.opwi_users
(
    `userid` FixedString(32),
    `preferedname` FixedString(64),
    `firstname` FixedString(64),
    `lastname` FixedString(64),
    `email` FixedString(128),
    `assignedrole` FixedString(24),
    `cdt` DateTime,
    `cby` FixedString(32),
    `uby` FixedString(32),
    `udt` DateTime,
    `rfg` Int8,
    `password` FixedString(64)
)
ENGINE = MergeTree()
PRIMARY KEY userid
ORDER BY userid
SETTINGS index_granularity = 8192