CREATE TABLE raw.opwi_job_log
(
    `id` Int32,
    `tool_name` FixedString(32),
    `file_name` FixedString(128),
    `job_start_time` DateTime,
    `job_status` FixedString(24),
    `copy_start_time` DateTime,
    `copy_end_time` DateTime,
    `copy_duration` Int32,
    `no_of_copy_retries` Int32,
    `copied_flag` Int32,
    `err_message` FixedString(256),
    `process_start_time` DateTime,
    `process_end_time` DateTime,
    `process_duration` Int32,
    `reconcile_status` Int32,
    `file_path` FixedString(256),
    `arch_path` FixedString(256),
    `imported_on` DateTime,
    `unique_header_id` FixedString(256)
)
ENGINE = MergeTree()
PRIMARY KEY (id, file_name)
ORDER BY (id, file_name)
SETTINGS index_granularity = 8192