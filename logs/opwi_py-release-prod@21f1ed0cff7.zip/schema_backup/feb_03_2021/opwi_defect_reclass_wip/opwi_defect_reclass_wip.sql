CREATE TABLE raw.opwi_defect_reclass_wip
(
    `mapid` FixedString(256),
    `userid` FixedString(32),
    `classnumber` Int32,
    `token` FixedString(128),
    `cdt` DateTime
)
ENGINE = Log