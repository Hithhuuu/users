CREATE TABLE raw.opwi_map_sct_wip_1231
(
    `mapid` Int32,
    `ref_x` Float32,
    `ref_y` Float32
)
ENGINE = MergeTree()
PRIMARY KEY (mapid, ref_x, ref_y)
ORDER BY (mapid, ref_x, ref_y)
SETTINGS index_granularity = 8192