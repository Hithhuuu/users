import glob
import os
import sqlite3
import csv
import yaml
from utils import logger
from contextvars import ContextVar
from metrics.doc_metrics import db_connection

# from libra_incrementals import libra_incremental


folder_path = "/path"
main_folder_paths = [
    folder_path + r"/libra_SD/libra-incremental/",
]
endpoint = "https://az-cogsearch-uswst3-dev-openai01.search.windows.net"
index_name = "science-direct-rag-v2"
api_key = "6L22P7O2GhqPrOnYfA22sGN8QwMOgllOAtnmpAJSTQAzSeACocFY"
class IncrementalSync:
    def __init__(self):
        print("Incremental Sync")
        # libra_incremental(folder_path, endpoint, index_name, api_key)


#     def read_yaml(self, file_path):
#         with open(file_path, 'r') as yaml_file:
#             config = yaml.safe_load(yaml_file)
#         return config
    
#     def read_csv(self, file_path):
#         files = []
#         with open(file_path, 'r') as csv_file:
#             csv_reader = csv.reader(csv_file)
#             for row in csv_reader:
#                 if row:
#                     files.append(row[0])
#         return files
    

# main_folder_paths = [
#     r"/hr-index/hr-indiaglobal/hr-incremental/",
#     r"/hr-index/hr-indiaglobal/csv/",
#     r"/hr-index/hr-indiaglobal/india-hr-shared/",
#     r"/hr-index/logs/indiaglobal/"
# ]

# for folder_path in main_folder_paths:
#     os.makedirs(folder_path, exist_ok=True)

# # Example usage
# NAS_PATH = "/hr-index/hr-indiaglobal/hr-incremental/"
# USERNAME = "chatgptkb"
# PASSWORD = "dkO3+aZYD8W"

# dir_path = os.path.dirname(os.path.abspath(__file__))
# CONFIG_PATH = os.path.join(dir_path, "connectors\config_et_libra_science_direct_file_system_incremental.yaml")


# def extract_json_data(url, params=None, username=None, password=None):
#     response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
 
#     if response.status_code == 200:
#         try:
#             json_data = response.json()
#             return json_data
#         except ValueError as e:
#             print("Error parsing JSON:", e)
#     else:
#         print("Error:", response.status_code)
 
 
# def download_content(url, save_path, params=None, username=None, password=None):
#     response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
#     if response.status_code == 200:
#         with open(save_path, "wb") as file:
#             file.write(response.content)
#         print("Content downloaded successfully.")
#     else:
#         print(f"Failed to download content. Status Code: {response.status_code}")
 
 
# def find_pdf(directory):
#     pdf_files = []
#     for root, dirs, files in os.walk(directory):
#         for file in files:
#             if file.lower().endswith(".pdf"):
#                 pdf_files.append(os.path.join(root, file))
#     return pdf_files
 
 
# def flat_dir(root_dir):
#     subfolders = [f.path for f in os.scandir(root_dir) if f.is_dir()]
#     for subfolder in subfolders:
#         subfolder_name = os.path.basename(subfolder)
#         for file_name in os.listdir(subfolder):
#             if file_name.endswith('.txt') or file_name.endswith('.json') or file_name.endswith('.pdf'):
#                 file_path = os.path.join(subfolder, file_name)
#                 new_file_name = subfolder_name + '_' + file_name
#                 new_file_path = os.path.join(root_dir, new_file_name)
#                 shutil.move(file_path, new_file_path)
 

# def delete_file(directory_path):
#     if os.path.exists(directory_path):
#         shutil.rmtree(directory_path)
#         print(f"The directory {directory_path} has been deleted.")
#     else:
#         print(f"The directory {directory_path} does not exist.")

#     def libra_incremental(self):
#         folder_path = 'C:\\Users\\x0150217\\Downloads\\xml_files_data'
#         latest_modified_file = None
#         latest_timestamp = 0
#         CONFIG_PATH = "connectors\\config_et_libra_science_direct_file_system_incremental.yaml"
#         CSV_PATH = "Sciencedirect-2024.csv"
#         context_vars = ContextVar('context', default={})
#         app_log = logger.getLogger(context_vars.get())
#         files = glob.glob(os.path.join(folder_path, '*.xml'))
#         if files:
#             for file in files:
#                 timestamp = os.path.getmtime(file)
#                 if timestamp > latest_timestamp:
#                     latest_timestamp = timestamp
#                     latest_modified_file = file
#             if latest_modified_file:
#                 app_log.info("Latest modified file")
#                 app_log.info("Latest modified file: %s", latest_modified_file)
#                 older_files_exist = len(files) > 1
#                 if older_files_exist:
#                     app_log.info("Older files exist.")
#                 else:
#                     app_log.info("No older files found.")
#                 # log_file_path = 'logs\\connectorframework.log'
#                 # file_already_read = False
#                 # with open(log_file_path, 'r') as log_file:
#                 #     for line in log_file:
#                 #         if latest_modified_file in line:
#                 #             file_already_read = True
#                 #             break
#                 # try:
#                 #     conn = db_connection()
#                 #     cursor = conn.cursor()
#                 #     cursor.execute("SELECT * FROM filestats_metrics WHERE fileid = %s", (latest_modified_file,))
#                 #     if cursor.fetchone():
#                 #         file_already_read = True
#                 #         os.remove(latest_modified_file)
#                 #         app_log.info("Duplicate file deleted.")
#                 #         cursor.execute("DELETE FROM filestats_metrics WHERE fileid = %s", (latest_modified_file,))
#                 #         conn.commit()
#                 #         app_log.info("Duplicate entry removed from the database.")
#                 #     else:
#                 #         cursor.execute("INSERT INTO filestats_metrics (fileid) VALUES (%s)", (latest_modified_file,))
#                 #         conn.commit()
#                 #         app_log.info("File marked as read in the database.")
#                 #     conn.close()
#                 # except Exception as e:
#                 #     app_log.error(e)
#                 # if file_already_read:
#                 #     app_log.info("The latest modified file has already been read.")
#                 # else:
#                 #     app_log.info("The latest modified file has not been read yet.")
#                 # Read YAML configuration file
#                 config = self.read_yaml(CONFIG_PATH)
#                 file_system_path = config.get("file_system_path")
#                 if file_system_path:
#                     # Construct the full file path using the file_system_path
#                     latest_modified_file = os.path.join(file_system_path, latest_modified_file)
#                 # Read CSV file
#                 csv_files = self.read_csv(CSV_PATH)
#                 if latest_modified_file not in csv_files:
#                     # Write the file path to the CSV file
#                     with open(CSV_PATH, 'a') as csv_file:
#                         csv_writer = csv.writer(csv_file)
#                         csv_writer.writerow([latest_modified_file])
