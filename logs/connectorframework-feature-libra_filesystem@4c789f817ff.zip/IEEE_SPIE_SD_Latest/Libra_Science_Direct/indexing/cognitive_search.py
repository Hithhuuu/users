import os
import openai
from typing import List
import tempfile
from azure.storage.blob import BlobServiceClient
from langchain.docstore.document import Document
from langchain.document_loaders import AzureBlobStorageFileLoader, TextLoader
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.text_splitter import RecursiveCharacterTextSplitter, Language
# from azure.search.documents.indexes.models import SearchField, SearchFieldDataType, SimpleField, SearchableField,SemanticConfiguration,SemanticSettings,SearchIndex,PrioritizedFields,SemanticField
from azure.search.documents.indexes.models import ExhaustiveKnnParameters,HnswParameters,SearchField, SearchFieldDataType, SimpleField, SearchableField,SemanticConfiguration,PrioritizedFields,SemanticField,SemanticSettings,SearchIndex,VectorSearch,  HnswVectorSearchAlgorithmConfiguration,VectorSearchAlgorithmKind,VectorSearchProfile,ExhaustiveKnnVectorSearchAlgorithmConfiguration
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.schema import BaseRetriever
import yaml
from indexing.reading_metadata import ReadingMetadata
from utils import logger
from contextvars import ContextVar
from datetime import datetime
from azure.search.documents import SearchClient
import psycopg2
import psycopg2.pool
from azure.core.credentials import AzureKeyCredential  
from azure.search.documents.indexes import SearchIndexClient
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
context = {}
import argparse
import json
import pandas as pd
import openai, uuid, json


parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
    "--file_path", default="config.yaml", help="Path to the config.yaml file"
)
args = parser.parse_args()

metadata_content = ReadingMetadata()

CONFIG_FILE = args.file_path

def get_env_config():
    """Return the config read from config.yaml file"""
    env = os.getenv("env")
    if env is None:
        env = "local"
    with open(CONFIG_FILE) as file:
        try:
            config = yaml.load(
                file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader
            )
        except Exception as e:
            config = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return config

# os.environ.update(config)
try:
    config = get_env_config()
    os.environ["AZURE_COGNITIVE_SEARCH_SERVICE_NAME"] = config['vector_db']['azure_cognitive_search_service_name']
    os.environ["AZURE_COGNITIVE_SEARCH_INDEX_NAME"] = config['vector_db']['azure_cognitive_search_index_name']
    os.environ["AZURE_COGNITIVE_SEARCH_API_KEY"] = config['vector_db']['azure_cognitive_search_api_key']
    os.environ['OPENAI_API_KEY'] = config['vector_db']['openai_api_key']
    os.environ['OPENAI_API_TYPE'] = config['vector_db']['openai_api_type']
    os.environ['OPENAI_API_BASE'] = config['vector_db']['openai_api_base']
    os.environ['OPENAI_API_VERSION'] = config['vector_db']['openai_api_version']
    os.environ['OPENAI_API_VERSION'] = config['vector_db']['openai_api_version']

    openai.api_base = os.environ['OPENAI_API_BASE']
    openai.api_type = os.environ['OPENAI_API_TYPE']
    openai.api_key = os.environ['OPENAI_API_KEY']
    openai.api_version = os.environ['OPENAI_API_VERSION']
    
except Exception as e:
    raise Exception (e)

vector_store_address: str = config['vector_db']['vector_store_address']
vector_store_password: str = os.environ["AZURE_COGNITIVE_SEARCH_API_KEY"]
index_name: str = os.environ["AZURE_COGNITIVE_SEARCH_INDEX_NAME"]
chunk_size = int(config['vector_db']["chunk_size"])
max_retries = int(config['vector_db']["max_retries"])

model: str = config['vector_db']['embeddings_model']
embedding_size = int(config['embeddings']["embedding_size"])

targetr_index = config['connector'].get("targetr_index" , 'NA')

# embeddings: OpenAIEmbeddings = OpenAIEmbeddings(model=model, chunk_size=chunk_size, max_retries=max_retries)
embeddings = None

# Used for adding new columns to Schema if matches with metadata
filter_fields = config['vector_db'].get("filter_fields", [])
multivalue_fields = config['vector_db'].get("separator_fields", [])
sharepoint_metadata_fields=config['vector_db'].get("sharepoint_metadata_fields", [])
csv_metadata_path = config['connector'].get("csv_path" , 'NA')
csv_metadata_fields = config['connector'].get('csv_fields', 'NA')
csv_metadata_primarykey = config['connector'].get('csv_primarykey','NA')

if (csv_metadata_path != 'NA' and csv_metadata_fields != 'NA' and csv_metadata_primarykey != 'NA'):
    csv_df = pd.read_csv(csv_metadata_path) if csv_metadata_path else pd.DataFrame()
else:
    csv_df = pd.DataFrame()

# if(targetr_index == 'pg_vector'):
#     conn_pool = psycopg2.pool.ThreadedConnectionPool(pgvector_minconn, pgvector_maxconn,
#            host=os.environ.get("PGVECTOR_HOST", "dcalpd3039"),
#            port=int(os.environ.get("PGVECTOR_PORT", "5888")),
#            database=os.environ.get("PGVECTOR_DATABASE", "postgres"),
#            user=os.environ.get("PGVECTOR_USER", "pgvector_ai"),
#            password=os.environ.get("PGVECTOR_PASSWORD", "pgpass#12"),
#        )

class AzureSearchVectorStore:
    def __init__(self, vector_store_address: str, vector_store_password: str, index_name: str, filename: str,filepath: str,embeddings: embeddings):
        self.embedding = embeddings
        self.filename = filename
        self.filepath = filepath
        self.vector_store_address=vector_store_address
        self.vector_store_password=vector_store_password
        self.credential = AzureKeyCredential(self.vector_store_password)
        self.index_name=index_name
        
        # self.vector_store = AzureSearch(
        #     azure_search_endpoint=vector_store_address,
        #     azure_search_key=vector_store_password,
        #     index_name=index_name,
        #     embedding_function=embeddings.embed_query,
        #     fields=self.get_default_fields()
        # )

        self.index_client = SearchIndexClient(
        endpoint=self.vector_store_address, credential=self.credential)
        fields = self.get_default_fields()
        semantic_config = self.configure_semantic_config()
        vector_search = self.configure_vector_search()
        semantic_settings = SemanticSettings(configurations=[semantic_config])
        index = SearchIndex(name=index_name, fields=fields,
                            vector_search=vector_search, semantic_settings=semantic_settings)
        result = self.index_client.create_or_update_index(index)
        print(f' {result.name} created')

    chunked_docs_batch =[]

    def configure_vector_search(self):
        # Configure the vector search configuration  
        vector_search = VectorSearch(
            algorithms=[
                HnswVectorSearchAlgorithmConfiguration(
                    name="myHnsw",
                    kind=VectorSearchAlgorithmKind.HNSW,
                    parameters=HnswParameters(
                        m=4,
                        ef_construction=400,
                        ef_search=500,
                        metric="cosine"
                    )
                ),
                ExhaustiveKnnVectorSearchAlgorithmConfiguration(
                    name="myExhaustiveKnn",
                    kind=VectorSearchAlgorithmKind.EXHAUSTIVE_KNN,
                    parameters=ExhaustiveKnnParameters(
                        metric="cosine"
                    )
                )
            ],
            profiles=[
                VectorSearchProfile(
                    name="myHnswProfile",
                    algorithm="myHnsw",
                    # vectorizer="myOpenAI"
                ),
                VectorSearchProfile(
                    name="myExhaustiveKnnProfile",
                    algorithm="myExhaustiveKnn",
                    # vectorizer="myOpenAI"
                )
            ],
        #     vectorizers=[
        #         AzureOpenAIVectorizer(
        #             name="myOpenAI",
        #             kind="azureOpenAI",
        #             azure_open_ai_parameters=AzureOpenAIParameters(
        #                 resource_uri=self.openai_base,
        # #                 resource_uri='https://openai-euwst-dev.openai.azure.com/',
        #                 deployment_id=model,
        #                 api_key=self.openai_key,
        # #                 api_key="4a091186d0c04ff5918d67f716c7db2e"
        #             )
        #     )  
        # ]  

        )
        return vector_search

    def configure_semantic_config(self):
        semantic_config = SemanticConfiguration(
        name="my-semantic-config",
        prioritized_fields=PrioritizedFields(
            prioritized_content_fields=[SemanticField(field_name="content")]
        )
        )
        return semantic_config

    def get_default_fields(self):
        try:
            schema_list = [
                SearchField(
                    name='id',
                    type=SearchFieldDataType.String,
                    key=True,
                    filterable=True,
                    sortable=True,
                ),
                SearchableField(
                    name='content',
                    type=SearchFieldDataType.String,
                ),
                SearchField(
                    name='content_vector',
                    type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                    searchable=True,
                    vector_search_dimensions=embedding_size,
                    vector_search_configuration="default",
                    vector_search_profile="myHnswProfile"
                ),
                SearchableField(
                    name='metadata',
                    type=SearchFieldDataType.String,
                    searchable=True,
                )
            ]
            metadata = metadata_content.reading_metadata(file_path=self.filepath,filename=self.filename)
            # ToDo - Commented below code as it was iterating same data
            ##for key,value in metadata.items():
              ##  if key in filter_fields:
            schema_list = metadata_content.define_dynamic_schema(schema_list, metadata)
            return schema_list
        except Exception as e:
            raise Exception (e)


    def add_documents(self, documents: List[Document]):
        try:
            self.vector_store.add_documents(documents=documents)
        except Exception as e:
            return("Error in adding documents:", e)
        
    no_of_batches = 0

    def process_blob_storage(self, chunked_docs_list):
        final_docs = []
        
        global no_of_batches
        try:
            for chunked_docs in chunked_docs_list:
                embeddings = {}
                pos=1
                for doc in chunked_docs["chunked_docs"]:
                    tmp_dict = {}
                    metadata = metadata_content.reading_metadata(chunked_docs['meta_data']['filepath'],chunked_docs['meta_data']['filename'])
                    mandatory = metadata_content.reading_mandatory(chunked_docs['meta_data']['filepath'],chunked_docs['meta_data']['filename'])
                    
                    if config['parser']['page_parser']:
                        metadata['page'] = doc.metadata.pop('page', None)
                        metadata['total_pages'] = doc.metadata.pop('total_pages', None)
                    if config['chunks']['type'] == 'smart_chunking':
                        metadata['chunk_header_info'] = doc.metadata.pop('chunk_header_info', None)
                        metadata['chunk_id'] = str(doc.metadata.pop('chunk_id', None))
                        metadata['page'] = str(doc.metadata.pop('page', None))
                    # pop_fields = config['vector_db'].get("pop_fields",[])
                    if config['common']['appname'] == 'ark':
                        metadata['chunk_id'] = str(pos)
                    if config['common']['appname'] == 'ET':
                       metadata['doctype']=str(doc.metadata.get('doctype', None))
                       metadata['chunk_id'] = str(pos)
                       field_names = ['security']
                       for k in filter_fields:
                            if not (k in field_names):
                                if(metadata.get(k) is not None):
                                    if(k=='year'):
                                        tmp_dict[k] = int(metadata.get(k, None))
                                    else:
                                        tmp_dict[k] = str(metadata.get(k, None)).lower()
                            else:
                                value = metadata.get(k, None)
                                json_val=[]
                                if not ('' in value) :
                                    for item in value:
                                        str_item = str(item)
                                        json_val.append(str_item)
                                tmp_dict[k] = json_val

                    if config['common']['appname'] == 'Test_IEEE_Incremental':
                       metadata['doctype']=str(doc["metadata"].get('doctype', None))
                       metadata['chunk_id'] = str(pos)
                       metadata['filename'] = chunked_docs['meta_data'].get('filename', None)

                    if config['common']['appname'] == 'Test_Libra_3':
                       # metadata['doctype']=str(doc["metadata"].get('doctype', None))
                       metadata['chunk_id'] = str(pos)
                       metadata['filename'] = chunked_docs['meta_data'].get('filename', None)


                       for k in filter_fields:
                            if(metadata.get(k) is not None):
                                tmp_dict[k] = str(metadata.get(k, None)).lower()


                    if not csv_df.empty:
                        filtered_data = csv_df[(csv_df[csv_metadata_primarykey.split(':')[1]] == mandatory[csv_metadata_primarykey.split(':')[0]])]
                        filtered_data = filtered_data.fillna('')
                        columns = filtered_data.columns
                        for column in columns:
                            metadata[column] = str(filtered_data[column].iloc[0])

                    metadata = split_values(metadata,multivalue_fields)
                    mandatory = split_values(mandatory,'')
                    content = "TITLE\n\n"+doc["Title"]+"\n\nSECTION_HEADING\n\n"+doc["Section_Heading"]+"\n\nPARAGRAPHTEXT\n\n"+doc["ParagraphText"]

                    tmp_dict['role']=str(doc["metadata"].get('role', None)).lower()
                    tmp_dict['page']=(doc["metadata"].get('page', None))
                    # tmp_dict['doctype']=str(doc["metadata"].get('doctype', None)).lower()
                    tmp_dict['content']=content
                    tmp_dict['id'] = str(uuid.uuid4())
                    tmp_dict['filename'] =  metadata['filename']

                    structured_metadata = {k:str(v) for k,v in metadata.items()}
                    structured_metadata['page']=tmp_dict['page']
                    structured_metadata['role']= tmp_dict['role']
                    structured_metadata['year']= tmp_dict['year']
                    tmp_dict['metadata'] = json.dumps(structured_metadata)
                    
                    dimensions = embedding_size
                    response = openai.Embedding.create(dimensions=dimensions,
                        input=content, engine=model)
                    embeddings = response['data'][0]['embedding']
                    tmp_dict['content_vector'] = embeddings
                    final_docs.append(tmp_dict)  

                    pos+=1
                    # For ET indexing changes needed
                # try:
                #     '''addding embedding data to json file'''                        
                #     result_print = {
                #         "filename": mandatory['filename'],
                #         "fileid": mandatory['fileid'],
                #         "embeddings": embeddings
                #         }  
                #     shared_path = config['connector']['stats_path']
                #     file_name =chunked_docs['meta_data']['filename'].split(".")[0]+".json"
                #     complete_path = shared_path +"\\"+config['common']['appname']+ "\\"+str(mandatory['jobid'])+'\\Embeddings'
                #     if not os.path.isdir(complete_path):
                #         os.makedirs(complete_path)
                #     completeName = os.path.join(complete_path, file_name)
                #     with open(completeName, 'w') as f:
                #         json.dump(result_print, f)
                    
                # except Exception as e:
                #     raise Exception(e)
                    
            if len(final_docs) > 0:
                # res = add_to_vector_store(final_docs)
                documents = final_docs
                search_client = SearchClient(endpoint=self.vector_store_address, index_name=self.index_name, credential=self.credential)
                result = search_client.upload_documents(documents=documents)
                print(f"Uploaded {len(documents)} documents") 
                self.chunked_docs_batch.clear()
        except Exception as e:
            raise Exception (e)
        
def split_values(metadata, multivalue_fields):
    for key, value in metadata.items():
        if len(multivalue_fields) >0 and key in multivalue_fields:
            separator = multivalue_fields[key] # Get separator for the key, default to ","
            metadata[key] = value.split(separator)
    return metadata

def no_of_batches():
    global no_of_batches
    return no_of_batches

def vector_store(chunked_docs):
    filename = chunked_docs[0]['meta_data']["filename"]
    filepath = chunked_docs[0]['meta_data']['filepath']
    # doctype= chunked_docs[0]['meta_data']['doctype']
    vector_store = AzureSearchVectorStore(vector_store_address, vector_store_password, index_name,filename,filepath, chunked_docs[0]['embeddings'])
    return vector_store
