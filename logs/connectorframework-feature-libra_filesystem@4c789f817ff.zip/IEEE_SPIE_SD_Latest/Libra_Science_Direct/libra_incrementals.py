import glob
import os
import sqlite3
import csv
import yaml
from contextvars import ContextVar
import time
from datetime import datetime,timedelta
import json
import csv
import requests
import re
import datetime
import shutil
import yaml
import pandas as pd
from requests.auth import HTTPBasicAuth
# from fastapi import APIRouter, Request
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from bs4 import BeautifulSoup
# from connectors.main_connector import ConnectorRun
from requests.auth import HTTPBasicAuth
#from ..Libra_Science_Direct.connectors.main_connector import ConnectorRun
from connectors.main_connector import ConnectorRun
import xml.etree.ElementTree as ET


def read_yaml(file_path):
        with open(file_path, 'r') as yaml_file:
            config = yaml.safe_load(yaml_file)
        return config
    
def read_csv(file_path):
        files = []
        with open(file_path, 'r') as csv_file:
            csv_reader = csv.reader(csv_file)
            for row in csv_reader:
                if row:
                    files.append(row[0])
        return files
    
folder_path = "/path"
main_folder_paths = [
    folder_path + r"/libra_SD/libra-incremental/",
    folder_path + r"/libra_SD/csv/",
]

for folder_path in main_folder_paths:
    os.makedirs(folder_path, exist_ok=True)
for folder_path in main_folder_paths:
    os.makedirs(folder_path, exist_ok=True)

# Example usage
NAS_PATH = "/libra_SD/libra_SD/libra_incremental/"
USERNAME = "chatgptkb"
PASSWORD = "dkO3+aZYD8W"

dir_path = os.path.dirname(os.path.abspath(__file__))
# CONFIG_PATH = os.path.join(dir_path, "Libra_Science_Direct\config_et_libra_science_direct_file_system_incremental.yaml")

yaml_files = glob.glob(os.path.join(dir_path, "**", "*.yaml"), recursive=True)

CONFIG_PATH = next((f for f in yaml_files if os.path.basename(f) == "config_et_libra_science_direct_file_system_incremental.yaml"), None)

def extract_json_data(url, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
 
    if response.status_code == 200:
        try:
            json_data = response.json()
            return json_data
        except ValueError as e:
            print("Error parsing JSON:", e)
    else:
        print("Error:", response.status_code)
 
 
def download_content(url, save_path, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
    if response.status_code == 200:
        with open(save_path, "wb") as file:
            file.write(response.content)
        print("Content downloaded successfully.")
    else:
        print(f"Failed to download content. Status Code: {response.status_code}")
  

def delete_file(directory_path):
    if os.path.exists(directory_path):
        shutil.rmtree(directory_path)
        print(f"The directory {directory_path} has been deleted.")
    else:
        print(f"The directory {directory_path} does not exist.")


def check_updated_files(file_path, reference_time, endpoint, index_name, api_key):
    file_modified_time = os.path.getmtime(file_path)
    modified_datetime = datetime.datetime.fromtimestamp(file_modified_time)
    if modified_datetime > reference_time:
        print("File {} has been updated.".format(file_path))

        # update_file_in_azure(file_path, endpoint, index_name, api_key)
        
    else:
        print("File {} has not been updated.".format(file_path))

def get_stored_date():
    try:
        stored_date = None
        file_path = os.path.join(dir_path,"stored_date.txt")
        if os.path.isfile(file_path):
            with open(file_path, "r") as file:
                stored_date = file.read()
        return stored_date
    except FileNotFoundError as e:
        print("File Not found error: ",e) 
    except Exception as e:
        print("Exception occoured during get stored data ",e) 

def get_file_size(file_path):
    return os.path.getsize(file_path)

CSV_FILENAME = 'IEEE_SPIE_SD_Latest\\Libra_Science_Direct\\updated_latest_libra_data.csv'
CSV_COLUMNS = ['Fulltextpath', 'sourcesize', 'rawsize', 'timestamp']
CSV_QUOTECHAR = '"'

def libra_incremental(folder_path, endpoint, index_name, api_key, time_delay):
    files = [os.path.join(root, name)
             for root, dirs, files in os.walk(folder_path)
             for name in files
             if name.endswith(".xml")]
    
    if files:
        new_files = []
        for file in files:
            file_name = os.path.basename(file)
            if is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
                delete_file_from_azure(file_name, endpoint, index_name, api_key)
            if not is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
                new_files.append(file)
        
        if new_files:
            data = []
            if os.path.isfile(CSV_FILENAME):
                with open(CSV_FILENAME, 'r') as csv_file:
                    csv_reader = csv.reader(csv_file, delimiter=',', quotechar=CSV_QUOTECHAR)
                    data = list(csv_reader)
            else:
                with open(CSV_FILENAME, 'w', newline='') as csv_file:
                    csv_writer = csv.writer(csv_file, delimiter=',', quotechar=CSV_QUOTECHAR, quoting=csv.QUOTE_MINIMAL)
                    csv_writer.writerow(CSV_COLUMNS)
            
            updated_data = []
            for row in data:
                if row and row in new_files:
                    file_path = os.path.join(folder_path, row)
                    sourcesize = get_file_size(file_path)
                    tree = ET.parse(file_path)
                    root = tree.getroot()
                    rawsize = len(ET.tostring(root))
                    updated_row = [row, str(sourcesize), str(rawsize), str(os.path.getctime(file_path))]
                    new_files.remove(row)
                    updated_data.append(updated_row)
                else:
                    updated_data.append(row)
            for new_file in new_files:
                file_path = os.path.join(folder_path, new_file)
                sourcesize = get_file_size(file_path)
                tree = ET.parse(file_path)
                root = tree.getroot()
                rawsize = len(ET.tostring(root))
                updated_data.append([new_file, str(sourcesize), str(rawsize), str(os.path.getctime(file_path))])
            
            with open(CSV_FILENAME, 'w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file, delimiter=',', quotechar=CSV_QUOTECHAR, quoting=csv.QUOTE_MINIMAL)
                csv_writer.writerow(CSV_COLUMNS)
                csv_writer.writerows(updated_data)
            
            # Call the connector to update the new files
            for data in updated_data:
                config = read_yaml(CONFIG_PATH)
                Connector = ConnectorRun(config.get("connector"))
                Connector.filesystem_run()
            if os.path.exists(f'{CSV_FILENAME}'):
                    os.remove(f'{CSV_FILENAME}')
        else:
            print("No new files found")
    else:
        print("No files found in the folder.")


def is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
    credential = AzureKeyCredential(api_key)
    client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)
    filter_condition = "filename eq '{}'".format(file_name)
    response = client.search(search_text="", filter=filter_condition)
    results = list(response)
    return len(results) > 0
# C:\Users\x0150217\OneDrive - Applied Materials\Desktop\connectorframework\connectorframework\connectors\libra_incrementals.py
def delete_file_from_azure(file_name, endpoint, index_name, api_key):
    credential = AzureKeyCredential(api_key)
    client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)
    filter_condition = "filename eq '{}'".format(file_name)
    response = client.search(search_text="", filter=filter_condition)
    updated_documents = []
    for result in response:
        updated_document = {
            "id": result["id"],
        }
        updated_documents.append(updated_document)
    if len(updated_documents) > 0:
        client.delete_documents(updated_documents)
