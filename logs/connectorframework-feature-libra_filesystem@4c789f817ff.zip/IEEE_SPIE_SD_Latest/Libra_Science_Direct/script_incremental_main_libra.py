from libra_incrementals import libra_incremental
from azure.storage.blob import BlobServiceClient
from datetime import datetime, timedelta ,timezone
import os

container_name = "roleaccess"
storage_account_name = "azsaopenaidev02"
storage_account_key = "TE5d6DPX8dEAbbCumGBBOvHNwcgcaxnXbOhBPfLAkst1X8MvNGRsVw+OJm+Tsjvo7nycpVvKav8x+AStYYrunw=="


def get_file_list_from_adls_gen2(container_name, storage_account_name, storage_account_key):
    blob_service_client = BlobServiceClient(account_url=f"https://{storage_account_name}.blob.core.windows.net", credential=storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)
    file_list = []
    
    # Calculate the time range
    now = datetime.now()
    earlier = now - timedelta(hours=24)
    
    for blob in container_client.list_blobs():
        # Check if the modified date falls within the time range
        if earlier <= blob.last_modified.replace(tzinfo=None) <= now:
            file_list.append(blob.name)
    
    return file_list

def download_blobs_from_adls_gen2(container_name, blob_names, storage_account_name, storage_account_key):
    local_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "adls_files")
    os.makedirs(local_directory, exist_ok=True)
    blob_service_client = BlobServiceClient(account_url=f"https://{storage_account_name}.blob.core.windows.net", credential=storage_account_key)
    container_client = blob_service_client.get_container_client(container_name)
    
    for blob_name in blob_names:
        blob_client = container_client.get_blob_client(blob_name)
        local_file_path = os.path.join(local_directory, blob_name)
        
        with open(local_file_path, "wb") as file:
            blob_data = blob_client.download_blob()
            file.write(blob_data.readall())
    return local_directory


# Get file list
file_list = get_file_list_from_adls_gen2(container_name, storage_account_name, storage_account_key)
print(file_list)


# Download blobs
local_directory = download_blobs_from_adls_gen2(container_name, file_list, storage_account_name, storage_account_key)



if __name__ == "__main__":
    # folder_path = "C:\\Users\\x0150217\OneDrive - Applied Materials\\Documents\\xml_files_data"
    endpoint = "https://az-cogsearch-uswst3-dev-openai01.search.windows.net"
    index_name = "science-direct-test-v3"
    api_key = "6L22P7O2GhqPrOnYfA22sGN8QwMOgllOAtnmpAJSTQAzSeACocFY"
    folder_path = local_directory
    libra_incremental(folder_path, endpoint, index_name, api_key,24)

