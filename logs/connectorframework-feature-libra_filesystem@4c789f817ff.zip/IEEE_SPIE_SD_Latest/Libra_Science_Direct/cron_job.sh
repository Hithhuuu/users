bash
!/bin/bash
export CONFIG_PATH="connectors/config_et_libra_science_direct_file_system_incremental.yaml"
python3 connectors\api_service\Libra_Science_Incrementals.py --file_path [CONFIG_PATH]
