from libra_spie_incrementals import libra_spie_incremental

if __name__ == "__main__":
    folder_path = "C:\\Users\\x0150217\\Downloads\connectors\\Science_Libra_Spie"
    endpoint = "https://az-cogsearch-uswst3-dev-openai01.search.windows.net"
    index_name = "spie-rag-v2-test_3"
    api_key = "6L22P7O2GhqPrOnYfA22sGN8QwMOgllOAtnmpAJSTQAzSeACocFY"
    libra_spie_incremental(folder_path, endpoint, index_name, api_key,60)