from __future__ import annotations
import argparse
import sys
import yaml
import os
import requests
from multiprocessing.pool import ThreadPool
from multiprocessing import Pool
import json
from multiprocessing.pool import ThreadPool
from multiprocessing import Pool
from abc import ABC, abstractmethod
from typing import Optional, Any
from connectors.main_connector import ConnectorRun
from chunking_method.main_chunking import ChunkingRun
from indexing.main_indexing import IndexingRun
from utils import logger
from contextvars import ContextVar
import time
from mail import send_mail
import socket

parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
    "--file_path", default="config.yaml", help="Path to the config.yaml file"
)
args = parser.parse_args()
file_path = args.file_path
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
context = {}

class Handler(ABC):
    @abstractmethod
    def set_next(self, handler: Handler) -> Handler:
        pass

    @abstractmethod
    def handle(self, request, data) -> Optional[str]:
        pass


class AbstractHandler(Handler):
    _next_handler: Handler = None

    def set_next(self, handler: Handler) -> Handler:
        self._next_handler = handler
        return handler

    @abstractmethod
    def handle(self, request: Any, data) -> str:
        if self._next_handler:
            return self._next_handler.handle(request)

        return None

class ConnectorHanlder(AbstractHandler):
    def __init__(self, config) -> None:
        self.config = config
        super().__init__()

    def handle(self, request: Any) -> str:
        if request == "Connector":
            start_time = time.time()
            connector = ConnectorRun(self.config)
            res = connector.run()
            process_time = (time.time() - start_time)
            context['component'] = "Connector"
            context['hostname'] = socket.gethostname()
            context['jobid'] = res
            context['exec_time'] = str(process_time)
            app_log.info('Connector component completed', extra=context)
            # send mail at this point res is jobid
            # url = f"http://dcilpb1805/dev/test/get_job_details?jobid='{res}'"  #url needs to be update when deployed in OCP
            # response = requests.get(url)
            # send_mail(response)  uncomment when deployed in server
            return res
        elif request == "fileConnector":
            connector = ConnectorRun(self.config)
            res = connector.filesystem_run()
            return res
        elif request == "Connector_online":
            connector = ConnectorRun(self.config)
            res = connector.run_online()
            return res


def read_yaml(file_path):
    with open(file_path, "r") as file:
        config_data = yaml.safe_load(file)
    return config_data

if __name__ == "__main__":
    config = read_yaml(file_path)
    context['appname'] = config['common']['appname']
    if(config['connector']['type'] == "sharepoint"):
        connector = ConnectorHanlder(config.get("connector"))
        connector.handle("Connector")
    elif(config['connector']['type'] == "filesystem"):
        connector = ConnectorHanlder(config.get("connector"))
        connector.handle("fileConnector")
    elif(config['connector']['type'] == "sharepoint_online"):
        connector = ConnectorHanlder(config.get("connector"))
        connector.handle("Connector_online")
