#!/bin/bash
python3 main.py --file_path "config_trillium.yaml"