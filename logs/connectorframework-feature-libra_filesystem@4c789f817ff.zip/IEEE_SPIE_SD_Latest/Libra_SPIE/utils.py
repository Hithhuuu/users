import os
import yaml
import time
import logging
from smart_logger.logger import InitializeLogger
import argparse

FORMATTER = logging.Formatter(
    "%(asctime)s — %(name)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s")
LOG_FILE = "connectorframework.log"
parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
    "--file_path", default="config.yaml", help="Path to the config.yaml file"
    )
args = parser.parse_args()
config_file = args.file_path


def initlogger():
    with open(config_file, 'r') as file:
        config_data = yaml.safe_load(file)

    logpath = config_data.get('common').get('smart_logger').get('LOG_PATH')
    if os.path.isdir("ddp-connectors"):
       os.rmdir("ddp-connectors")
    if not os.path.exists(logpath):
        os.makedirs(logpath)

    config = {
        'logger_name': 'framework',
        'formatter': '%(asctime)s | %(levelname)s | %(hostname)s | %(lineno)s | %(component)s | %(funcName)s | %(exec_time)s | '
                     '%(jobid)s | %(appname)s | %(file_name)s | %(status)s | %(actual_filesize)s | %(raw_filesize)s |  %(record_count)s |'
                     '%(message)s',
        'extra_keys': ['exec_time', 'hostname', 'component', 'file_name', 'actual_filesize', 'raw_filesize',
                       'record_count', 'appname', 'jobid', 'status'],
        'log_level': 'ERROR',
        'custom_methods': ['query', 'payload', 'access'],
        'single_method_file': True,
        'profiling': False,
        'log_path': f'{logpath}',
        'log_filename': 'connectorframework',
        'retention': {'when': 'D', 'interval': 30, 'backupCount': 30},
        'timezone': time.localtime  # optional
    }

    logger = InitializeLogger(config)
    return logger


logger = initlogger()
