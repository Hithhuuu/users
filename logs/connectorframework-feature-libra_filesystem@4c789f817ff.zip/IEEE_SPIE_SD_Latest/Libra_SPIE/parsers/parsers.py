import os
import yaml
from typing import List
import argparse
import json
from parsers.base import AbstractClass
from parserframework.doc_parser import DocsParser
from parserframework.pdf_parser import PDFParser
from parserframework.pptx_parser import PptxParser
from parserframework.excel_parser import ExcelParser
import json
import pandas as pd
from langchain.docstore.document import Document
import re
import lxml.etree as ET
from html import escape, unescape


class Parser(AbstractClass):
    def __init__(self):
        self.parser = MainParser()

    def method_first(self, chunked_data):
        output = self.parser.parse(chunked_data)
        return output


class MainParser():
    def __init__(self) :
        self.docs_parser = DocsParser
        # self.img_parser = ImgParser
        self.config = 'config.yaml'
        self.pdf_parser = PDFParser
        self.pptx_parser = PptxParser
        self.excel_parser = ExcelParser
        
        parser = argparse.ArgumentParser(description="Data Ingestion Flow")
        parser.add_argument(
         "--file_path", default="config.yaml", help="Path to the config.yaml file"
                )
        args = parser.parse_args()
        file_path = args.file_path
        with open(file_path, 'r') as file:
            config_data = yaml.safe_load(file)
            self.parser_data = config_data['parser']

    def excel_to_jsonstring1(self,**kwargs):
        text = []
        df = pd.read_excel(kwargs.get('file_path'),sheet_name=None, dtype=str)
        for sheet_name, sheet_data in df.items():
            sheet_data = sheet_data.astype(str)  # Convert all columns to strings
            sheet_json = sheet_data.to_dict(orient='records')
            sheet_text = [json.dumps(record) for record in sheet_json]
            text.extend(sheet_text)
        return text

    '''added below 2 methods for ECC'''
    def getfieldvalue(self, key, value):
        if (value != "NA" and value != 'nan'):
            if len(str(value))>0:
                return f"{key}\n{value}\n"
            else:
                return ''
        else:
            return ''

    def nonmalize(self, data):
        data=str(data)
        data=re.sub(r"[0-9]+.[0-9]+.[0-9].*?(?=Work notes)+Work notes\)", "",data)
        data=data.replace('""','')
        data=re.sub('\(+\?*\)','',data)
        data=re.sub('\n+','\n',data)
        data=data.replace("\\n","\n")
        return data.lower()

    def parse(self, file):
        try:
            # if not os.path.isdir(file.get("filepath")):
                # loop = asyncio.get_event_loop()
            parser = argparse.ArgumentParser(description="Data Ingestion Flow")
            parser.add_argument(
                "--file_path", default="config.yaml", help="Path to the config.yaml file"
                )
            args = parser.parse_args()
            file_path = args.file_path
            # with open(file_path, 'r') as file_data:
            #     config_data = yaml.safe_load(file_data)
            # result_text = []
            # parser_data = config_data['parser']
            # ADI_parser = parser_data.get('ADI_parser')
            # ADI_nas_path = parser_data.get('nas_path')
            # presentaition_shared_path=config_data['connector'].get('presentaition_shared_path')
            # task = ''
            # page_parser = False
            # if file.get('shared_file_path').endswith('.pdf'):
            #     if not ADI_parser:
            #         if parser_data.get('page_parser', False):
            #             page_parser = True
            #             task = self.pdf_parser.pdf_page_number(file_path=file.get("shared_file_path"))
            #         else:
            #             try:
            #                 task = self.pdf_parser.pdf_to_text(file_path=file.get("shared_file_path"))
            #             except Exception:
            #                 task = self.pdf_parser.pdf_process(file_path=file.get("shared_file_path"))
            #     else:
            #         json_path = os.path.join(presentaition_shared_path, os.path.basename(file.get('shared_file_path')).replace('.pdf', '.json'))
            #         if os.path.exists(json_path):
            #             with open(json_path, 'r') as json_file:
            #                 task = json_file.read()

            # elif file.get('shared_file_path').endswith('.json'):
            #     json_path = os.path.join(ADI_nas_path, os.path.basename(file.get('shared_file_path')).replace('.pdf', '.json'))
            #     if os.path.exists(json_path):
            #         with open(json_path, 'r') as json_file:
            #             task = json_file.read()

            # if file.get('shared_file_path').split('.')[-1] in ['pptx','ppt']:
            #     task = self.pptx_parser.pptx(file_path = file.get("shared_file_path"))

            # if file.get('shared_file_path').split('.')[-1] in ['docs','doc','docx']:
            #     task = self.docs_parser.doc_parser_type1(file_path = file.get("shared_file_path"))

            # if file.get('shared_file_path').split('.')[-1] in ['txt']:
            #     with open(file.get("shared_file_path"), 'r', encoding='utf-8') as text_file:
            #     # Read the contents of the file
            #         task = text_file.read()
            # if file.get('shared_file_path').split('.')[-1] in ['xlsx']:
            #     task = self.excel_parser.excel_to_jsonstring(file_path = file.get("shared_file_path"))

            # if file.get('shared_file_path').split('.')[-1] in ['csv']:
            #     task = self.excel_parser.csv_to_jsonstring(file_path=file.get("shared_file_path"))

            # if file.get('shared_file_path').split('.')[-1] in ['cs','xml','cpp','h','ectd','ecti']:
            #     # task = self.docs_parser.doc_parser_type2(file_path=file.get("file_path"))

            #     with open(file.get("file_path"), "r", encoding="utf-8") as xml_file:
            #         content = xml_file.read()
            #     replaced_content = content.replace("xlink:href", " xlinkhref")
            #     replaced_content = re.sub(r'&.*?;', '', replaced_content)
            #     xml_content = replaced_content.encode('utf-8')
            #     root = ET.fromstring(xml_content)
            #     task = ' '.join(root.xpath('//text()')).strip()
            #     page_parser  = True
            # if os.path.isfile('task.txt'):
            #     os.remove('task.txt')
            # if task != '' and (not parser_data.get('page_parser', False) or not file.get('shared_file_path').__contains__(".pdf")) and not file.get('file_extn') in ('cs','xml','cpp','h','ectd','ecti'):
            #     text_res =''
            #     if file.get('shared_file_path').split('.')[-1] in ['csv','xlsx']:
            #         with open('task.txt', 'a', encoding='utf-8') as file_temp:
            #             temp_task = []
            #             count=0
            #             for task_one in task:
            #                 count +=1
            #                 json_data = json.loads(task_one)
            #                 doc_data = ""
            #                 data = ""
            #                 metadata ={}
            #                 if(config_data["common"].get("appname",'NA') == "ECC"):
            #                     data= f'problem statement:\n{self.getfieldvalue("short_description",str(json_data.get("short_description","NA")))}\n{str(json_data.get("Description",""))}\nresolution:\n{self.getfieldvalue("Action_performed",self.nonmalize(str(json_data.get("Action_performed",""))))}\n{self.getfieldvalue("close_notes",str(json_data.get("close_notes","NA")))}\nIncident_Number: {json_data.get("Incident_Number","")}\nProduct_name: {json_data.get("Product_name","")}'
            #                     metadata["type"] = "Etch Command Center"
            #                     metadata["sourcelink"] = f'https://amat.service-now.com/text_search_exact_match.do?sysparm_search={str(json_data.get("Incident_Number"))}'
            #                 for key in json_data:
            #                     meta_content  = config_data['vector_db'].get("xlsx_fields", 'NA') if file.get('shared_file_path').endswith(".xlsx") else config_data['vector_db'].get("csv_fiels", 'NA')
            #                    # meta_content = config_data['vector_db'].get("csv_fiels", 'NA')
            #                     if str(key) in meta_content:
            #                         doc_data = doc_data + str(key) + ": " + str(json_data[key]) + "\n"
            #                         metadata[key] =  str(json_data[key])
            #                     elif meta_content == 'NA':
            #                         doc_data = doc_data + str(key) + ": " + str(json_data[key]) + "\n"
            #                     else:
            #                         metadata[key] =  str(json_data[key])
            #                 if data != '':
            #                     doc_data = data
            #                 doc_data.rstrip("\n")
            #                 file_temp.write(doc_data)
            #                     #print(json_data[key],"\n-------------------------\n")
            #                 doc =  Document(page_content=doc_data,metadata=metadata)
            #                 temp_task.append(doc)
            #             task = temp_task
            #         page_parser  = True
            #     elif ADI_parser:

            #         if "Abstracts" in file['shared_file_path']:
            #             with open('task.txt', 'w', encoding='utf-8') as file_temp:
            #                 file_temp.write(task)
            #         else:
            #             text_content = json.loads(task)
            #             with open('task.txt', 'w', encoding='utf-8') as file_temp:
            #                 file_temp.write(text_content["content"])
            #     else:
            #         with open('task.txt', 'w', encoding='utf-8') as file_temp:
            #             file_temp.write(task)
            #     # Find the size of the file
            #     file_size = os.path.getsize('task.txt')
            #     # Delete the file
            #     os.remove('task.txt')
            # elif parser_data.get('page_parser', False) and len(task) > 0:
            #     # Print task into a text file
            #         text_res =''
            #         with open('task.txt', 'a', encoding='utf-8') as file_temp:
            #             for task_one in task:
            #                 #text_res += text_res + ' ' +task_onpage_contente.page_content
            #                 file_temp.write(task_one.page_content)
            #             # Find the size of the file
            #         file_size = os.path.getsize('task.txt')
            #         # Delete the file
            #         os.remove('task.txt')
            # elif file.get('file_extn') in ('cs','xml','cpp','h','ectd','ecti') and len(task) > 0:
            #      # Print task into a text file
            #         text_res =''
            #         with open('task.txt', 'a', encoding='utf-8') as file_temp:
            #             for task_one in task:
            #                 #text_res += text_res + ' ' +task_onpage_contente.page_content
            #                 file_temp.write(task_one.page_content)
            #             # Find the size of the file
            #         file_size = os.path.getsize('task.txt')
            #         # Delete the file
            #         os.remove('task.txt')               
            # # if not page_parser:
            # #     file_size = len(task)
            # # else:
            # #     try:
            # #         file_size = sum(len(i) for i in task)
            # #     except Exception:
            # #         try:
            # #             file_size= len(task)
            # #         except Exception:
            # #             print('Exception')
            # if parser_data.get('page_parser', False) and not file.get('shared_file_path').__contains__(".csv") and file.get('shared_file_path').__contains__(".pdf"):
            #     # result_text = []
            #     for task_one in task:
            #         result_text.append(task_one.page_content)
            # # elif file.get('shared_file_path').__contains__(".csv") or file.get('shared_file_path').__contains__(".xlsx") or page_parser:
            # #     for task_one in task:
            # #         pass
            # #         # result_text.append(task_one.page_content)
            # else:
            #     result_text = task
            
            # 
            page_parser=True #ieee offline processing
            result_text=''
            result = {
                "data": result_text,
                "page_parser": page_parser,
                "file_url": file['json_path'],
                "file_name": file['file_name'],
                "raw_filesize": file['raw_filesize'],
                "shared_file_path": file['shared_file_path'],
                "file_path": file['file_path'],
                "tittle": file['title'],
                "authors": file['authors'],
                'doctype': file['doctype'],
                'year': file['year'],
                'affiliation': file['affiliation'],
                'file_size': file['file_size'],
                'file_crt_date': file['file_crt_date'],
                'file_mod_date':file['file_mod_date'],
                'file_acc_time': file['file_acc_time'],
                'job_id': file['job_id'],
                'last_updated': file['last_updated'],
                'projectid':file['projectid'],
                'file_id':file['file_id'],
                'json_path':file['json_path'],
                'is_last': file['is_last']

                # "title": file.get('metadata')['title']
            }
            # result_to_write = {
            #     "data": result_text,
            #     "page_parser": page_parser,
            #     "file_url": file['json_path'],
            #     "file_name": file['file_name'],
            #     "raw_filesize": file_size,
            #     "shared_file_path": file['shared_file_path'],
            #     # "title": file.get('metadata')['title']
            # }
            #'''addding parsing data to json file'''
            # try:
            #     shared_path = config_data['connector']['stats_path']
            #     file_name = file['file_name'].split(".")[0]+".json"
            #     complete_path = shared_path +"\\"+config_data['common']['appname']+ "\\"+str(file.get('job_id'))+'\\Parsing'
            #     if not os.path.isdir(complete_path):
            #         os.makedirs(complete_path)
            #     completeName = os.path.join(complete_path, file_name)
            #     with open(completeName, 'w', encoding='utf-8') as f:
            #         json.dump(result_to_write, f)
            # except Exception as e:
            #     raise Exception(e)
            print(f"Parsing Completed : {file['file_path']}")
            return result
        except Exception as err:
            print(err)
