from chunking_method.base import AbstractClass
from chunking_method.chunking import Chunking

class ChunkingRun():

    def run(self, raw_data):
        try:
            response = self.method_call(Chunking(), raw_data)
        except Exception as e:
            raise Exception(e)
        return response

    def method_call(self, abstract_class: AbstractClass, raw_data):
        try:
            response = abstract_class.template_method(raw_data)
        except Exception as e:
            raise Exception(e)
        return response