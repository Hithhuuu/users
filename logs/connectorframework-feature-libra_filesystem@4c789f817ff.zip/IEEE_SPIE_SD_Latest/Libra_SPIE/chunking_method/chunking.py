import yaml
import asyncio
from chunking_method.base import AbstractClass
from chunkingembedding.embedding_method.embedding import embedding
from chunking_method.custom_chunking.smart_chunking import smart_chunking
from chunking_method.custom_chunking.smart_chunking_et_v1 import smart_chunking_et_v1
# from chunking_method.custom_chunking.xml_chunking_et_journal import XMLParser as xml_chunking_et_journal
from chunking_method.custom_chunking.xml_ieee_smart_chunker import XMLParser as xml_ieee_smart_chunker
from chunking_method.custom_chunking.xml_chunking_science_direct import XMLParser as xml_chunking_science_direct
from chunking_method.custom_chunking.xml_chunking_spie import XMLParser as xml_chunking_spie
import argparse
import os
import json
from langchain.docstore.document import Document


class Chunking(AbstractClass):

    def __init__(self, config=None):
        #        self.config = config if config else 'config.yaml'
        parser = argparse.ArgumentParser(description="Data Ingestion Flow")
        parser.add_argument(
            "--file_path", default="config.yaml", help="Path to the config.yaml file"
        )
        args = parser.parse_args()
        self.config = args.file_path

    def method_first(self, raw_data):
        try:
            with open(self.config, 'r') as file:
                config_data = yaml.safe_load(file)
            chunk_fun = config_data['chunks']['type']
            page_parser = raw_data['page_parser']
            config_data['chunks']['page_parser'] = page_parser
            data = raw_data['data']

            embeddings = embedding(config_data=config_data['embeddings'])

            

            if config_data['chunks']['type'] == 'smart_chunking_et_v1':
                with open(raw_data['file_url'], 'r') as read_file:
                    data = json.load(read_file)
                # title=
                obj = smart_chunking_et_v1(data, config_data, raw_data['shared_file_path'], raw_data['file_name'],
                                           raw_data['title'])
                chunked_docs_text = obj.getchunks()
                try:
                    pages = str(max([doc.metadata.get('page') for doc in chunked_docs_text]))
                except Exception:
                    pages = 0
                result = {
                    "pages": pages,
                    "chunked_docs": chunked_docs_text,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }

            elif config_data['chunks']['type'] == 'xml_ieee_smart_chunker':

                obj = xml_ieee_smart_chunker(data, config_data, raw_data['shared_file_path'], raw_data['file_name'],
                                             raw_data['file_path'], config_data['chunks']['doctype'])
                chunked_docs_text = obj.parse()
                try:
                    pages = str(max([doc.metadata.get('page') for doc in chunked_docs_text]))
                except Exception:
                    pages = 0
                result = {
                    "pages": pages,
                    "chunked_docs": chunked_docs_text,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }

            elif config_data['chunks']['type'] == 'xml_chunking_et_conference':
                obj = xml_ieee_smart_chunker()
                chunked_docs_text = obj.parse(data)
                try:
                    pages = str(max([doc.metadata.get('page') for doc in chunked_docs_text]))
                except Exception:
                    pages = 0
                result = {
                    "pages": pages,
                    "chunked_docs": chunked_docs_text,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }
            elif config_data['chunks']['type'] == 'xml_chunking_science_direct':
                obj = xml_chunking_science_direct(data, config_data, raw_data['shared_file_path'], raw_data['file_name'],
                                             raw_data['file_path'], config_data['chunks']['doctype'])
                chunked_docs_text = obj.parse()
                # create_chunks_indexing = raw_data['file_path']
                try:
                    pages = str(max([doc["metadata"].get('page') for doc in chunked_docs_text]))
                    # pages = str(max([doc.metadata.get('page') for doc in chunked_docs_text]))
                except Exception:
                    pages = 0
                result = {
                    "pages": pages,
                    "chunked_docs": chunked_docs_text,
                    "embeddings": embeddings,
                    # 'chunking': create_chunks_indexing,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }
            elif config_data['chunks']['type'] == 'xml_chunking_spie':
                obj = xml_chunking_spie(data, config_data, raw_data['shared_file_path'], raw_data['file_name'],
                                             raw_data['file_path'], config_data['chunks']['doctype'])
                chunked_docs_text = obj.parse()
                try:
                    pages = str(max([doc["metadata"].get('page') for doc in chunked_docs_text]))
                except Exception:
                    pages = 0
                result = {
                    "pages": pages,
                    "chunked_docs": chunked_docs_text,
                    "embeddings": embeddings,
                    # 'chunking': create_chunks_indexing,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }
            else:
                obj = smart_chunking(data, config_data)
                func_call = obj.getchunks()
                chunked_docs_text = []
                for i, _ in enumerate(func_call):
                    #chunked_docs_text.append(Document(page_content=func_call[i][0]))
                    pages = ', '.join(map(str, func_call[i][1])) if isinstance(func_call[i][1], list) else func_call[i][
                        1]
                    chunked_docs_text.append(Document(page_content=func_call[i][0],
                                                      metadata={"page": pages, "chunk_header_info": func_call[i][2],
                                                                "chunk_id": i}))
                print("chunked_result",chunked_docs_text)

                result = {
                    "chunked_docs": chunked_docs_text,
                    "pages": pages,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }
            try:
                pass
            #     '''addding chunking data to json file'''
            #     data_chunks = {}
            #     pos = 0

            #     if config_data['parser'].get('ADI_parser', False):
            #         for i in result['chunked_docs']:
            #             data_chunks[pos] = i.page_content
            #             pos += 1
            #     else:
            #         for i in result['chunked_docs']:
            #             data_chunks[pos] = i.page_content
            #             pos += 1
            #             # print("res",result['chunked_docs'])
            #     result_print = {
            #         "chunked_docs": data_chunks,
            #         "meta_data": {
            #             "filename": raw_data['file_name'],
            #             "filepath": raw_data['file_url'],
            #             "chunk_type": chunk_fun,
            #             "chunk_size": config_data['chunks']['chunksize']
            #         }
            #     }
            #     print(result_print)
                # shared_path = config_data['connector']['stats_path']
                # file_name =raw_data['file_name'].split(".")[0]+".json"
                # complete_path = shared_path +"\\"+config_data['common']['appname']+ "\\"+str(raw_data.get('job_id'))+'\\Chunking'
                # if not os.path.isdir(complete_path):
                #     os.makedirs(complete_path)
                # completeName = os.path.join(complete_path, file_name)
                # with open(completeName, 'w') as f:
                #     json.dump(result_print, f)
            except Exception as e:
                raise Exception(e)
        except Exception as e:
            raise Exception(e)
        return result
