import re
import xml.etree.ElementTree as ET
from langchain.text_splitter import RecursiveCharacterTextSplitter
import json
import os
import json
import os
# from fuzzywuzzy import fuzz
# from azure.core.credentials import AzureKeyCredential
# from azure.identity import DefaultAzureCredential
# from azure.core.credentials import AzureKeyCredential
# from azure.ai.formrecognizer import FormRecognizerClient, FormTrainingClient, DocumentAnalysisClient
# import pandas as pd
# from collections import defaultdict
from tqdm import tqdm
import openai
import re
from docx2python import docx2python
import json
from dotenv import load_dotenv
from tenacity import retry, wait_random_exponential, stop_after_attempt 
# from new_azure_index_creation import Custom_azure_search_client
import langchain

from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.docstore.document import Document


import json
import argparse
import uuid
import os
from dotenv import load_dotenv
# from new_azure_index_creation import Custom_azure_search_client
from tenacity import retry, wait_random_exponential, stop_after_attempt 
import pandas
import json
import langchain


# Load the .env file
load_dotenv()

class XMLParser:
    def __init__(self, data, config_data,shared_file_path,file_name,file_path):
        # xml_file_path = r"C:\Users\e183066\OneDrive - Applied Materials\Desktop\ieee\10000065_ft.xml"
        # print("file path",xml_file_path)
        self.xml_file_path = file_path
        self.config = config_data
        self.engine = self.config['chunks']['engine']
        self.article_title = None
        self.pattern = r'\s+'
        self.max_chunk_size = 2000
        self.chunk_overlap = 50
        self.chunk_sequence = 0
        self.chunks = []
        self.char_text_splitter = RecursiveCharacterTextSplitter(chunk_size=self.max_chunk_size, chunk_overlap=self.chunk_overlap)
        self.tag_callbacks={'sec':self.parse_section,'p':self.parse_paragraph,'title':self.parse_title,'table-wrap':self.parse_table,'fig':self.parse_fig,'xref':self.parse_xref,'label':self.parse_label,'default':self.parse_default,'inline-formula':self.parse_formula}
        
    def parse(self, xmlstring):  

        if not self._is_valid_file(): #check if the file is full text or metadata
            return None      
        root = ET.fromstring(self._read_xml_file())   
        self.parse_abstract(root)
        self.parse_body(root)
        return langchain_document(self.chunks)
    
    def langchain_document(content_dict):
        all_docs = []
        for item in content_dict:
            output_list = []
            all_sen = []
            value = item  # Remove eval() function
            for k, v in value.items():
                if k == "metadata":
                    continue
                all_sen.append(f"{k.upper()}\n\n{v}\n")
            heading_paragraph = "\n".join(all_sen)
            metadata = value['metadata']
            output_list.append((heading_paragraph, metadata))  # Fix: Pass a tuple as a single argument
            tmp_doc = langchain.docstore.document.Document(page_content=heading_paragraph, metadata=metadata)
            all_docs.append(tmp_doc)
        return all_docs

    def seperate_tables_text(self,text):
        pattern =r"\*\*table\*\*([\s\S]*?)\*\*table_\*\*"
        result = re.split(pattern, text) #entire paragraph is split into text and tables
        # print("table result#################################",result)
        text_without_tables = ''.join(result[::2])
        table_pair=[]
        for j,text in enumerate(result):
            if j%2==1 or j+1>=len(result):
                continue
            table_pair.append((text,result[j+1]))
        return text_without_tables,table_pair
    
    def get_completion_summary(self,para_text): 
        engine=self.engine
        prompt = f"""
        As a knowledgeable assistant, you are given content from a subsection of the IEEE document article.
        Your task is to condense the following paragraph within 200 characters, ensuring that key details are captured and semantic meaning is preserved.
        Do not include any information that is not present within internal data provided.


        Internal Data: 
        ```{para_text}```
        """
        messages = [{"role": "user", "content": prompt}]
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=messages,
            temperature=0, # this is the degree of randomness of the model's output,
            max_tokens = 150,
            top_p = 1.0,
            frequency_penalty = 0.0,
            presence_penalty = 0.0
        )
        return response.choices[0].message["content"]


    def convert_xml_table_to_markdown(self,xml_string):
        # Parse the XML
        root = ET.fromstring(xml_string)
        label = root.find('label').text
        caption=''
        for element in root:
            # print("#######################################",element.tag)
            try:
                if element.tag=='caption':
                    caption+=element.find('title').text if element.find('title').text is not None else ''
                    break 
                elif element.tag=='title':
                    caption+=element.text
                    break
            except:
                caption=''

        # print("Label: ", label)
        # print("Caption: ", caption)
        table_heading = label + " - " + caption
        # Extract table data
        headers = []
        rows = []
        for row_elem in root.findall('.//tr'):
            row_data = []
            for cell_elem in row_elem.findall('.//th'):
                cell_text = cell_elem.text.strip() if cell_elem.text else ''
                row_data.append(cell_text)
                headers = row_data
                is_header=True
            for cell_elem in row_elem.findall('.//td'):
                cell_text = cell_elem.text.strip() if cell_elem.text else ''
                row_data.append(cell_text)
                is_header=False
            if not is_header:
                rows.append(row_data)

        # Construct Markdown table
        # print("########################",table_heading)
        return table_heading, headers,rows
    
        
    def parse_default(self,element):
        #print(element.tag)
        text=element.text.strip() if element.text is not None else ""
        tail=element.tail.strip() if element.tail is not None else ""
        return text+tail

    def parse_abstract(self,root):
        self.article_title = root.find(".//article-title").text
        self.abstract_element = root.find('.//abstract') 
        self.abstract_text = ET.tostring(self.abstract_element, method='text', encoding='unicode').strip() #get abstract paragraph
        # print(self.abstract_text)
        if self.abstract_text: #if articles text is not empty
            self.abstract_text = re.sub(self.pattern, ' ', self.abstract_text) # replace one or more whitespace characters
            achunks = self.get_chunks(self.abstract_text) #split 
            chunk_len=1
            for _chunk in achunks:
                section_heading="Abstract"+"-"+str(chunk_len) if len(achunks)>1 else "Abstract"
                chunk_len+=1
                self.chunks.append({"Title":self.article_title, "Section_Heading": section_heading,"ParagraphText":_chunk , 
                                     "metadata" : {"page":self.chunk_sequence,"role": "paragraph", "doc_type": "journals"}})
                # self.chunks.append([self.chunk_sequence,'Abstract > '+ _chunk, self.article_title +' > '+'Abstract '])
                self.chunk_sequence += 1
    

    def parse_body(self,root):     #body is where the sections of the document starts sec1, sec2 etc
        body = root.find('body')
        sections={}
        for element in body:
            # print("#######################################",element.tag)
            if element.tag!='sec':
                print("not section")
                continue     
            section_title = element.find('title')
            if section_title is not None:
                sec_title_value = section_title.text.strip() #section heading
            else:
                sec_title_value = ''
            # print("sec title",sec_title_value)   
            sections[sec_title_value] =[]             
            for sec in element:
                if sec.tag not in self.tag_callbacks:
                    tag_return=self.tag_callbacks['default'](sec)
                else:
                    tag_return=self.tag_callbacks[sec.tag](sec)
                if tag_return!="":
                    sections[sec_title_value].append((tag_return,sec.tag))
        if len(sections) != 0:
            #table chunks ("Title",("paragraph",table_xml))
            text_chunks,table_chunks=self.extract_subsections(sections)
            # print("SEction body text_chunks",text_chunks)
            # print("SEction body table_chunks",table_chunks)
        else:
            text_chunks, table_chunks = self.no_section_body(body)
            # print("no SEction body text_chunks",text_chunks)
            # print("no SEction body table_chunks",table_chunks)
        #     text_chunks,table_chunks=#write the function for extracting the body without any sections
        
        for chunks in text_chunks:
            result=self.char_text_splitter.split_text(chunks[1])
            chunk_len=1
            for r in result:
                if len(r)<200:
                    continue
                self.chunk_sequence+=1
                section_heading=chunks[0]+"-"+str(chunk_len) if len(result)>1 else chunks[0]
                self.chunks.append({"Title":self.article_title, "Section_Heading": section_heading,"ParagraphText":r , 
                                     "metadata" : {"page":self.chunk_sequence,"role": "paragraph", "doc_type": "conference"}})
                chunk_len+=1
        print("tables",len(table_chunks))
        
        previous_section_heading = None
        previous_para_text = None
        for i in table_chunks: 
            section_heading = i[0]
            # print(section_heading)
            para_text = i[1][0]
            table = i[1][1]
            if para_text.strip() == '':
                if previous_section_heading == section_heading and previous_para_text is not None:
                    para_text = previous_para_text
            else:
                previous_section_heading = section_heading
                previous_para_text = para_text
            table_intro = self.get_completion_summary(para_text)
            table_heading,headers,rows = self.convert_xml_table_to_markdown(table)
            table_intro += "\n"+'| ' + ' | '.join(headers) + ' |\n'
            table_intro += '| ' + ' | '.join(['---'] * len(headers)) 
            final_section_heading = section_heading + "-" + table_heading
            table_chunk=table_intro+' |\n' 
            no_rows=0
            table_results=[]

            for row in rows:
                markdown_row= '| ' + ' | '.join(row) + ' |\n'
                if len(table_chunk)+len(markdown_row)<2000:
                    table_chunk+=markdown_row
                    no_rows+=1
                elif no_rows>=1:
                    table_results.append(table_chunk)
                    table_chunk=table_intro+' |\n' +markdown_row
                    no_rows=1

            if no_rows>=1:
                table_results.append(table_chunk)
                
            chunk_len=1
            for r in table_results:
                if len(r)<200:
                    continue
                self.chunk_sequence+=1
                section_heading=final_section_heading+str(chunk_len) if len(table_results)>1 else final_section_heading                   
                self.chunks.append({"Title":self.article_title, "Section_Heading": final_section_heading,"ParagraphText":r ,
                                    "metadata" : {"page":self.chunk_sequence,"role": "table", "doc_type": "conference"}})
                chunk_len+=1
        # print(self.chunks)
        return self.chunks

    def no_section_body(self,body):
        sections={}
        sections["Body"] =[] 
        for element in body:
            # print("###### no section ########",element,"\n")
            if element.tag not in self.tag_callbacks:
                tag_return=self.tag_callbacks['default'](element)
                if tag_return!="":
                    sections["Body"].append((tag_return,element.tag))
            else:
                tag_return=self.tag_callbacks[element.tag](element)
                if tag_return!="":
                    sections["Body"].append((tag_return,element.tag))
            
        # print("no section body sections",sections["Body"])
        
        if sections["Body"]:
            text_chunks=[]
            table_chunks=[]
            chunks=[]
            prev_text=''
            for i in sections['Body']:
                prev_text+=i[0].strip()
            if prev_text!='':
                chunks.append(('Body',prev_text))
            # print("no section body chunks",chunks)
            
            for i in chunks:
                text,tables=self.seperate_tables_text(i[1])
                text_chunks.append((i[0],text))
                if len(tables)>0:
                    for table in tables:
                        table_chunks.append((i[0],table))
        # print("no section body text_chunks",text_chunks)
        # print("no section body table_chunks",table_chunks)


        return text_chunks,table_chunks
    #     


    def extract_subsections(self,sections):

        text_chunks=[]
        table_chunks=[]
        for sec in sections:
            # print("######new section########",sec,"\n") #introduction
            chunks=[]
            prev_text=''
            for i in sections[sec]: #each line in the introduction , tag (p)
                if i[1].strip()=='sec': 
                    if prev_text!='':
                        chunks.append((sec,prev_text))
                    chunks.append((sec+"-"+i[0].split("\n")[0],''.join(i[0].split("\n")[1:])))
                    prev_text=''
                else:
                    prev_text+=i[0].strip()
            if prev_text!='':
                chunks.append((sec,prev_text))
            # print("chunks.append((sec,prev_text))",chunks) #entire section [("Introduction","text")]
            for i in chunks: # i = ["Introduction","text"]
                # print("tanble.........#",i[1])
                text,tables=self.seperate_tables_text(i[1]) #removing tables
                # print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$",tables)
                text_chunks.append((i[0],text))
                if len(tables)>0: #["Introduction","text"]
                    for table in tables:
                        table_chunks.append((i[0],table))
                # if table_chunks == []:
                #     table_chunks = ""
        # print("section text_chunks",text_chunks)
        # print("section table_chunks",table_chunks)
        return text_chunks,table_chunks

    def parse_section(self,element):
        section_title = element.find('title')
        if section_title is not None:
            sec_text = section_title.text.strip() #section heading
        else:
            sec_text = ''            
        for sec in element:
            if sec.tag not in self.tag_callbacks:
                callback_text=self.tag_callbacks['default'](sec)
                sec_text=sec_text+"\n"+callback_text if callback_text !="" else sec_text
            else:
                callback_text=self.tag_callbacks[sec.tag](sec)
                sec_text=sec_text+"\n"+callback_text if callback_text !="" else sec_text
        return sec_text     

    def parse_paragraph(self,element):
        para_text=element.text.strip() if element.text is not None else ''
        for tag in element:
            para_text+=" "+self.tag_callbacks[tag.tag](tag) if tag.tag in self.tag_callbacks else " "+self.tag_callbacks['default'](tag)
        return para_text

    def parse_fig(self,element):
        return ""

    def parse_table(self,element):
        return "**table**"+ET.tostring(element, encoding='unicode').strip()+"**table_**"
        # return "***************************Here you should include table"

    def parse_label(self,element):
        return ""

    def parse_title(self,element):
        return ""

    def parse_xref(self,element):
        text=element.text if element.text is not None else ''
        tail=element.tail if element.tail is not None else ''
        return text+tail

    def parse_formula(self,element):
        tail=element.tail if element.tail is not None else ''
        return tail

    def _read_xml_file(self):
        with open(self.xml_file_path, "r", encoding="utf-8") as file:
            content = file.read()
        replaced_content = content.replace("xlink:href", " xlinkhref")
        replaced_content = re.sub(r'&.*?;', ' ', content)
        self.xml_content = replaced_content.encode('utf-8')
        return self.xml_content
    
    # def replace_xlink_href(file_path):
    #     with open(file_path, "r", encoding="utf-8") as file:
    #         content = file.read()
    #     replaced_content = content.replace("xlink:href", " xlinkhref")
    #     with open(file_path, "w", encoding="utf-8") as file:
    #         file.write(replaced_content)
    
    def get_chunks(self,content):
        content = re.sub(self.pattern, ' ', content) #replace with single whitespace
        return self.char_text_splitter.split_text(content)
    
    def _is_valid_file(self):
                filename = os.path.basename(self.xml_file_path)
                return '_ft' in filename

# xml_file_path = r"C:\Users\e183066\OneDrive - Applied Materials\Desktop\ieee\ieee_sample\10000065_ft.xml"
# parser=XMLParser(xml_file_path)
# chunks = parser.parse()

# # print(chunks)

# # # Save content to JSON
# # with open(xml_file_path + '_content.json', 'w') as f:
# #     json.dump(content, f)

# # Save chunks to JSON
# with open(xml_file_path + '22chunks.json', 'w') as f:
#     json.dump(chunks, f)
    
def langchain_document(content_dict):
    all_docs = []
    for item in content_dict:
        output_list = []
        all_sen = []
        value = item  # Remove eval() function
        for k, v in value.items():
            if k == "metadata":
                continue
            all_sen.append(f"{k.upper()}\n\n{v}\n")
        heading_paragraph = "\n".join(all_sen)
        metadata = value['metadata']
        output_list.append((heading_paragraph, metadata))  # Fix: Pass a tuple as a single argument
        tmp_doc = langchain.docstore.document.Document(page_content=heading_paragraph, metadata=metadata)
        all_docs.append(tmp_doc)
    return all_docs

@retry(wait=wait_random_exponential(min=1, max=20), stop=stop_after_attempt(6))
# Function to generate embeddings for title and content fields, also used for query embeddings
# def generate_embeddings(text):
#     dimensions = embedding_size
#     response = openai.Embedding.create(dimensions=dimensions,
#         input=text, engine=embedding_engine)
#     embeddings = response['data'][0]['embedding']
#     # embeddings = HF_EMBEDDINGS.embed_query(text)
#     return embeddings

# def create_azure_index_doc(lang_docs):
#     # print("Creating Azure index document")
#     # print("LANG DOCS", len(lang_docs))
#     final_docs = []
#     for item in lang_docs:
#         tmp_dict = {}
#         content = item.page_content
#         content_embeddings = generate_embeddings(content)
        
#         tmp_dict['id'] = str(uuid.uuid4())
#         tmp_dict['content_vector'] = content_embeddings
#         tmp_dict['content'] = content
#         tmp_dict['metadata'] = json.dumps(item.metadata)
#         # print("Temp",tmp_dict)
#         for key,value in item.metadata.items():
#             if key=="year":
#                 tmp_dict[key]=int(value)
#             else:
#                 tmp_dict[key]=str(value).lower()
#         # # print(tmp_dict)
#         final_docs.append(tmp_dict)
#     return final_docs



def create_chunks_indexing(data_folder):
    # if not os.path.exists(result_folder):
    #     os.mkdir(result_folder)
    files = os.listdir(data_folder)
    error_docs=[]
    # Iterate over the files
    for file in tqdm(files):
        try:
            if (file.endswith('.xml')):
                file_path = os.path.join(data_folder, file)
                parser=XMLParser(file_path)
                indexes = parser.parse()
                print("indexes created")     
                if len(indexes)==0:
                    continue  
            
            # Rres = create_azure_index_doc(langchain_document(indexes))  
            # azure_cls.add_to_vector_store(Rres) #to add to vector store 
            print("addded to vector store", file)
        except Exception as e:
            print(f"error in document {file}. Error : {e}")
            error_docs.append(file)
    print(f"Chunk creation finished. Total Errored documents : {len(error_docs)}")
    print("Errored files :")
    
    for docs in error_docs:
        print(f"errored :",docs)