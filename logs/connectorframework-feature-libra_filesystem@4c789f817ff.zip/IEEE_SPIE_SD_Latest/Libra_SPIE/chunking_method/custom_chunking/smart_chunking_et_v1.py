import json
import openai
import re
from docx2python import docx2python

import langchain

from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.docstore.document import Document



CONSTANT_SEGREGATOR = ' > '

stopwords_file = r'stopwords.txt'

class smart_chunking_et_v1:

    def __init__(self, data, config_data,shared_file_path,file_name,title):

        self.config = config_data
        self.shared_path = self.config.get("shared_path")
        self.engine = self.config['chunks']['engine']
        self.data = data
        self.shared_file_path = shared_file_path
        self.file_name=file_name
        self.title=title

    def getchunks(self):
        chunk_paragraph=[]
        file_path=self.shared_file_path
        title= self.title
        ext=file_path.split('.')[-1]
        if ext=="pdf":        
            indexes=self.chunk_pdf_file(file_path,title)
        elif ext=="docx":
            indexes=self.chunk_docx_file(file_path,title)
        all_docs = self.langchain_document(indexes)   
        if(len(all_docs)>0):
           chunk_paragraph.extend(all_docs)
        return chunk_paragraph


    def langchain_document(self,content_dict):
        all_docs = []
        for i in content_dict: # iterate over dictionary keys
            output_list = []
            # print(content_dict[i])
            # heading_paragraph = content_dict[i]['Heading'] + '\n' + content_dict[i]['Paragraph']
            all_sen=[]
            for k, v in content_dict[i].items():
                if k=="metadata":
                    continue
                all_sen.append(f"{k.upper()}\n\n{v}\n")
            heading_paragraph = "\n".join(all_sen)    
            metadata = content_dict[i]['metadata']
            output_list.append((heading_paragraph, metadata))  # Fix: Pass a tuple as a single argument
            tmp_doc = langchain.docstore.document.Document(page_content=heading_paragraph, metadata=metadata)
            all_docs.append(tmp_doc)
        return all_docs

    def chunk_docx_file(self,docx_file,title):
        try:
            indexes= self.extract_docx_info(docx_file,title)
        except Exception as e:
            print(e)
            print("Error in chunking stratergy. going for fixed length chunking")
            indexes= self.fixed_chunks(docx_file,title)
        return indexes  

    def extract_docx_info(self,docx_file,title):
        try:
            doc = docx2python(docx_file)
            body= self.extract_text(doc.body)
            # print("headers are",headers)
            # print("footers are",footers)
            # print("body are",body)
            header_next=True

            meta_headings=[]
            meta_contents=[]
            headings=[]
            contents=[]
            pattern = r'[^a-zA-Z0-9\s]'
            meta_finished=False
            for text in body:

                if self.check_if_valid_heading(text) and len(meta_headings)>1 and not meta_finished:
                    meta_finished=True
                    header_next=True
                if header_next and len(text)<250:        
                    if not meta_finished:
                        heading = re.sub(pattern, '',text).lower()
                        meta_headings.append(heading)
                        header_next=False
                    else:
                        if self.check_if_valid_heading(text):
                            heading = re.sub(pattern, '',text).lower()
                            headings.append(heading)
                            header_next=False      
                        else:
                            contents[-1]=contents[-1]+text
                elif header_next and len(text)>250:
                    splitted_text=text.split(':')
                    if len(splitted_text)>0 and len(splitted_text[0])<250 and self.check_if_valid_heading(splitted_text[0]):
                        headings.append(re.sub(pattern, '',splitted_text[0]).lower())
                        contents.append(''.join(splitted_text[1:]))
                    else:
                        contents[-1]=contents[-1]+text
                elif not header_next:
                    if not meta_finished:
                        meta_contents.append(text)
                    else:
                        contents.append(text)
                    header_next=True  
            indexes={}    

            # for i,heading in enumerate(meta_headings):
            #     # print(heading)
            #     if i==len(meta_contents):
            #         break
            #     metadata[heading]=meta_contents[i]
            # metadata["doc_type"]="Abstract"
            # title=metadata["title"]

            response = self.abstract_summary(body)

            content_count=0
            for i,heading in enumerate(headings):
                # print(heading)
                if i==len(contents):
                    break
                if self.check_if_valid_heading(heading) and len(indexes)<=3:
                    if(content_count==0):
                        index={"Title":title,"Section_Heading":heading,"ParagraphText":contents[i],"metadata":{}}
                        index["metadata"]["page"]=0
                        index["metadata"]["role"]="paragraph"
                        index["metadata"]["ParagraphText"]=response
                        index["metadata"]["doctype"]="Abstract"
                        index["Section_Heading"]= "Summary" 
                        index["Title"]=title
                        indexes[content_count]=index

                    content_count+=1
                    # index={"Title":title,"Section_Heading":heading,"ParagraphText":contents[i],"metadata":{}}
                    index={"Title":title,"Section_Heading":heading,"ParagraphText":contents[i],"metadata":{}}
                    # for key,value in metadata.items():
                    #     index["metadata"][key]=value
                    index["metadata"]["page"]=1
                    index["metadata"]["role"]="paragraph"
                    index["metadata"]["doctype"]="Abstract"
                    indexes[content_count]=index
                    
            # indexes[0]["Section_Heading"]= "Summary" 
            # indexes[0]["ParagraphText"]=response
            # indexes[0]["metadata"]["page"] = 0
            # indexes[0]["metadata"]["role"] = "paragraph"
            
            # indexes["abs_summary"]={}
            # indexes["abs_summary"]["Title"]=title
            # indexes["abs_summary"]["Section_Heading"]= "Summary" 
            # indexes["abs_summary"]["ParagraphText"]=response
            # indexes["abs_summary"]["metadata"]["page"] = 0
            # indexes["abs_summary"]["metadata"]["role"] = "paragraph"

            # print("file :",docx_file)
            # if len(metadata.keys())!=4 or len(indexes.keys())<3:
            #     print("########################check it###########################")
            # # print(indexes)

            # for i in indexes:
            #     print(indexes[i]["Heading"])
            # print(metadata.keys(),"\n")      
            return indexes
        except Exception as e:
            print(e)
            

    def check_if_valid_heading(self,text):
        return any(substring in text.lower() for substring in ['purpose','evaluation','description'])

    def fixed_chunks(self,docx_file,title):
    
        doc = docx2python(docx_file)
        body=self.extract_text(doc.body)
        chunk=''
        chunk_count=0
        indexes={}
        # metadata["doc_type"]="Abstract"
        # title=metadata["title"]
        response = self.abstract_summary(body)
        index={"Title":title,"Section_Heading":'',"ParagraphText":'',"metadata":{}}
        index["metadata"]["page"]=0
        index["metadata"]["role"]="paragraph"
        index["metadata"]["ParagraphText"]=response
        index["metadata"]["doctype"]="Abstract"
        index["Section_Heading"]= "Summary" 
        index["Title"]=title
        indexes[0]=index
        for text in body:
            if len(chunk)+len(text)>2000:
                chunk_count+=1
                # index={"Title":title,"Section_Heading":f"Section {chunk_count}","ParagraphText":chunk,"metadata":{}}
                index={"Title":title,"Section_Heading":f"Section {chunk_count}","ParagraphText":chunk,"metadata":{}}
                # for key,value in metadata.items():
                #     index["metadata"][key]=value
                index["metadata"]["page"]=1  
                index["metadata"]["role"]="paragraph"
                index["metadata"]["doctype"]="Abstract"

                indexes[chunk_count]=index          
                chunk=''
            else:
                chunk+=text
        if len(chunk)>200:
            chunk_count+=1
            # index={"Title":title,"Section_Heading":f"Section {chunk_count}","ParagraphText":chunk,"metadata":{}}
            index={"Title":title,"Section_Heading":f"Section {chunk_count}","ParagraphText":chunk,"metadata":{}}
            # for key,value in metadata.items():
            #     index["metadata"][key]=value
            index["metadata"]["page"]=1  
            index["metadata"]["role"]="paragraph"
            index["metadata"]["doctype"]="Abstract"
            indexes[chunk_count]=index           
        return indexes


    def extract_text(self,text):
        text_list = []
        if isinstance(text, list):
            for item in text:
                text_extracted=self.extract_text(item)
                text_list.extend(text_extracted)
        else:
            if text.strip()!='':
                text_list.append(text)
        return text_list

    def chunk_pdf_file(self,pdf_file_path,title):
        metadata={}
        # pdf_file_path=file_groups["824"]["pdf"]
        json_filepath= re.sub(r'\.pdf$', '.json', pdf_file_path)
        with open(json_filepath, "rb") as file:
            file_contents = file.read()
        # title=self.shared_file_path
        result = json.loads(file_contents)
        pdf_dict=self.extract_paragraphs(result,title)
        return pdf_dict
    
    def extract_paragraphs(self,result,title): 
        table_regions=self.get_table_regions(result)
        pdf_content={}
        section_count={}
        prev_pgno=0
        # metadata["doc_type"]="Slides"
        # title=metadata["title"]
        for para in result.get("paragraphs"):
            # print(para)
            pg_no=para.get("bounding_regions")[0].get("page_number")
            if pg_no!=prev_pgno:
                prev_bbox=None
            prev_pgno=pg_no
            if pg_no==1:
                continue
            # if pg_no!=9:
            #     continue    
            polygon=para.get("bounding_regions")[0].get("polygon")
            content=para.get("content")
            # print(para)
            try:
                role=para.get("role")
            except:
                role=None         
            para_val,bb_box=self.validate_paragraph(content,polygon,role,prev_bbox)   
            # print(para_val,content)
            if not para_val:
                continue 
            # print("prev_box",prev_bbox)
            is_table=self.check_if_table(pg_no,bb_box,table_regions) 

            if is_table:
                # print("#####################table content")
                continue  

            
            if pg_no not in pdf_content:
                pdf_content[pg_no]={"Title":title,"Section_Heading":content}
                pdf_content[pg_no]["ParagraphText"]=""

            else:
                # pdf_content[pg_no]["content"]=f'{pdf_content[pg_no]["content"]}text : {re.sub(r"^[^a-zA-Z0-9]+", "", content)}, ###bouding box: {bb_box}\n'
                prev_bbox=bb_box
                pdf_content[pg_no]["ParagraphText"]=pdf_content[pg_no]["ParagraphText"]+content+"\n"
        # print(pdf_content)

        doc_dict={}        
        for page in pdf_content:

            slide_content=f'{pdf_content[page]["Section_Heading"]} \n {pdf_content[page]["ParagraphText"]}'
            if len(slide_content)<200:
                continue
            gpt_summary=self.get_completion_slides(slide_content.strip())
            # print(gpt_summary)
            doc_dict[f"slide_{page}"]={}
            doc_dict[f"slide_{page}"]["Title"]=title
            doc_dict[f"slide_{page}"]["Section_Heading"]=pdf_content[page]["Section_Heading"]
            doc_dict[f"slide_{page}"]["ParagraphText"]=gpt_summary
            doc_dict[f"slide_{page}"]["metadata"]={}
            # for key,value in metadata.items():
            #     doc_dict[f"slide_{page}"]["metadata"][key]=value
            doc_dict[f"slide_{page}"]["metadata"]["page"]=page
            doc_dict[f"slide_{page}"]["metadata"]["role"]="paragraph"
            doc_dict[f"slide_{page}"]["metadata"]["doctype"]="Slides" 


        slide_content_list = "\n".join([doc_dict[i]["ParagraphText"] for i in doc_dict])
        response = self.get_completion_summary(slide_content_list)

        doc_dict["slide_0"]={}
        doc_dict[f"slide_0"]["Title"]=title
        doc_dict["slide_0"]["Section_Heading"]="Summary"
        doc_dict["slide_0"]["ParagraphText"]=response
        doc_dict["slide_0"]["metadata"]={}
        # for key,value in metadata.items():
        #     doc_dict["slide_1"]["metadata"][key]=value
        doc_dict["slide_0"]["metadata"]["page"]=0 
        doc_dict[f"slide_0"]["metadata"]["role"]="paragraph" 
        doc_dict[f"slide_0"]["metadata"]["doctype"]="Slides" 
        

        return doc_dict

    #summarization function
    def get_completion_slides(self,slide_content): 
        engine=self.engine
        prompt = f"""
        As a knowledgeable assistant, you are provided with internal data of applied materials captured in a slide deck.
        Your task is to condense the following list of items within 1000 characters, ensuring that key details are captured and semantic meaning is preserved.
        Do not include any information that is not present within internal data provided.
    
    
        Internal Data: 
        ```{slide_content}```
        """
    
        messages = [{"role": "user", "content": prompt}]
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=messages,
            temperature=0, # this is the degree of randomness of the model's output,
            max_tokens = 250,
            top_p = 1.0,
            frequency_penalty = 0.0,
            presence_penalty = 0.0
        )
        return response.choices[0].message["content"]


    def get_completion_summary(self,slide_content_all): 
        engine=self.engine
        prompt = f"""
        As a knowledgeable assistant, you are given list of content from entire slide deck.
        Your task is to condense the following list of items within 2000 characters, ensuring that key details are captured and semantic meaning is preserved.
        Do not include any information that is not present within internal data provided.


        Internal Data: 
        ```{slide_content_all}```
        """
        messages = [{"role": "user", "content": prompt}]
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=messages,
            temperature=0, # this is the degree of randomness of the model's output,
            max_tokens = 1000,
            top_p = 1.0,
            frequency_penalty = 0.0,
            presence_penalty = 0.0
        )
        return response.choices[0].message["content"]

    def abstract_summary(self,abstract_content):
        engine=self.engine
        prompt = f"""
        As a knowledgeable assistant, you are given list of content from entire abstract excluding title, author and co-author details.
        Your task is to condense the following list of items within 2000 characters, ensuring that key details are captured and semantic meaning is preserved.
        Do not include any information that is not present within internal data provided.


        Internal Data: 
        ```{abstract_content}```
        """
        messages = [{"role": "user", "content": prompt}]
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=messages,
            temperature=0, # this is the degree of randomness of the model's output,
            max_tokens = 500,
            top_p = 1.0,
            frequency_penalty = 0.0,
            presence_penalty = 0.0
        )
        return response.choices[0].message["content"]

    def check_if_table(self,pg_no,bb_box,table_regions):
        if pg_no not in table_regions:
            return False
        tables=table_regions[pg_no]
        for table in tables:
            if self.is_boxes_intersect(table,bb_box):
                return True
        return False


    def is_boxes_intersect(self,box1,box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        # print(box1,box2)
        # If the boxes do not intersect, return 0
        if x2 < x1 or y2 < y1:
            return False
        else:
            return True
    
    def get_table_regions(self,result):
        try:
            table_regions={}
            for tables in result.get("tables"):
                for table in tables.get("bounding_regions"):
                    _,_,bbox=self.get_polygon(table.polygon)
                    # print(table)
                    pg_no=table.page_number
                    if pg_no not in table_regions:
                        table_regions[pg_no]=[bbox]
                    else:
                        table_regions[pg_no].append(bbox)
            return table_regions
        except:
            return {}
    
    def validate_paragraph(self,content,polygon,role,prev_bbox):
        height,width,bb_box=self.get_polygon(polygon)
        # print(height,width)    
        if any(substring in content for substring in ["Applied Materials Confidential"]) :
            return False,None 
        if role in ["pageFooter","pageNumber"] and len(content.split(' '))<4:
            # print("F")
            return False,None    
        # elif len(content.split(" "))<2 and len(content)<=10:
        #     return False,None
        # if height<=0.1:
        #     return False,None
        elif width/height<1: #removing vertical texts
            # print("False with aspect")
            return False,None 
        elif len(re.sub('[^A-Za-z]', '', content))<=10:
            if prev_bbox is None:
                return False,None  
            else:
                if not self.check_horizontal_overlap(bb_box,prev_bbox):
                    # print("####anomally")
                    return False,None
        # elif width<=.5: #removing small texts. Most probably it is inside the image.
        #     # print("False with height")
        #     return False,None
        # print(content)

        return True,bb_box
    
    def check_horizontal_overlap(self,box1, box2):
        # Check if the y-coordinate ranges overlap
        if (box1[0] <= box2[2] and box2[0] <= box1[2]) or (box2[0] <= box1[2] and box1[0] <= box2[2]):
            return True
        else:
            return False

    def get_polygon(self,polygon):
        y_values=[point.get("y") for point in polygon]
        height=max(y_values)-min(y_values)
        x_values =[point.get("x") for point in polygon]
        width=max(x_values)-min(x_values)
        bb_box=[min(x_values),min(y_values),max(x_values),max(y_values)]
        # print(bb_box)
        return height,width,bb_box