import re
import xml.etree.ElementTree as ET
from langchain.text_splitter import RecursiveCharacterTextSplitter
import json
import os
import json
import os
from fuzzywuzzy import fuzz
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import FormRecognizerClient, FormTrainingClient, DocumentAnalysisClient
import pandas as pd
from collections import defaultdict
from tqdm import tqdm
import openai
import re
from docx2python import docx2python
import json
from dotenv import load_dotenv
from tenacity import retry, wait_random_exponential, stop_after_attempt
# from new_azure_index_creation import Custom_azure_search_client
import langchain

from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.docstore.document import Document
from io import StringIO

import json
import argparse
import uuid
import os
from dotenv import load_dotenv
# from new_azure_index_creation import Custom_azure_search_client
from tenacity import retry, wait_random_exponential, stop_after_attempt
import pandas
import json
import langchain
import os

load_dotenv()

class XMLParser:
    def __init__(self, data, config_data,shared_file_path,file_name,file_path,doctype):

        self.config_data = config_data
        self.xml_file_path = file_path
        self.article_title = None
        self.pattern = r'\s+'
        self.max_chunk_size = 2000
        self.chunk_overlap = 50
        self.chunk_sequence = 0
        self.chunks = []
        self.check_rawtext = True
        self.doctype=doctype
        self.char_text_splitter = RecursiveCharacterTextSplitter(chunk_size=self.max_chunk_size,
                                                                 chunk_overlap=self.chunk_overlap)
        self.namespaces = {'xocs': 'http://www.elsevier.com/xml/xocs/dtd',
                           'ce': 'http://www.elsevier.com/xml/common/dtd'}
        self.tag_callbacks = {'default': self.parse_default, 'section-title': self.parse_section_title,
                              'list-item': self.parse_list_item, 'label': self.parse_label, 'figure': self.parse_figure}

    def parse(self):
        # if not self._is_valid_file(): #check if the file is full text or metadata
        #     return None
        root = ET.fromstring(self._read_xml_file())
        self.parse_abstract(root)
        self.parse_body(root)
        self.parse_table(root)
        if self.check_rawtext:
            self.parse_rawtext(root)
        if len(self.chunks) == 0:
            print(f"Could not extract any chunks for the file {self.xml_file_path}")
        # print("chunks",self.chunks)
        return self.chunks

    def callback(self, element):
        tag = element.tag.split('}')[0] if len(element.tag.split('}')[0]) == 1 else element.tag.split('}')[-1]
        tag_text = self.tag_callbacks[tag](element) if tag in self.tag_callbacks else self.tag_callbacks['default'](
            element)

        return tag_text.encode("ascii", "ignore").decode()

    def parse_rawtext(self, root):
        rawtext_element = root.find('.//{*}rawtext')
        if rawtext_element is None:
            # print("Could not find raw text")
            return None
        rawtext = self.callback(rawtext_element)
        chunks = self.get_chunks(rawtext)
        for _chunk in chunks:
            if len(_chunk) < 200:
                continue
            self.chunks.append({"Title": self.article_title, "ParagraphText": _chunk,
                                "metadata": {"page": self.chunk_sequence, "role": "paragraph",
                                             "doctype": ""}})
            self.chunk_sequence += 1

        print(self.chunks)
        return self.chunks

    def parse_table(self, root):
        table_elements = root.findall('.//{*}table')
        for table_element in table_elements:
            # print(table_element.tag)
            try:
                try:
                    table_id = table_element.attrib["id"]
                    # print(table_id)
                except:
                    break
                table_section, table_intro = self.get_table_section(root, table_id)
                if table_section == '' and table_intro == '':
                    # print("no ref found for the table")
                    continue
                tgroups = table_element.findall(".//{*}tgroup")
                caption_element = table_element.find('.//{*}caption')
                table_caption = self.callback(caption_element) if caption_element is not None else ''
                for tgroup in tgroups:
                    header_spec = self.get_table_details(tgroup)
                    # print("header spec",header_spec)
                    # get the table headings
                    head_element = tgroup.find('.//{*}thead')
                    head_rows = head_element.findall('.//{*}row') if head_element is not None else []
                    headings = self.process_table_rows(head_rows, header_spec)
                    flattened_heading = self.flatten_heading(headings, header_spec)

                    # get the table rows
                    body_element = tgroup.find('.//{*}tbody')
                    table_rows = body_element.findall('.//{*}row') if body_element is not None else []
                    rows = self.process_table_rows(table_rows, header_spec)

                    # print("table_section", table_section)
                    # print("table_intro", table_intro)
                    # print("\n")
                    # print("table_caption", table_caption)
                    # print("\n")
                    # print(','.join(flattened_heading))

                    # for row in rows:
                    #     print(','.join(row))
                    # print("\n")

                    table_results = []
                    no_rows = 0
                    # table_chunk =table_intro+ "\n"
                    table_chunk = ','.join(flattened_heading) + "\n"
                    for row in rows:
                        table_row = ','.join(row) + "\n"
                        if len(table_chunk + table_row + table_intro) < 2000:
                            table_chunk += table_row
                            no_rows += 1
                        elif no_rows >= 1:
                            table_results.append(table_chunk)
                            table_chunk = ','.join(flattened_heading) + '|\n' + table_row
                            no_rows = 1

                    table_results.append(table_chunk)
                    # print("table_results", table_results)

                    chunk_len = 1
                    for r in table_results:
                        if len(r) + len(table_intro) < 200:
                            continue

                        final_section_heading = table_section + "-" + table_caption
                        section_heading = final_section_heading + ' - ' + str(chunk_len) if len(
                            table_results) > 1 else final_section_heading
                        self.chunks.append({"Title": self.article_title, "Section_Heading": section_heading,
                                            "ParagraphText": table_intro, "TableText": r,
                                            "metadata": {"page": self.chunk_sequence, "role": "table",
                                                         "doctype": "science_direct"}})

                        chunk_len += 1
                        self.chunk_sequence += 1
            except Exception as error:
                print(f"Error in parsing the table in the document {self.xml_file_path}. {error}")
        # print(self.chunks)
        return self.chunks

        # return table_results

    def get_table_details(self, table_element):
        colspec = table_element.findall('.//{*}colspec')
        header_spec = {}
        col_num = 1
        for col in colspec:
            col_attrib = col.attrib
            header_spec[col_attrib["colname"]] = col_num
            # print(col_num)
            col_num += 1
        return header_spec

    def get_table_section(self, root, table_id):
        ###########get the section title which in which table was referenced
        # print(table_id)
        sections = root.findall('.//{*}section')
        table_section = ''
        for section in sections:
            ref_tag = section.find('.//{*}float-anchor[@refid="' + table_id + '"]')
            if ref_tag is None:
                continue
            section_title_element = section.find('.//{*}section-title')
            section_title = self.callback(section_title_element).strip() if section_title_element is not None else ''
            table_section += section_title
            sub_sections = section.findall('.//{*}section')
            for sub in sub_sections:
                ref_tag = sub.find('.//{*}float-anchor[@refid="' + table_id + '"]')
                if ref_tag is None:
                    continue
                section_title_element = sub.find('.//{*}section-title')
                section_title = self.callback(
                    section_title_element).strip() if section_title_element is not None else ''
                table_section += " - " + section_title
            if table_section != '':
                break

                #######get the para in which the table was refered
        ref_tag = root.find('.//{*}float-anchor[@refid="' + table_id + '"]...')
        table_text = self.callback(ref_tag) if ref_tag is not None else ''
        table_intro = table_text if len(table_text) < 250 else table_text[-250:]

        return table_section, table_intro

    def flatten_heading(self, headings, header_spec):
        flattened_heading = []
        for i in range(len(header_spec)):
            column_heading = ''
            for j in range(len(headings)):
                if j != 0 and headings[j][i] == headings[j - 1][i]:
                    merg_val = ''
                else:
                    merg_val = headings[j][i]
                column_heading = column_heading + " - " + headings[j][i] if (
                            column_heading != '' and merg_val != '') else headings[j][i]
            flattened_heading.append(column_heading)
        return flattened_heading

    def process_table_rows(self, rows, header_spec):
        table_rows = [['' for i in range(len(header_spec))] for j in range(len(rows))]
        curr_row = 0
        for row in rows:
            curr_col = 1
            for col in row:
                col_attri = col.attrib

                if "namest" in col_attri:
                    start_col = header_spec[col_attri["namest"]]

                else:
                    start_col = curr_col

                if "nameend" in col_attri:
                    end_col = header_spec[col_attri["nameend"]]
                else:
                    end_col = start_col

                if "morerows" in col_attri:
                    end_row = int(col_attri["morerows"]) + 1
                else:
                    end_row = 1

                col_value = self.callback(col).strip()
                col_value = col_value if col_value != '' else "-"
                for i in range(end_row):
                    row_num = curr_row + i
                    # print(row_num,start_col,col_value)
                    # print(table_rows)
                    while True:  # to check if the cell is already occupied from previous run
                        if table_rows[row_num][start_col - 1] == '':
                            break
                        start_col += 1
                        end_col += 1
                    # print("start",start_col,end_col)
                    for j in range(start_col, end_col + 1):
                        col_num = j - 1
                        # print(row_num,col_num)
                        table_rows[row_num][col_num] = col_value

                curr_col = end_col + 1
            curr_row += 1

        return table_rows

    def parse_abstract(self, root):
        title_element = root.find('.//{*}title')

        self.article_title = self.callback(title_element) if title_element is not None else ''
        #######################validation
        # print(self.article_title )

        self.abstract_elements = root.findall('.//{*}abstract', self.namespaces)

        if len(self.abstract_elements) == 0:
            # print(f"Could not find abstract for the file {self.xml_file_path}")
            self.check_rawtext = False
            return None

        text_abstract = ''
        for abstract_element in self.abstract_elements:
            text_abstract += self.callback(abstract_element) + "\n"

        chunks = self.get_chunks(text_abstract)
        #######################validation
        # print(text_abstract)
        #######################validation
        chunk_len = 1
        for _chunk in chunks:
            if len(_chunk) < 200:
                continue
            section_heading = "Abstract,Summary" + "-" + str(chunk_len) if len(chunks) > 1 else "Abstract,Summary"
            chunk_len += 1
            self.chunks.append(
                {"Title": self.article_title, "Section_Heading": section_heading, "ParagraphText": _chunk,
                 "metadata": {"page": self.chunk_sequence, "role": "paragraph", "doctype": ""}})
            self.chunk_sequence += 1

        return self.chunks

    def extract_subsections(self, sections):

        text_chunks = []
        table_chunks = []
        for sec in sections:

            chunks = []
            prev_text = ''
            for i in sections[sec]:  # each line in the introduction , tag (p)
                if i[1].strip() == 'section':
                    if prev_text != '':
                        chunks.append((sec, prev_text))
                    chunks.append((sec + "-" + i[0].split("\n")[0], ''.join(i[0].split("\n")[1:])))
                    prev_text = ''
                else:
                    prev_text += i[0].strip()
            if prev_text != '':
                chunks.append((sec, prev_text))
            for i in chunks:
                text_chunks.append((i[0], i[1]))
        return text_chunks

    def parse_body(self, root):  # body is where the sections of the document starts sec1, sec2 etc

        # serial_tag = root.find('{*}serial-item')
        # article_tag = serial_tag.find('{*}article')
        # body = article_tag.find('{*}body')
        # body_sections = body.find('{*}sections')
        body = root.find('.//{*}body')
        if body is None:
            # print(f"Could not find body for the file {self.xml_file_path}")
            self.check_rawtext = True
            return None
        body_sections = body.find('{*}sections')
        if body_sections is None:
            print(f"Could not find body sections for the file {self.xml_file_path}")
            return None
        sections = {}
        unknown_count = 0

        for section in body_sections:
            unknown_count += 1
            section_title_element = section.find('.//{*}section-title')
            section_title = self.callback(section_title_element).strip() if section_title_element is not None else str(
                unknown_count)
            # print(unknown_count)
            section_content = []
            seciont_tag = section.tag.split('}')[0] if len(section.tag.split('}')[0]) == 1 else section.tag.split('}')[
                -1]

            if seciont_tag == "section":
                for element in section:
                    tag = element.tag.split('}')[0] if len(element.tag.split('}')[0]) == 1 else element.tag.split('}')[
                        -1]
                    if tag == 'section-title':
                        continue
                    text_extracted = self.callback(element)
                    if text_extracted.strip() != '':
                        section_content.append((text_extracted, tag))
            else:
                text_extracted = self.callback(section)
                section_content.append((text_extracted, seciont_tag))
            sections[section_title] = section_content

        if len(sections) == 0:
            print("No Sections found")
        text_chunks = self.extract_subsections(sections)

        #######################validation
        # for sec in text_chunks:
        #     print(sec[0])
        #     print(sec[1],"\n")
        #######################validation

        for i in text_chunks:
            result = self.char_text_splitter.split_text(i[1])
            chunk_len = 1
            for r in result:
                if len(r) < 200:
                    continue
                section_heading = i[0] + "-" + str(chunk_len) if len(result) > 1 else i[0]
                self.chunks.append({"Title": self.article_title, "Section_Heading": section_heading, "ParagraphText": r,
                                    "metadata": {"page": self.chunk_sequence, "role": "paragraph",
                                                 "doctype": ""}})
                chunk_len += 1
                self.chunk_sequence += 1

        return self.chunks

    def parse_default(self, element):
        text = element.text if element.text is not None else ''
        child_tags = ' '.join([self.callback(tag) for tag in element])
        tail = element.tail if element.tail is not None else ''

        return text + child_tags + tail

    def parse_section_title(self, element):
        text = element.text if element.text is not None else ''
        child_tags = ' '.join([self.callback(tag) for tag in element])
        tail = element.tail if element.tail is not None else ''

        return text + child_tags + tail + "\n"

    def parse_list_item(self, element):
        text = element.text if element.text is not None else ''
        child_tags = ' '.join([self.callback(tag) for tag in element])
        tail = element.tail if element.tail is not None else ''

        return text + child_tags + tail + "\n"

    def parse_label(self, element):
        tail = element.tail if element.tail is not None else ''
        return tail

    def _read_xml_file(self):
        with open(self.xml_file_path, "r", encoding="utf-8") as file:
            content = file.read()
        replaced_content = content.replace("xlink:href", " xlinkhref")
        self.xml_content = replaced_content.encode('utf-8')
        return self.xml_content

    def parse_figure(self, element):
        return ""

    def get_chunks(self, content):
        content = re.sub(self.pattern, ' ', content)  # replace with single whitespace
        return self.char_text_splitter.split_text(content)


def langchain_document(content_dict):
    all_docs = []
    for item in content_dict:
        output_list = []
        all_sen = []
        value = item  # Remove eval() function
        for k, v in value.items():
            if k == "metadata":
                continue
            all_sen.append(f"{k.upper()}\n\n{v}\n")
        heading_paragraph = "\n".join(all_sen)
        print("heading", heading_paragraph)
        metadata = value['metadata']
        output_list.append((heading_paragraph, metadata))  # Fix: Pass a tuple as a single argument
        tmp_doc = langchain.docstore.document.Document(page_content=heading_paragraph, metadata=metadata)
        all_docs.append(tmp_doc)
        # print(tmp_doc)
    return all_docs


# @retry(wait=wait_random_exponential(min=1, max=20), stop=stop_after_attempt(6))
# # Function to generate embeddings for title and content fields, also used for query embeddings
# def generate_embeddings(text):
#     # dimensions = embedding_size
#     try:
#         response = openai.Embedding.create(dimensions=512,
#                                            input=text, engine=embedding_engine)
#         embeddings = response['data'][0]['embedding']
#     # embeddings = HF_EMBEDDINGS.embed_query(text)
#     except Exception as e:
#         print(f"Error in generating embeddings for text {text}. Error : {e}")
#         embeddings = None
#     return embeddings

# def create_chunks_indexing(data_folder):
#     # if not os.path.exists(result_folder):
#     #     os.mkdir(result_folder)
#     files = []
#     for root, dirs, filenames in os.walk(data_folder):
#         for filename in filenames:
#             files.append(os.path.join(root, filename))
#     error_docs=[]
#     # breakpoint()
#     # Iterate over the files
#     for file in tqdm(files):
#         try:
#             if (file.endswith('.xml')):
#                 # file_path = os.path.join(data_folder, file)
#                 parser=XMLParser(file)
#                 indexes = parser.parse()
#                 # print("indexes created")     
#                 if len(indexes)==0:
#                     continue  

#                 # with open(f'{file}.json', 'w') as file:
#                 #     json.dump(indexes, file)                
#                 Rres = create_azure_index_doc(langchain_document(indexes))  
#                 azure_cls.add_to_vector_store(Rres) #to add to vector store 
#                 print("addded to vector store", file)
#                 return Rres
#         except Exception as e:
#             print(f"error in document {file}. Error : {e}")
#             error_docs.append(file)
#         return error_docs
#     print(f"Chunk creation finished. Total Errored documents : {len(error_docs)}")
#     print("Errored files :")
    
#     for docs in error_docs:
#         print(f"errored :",docs)


# def create_azure_index_doc(lang_docs):
#     # print("Creating Azure index document")
#     # print("LANG DOCS", len(lang_docs))
#     final_docs = []
#     for item in lang_docs:
#         tmp_dict = {}
#         content = item.page_content
#         content_embeddings = generate_embeddings(content)  # Call the method using 'self'
#         tmp_dict['id'] = str(uuid.uuid4())
#         tmp_dict['content_vector'] = content_embeddings
#         tmp_dict['content'] = content
#         tmp_dict['metadata'] = json.dumps(item.metadata)
#         # print("Temp",tmp_dict)
#         for key, value in item.metadata.items():
#             if key == "year":
#                 tmp_dict[key] = int(value)
#             else:
#                 tmp_dict[key] = str(value).lower()
#         # # print(tmp_dict)
#         final_docs.append(tmp_dict)
#     return final_docs


# # if __name__ == "__main__":
#     file = "../data2\pii_S0020768399002565.xml"
#     xml_parser = XMLParser(file)
#     xml_parser.parse()
