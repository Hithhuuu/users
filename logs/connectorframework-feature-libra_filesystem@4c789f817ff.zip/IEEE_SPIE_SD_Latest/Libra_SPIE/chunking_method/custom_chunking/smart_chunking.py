import json
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os

CONSTANT_SEGREGATOR = ' > '

stopwords_file = r'stopwords.txt'

class smart_chunking:

    def __init__(self, data, config_data):
        self.page_title_section_heading = ''
        self.page_title = ''
        self.skip_ids = []
        self.first_run = True
        self.previous_table_status = False
        self.previous_table_id = -1
        self.section_header = []
        self.config = config_data
        # json_file_path = os.path.join(config_data['parser']['nas_path'], filename.replace('.pdf', '.json'))

        # with open(json_file_path) as user_file:
        #     file_contents = user_file.read()
        self.result = json.loads(data)
        # self.result=parsed_json['analyzeResult']

        # get the length of paragraphs and tables and set initial id's to -1
        self.paragraph_len = len(self.result['paragraphs'])
        self.table_len = len(self.result['tables'])
        self.table_id = -1
        self.paragraph_id = -1
        self.remove_section_headings = ['pageFooter','pageHeader','pageNumber']

        self.stopwords = []
        relative_path = os.path.join('connectors', 'stopwords.txt')
        current_dir = os.getcwd()
        stopwords_file = os.path.join(current_dir, relative_path)

        with open(stopwords_file, "r", encoding='utf-8') as file:
            stopwords = file.read().splitlines()
            self.stopwords = [stopword.lower() for stopword in stopwords]

    def table_id_pagenum_polygen(self,id):
        '''Get table id and position'''
        result = self.result
        if id == -1:
            id = 0
            #print(f'Get first table id and position')
            if(len(result['tables']) == 0):
                return ('Table Completed', 0 , 0)
            ##print(f'id = {result['tables'][id]} and position = {result['tables'][id]['bounding_regions'][0]['polygon'][0]}')
            return (id, result['tables'][id]['bounding_regions'][0]['page_number'], result['tables'][id]['bounding_regions'][0]['polygon'][0])
        else:
            id +=1
            ##print(f'Get next table id and position')
            if(id >= self.table_len):
                ##print(f'No more tables, returning last table id and position')
                id = self.table_len - 1
                return ('Table Completed', result['tables'][id]['bounding_regions'][0]['page_number'], result['tables'][id]['bounding_regions'][0]['polygon'][0])
                ###print(f'id = {result['tables'][id]} and position = {result['tables'][id]['bounding_regions'][0]['polygon'][0]}')
            return (id, result['tables'][id]['bounding_regions'][0]['page_number'], result['tables'][id]['bounding_regions'][0]['polygon'][0])

    def update_section_heading(self,content):
        '''Update section heading list'''
        ##print(f"content = {content} and section_header = {section_header}")
        if len(self.section_header) == 0:
            self.section_header.append(content)
        elif content[0].isdigit():
            check = False
            while check == False:
                split_content = content.split()
                split_section_header = self.section_header[-1].split()
                split_content_core = '.'.join(split_content[0].split('.')[:-1])
                if split_content_core == split_section_header[0]:
                    ##print(f"split_content_core = {split_content_core} and split_section_header = {split_section_header[0]}")
                    ##print(f"Updating section header  - {content}  to section header list")
                    self.section_header.append(content)
                    check = True
                elif split_content_core.isdigit() or split_content[0].isdigit():
                    ##print(f"popping 1 header out of section header list as the input is digit")
                    self.section_header.pop()
                    if (len(self.section_header) == 0):
                        ##print(f"no section header found, making section header as empty list")
                        self.section_header = []
                        self.section_header.append(content)
                        check = True
                elif len(self.section_header) > 1:
                    ##print(f"popping 1 header out of section header list")
                    ##print(f"popping section header - {self.section_header[-1]}")
                    self.section_header.pop()
                    if (len(self.section_header) == 0):
                        self.section_header.append(content)
                        check = True
                else:
                    ##print(f"no section header found, making section header as empty list")
                    if(len(content) > 0):
                        self.section_header = []
                        self.section_header.append(content)
                    else:
                        self.section_header = []
                    check = True
        else:
            self.section_header.append(content)
        ##print(f"Adding section header id - {id} to section header list")

    def paragraph_id_pagenum_polygen(self, id):
        result = self.result
        '''Get paragraph id and position and check if it is in remove list & skip it'''
        if id == -1:
            id = 0
            if(len(result['paragraphs']) == 0):
                return ('Paragraph Completed', 0 , 0)
            ##print(f"Get first paragraph id and position")
            ##print(result['paragraphs'][id]['content'])
            while(id < self.paragraph_len and result['paragraphs'][id]['content'].lower() in self.stopwords):
                ##print(f"{result['paragraphs'][id]['content']} is in stopwords list")
                id +=1
            if (result['paragraphs'][id].get('role') is not None):
                ##print("role ->" +  result['paragraphs'][id]['role'])
                while(result['paragraphs'][id]['role'] == 'sectionHeading' and id < self.paragraph_len):
                    self.update_section_heading(result['paragraphs'][id]['content'])
                    id +=1
            if (result['paragraphs'][id].get('role') is not  None):
                while (result['paragraphs'][id]['role'] in self.remove_section_headings):
                    id +=1
                    ##print(f"Get next paragraph id and position as it is in remove list")
                    ##print(result['paragraphs'][id]['bounding_regions'][0]['page_number'] == 1)
            while (id < self.paragraph_len and result['paragraphs'][id]['bounding_regions'][0]['page_number'] == 1 and self.first_run == True):
                '''Get page title from first page'''
                if (result['paragraphs'][id].get('role') is not None):
                    ##print("role ->" +  result['paragraphs'][id]['role'])
                    if(result['paragraphs'][id]['role'] == 'title'):
                        self.page_title_section_heading += ' '+result['paragraphs'][id]['content']
                        self.skip_ids.append(id)
                ##print(result['paragraphs'][id]['bounding_regions'][0]['page_number'] == 1)
                ##print(result['paragraphs'][id]['content'])



                if(result['paragraphs'][id]['content'].lower() not in self.stopwords and result['paragraphs'][id].get('role') not in self.remove_section_headings):
                    self.page_title += ' '+result['paragraphs'][id]['content']
                else:
                    pass
                    ##print(f"paragraph present in stopword - {result['paragraphs'][id]['content']}")
                if(len(self.page_title_section_heading) > 0):
                    self.page_title = self.page_title_section_heading + ' '
                else:
                    self.page_title += ' '
                #print("Page_title -> " + page_title)
                id +=1
            self.page_title = self.page_title.strip()
            self.first_run = False
            if(len(self.page_title_section_heading) > 0):
                id = 0
                while(id in self.skip_ids):
                    id +=1
        else:
            id +=1
            if(id < self.paragraph_len):
                while(id < self.paragraph_len and result['paragraphs'][id]['content'].lower() in self.stopwords):
                    #print(f"{result['paragraphs'][id]['content']} is in stopwords list")
                    temp_id = id +1
                    if (temp_id < self.paragraph_len):
                        id+=1;
                    else:
                        break
                if (result['paragraphs'][id].get('role') is not None):
                    #print("role ->" +  result['paragraphs'][id]['role'])
                    if(result['paragraphs'][id]['role'] == 'sectionHeading' and id < self.paragraph_len):
                        self.update_section_heading(result['paragraphs'][id]['content'])
                        id +=1
                        #print(f"Adding section header id - {id} to section header list")
                while (id < self.paragraph_len and result['paragraphs'][id].get('role') in self.remove_section_headings ):
                    id +=1
                    if(id >= self.paragraph_len):
                        break
                    #print(f"Get next paragraph id and position as it is in remove list")
                if self.previous_table_status == True:
                    #print(f"previous table id - {previous_table_id} and current paragraph id - {id}")
                    table_content_id = 0
                    while(result['paragraphs'][id]['content'] == result['tables'][self.previous_table_id]['cells'][table_content_id]['content']):
                        #print(f"Get next paragraph id and position as it is same as previous table content")
                        #print(f"paragrapj id = {result['paragraphs'][id]['content']} and table content = {result['tables'][self.previous_table_id]['cells'][table_content_id]['content']}")
                        id +=1
                        table_content_id +=1
                        if(id >= self.paragraph_len or table_content_id >= len(result['tables'][self.previous_table_id]['cells']) ):
                            break
                    self.previous_table_status = False
                    self.previous_table_id = -1
                while(id < self.paragraph_len and result['paragraphs'][id]['content'].lower() in self.stopwords):
                    #print(f"{result['paragraphs'][id]['content']} is in stopwords list")
                    id +=1
                ##print(f'id = {result['paragraphs'][id]} and position = {result['paragraphs'][id]['bounding_regions'][0]['polygon'][0]}')
        if(id >= self.paragraph_len):
            #print(f"No more paragraphs, returning last paragraph id and position")
            id = self.paragraph_len - 1
            return ("Paragraph Completed", result['paragraphs'][id]['bounding_regions'][0]['page_number'], result['paragraphs'][id]['bounding_regions'][0]['polygon'][0])
            ##print(f'id = {result['paragraphs'][id]} and position = {result['paragraphs'][id]['bounding_regions'][0]['polygon'][0]}')
        else:
            return (id, result['paragraphs'][id]['bounding_regions'][0]['page_number'], result['paragraphs'][id]['bounding_regions'][0]['polygon'][0])
            #print(f'Get next paragraph id and position')

    def compare_table_paragraph(self,paragraph_id,table_id):
        """Compare table and paragraph position and return the id of the one which is below the other"""
        table_id, table_page_num, table_polygen = self.table_id_pagenum_polygen(table_id)
        paragraph_id, paragraph_page_num, paragraph_polygen = self.paragraph_id_pagenum_polygen(paragraph_id)
        if table_id == "Table Completed" and paragraph_id == "Paragraph Completed":
            return("Completed", table_id)
        if table_page_num == paragraph_page_num and table_id != "Table Completed" and paragraph_id != "Paragraph Completed":
            #print(f'Table and paragraph are in same page')
            if table_polygen['y'] > paragraph_polygen['y']:
                #print(f'Table is below paragraph, returning paragraph id')
                paragraph_id +=1
                return("paragraph", paragraph_id-1)
            else:
                #print(table_id)
                table_id +=1
                self.previous_table_status = True
                self.previous_table_id = table_id-1
                #print(f'Paragraph is below table, returning table id')
                return("table", table_id-1)
        elif table_page_num > paragraph_page_num or table_id == "Table Completed":
            if(table_page_num > paragraph_page_num):
                pass
                #print(f"Table id - {table_id} is in next page, returning paragraph id - {paragraph_id}")
            else:
                pass
                #print(f"No more tables, returning paragraph id - {paragraph_id}")
            paragraph_id +=1
            return("paragraph", paragraph_id-1)
        elif paragraph_page_num > table_page_num or paragraph_id == "Paragraph Completed":
            if(paragraph_page_num > table_page_num):
                pass
                #print(f"Paragraph id - {paragraph_id} is in next page, returning table id - {table_id}")
            else:
                pass
                #print(f"No more paragraphs, returning table id - {table_id}")
            table_id +=1
            #print(f'Paragraph is in next page, returning table id')
            return("table", table_id-1)

    def get_table_content(self,table_id):
        '''get table content for table_id'''
        table_content = '##BEGIN TABLE##'
        row_index = -1
        for cell in self.result['tables'][table_id]['cells']:

            if row_index == -1:
                row_index = cell['row_index']
                table_content += ' '+cell['content']
                #print(table_content)
            elif row_index == cell['row_index']:
                table_content += '|'+cell['content']
                #print(table_content)
            else:
                row_index = cell['row_index']
                table_content += '\n'+cell['content']
                #print(table_content)
        return table_content+ '##END TABLE##'

    def get_chunk(self,paragraph_id, table_id):
        """Get chunk of text from the document"""
        name, id = self.compare_table_paragraph(paragraph_id,table_id)
        if name == "paragraph":
            chunk = self.result['paragraphs'][id]['content']
            paragraph_id = id
            #print(f"paragraph id = {paragraph_id}")
            return paragraph_id,table_id,chunk,self.result['paragraphs'][id]['bounding_regions'][0]['page_number']
        if name == "table":
            chunk = self.get_table_content(id)
            #print(f"this is a table content for table_id {id} and content {chunk}")
            table_id = id
            #print(f"table id = {table_id}")
            return paragraph_id,table_id,chunk,self.result['tables'][id]['bounding_regions'][0]['page_number']
        if name == "Completed":
            return self.paragraph_len,self.table_len, '##Completed##', self.result['paragraphs'][self.paragraph_len-1]['bounding_regions'][0]['page_number']

    def generate_overlap_subheader(self):
        '''Generate subheader for the overlap'''
        #print(f'generate subheader for overlap')
        section_header_text= ' '.join(self.section_header)
        #print(section_header_text)
        return section_header_text

    def get_overlap(self,paragraph_id,table_id):
        overlap_chunk = ''
        if len(self.section_header) > 0:
                overlap_chunk = self.generate_overlap_subheader()
                #print(f"overlap chunk = {overlap_chunk}")
        return overlap_chunk


    def get_heading_chunk(self):
        '''Get heading chunk'''
        heading_chunk = ''
        if len(self.page_title) > 1:
            heading_chunk += self.page_title
            heading_chunk += CONSTANT_SEGREGATOR
        if len(self.section_header) > 0:
            heading_chunk += CONSTANT_SEGREGATOR.join(self.section_header)+CONSTANT_SEGREGATOR
        return heading_chunk

    def split_table_content(self,table_id, chunk_size_for_table):
        #print(f"chunk size for table  - >{chunk_size_for_table}")
        chunked_table = []
        row_index = -1
        table_header = ''
        chunk_split = ''
        table_rows = []
        table_row = ''
        for cell in self.result['tables'][table_id]['cells']:
                if row_index == -1:
                    row_index = cell['row_index']
                    table_row += ' '+cell['content'].replace(":selected:","").replace(":unselected:","")
                elif row_index == cell['row_index']:
                    table_row += '|'+cell['content'].replace(":selected:","").replace(":unselected:","")
                else:
                    table_rows.append(table_row)
                    table_row = ''
                    row_index = cell['row_index']
                    table_row += cell['content'].replace(":selected:","").replace(":unselected:","")
        new_split = ''
        for i in range(1, len(table_rows)):
            if (len(table_rows[0]) +len(chunk_split)+ len(table_rows[i]) + 3) < chunk_size_for_table:
                new_split = table_rows[i] + "\n"
                chunk_split += new_split
            else:
                chunked_table.append(table_rows[0] + "\n" + chunk_split )
                chunk_split = new_split
        if chunk_split:
            chunked_table.append(table_rows[0] + "\n" + chunk_split )
        return chunked_table

    def text_splitter(self, text):
        # Base case: if the text is shorter than the chunk size, return a list containing just the text
        chunks = []
        chunk_size = self.config['chunks']['chunksize']
        overlap_size = self.config['chunks']['overlap']
        while len(text) > chunk_size:
            chunk = text[:chunk_size]
            chunks.append(chunk)
            text = text[chunk_size - overlap_size:]  # Keep the overlap in the rest of the text
        # Add the remaining text as the last chunk
        chunks.append(text)
        return chunks

    def getchunks(self):
        new_chunk= ''
        chunks = []
        previous_heading = ''
        heading_change= False
        heading_chunk = ''
        chunk_paragraph=[]
        page_num_arr = [1]
        table_id = -1
        paragraph_id = -1
        while (paragraph_id < self.paragraph_len) and (table_id < self.table_len):
            chunk = new_chunk
            while len(chunk) <= self.config['chunks']['chunksize'] and heading_change == False:
                paragraph_id,table_id,new_chunk,page_num = self.get_chunk(paragraph_id,table_id)
                heading_chunk = self.get_heading_chunk()
                if len(chunks) == 0:
                    chunks.append(heading_chunk[:-3])
                    chunk_paragraph.append([heading_chunk[:-3], 1, heading_chunk[:-3]])
                    previous_heading = heading_chunk
                    page_num_arr = []
                if previous_heading == heading_chunk:
                    heading_change = False
                    if page_num not in page_num_arr:
                        page_num_arr.append(page_num)
                else:
                    heading_change = True
                if(len(chunk) + len(new_chunk) < self.config['chunks']['chunksize'] and new_chunk != '##Completed##' and heading_change == False):
                    chunk += new_chunk if len(chunk) < 1 else ' ' + new_chunk
                    if page_num not in page_num_arr:
                        page_num_arr.append(page_num)
                elif len(chunk) < self.config['chunks']['chunksize'] and len(page_num_arr) == 0:
                    if page_num not in page_num_arr:
                        page_num_arr.append(page_num)
                    break
                else:
                    break
            original_chun = chunk
            original_heading = previous_heading
            chunk = chunk.replace(":selected:","").replace(":unselected:","")
            previous_heading = previous_heading.replace(":selected:","").replace(":unselected:","")
            #print(len(chunk_paragraph))
            if len(original_chun)  > self.config['chunks']['chunksize']:
                #print(f"Chunk length greater, splitting based on paragraph or table")
                ##do something to split
                if page_num not in page_num_arr:
                    page_num_arr.append(page_num)
                if chunk.startswith('##BEGIN TABLE##'):
                    #print(f"I am a table, splitting based on row")
                    chunked_table = self.split_table_content(table_id, self.config['chunks']['chunksize'])
                    # chunked_table = self.split_table_content(table_id, MAX_CHUNK_SIZE - len(previous_heading))
                    for i in range(0, len(chunked_table)):
                        chunks.append(previous_heading + str(chunked_table[i]))
                        chunk_paragraph.append([str(chunked_table[i]), page_num_arr,previous_heading])
                    page_num_arr = []

                else:
                    #print(f'I am a text, splitting via text splitter')
                    # splitter = self.create_text_splitter(MAX_CHUNK_SIZE - len(previous_heading))
                    # chunked_data = splitter.split_text(chunk)
                    chunked_data = self.text_splitter(chunk)
                    for i in range(0, len(chunked_data)):
                        chunks.append(previous_heading + str(chunked_data[i]))
                        chunk_paragraph.append([str(chunked_data[i]), page_num_arr,previous_heading])
                    page_num_arr = []
                new_chunk = ''
                chunk = 'OVER_SIZE_CHUNK_ADDED'
                #else:
                #    #print(f'HEADING IS GREATER THANN CHUNK SIZE')
            heading_change = False
            if(chunk != 'OVER_SIZE_CHUNK_ADDED'):
                chunk = chunk.replace("##BEGIN TABLE##","").replace("##END TABLE##","")
                chunks.append(previous_heading + chunk)
                chunk_paragraph.append([chunk, page_num_arr,previous_heading])
                page_num_arr = []
            previous_heading = heading_chunk
        return chunk_paragraph
