import uuid
import os
from dotenv import load_dotenv
# from new_azure_index_creation import Custom_azure_search_client
from tenacity import retry, wait_random_exponential, stop_after_attempt 
import json
import langchain
from langchain.text_splitter import RecursiveCharacterTextSplitter

import re
import xml.etree.ElementTree as ET
from fuzzywuzzy import fuzz
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import FormRecognizerClient, FormTrainingClient, DocumentAnalysisClient
import pandas as pd
from collections import defaultdict
from tqdm import tqdm
import openai
from docx2python import docx2python
from tenacity import retry, wait_random_exponential, stop_after_attempt
# from new_azure_index_creation import Custom_azure_search_client
import langchain

from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.docstore.document import Document
from io import StringIO


load_dotenv()
class XMLParser:
    def __init__(self, data, config_data,shared_file_path,file_name,file_path,doctype):

        self.config_data = config_data
        self.xml_file_path = file_path
        self.article_title = None
        self.pattern = r'\s+'
        self.max_chunk_size = 2000
        self.chunk_overlap = 50
        self.chunk_sequence = 0
        self.chunks = []
        self.check_rawtext = True
        self.doctype=doctype
        self.char_text_splitter = RecursiveCharacterTextSplitter(chunk_size=self.max_chunk_size, chunk_overlap=self.chunk_overlap)
        self.namespaces = {'xocs':'http://www.elsevier.com/xml/xocs/dtd', 'ce': 'http://www.elsevier.com/xml/common/dtd'}
        self.tag_callbacks={'default':self.parse_default,'title':self.parse_title,'label':self.parse_label,'inline-formula':self.parse_formula,'table-wrap':self.parse_table,'fig':self.parse_figure,'p':self.parse_paragraph,'sup':self.parse_superscript}

        self.tables={}

    def callback(self,element):
        tag=element.tag
        tag_text=self.tag_callbacks[tag](element) if tag in self.tag_callbacks else self.tag_callbacks['default'](element)

        return tag_text.encode("ascii", "ignore").decode()

    def parse_default(self,element):
        text=element.text if element.text is not None else ''
        child_tags=' '.join([self.callback(tag) for tag in element])
        tail=element.tail if element.tail is not None else ''

        return text+child_tags+tail                
        
    def parse(self):  
        # if not self._is_valid_file(): #check if the file is full text or metadata
        #     return None      
        root = ET.fromstring(self._read_xml_file())           
        try:

            self.article_type=root.attrib["article-type"]
            
        except:
            self.article_type=''
        
        self.article_title=self.callback(root.find(".//article-title")) if root.find(".//article-title") is not None else ''
   
        exclusion_list=['LETTER', 'JBO LETTERS', 'BOOK-REVIEW', 'NEWS AND COMMENTARIES', 'INTRODUCTION', 'NEWS AND COMMENT', 'ARTICLE-COMMENTARY', 'JM3 LETTERS', 'LETTERS', 'ABOUT THE COVER', 'EDITORIAL', 'EDITORIALS', 'GUEST-EDITORIAL', 'CORRECTION', 'ERRATA', 'ERRATUM']
        for article in exclusion_list:
            if self.article_type.upper() in article and len(self.article_type.split(' '))<=3:
                return []
            
        self.parse_abstract(root)

        self.parse_body(root)
        # print(self.chunks)
        return self.chunks

    
    def callback(self,element):
        tag=element.tag.split('}')[0] if len(element.tag.split('}')[0])==1 else element.tag.split('}')[-1]
        return self.tag_callbacks[tag](element) if tag in self.tag_callbacks else self.tag_callbacks['default'](element)
    
    def parse_abstract(self,element):
        abstract_element=element.find(".//abstract")
        if abstract_element is None:
            return None
        abstract_text=''
        for tag in abstract_element:
            abstract_text+=self.callback(tag)
        chunks=self.get_chunks(abstract_text)
        chunk_len=1
        for _chunk in chunks:
            if len(_chunk)<200:
                continue            
            section_heading="Abstract,Summary"+"-"+str(chunk_len) if len(chunks)>1 else "Abstract,Summary"
            chunk_len+=1
            self.chunks.append({"Title":self.article_title, "Section_Heading": section_heading,"ParagraphText":_chunk , 
                                    "metadata" : {"page":self.chunk_sequence,"role": "paragraph", "doctype": f"{self.article_type} (SPIE)"}})
            self.chunk_sequence += 1
                    

    def parse_body(self,element):
        body_element=element.find(".//body")
        if body_element is None:
            return None        
        sections=body_element.findall(".//sec")
        if len(sections)>0:
            sections=self.parse_sections(body_element)
        else:
            # print(f"No sections. Going with 2000 splits {self.xml_file_path}")
            sections=self.parse_nonsections(body_element)

        text_chunks,table_chunks=self.extract_subsections(sections)
        
        for chunks in text_chunks:
            result=self.char_text_splitter.split_text(chunks[1])
            chunk_len=1
            for r in result:
                if len(r)<200:
                    continue                
                section_heading=chunks[0]+"-"+str(chunk_len) if len(result)>1 else chunks[0]
                self.chunks.append({"Title":self.article_title, "Section_Heading": section_heading,"ParagraphText":r , 
                                     "metadata" : {"page":self.chunk_sequence,"role": "paragraph", "doctype": f"{self.article_type} (SPIE)"}})
                chunk_len+=1   
                self.chunk_sequence+=1   

        if len(table_chunks)>0:
            final_tables=self.process_tables(table_chunks)
            for section_title,paratext,tabletext in final_tables: 
                
                # print(tabletext)
                self.chunks.append({"Title":self.article_title, "Section_Heading": section_title,"ParagraphText": paratext,"TableText":tabletext,
                                    "metadata" : {"page":self.chunk_sequence,"role": "table", "doctype": f"{self.article_type} (SPIE)"}})
                self.chunk_sequence+=1
    def parse_sections(self,element):
        sections={}
        section_count=0
        for section in element:
            section_count+=1
            if section.tag!='sec':
                continue
            section_title=''
            section_texts=[]
            for tag in section:
                if tag.tag=='title':
                    section_title=self.callback(tag).strip()
                else:
                    section_texts.append((self.callback(tag),tag.tag))
            section_title=section_title if section_title!='' else "Section "+str(section_count)
            sections[section_title]=section_texts
        # print(sections)
        return sections
    
    def parse_nonsections(self,element):
        rawtext=[]
        for tag in element:
            rawtext.append((self.callback(tag),tag.tag))
        return {'Paragraph':rawtext}
        
    def process_tables(self,table_chunks):
        table_splits=[]
        for table in table_chunks:
            section=table[0]
            para_text=table[1][0]
            para_text=para_text if len(para_text)<=250 else para_text[-250:]
            table_element=table[1][1]
            table_caption=self.callback(table_element.find(".//caption")).strip() if table_element.find(".//caption") is not None else ''

            tgroups=table_element.findall(".//{*}tgroup")
            for tgroup in tgroups:  
                try:              
                    header_spec=self.get_table_details(table_element)
                    head_element = tgroup.find('.//{*}thead')
                    head_rows = head_element.findall('.//{*}row') if head_element is not None else []                            
                    headings=self.process_table_rows(head_rows,header_spec)   
                    
                    heading=self.flatten_heading(headings,header_spec)
                    
                    final_heading=','.join(heading)

                    remaining_chars=2000-250-len(final_heading)#250 characters for para text

                    body_element = tgroup.find('.//{*}tbody')
                    body_rows = body_element.findall('.//{*}row') if body_element is not None else []                            
                    body_rows=self.process_table_rows(body_rows,header_spec)
                    row_split=""
                    ind_table_splits=[]
                    for row in body_rows:
                        row_text=','.join(row)+"\n"
                        if len(row_split)+len(row_text)<remaining_chars:
                            row_split+=row_text
                        else:
                            ind_table_splits.append([section+" - "+table_caption,para_text,final_heading+"\n"+row_split])
                            row_split=row_text
                    if row_text!='':
                        ind_table_splits.append([section+" - "+table_caption,para_text,final_heading+"\n"+row_split])
                    split_count=1
                    for splits in ind_table_splits:

                        if len(ind_table_splits)>1:
                            split_heading=splits[0]+" - "+str(split_count)
                            split_count+=1
                            splits[0]=split_heading
                            table_splits.append(splits)
                        else:
                            table_splits.append(splits)
                except Exception as error:
                    print(f"Error in table processing {table_caption} {self.xml_file_path}",error)
                        
        return table_splits
    
    def get_table_details(self,table_element):
        colspec=table_element.findall('.//{*}colspec')
        header_spec={}
        col_num=1
        for col in colspec:
            col_attrib=col.attrib
            header_spec[col_attrib["colname"]]=col_num
            # print(col_num)
            col_num+=1
        return  header_spec  
         
    def flatten_heading(self,headings,header_spec):
        flattened_heading=[]
        for i in range(len(header_spec)):
            column_heading=''
            for j in range(len(headings)):
                if j!=0 and headings[j][i]==headings[j-1][i]:
                    merg_val=''
                else:
                    merg_val=headings[j][i]
                column_heading=column_heading+" - "+headings[j][i] if (column_heading!='' and merg_val!='') else headings[j][i]
            flattened_heading.append(column_heading)
        return flattened_heading      
              
    def process_table_rows(self,rows,header_spec):
        # print(len(header_spec),len(rows))
        table_rows=[['' for i in range(len(header_spec))] for j in range(len(rows))]
        curr_row=0
        for row in rows:
            curr_col=1
            for col in row:
                col_attri=col.attrib
            
                if "namest" in col_attri:
                    start_col=header_spec[col_attri["namest"]]
                    
                else:
                    start_col=curr_col

                if "nameend" in col_attri:
                    end_col=header_spec[col_attri["nameend"]]
                else:
                    end_col=start_col    

                if "morerows" in col_attri:
                    end_row=int(col_attri["morerows"])+1
                else:
                    end_row=1

                col_value=self.callback(col).strip()
                col_value=col_value if col_value.strip()!='' else "-"
                if start_col>=len(header_spec)+1:
                    break
                for i in range(end_row):
                    row_num=curr_row+i
                    # print(row_num,start_col,col_value)
                    # print(table_rows)
                    while True:#to check if the cell is already occupied from previous run
                        if row_num>=len(table_rows):
                            table_rows.append(['' for i in range(len(header_spec))])
                        if len(header_spec)==start_col:
                            break
                        # print("start col",start_col,row_num,col_value)
                        if table_rows[row_num][start_col-1]=='':
                            break
                        start_col+=1
                        end_col+=1
                    # print("start",start_col,end_col)
                    for j in range(start_col,end_col+1):
                        col_num=j-1
                        # print(row_num,col_num)
                        table_rows[row_num][col_num]=col_value
                        
                curr_col=end_col+1
            curr_row+=1

        return table_rows
    def seperate_tables_text(self,text):
        table_pair=[]
        for table in self.tables:
            text_split=text.split(table)
            if len(text_split)>1:
                table_pair.append((text_split[0],self.tables[table]))
                text=' '.join(text_split)

        return text,table_pair
    
    def extract_subsections(self,sections):

        text_chunks=[]
        table_chunks=[]
        for sec in sections:
            # print("######new section########",sec,"\n") #introduction
            chunks=[]
            prev_text=''
            for i in sections[sec]: #each line in the introduction , tag (p)
                if i[1].strip()=='sec': 
                    if prev_text!='':
                        chunks.append((sec,prev_text))
                    chunks.append((sec+"-"+i[0].split("\n")[0],'\n'.join(i[0].split("\n")[1:])))
                    prev_text=''
                else:
                    prev_text+=i[0].strip()
                    if i[1].strip()=='p':
                        prev_text+="\n"
            if prev_text!='':
                chunks.append((sec,prev_text))
            
            for chunk in chunks:
                text,tables=self.seperate_tables_text(chunk[1])                
                text_chunks.append((chunk[0],text))
                if len(tables)>0: #["Introduction","text"]
                    for table in tables:
                        table_chunks.append((chunk[0],table))
        return text_chunks,table_chunks

    def parse_title(self,element):
        text=element.text if element.text is not None else ''
        child_tags=' '.join([self.callback(tag) for tag in element])
        tail=element.tail if element.tail is not None else ''

        return text+child_tags+tail+"\n"   
    
    def parse_label(self,element):
        return ""
    
    def parse_superscript(self,element):
        tail=element.tail if element.tail is not None else ''
        return "" +tail    
        
    def parse_table(self,element):
        table_ref=f"**table{len(self.tables)+1}**"
        self.tables[table_ref]=element
        tail=element.tail if element.tail is not None else ''
        return table_ref+tail
    
    def parse_figure(self,element):
        return ""

    def parse_paragraph(self,element):

        text=element.text if element.text is not None else ''
        child_tags=' '.join([self.callback(tag) for tag in element])
        tail=element.tail if element.tail is not None else ''

        return text+child_tags+tail+"\n"           
    
    def parse_formula(self,element):
        text=element.text if element.text is not None else ''
        child_tags=' '.join([self.callback(tag) for tag in element])
        tail=element.tail if element.tail is not None else ''

        return text+child_tags+tail+" "     
           
    def _read_xml_file(self):
        try:
            with open(self.xml_file_path, "r", encoding="utf-8") as file:
                content = file.read()
        except:
            with open(self.xml_file_path, "r", encoding="latin-1") as file:
                content = file.read()
        replaced_content = content.replace("xlink:href", " xlinkhref")
        self.xml_content = replaced_content.encode('utf-8')
        return self.xml_content

    
    def get_chunks(self,content):
        content = re.sub(self.pattern, ' ', content) #replace with single whitespace
        return self.char_text_splitter.split_text(content)


# xml_file_path = r"C:\Users\e183066\OneDrive - Applied Materials\Desktop\ieee\ieee_sample\10000065_ft.xml"
# parser=XMLParser(xml_file_path)
# chunks = parser.parse()

# # print(chunks)

# # # Save content to JSON
# # with open(xml_file_path + '_content.json', 'w') as f:
# #     json.dump(content, f)

# # Save chunks to JSON
# with open(xml_file_path + '22chunks.json', 'w') as f:
#     json.dump(chunks, f)
    
def langchain_document(content_dict):
    all_docs = []
    for item in content_dict:
        output_list = []
        all_sen = []
        value = item  # Remove eval() function
        for k, v in value.items():
            if k == "metadata":
                continue
            all_sen.append(f"{k.upper()}\n\n{v}\n")
        heading_paragraph = "\n".join(all_sen)
        metadata = value['metadata']
        output_list.append((heading_paragraph, metadata))  # Fix: Pass a tuple as a single argument
        tmp_doc = langchain.docstore.document.Document(page_content=heading_paragraph, metadata=metadata)
        all_docs.append(tmp_doc)
    return all_docs

