from utils import logger
from contextvars import ContextVar
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())


class IncrementalSync:
    def __init__(self) -> None:
        app_log.info('Incremental Sync')
        pass
    pass