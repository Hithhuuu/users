import os
import urllib.parse
from datetime import datetime
import json
from metrics.main_metrics import MetricsRun

DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"


def encode(object_name):
    """Performs encoding on the name of objects
    containing special characters"""
    name = urllib.parse.quote(object_name, safe="'")
    return name.replace("'", "''")


def split_list_into_buckets(documents, total_buckets):
    """Divide large number of documents amongst the total buckets
    :param documents: list to be partitioned
    :param total_buckets: number of groups to be formed
    """
    if documents:
        groups = min(total_buckets, len(documents))
        group_list = []
        for i in range(groups):
            group_list.append(documents[i::groups])
        return group_list
    else:
        return []


def split_documents_into_equal_chunks(documents, chunk_size):
    """This method splits a list or dictionary into equal chunks size
    :param documents: List or Dictionary to be partitioned into chunks
    :param chunk_size: Maximum size of a chunk
    Returns:
        list_of_chunks: List containing the chunks
    """
    list_of_chunks = []
    for i in range(0, len(documents), chunk_size):
        if type(documents) is dict:
            partitioned_chunk = list(documents.items())[i : i + chunk_size]
            list_of_chunks.append(dict(partitioned_chunk))
        else:
            list_of_chunks.append(documents[i : i + chunk_size])
    return list_of_chunks


def split_date_range_into_chunks(start_time, end_time, number_of_threads):
    """Divides the timerange in equal partitions by number of threads
    :param start_time: start time of the interval
    :param end_time: end time of the interval
    :param number_of_threads: number of threads defined by user in config file
    """
    start_time = datetime.strptime(start_time, DATETIME_FORMAT)
    end_time = datetime.strptime(end_time, DATETIME_FORMAT)

    diff = (end_time - start_time) / number_of_threads
    datelist = []
    for idx in range(number_of_threads):
        date_time = start_time + diff * idx
        datelist.append(date_time.strftime(DATETIME_FORMAT))
    formatted_end_time = end_time.strftime(DATETIME_FORMAT)
    datelist.append(formatted_end_time)
    return datelist


def delete_file(file_path):
    os.remove(file_path)


def write_to_file(file_path, file_metrics):
    try:
        # directory = os.path.dirname(file_path)
        # if not os.path.exists(directory):
        #     os.makedirs(directory)
        # with open(file_path, "wb") as f:
        #     f.write(content)

        file_metrics.append(file_path)
        if "Abstracts" in file_metrics[4]:
            file_metrics[5]=os.path.getsize(file_path)
        file_metrics.append("Success")
        # else:
        #     file_metrics.append("Failed")
        MetricsRun().run_source_metrics(file_metrics)

    except Exception as ex:
        file_metrics.append(f'Failed -> {ex}')
        MetricsRun().run_source_metrics(file_metrics)
        print(ex)


def write_json(file_path, data):
    try:
        directory = os.path.dirname(file_path)

        if not os.path.exists(directory):
            os.makedirs(directory)
            
        with open(file_path, "w") as file:
            json.dump(data, file, indent=4)
    except Exception as ex:
        print(ex)
