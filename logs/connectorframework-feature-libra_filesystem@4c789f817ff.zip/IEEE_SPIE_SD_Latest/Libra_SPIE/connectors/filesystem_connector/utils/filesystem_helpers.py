import os
import threading
import time
from urllib.parse import urljoin
import requests
import uuid
import warnings
from dateutil.parser import parse
from multiprocessing import Pool
from chain_template import main_call
import xml.etree.ElementTree as ET
import re
import pandas as pd
from connectors.filesystem_connector.utils.utils import (
    encode,
    split_documents_into_equal_chunks,
    split_list_into_buckets,
    write_to_file,
    write_json,
)
from datetime import datetime
import calendar
import argparse
import yaml

IDS_PATH = os.path.join(os.path.dirname(__file__), "doc_id.json")

SITE = "site"
LIST = "list"
ITEM = "item"
SITES = "sites"
LISTS = "lists"
LIST_ITEMS = "list_items"
DRIVE_ITEMS = "drive_items"

warnings.filterwarnings("ignore")

parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
         "--file_path", default="filesystem.yaml", help="Path to the config.yaml file"
                )
args = parser.parse_args()
filesystem_config = args.file_path
with open(filesystem_config, 'r') as file:
    common_data = yaml.safe_load(file)


def get_results(logger, response, entity_name):
    """Attempts to fetch results from a Sharepoint Server response
    :param response: response from the sharepoint client
    :param entity_name: entity name whether it is SITES, LISTS, LIST_ITEMS OR DRIVE_ITEMS
    Returns:
        Parsed response
    """
    if not response:
        logger.error(f"Empty response when fetching {entity_name}")
        return None

    if entity_name == "attachment" and not response.get("d", {}).get("results"):
        logger.info("Failed to fetch attachment")
        return None
    return response.get("d", {}).get("results")


class SyncFileSystem:
    """This class allows syncing objects from the filesystem Server."""

    def __init__(
        self,
        config,
        logger,
        sync_type,
        start_time,
        end_time,
    ):
        self.config = config
        self.logger = logger

        self.objects = config.get("objects")
        self.sync_type = sync_type
        self.start_time = start_time
        self.end_time = end_time
        self.filesystem_thread_count = config.get("filesystem_sync_thread_count")
        self.file_extensions = config.get("file_extensions")
        self.seclore_api_url = config.get("seclore.seclore_api_url")
        self.doctype = common_data['chunks']['doctype']
        self.shared_path = config.get("shared_path")
        self.metadata_path = config.get("metadata_path")
        self.batch_size = config.get("batch_size")
        self.processor = config.get("num_of_processes")
        self.file_batch_size = config.get("file_batch_size")
        csv_file_path=config.get("file_batch_size")
        self.column_name=config.get("column_names")
        if not (config.get("projectid") is None):
            self.projectid = config.get("projectid")
        else:
            self.projectid =common_data['common']['appname'] + "_" + common_data['vector_db']['destination_name'] + "_" + config.get("type").replace('_','') + "_" + str(calendar.timegm(time.gmtime()))
       # self.projectid = config.get("projectid")
        self.type = config.get("type")
        current_time = datetime.now()
        self.job_id = calendar.timegm(current_time.timetuple())

    def fetch_filessytem_prop(self,url,input_type):
        responses = []
        if(input_type == 'local'):
            if os.path.isdir(url):
                folder_properties = []
                for first_lvl_file_name in os.listdir(url):
                    first_lvl_file_path = os.path.join(url, first_lvl_file_name)
                    if os.path.isfile(first_lvl_file_path):
                        responses.append(self.create_document(first_lvl_file_path,first_lvl_file_name))
                    else:
                         for second_lvl_file_name in os.listdir(first_lvl_file_path):
                             second_lvl_file_path = os.path.join(first_lvl_file_path, second_lvl_file_name)
                             if os.path.isfile(second_lvl_file_path):
                                responses.append(self.create_document(second_lvl_file_path,second_lvl_file_name))
                             else:
                                 for third_lvl_file_name in os.listdir(second_lvl_file_path):
                                     third_lvl_file_path = os.path.join(second_lvl_file_path, third_lvl_file_name)
                                     if os.path.isfile(third_lvl_file_path):
                                         responses.append(self.create_document(third_lvl_file_path,third_lvl_file_name))
                                     else:
                                         for fourth_lvl_file_name in os.listdir(third_lvl_file_path):
                                             fourth_lvl_file_path = os.path.join(third_lvl_file_path, fourth_lvl_file_name)
                                             if os.path.isfile(fourth_lvl_file_path):
                                                 responses.append(self.create_document(fourth_lvl_file_path,fourth_lvl_file_name))
        return responses
    
    def create_document(self, first_lvl_file_path, file_name):
        document = {}
        file_stat = os.stat(first_lvl_file_path)
        document["file_name"] = file_name
        document["file_size"] = str(file_stat.st_size)
        document["file_crt_date"] = datetime.fromtimestamp(os.path.getctime(first_lvl_file_path)).strftime('%Y-%m-%d %H:%M:%S')
        document["file_mod_date"] = datetime.fromtimestamp(os.path.getmtime(first_lvl_file_path)).strftime('%Y-%m-%d %H:%M:%S')
        document["file_acc_time"] = datetime.fromtimestamp(os.path.getatime(first_lvl_file_path)).strftime('%Y-%m-%d %H:%M:%S')
        document["file_path"] = first_lvl_file_path
        document["job_id"] = self.job_id
        document["projectid"] = self.projectid
        document["type"] = self.type
        return document
    
    def create_doc_ieee(self, first_lvl_file_path, file_name,current_time,sourcesize,rawsize):
        document = {}
        
        document["file_name"] = file_name
        document["file_size"] = sourcesize
        document["file_crt_date"] = current_time
        document["file_mod_date"] = current_time
        document["file_acc_time"] = current_time
        document["file_path"] = first_lvl_file_path
        document["job_id"] = self.job_id
        document["projectid"] = self.projectid
        document["type"] = self.type
       # document["meta_path"] = meta_path
        document["raw_filesize"] = rawsize
        #print("xml file",document)
        return document

    def create_doc_science_direct(self, first_lvl_file_path, file_name,current_time,sourcesize,rawsize):
        document = {}
        
        document["file_name"] = file_name
        document["file_size"] = sourcesize
        document["file_crt_date"] = current_time
        document["file_mod_date"] = current_time
        document["file_acc_time"] = current_time
        document["file_path"] = first_lvl_file_path
        document["job_id"] = self.job_id
        document["projectid"] = self.projectid
        document["type"] = self.type
       # document["meta_path"] = meta_path
        document["raw_filesize"] = rawsize
        # print("xml file",document)
        return document

    def create_doc_spie(self, first_lvl_file_path, file_name,current_time,sourcesize,rawsize):
        document = {}
        
        document["file_name"] = file_name
        document["file_size"] = sourcesize
        document["file_crt_date"] = current_time
        document["file_mod_date"] = current_time
        document["file_acc_time"] = current_time
        document["file_path"] = first_lvl_file_path
        document["job_id"] = self.job_id
        document["projectid"] = self.projectid
        document["type"] = self.type
       # document["meta_path"] = meta_path
        document["raw_filesize"] = rawsize
        # print("xml file",document)
        return document

    def process_files(self, files):
        try:
            # print("Thread id", str(threading.get_ident()))
            unique_string = str(uuid.uuid4())
            shared_path = self.shared_path
            # metadata_path=self.metadata_path
            # text_mapping=self.text_mapping
            json_path = os.path.join(
                shared_path,
                unique_string,
                "file_info.json",
            )
            json_response = []
            index = 0
            for i, _ in enumerate(files):
                index = i
                json_data = {}

                file_path=files[i]["file_path"]
                
                # with open(file_path, "r", encoding="utf-8") as file:
                #      content = file.read()
               # replaced_content = re.sub(r'&.*?;', '', content)
                #xml_content = replaced_content.encode('utf-8')
                #root = ET.fromstring(xml_content)
                #print(root)
                # xml_content = replaced_content.encode('utf-8')
                # root = ET.fromstring(xml_content)

                # xplore_article_id=root.find('.//xplore-article-id').text
                # xplore_issue=root.find('.//xplore-issue').text
                # xplore_pub_id=root.find('.//xplore-pub-id').text


                # Actual_meta_path=os.path.join(
                #         metadata_path,
                #         xplore_pub_id,
                #         xplore_issue,
                #         os.path.basename(file_path).replace('_ft','')
                #     )
                
                # file_path = files[i]["file_path"]

               # Actual_a_path = os.path.basename(file_path).replace('_ft','')
                #print("path of file", file_path)
                if file_path.endswith(".xml"):
                    print(file_path)
                
                meta_root = ET.parse(file_path).getroot()
                #print(Actual_a_path_path)  
                authors,coauthors=self.extract_authors_coauthors(meta_root)
                json_data['articleid'] = self.extract_articleid(meta_root)
                json_data['title'] = self.extract_title(meta_root)
                json_data['authors'] = authors 
                json_data['coauthors'] = coauthors      
                json_data['keywords'] = self.extract_keywords(meta_root)
                json_data['doctype']= self.extract_doctype(meta_root) 
                #need to be replaced from YAML file with doctype journal or conference
                json_data['pubtopicalbrowse'] = ''
                json_data['year'] = self.extract_year(meta_root)
                json_data['affiliation'] = self.extract_affiliations(meta_root)
                json_data['fileurl'] = f"https://doi.org/{json_data['articleid']}"
                json_data['raw_filesize'] = files[i]["raw_filesize"]       
                json_data["file_size"] = files[i]["file_size"]
                json_data["file_crt_date"] = files[i]["file_crt_date"]
                json_data["file_mod_date"] = files[i]["file_mod_date"]
                json_data["file_acc_time"] = files[i]["file_acc_time"]
                json_data["file_name"] = files[i]["file_name"]
                json_data["file_path"] = files[i]["file_path"]
                json_data["file_url"] = files[i]["file_path"] +json_data["file_name"]
                json_data["job_id"] = files[i]["job_id"]
                json_data["last_updated"]=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                if not (files[i].get("projectid") is None):
                    json_data["projectid"] = files[i]["projectid"]
                else:
                    json_data["projectid"] = files[i]["type"] + "_" + str(calendar.timegm(time.gmtime()))
                json_data["file_id"] = files[i]["file_path"]
                file_path = files[i]["file_path"]
                # with open(file_path, 'rb') as file:
                #     content = file.read()
                #     file_path_update = os.path.join(
                #         shared_path,
                #         unique_string,
                #         files[i].get("file_name"),
                #     )
                    #add source, filename, path, security, size
                content = ""
                file_metrics = [json_data["projectid"], json_data["job_id"], "FileSystem", json_data["file_name"], json_data["file_path"], json_data["file_size"],
                                common_data['common']['appname'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                write_to_file(file_path, content,file_metrics)
                json_data['shared_file_path'] = file_path
                json_response.append(json_data)
            write_json(json_path, json_response)
            main_call(json_path)
            return json_path

        except Exception as exception:
            self.logger.error(
                "Error while downloading the contents from the file at %s, Error %s"
                % (files[index].get("file_path"), exception)
            )
    def extract_articleid(self,meta_root):
        article_id =meta_root.find('.//article-id') 
        if article_id is not None:
            return article_id.text
        else:
            return ''
    def extract_title(self,meta_root):     
        article_title = meta_root.find('.//{*}article-title')
        if article_title is not None:
            return article_title.text
        else:
            return ''

    def extract_authors_coauthors(self,meta_root):
        authors = []
        coauthors = []

        for author in meta_root.findall('.//{*}contrib'):
            if author.find('.//{*}given-names') is not None:
                author_name = author.find('.//{*}given-names').text
                if author.find('.//{*}surname') is not None:
                    author_name += ' ' + author.find('.//{*}surname').text
                if author.get('corresp') == 'yes':
                    coauthors.append(author_name)
                else:
                    authors.append(author_name)
        return ', '.join(authors), ', '.join(coauthors)
    
    def extract_doctype(self,meta_root):     
        documenttype =meta_root.attrib['article-type']
        if documenttype is not None:
            return documenttype
        else:
            return 'science direct'
   
    def extract_affiliations(self,meta_root):
        affiliations = []
        for affiliation in meta_root.findall('.//{*}aff'):
            if affiliation.find('.//{*}label') is not None:
               
                affiliations.append(re.sub('\\n\\t\\t\\t\\t', '', affiliation.find('.//{*}label').tail))
        return '| '.join(affiliations)
    
    def extract_year(self,meta_root):
        yearnav = meta_root.find('.//{*}pub-date')
        if yearnav is not None:
            return yearnav.find('.//{*}year').text
        else:
            return None
    def extract_keywords(self,meta_root):
        keywords = []
        for keyword in meta_root.findall('.//{*}kwd'):
            if keyword is not None:
                keywords.append(keyword.text)
        return ', '.join(keywords)

    # def extract_number_from_filename(self,file_path, root):
    #     filename = file_path.split('/')[-1]
    #     number = re.search(r'\d+', filename)
    #     if number is not None:
    #         number = number.group().lstrip('0')
    #     else:
    #         number = None

    # def extract_article_number(self,meta_root):
    #     pii_unformatted = meta_root.find('.//{*}pii-unformatted')
    #     if pii_unformatted is not None:
    #         pii_text = pii_unformatted.text
    #     else:
    #         pii_text = None
    #     return pii_text
    
    # def extract_title(self,meta_root):
    #     title = meta_root.find('.//article/title')
    #     if title is not None:
    #         return title.text
    #     cetitle = meta_root.find('.//{*}title')
    #     if cetitle is not None:
    #         return cetitle.text
    #     else:
    #         return ''
    
    # def extract_authors(self, meta_root):
    #     authors = []
    #     if meta_root.findall('.//author'):
    #         for author in meta_root.findall('.//author'):
    #             role = author.get('role')
    #             if not role or role == 'author' or role == 'primary-author' or 'primary' in role:
    #                 author_name = author.find('nonnormname').text
    #                 authors.append(author_name)
    #     elif meta_root.findall('.//{*}author'):
    #         for author in meta_root.findall('.//{*}author'):
    #             given_name = author.find('.//{*}given-name')
    #             if given_name is not None:
    #                 author_name = given_name.text
    #                 surname = author.find('.//{*}surname')
    #                 if surname is not None:
    #                     author_name += ' ' + surname.text
    #                     authors.append(author_name)
    #     if not authors:
    #         return None
    #     return ', '.join(authors)
    
    # def extract_authors_science_direct(self,meta_root):
    #     authors = []
    #     for author in meta_root.findall('.//{*}author'):
    #         given_name = author.find('.//{*}given-name')
    #         if given_name is not None:
    #             author_name = given_name.text
    #             surname = author.find('.//{*}surname')
    #             if surname is not None:
    #                 author_name += ' ' + surname.text
    #                 authors.append(author_name)
    #     if not authors:
    #         return None
    #     return ', '.join(authors)
    
    
    # def extract_doctype(self,meta_root):   
    #     documenttype = meta_root.find('.//{*}document-type')
    #     if documenttype is  not None:
    #         return documenttype.text
    #     else:
    #         return 'science direct'



    # def extract_coauthors(self,meta_root):
    #     coauthors = []
    #     for coauthor in meta_root.findall('.//author[@role="coauthor"]'):
    #         coauthor_name = coauthor.find('nonnormname').text
    #         coauthors.append(coauthor_name)
    #     for coauthor in meta_root.findall('.//author[@role="corresponding"]'):
    #         coauthor_name = coauthor.find('nonnormname').text
    #         coauthors.append(coauthor_name)
    #     return ', '.join(coauthors)

    # def extract_keywords(self,meta_root):
    #     keywords = []
    #     for keyword in meta_root.findall('.//keywordterm'):
    #         keywords.append(keyword.text)        
    #     return ', '.join(keywords)

    # def extract_pubtopicalbrowse(self,meta_root):
    #     pubtopicalbrowsedata = []
    #     for pubtopicalbrowse in meta_root.findall('.//pubtopicalbrowse'):
    #         pubtopicalbrowsedata.append(str(pubtopicalbrowse.text))
            
    #     return ', '.join(pubtopicalbrowsedata)
    
    def count_files(directory):
        count = 0
        for root, dirs, files in os.walk(directory):
            count += len(files)
        return count
    
    
    
    
    num_files = 0
    def fetch_records_from_filesystem(self, thread_count, ids, url, input_type):

        global num_files
        st = time.time()
        tempbatchsize=0
        final_jsonpath=[]
        try:
            df = pd.read_csv(url)
            # print(df)
            print(f'processing batch :{tempbatchsize}')
            tempbatchsize=tempbatchsize+1
            documents = []
            """Fetch document properties from filesystem"""
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            filecounter=0
            for  row in df.itertuples():
                try:
                    
                    if row.Fulltextpath and row.sourcesize and row.rawsize:
                        # print(row.Fulltextpath,os.path.basename(row.Fulltextpath))
                        documents.append(self.create_doc_spie(row.Fulltextpath,os.path.basename(row.Fulltextpath),current_time,row.sourcesize,row.rawsize))
                        filecounter=filecounter+1
                except Exception as ex:
                    print(ex)         
            
            print(f"Actual Number of files to be indexed: {filecounter}") 
            new_lists = []
            # print(documents)
            for i in range(0, len(documents), 2):
                new_lists.append(documents[i:i+2])
            #print(new_lists)
            

            # multi processing
            json_path = []
            batch_size = int(self.file_batch_size)
            pool_object = Pool(self.processor)
            file_batches = [documents[i:i + batch_size] for i in range(0,len(documents), batch_size)]

            try:
            # Spawn threads
                json_path = pool_object.map(self.process_files, file_batches)
                pool_object.close()
                pool_object.join()
            except Exception as err:
                # Terminate the thread if failed
                pool_object.close()
                pool_object.join()
            final_jsonpath.append(json_path)
            et = time.time()
            print("time of execution", et - st)
            print(f'Total processed batch :{tempbatchsize}')
            #print("path of the json file", json_path)
            return final_jsonpath  # files
        except Exception as ex:
            self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")
