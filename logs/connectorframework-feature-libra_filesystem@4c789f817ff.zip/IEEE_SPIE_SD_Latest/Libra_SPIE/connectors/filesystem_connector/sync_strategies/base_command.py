import os
import time
import logging

try:
    from functools import cached_property
except ImportError:
    from cached_property import cached_property

from concurrent.futures import ThreadPoolExecutor, as_completed

from connectors.filesystem_connector.utils.local_storage import LocalStorage

LOG_PATH = os.path.join(os.path.dirname(__file__), "log.log")


class Parser:
    pass


class BaseCommand:
    """Base interface for all module commands.

    Inherit from it and implement 'execute' method, then add
    code to cli.py to register this command."""

    def __init__(self, config):
        self.config = config

    def execute(self):
        """Run the command.

        This method is overridden by actual commands with logic
        that is specific to each command implementing it."""
        raise NotImplementedError

    @cached_property
    def logger(self):
        """Get the logger instance for the running command.

        log level will be determined by the configuration
        setting log_level.
        """
        log_level = self.config.get("log_level")
        handler = logging.FileHandler(LOG_PATH)
        formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
        handler.setFormatter(formatter)

        # Add handler to logger
        logger = logging.getLogger(__name__)
        logger.addHandler(handler)
        logger.propagate = False
        logger.setLevel(log_level)

        return logger

    @staticmethod
    def producer(thread_count, func, args, items, wait=False, type=None):
        """Apply async calls using multithreading to the targeted function
        :param thread_count: Total number of threads to be spawned
        :param func: The target function on which the async calls would be made
        :param args: Arguments for the targeted function
        :param items: iterator of partition
        :param wait: wait until job completes if true, otherwise returns immediately
        """
        total_processed = 0
        start_time = time.time()
        with ThreadPoolExecutor(max_workers=thread_count) as executor:
            futures = []
            for thread_num, item in enumerate(items, start=1):
                total_processed += 1  # Increment the counter
                futures.append(executor.submit(func, *args, item))

            if wait:
                result = []
                if type == "drive_items":
                    for future in as_completed(futures):
                        result.extend(future.result())
                else:
                    result = [future.result() for future in as_completed(futures)]
                elapsed_time = time.time() - start_time  # Calculate elapsed time
                print("Elapsed Time: {:.2f} seconds".format(elapsed_time))
                return result

    @staticmethod
    def consumer(thread_count, func):
        """Apply async calls using multithreading to the targeted function
        :param thread_count: Total number of threads to be spawned
        :param func: The target function on which the async calls would be made
        """
        print("thread_count", thread_count)
        with ThreadPoolExecutor(max_workers=thread_count) as executor:
            for _ in range(thread_count):
                executor.submit(func)

    @cached_property
    def local_storage(self):
        """Get the object for local storage to fetch and update ids stored locally"""
        return LocalStorage(self.logger)
