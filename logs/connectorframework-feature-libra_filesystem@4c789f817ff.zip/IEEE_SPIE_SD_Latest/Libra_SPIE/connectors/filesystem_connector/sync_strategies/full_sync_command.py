from datetime import datetime

from .base_command import BaseCommand
from connectors.filesystem_connector.utils.connector_queue import ConnectorQueue
from connectors.filesystem_connector.utils.filesystem_helpers import SyncFileSystem
from connectors.filesystem_connector.utils.utils import split_date_range_into_chunks
from metrics.main_metrics import MetricsRun
from metrics.doc_metrics import Metrics
from indexing.cognitive_search import AzureSearchVectorStore
import argparse
import sys
import yaml

parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
         "--file_path", default="filesystem.yaml", help="Path to the config.yaml file"
                )
args = parser.parse_args()
filesystem_config = args.file_path

with open(filesystem_config, 'r') as file:
    config_data = yaml.safe_load(file)


class FullSync(BaseCommand):
    """This class start execution of fullsync feature of filesystem connector."""

    def fetch_filesystem_documents(self):
        """This method starts async calls for the producer which is responsible for fetching documents from
        the filesystem and pushing them in the shared queue
        :param queue: Shared queue to fetch the stored documents
        """
        self.logger.debug("Starting the file system full indexing..")
        self.sync_type = "full"
        current_time = (datetime.utcnow()).strftime("%Y-%m-%dT%H:%M:%SZ")
        time1 = datetime.now()
        thread_count = self.config.get("filesystem_sync_thread_count")
        start_time, end_time = self.config.get("start_time"), current_time
        indexing_status = 'Failure'
        try:
            sync_filesystem = SyncFileSystem(
                self.config,
                self.logger,
                self.sync_type,
                start_time,
                end_time,
            )
            # Iterate over all paths mentioned in yaml

            # for url in self.config.get("filesystem_path"):
            url=self.config.get("filesystem_path")
            
            storage_with_collection = (
                self.local_storage.get_storage_with_collection(url)
            )
            self.logger.info(
                "Starting to index all the objects configured in the object field: %s"
                % (str(url))
            )
            ids = storage_with_collection["global_keys"][url]
            files = sync_filesystem.fetch_records_from_filesystem(
                thread_count, ids, url, self.config.get("input_type")
            )
            indexing_status = 'Success'
            self.logger.info(
                f"Done fetching data from filesystem {thread_count}")
            return files
        except Exception as exception:
            self.logger.exception(
                f"Error while fetching the objects from filesystem . Error {exception}"
            )
            raise exception
        finally:
            collection_name = config_data['vector_db']['azure_cognitive_search_index_name']
            project_id = sync_filesystem.projectid if sync_filesystem.projectid else "N/A"
            job_id = sync_filesystem.job_id if  sync_filesystem.job_id else "N/A"
            documentCount = 0
            indexsize = 0
            time2 = datetime.now()
            processing_time = (time2 - time1).total_seconds() * 10**3   #execution time in ms
            time2 = time2.strftime('%Y-%m-%d %H:%M:%S')
            appname = config_data['common']['appname']
            file_metrics = [project_id, job_id, indexing_status, documentCount,  processing_time, indexsize, collection_name, appname, time2]
            MetricsRun().run_index_metrics(file_metrics)
        # self.local_storage.update_storage(storage_with_collection)

    def execute(self):
        """This function execute the start function of filesystem connector."""
        return self.fetch_filesystem_documents()
