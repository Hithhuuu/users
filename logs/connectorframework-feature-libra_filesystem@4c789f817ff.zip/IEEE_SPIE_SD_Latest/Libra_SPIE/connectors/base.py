import os
import sys
from abc import ABC, abstractmethod


class AbstractClass(ABC):

    def template_method(self) -> None:
        """
        The template method defines the skeleton of an algorithm.
        """
        return self.main()
        # self.method_second()

    @abstractmethod
    def main(self) -> None:
        pass

    # @abstractmethod
    # def method_second(self) -> None:
    #     pass