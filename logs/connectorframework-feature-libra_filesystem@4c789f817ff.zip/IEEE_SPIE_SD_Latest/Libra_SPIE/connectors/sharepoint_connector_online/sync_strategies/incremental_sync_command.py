class IncrementalSync:
    def __init__(self) -> None:
        print("Incremental Sync")
        pass
    pass