import time
import requests
import base64


from requests.exceptions import RequestException
from requests_ntlm import HttpNtlmAuth

from requests.exceptions import RequestException
from requests_ntlm import HttpNtlmAuth
from msal import ConfidentialClientApplication
from typing import  NamedTuple, Any,cast
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, pkcs12, PrivateFormat
from typing import  NamedTuple, Any,cast
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes

from utils import logger
from contextvars import ContextVar
import os
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
context = {}

class SharePoint:
    _Cert = NamedTuple("_Cert", [("pem_bytes", bytes), ("private_key", "Any"), ("fingerprint", bytes)]) 
    def __init__(self, config, logger):
        self.logger = logger
        self.retry_count = int(config.get("retry_count"))
        self.host = config.get("sharepoint.host_url")
        self.domain = config.get("sharepoint.domain")
        self.username = config.get("sharepoint.username")
        # self.password = config.get("sharepoint.password")
        self.password = base64.b64decode(config.get("sharepoint.password")).decode()
        self.secure_connection = config.get("sharepoint.secure_connection")
        self.certificate_path = config.get("sharepoint.certificate_path")
        self.batch_size = config.get("batch_size")
        self.spc_certificate_path = config.get("sharepoint.spc_certificate_path")
        self.spc_certificate_password = config.get("sharepoint.spc_certificate_password")
        self.spc_certificate_thumbprint = config.get("sharepoint.spc_certificate_thumbprint")
        self.authority = config.get("sharepoint.authority")
        self.spo_tenanat_name = config.get("sharepoint.spo_tenanat_name")
        # if not (config.get("sharepoint.crt_certificate_path") is None):
        self.crt_certificate_path = config.get("sharepoint.crt_certificate_path")
        self.file_extensions = config.get("file_extensions")

    def get(self, rel_url, query, param_name):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is sites, lists, list_items, drive_items, permissions or deindex
        Returns:
            Response of the GET call"""
        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        response_list = {"d": {"results": []}}
        paginate_query = True
        skip, top = 0, 500
        next_url = None
        next = True
        while next:
            if param_name in ["sites", "lists"]:
                if query is None or query == "":
                    paginate_query = f"?$top={top}"
                else:
                    paginate_query = query + f"&$top=5000"
            elif skip == 0 and param_name in ["list_items", "drive_items"]:
                paginate_query = query + f"&$top={top}"
            elif param_name in [
                "permission_users",
                "permission_groups",
                "deindex",
                "attachment",
            ]:
                paginate_query = query
            next_url = (
                next_url
                if next_url is not None
                else f"{self.host}/{rel_url}{paginate_query}"
            )
            print("URL", next_url)
            skip += 500
            retry = 0
            if self.secure_connection and self.certificate_path:
                verify = self.certificate_path
            else:
                verify = self.secure_connection
            while retry <= self.retry_count:
                try:
                    response = None
                    print("certificate_path",self.crt_certificate_path)
                    if self.domain == "SPO":
                        os.environ['REQUESTS_CA_BUNDLE' ] = os.path.join(self.crt_certificate_path)
                        f = open(self.spc_certificate_path, "rb")
                        certificate_data = f.read()
                        password = self.spc_certificate_password.encode("utf-8")
                        cert = self.load_pkcs12_certificate(certificate_data,password)
                        app = ConfidentialClientApplication(client_id=self.username,client_credential={"private_key": cert[0],
                          "thumbprint": self.spc_certificate_thumbprint},
                                                             authority=self.authority)
                        scopes = [f"https://{self.spo_tenanat_name}/.default"]
                        result = app.acquire_token_for_client(scopes=scopes)
                        token = result["access_token"]
                        request_headers = {
                                "accept": "application/json;odata=verbose",
                                "content-type": "application/json;odata=verbose",
                                "Authorization": f"Bearer {token}"
                            }
                        response = requests.get(
                                next_url,
                                headers=request_headers,
                                verify=False,
                            )
                        os.environ.pop("REQUESTS_CA_BUNDLE")
                    else:   
                        response = requests.get(
                        next_url,
                        auth=HttpNtlmAuth(
                            self.domain + "\\" + self.username, self.password
                        ),
                        headers=request_headers,
                        verify=verify,
                    )
                    if response.ok:
                        if param_name in ["sites", "lists"] and response:
                            response_data = response.json()
                            response_result = response_data.get(
                                "d", {}).get("results")
                            response_list["d"]["results"].extend(
                                response_result)
                            next = None
                            break
                        if param_name in ["list_items", "drive_items"] and response:
                            response_data = response.json()
                            response_list["d"]["results"].extend(
                                response_data.get("d", {}).get("results")
                            )
                            print(
                                "\nresponse_list\n",
                                response_data.get("d", {}).get(
                                    "__next", False),
                                len(response_list["d"]["results"]),
                            )
                            next_url = response_data.get(
                                "d", {}).get("__next", False)
                            if not next_url:
                                next = False
                            print("\nurl\n", next_url)
                            break

                        return response

                    if response.status_code >= 400 and response.status_code < 500:
                        if not (
                            param_name == "deindex" and response.status_code == 404
                        ):
                            app_log.exception(
                                f"Error: {response.reason}. Error while fetching from the sharepoint, url: {next_url}."
                            )
                        return response
                    app_log.error(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {response.reason}"
                    )
                    # This condition is to avoid sleeping for the last time
                    if retry < self.retry_count:
                        time.sleep(2**retry)
                    retry += 1
                    paginate_query = None
                    continue
                except RequestException as exception:
                    app_log.exception(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {exception}"
                    )
                    # This condition is to avoid sleeping for the last time
                    if retry < self.retry_count:
                        time.sleep(2**retry)
                    else:
                        return False
                    retry += 1
        if retry > self.retry_count:
            return response
        return response_list

    def download_file(self, file_url):
        try:
            if file_url.split(".")[-1] in self.file_extensions:
                request_headers = {
                "accept": "application/json;odata=verbose",
                "content-type": "application/json;odata=verbose",
                }
                app_log.info(f"Attempting to download {file_url}")
            # if (str(file_url).__contains__('General')):
                print("in if file_url",str(file_url))
                if self.secure_connection and self.certificate_path:
                    verify = self.certificate_path
                else:
                    verify = self.secure_connection
                requestUrl=f"{self.host}/{file_url}"
                if self.domain == "SPO":
                    os.environ['REQUESTS_CA_BUNDLE' ] = os.path.join(self.crt_certificate_path)
                    f = open(self.spc_certificate_path, "rb")
                    certificate_data = f.read()
                    password = self.spc_certificate_password.encode("utf-8")
                    cert = self.load_pkcs12_certificate(certificate_data,password)
                    app = ConfidentialClientApplication(client_id=self.username,
                                                        client_credential={"private_key": cert[0],
                                                                            "thumbprint": self.spc_certificate_thumbprint},
                                                                            authority=self.authority
                    )
                    scopes = [f"https://{self.spo_tenanat_name}/.default"]
                    result = app.acquire_token_for_client(scopes=scopes)
                    token = result["access_token"]
                    request_headers = {
                            "accept": "application/json;odata=verbose",
                            "content-type": "application/json;odata=verbose",
                            "Authorization": f"Bearer {token}"
                        }
                    response = requests.get(
                            requestUrl,
                            headers=request_headers,
                            verify=False,
                        )
                    os.environ.pop("REQUESTS_CA_BUNDLE")
                else:
                    response = requests.get(
                    file_url,
                    auth=HttpNtlmAuth(
                        f"{self.domain}\\{self.username}", self.password), headers=request_headers , verify=False
                )                
                return response
        except Exception as ex:
            app_log.exception(f"\nError downloading file: {ex}\n", extra=context)

    def get_data_batch(self, rel_url, query, param_name):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is sites, lists, list_items, drive_items, permissions or deindex
        Returns:
            Response of the GET call"""
        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        paginate_query = True
        top = 500
        if param_name in ["sites", "lists"]:
            if query is None or query == "":
                paginate_query = f"&$top={top}"
            else:
                paginate_query = query
        elif param_name in ["list_items", "drive_items"]:
            if query is None or query == "":
                paginate_query = f"&$top={top}"
            else:
                paginate_query = query
        elif param_name in [
            "permission_users",
            "permission_groups",
            "deindex",
            "attachment",
        ]:
            paginate_query = query

        url = f"{self.host}/{rel_url}{paginate_query}"
        # print("URL", url)

        retry = 0
        if self.secure_connection and self.certificate_path:
            verify = self.certificate_path
        else:
            verify = self.secure_connection
        try:
            response = None
            # print("domain",self.domain)
            if self.domain == "SPO":
                os.environ['REQUESTS_CA_BUNDLE' ] = os.path.join(self.crt_certificate_path)
                print("getting certificate from ",self.crt_certificate_path)
                print("opening the certificate file ",self.crt_certificate_path)
                f = open(self.spc_certificate_path, "rb")
                print("opened the certificate file ",self.crt_certificate_path)
                certificate_data = f.read()
                print("printing certificate data ",certificate_data)
                password = self.spc_certificate_password.encode("utf-8")
                cert = self.load_pkcs12_certificate(certificate_data,password)
                print("cert", cert)
                app = ConfidentialClientApplication(
                                client_id=self.username,
                                client_credential={"private_key": cert[0],
                                    "thumbprint": self.spc_certificate_thumbprint
                                                   },
                                authority=self.authority
                            )
                print("app", app)
                scopes = [f"https://{self.spo_tenanat_name}/.default"]
                print("scopes", scopes)
                result = app.acquire_token_for_client(scopes=scopes)
                token = result["access_token"]
                print("token", token)
                request_headers = {
                                "accept": "application/json;odata=verbose",
                                "content-type": "application/json;odata=verbose",
                                "Authorization": f"Bearer {token}"
                            }
                print("getting response Value")
                response = requests.get(
                                url,
                                headers=request_headers,
                                verify=verify,
                            )
                print("got response Value",response)
                os.environ.pop("REQUESTS_CA_BUNDLE")
            else:
                response = requests.get(
                    url,
                    auth=HttpNtlmAuth(self.domain + "\\" + self.username, self.password),
                    headers=request_headers,
                    verify=verify,
                )
                
        except Exception as ex:
             print("not able to read  certificate path",self.crt_certificate_path)
             self.logger.exception(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {ex}"
                    )
        if response.ok:
            if param_name in ["sites", "lists"]:
                print("param_name", param_name)
                response_data = response.json()
                response_result = response_data.get("d", {}).get("results")
                response_list = {"d": {"results": response_result}}
                return response_list
            elif param_name in ["list_items", "drive_items"]:
                print("next_url", param_name)
                response_data = response.json()
                response_list = {
                    "d": {"results": response_data.get("d", {}).get("results")}}
                next_url = response_data.get("d", {}).get("__next", False)
                return response_list
            else:
                return response
        elif response.status_code >= 400 and response.status_code < 500:
            if not (param_name == "deindex" and response.status_code == 404):
                app_log.exception(
                    f"Error: {response.reason}. Error while fetching from the sharepoint, url: {url}.")
            return response
        else:
            app_log.error(
                f"Error while fetching from the sharepoint, url: {url}. Retry Count: {retry}. Error: {response.reason}")
            return None
        
  
        
    def load_pkcs12_certificate(self,certificate_data: bytes, password: [bytes] = None) -> _Cert:
        try:
            private_key, cert, additional_certs = pkcs12.load_key_and_certificates(
                certificate_data, password, backend=default_backend()
            )
        except ValueError as ex:
        # mentioning PEM here because we raise this error when certificate_data is garbage
            raise ValueError("Failed to deserialize certificate in PEM or PKCS12 format") from ex
        if not private_key:
            raise ValueError("The certificate must include its private key")
        if not cert:
            raise ValueError("Failed to deserialize certificate in PEM or PKCS12 format")
        
         # This serializes the private key without any encryption it may have had. Doing so doesn't violate security
        # boundaries because this representation of the key is kept in memory. We already have the key and its
        # password, if any, in memory.
        key_bytes = private_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
        pem_sections = [key_bytes] + [c.public_bytes(Encoding.PEM) for c in [cert] + additional_certs]
        pem_bytes = b"".join(pem_sections)

        fingerprint = cert.fingerprint(hashes.SHA1())  # nosecreturn _Cert(pem_bytes, private_key, fingerprint)
        return self._Cert(key_bytes, private_key, fingerprint)
    
    def get_items_batch(self, rel_url, query, param_name, pageUrl=None):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is list_items, drive_items
        Returns:
            Response of the GET call"""
        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        paginate_query = True
        top = self.batch_size
        if param_name in ["list_items", "drive_items"]:
            if query is None or query == "":
                paginate_query = f"&$top={top}"
            else:
                paginate_query = query
        elif param_name in ["attachment"]:
            paginate_query = query

        if pageUrl is None:
            url = f"{self.host}/{rel_url}{paginate_query}"
        else:
            url = pageUrl
        # print("URL", url)

        retry = 0
        if self.secure_connection and self.certificate_path:
            verify = self.certificate_path
        else:
            verify = self.secure_connection
        try:
            response = None
            # print("domain",self.domain)
            if self.domain == "SPO":
                os.environ['REQUESTS_CA_BUNDLE'] = os.path.join(self.crt_certificate_path)
                f = open(self.spc_certificate_path, "rb")
                certificate_data = f.read()
                password = self.spc_certificate_password.encode("utf-8")
                cert = self.load_pkcs12_certificate(certificate_data,password)
                app = ConfidentialClientApplication(
                                client_id=self.username,
                                client_credential={"private_key": cert[0],
                                    "thumbprint": self.spc_certificate_thumbprint
                                                   },
                                authority=self.authority
                            )
                scopes = [f"https://{self.spo_tenanat_name}/.default"]
                result = app.acquire_token_for_client(scopes=scopes)
                token = result["access_token"]
                request_headers = {
                                "accept": "application/json;odata=verbose",
                                "content-type": "application/json;odata=verbose",
                                "Authorization": f"Bearer {token}"
                            }
                response = requests.get(
                                url,
                                headers=request_headers,
                                verify=verify,
                            )
                os.environ.pop("REQUESTS_CA_BUNDLE")
            else:
                response = requests.get(
                    url,
                    auth=HttpNtlmAuth(self.domain + "\\" + self.username, self.password),
                    headers=request_headers,
                    verify=verify,
                )
        except RequestException as exception:
             self.logger.exception(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {exception}"
                    )
        if response.status_code < 400:
            if param_name in ["list_items", "drive_items"]:
                response_data = response.json()
                response_list = {
                    "d": {"results": response_data.get("d", {}).get("results")}}
                next_url = response_data.get("d", {}).get("__next", False)
                return response_list, next_url
            else:
                return response, None
        elif response.status_code >= 400 and response.status_code < 500:
            if not (param_name == "deindex" and response.status_code == 404):
                app_log.exception(
                    f"Error: {response.reason}. Error while fetching from the sharepoint, url: {url}.")
            return response, None
        else:
            app_log.error(
                f"Error while fetching from the sharepoint, url: {url}. Retry Count: {retry}. Error: {response.reason}")
            return None, None

    @staticmethod
    def get_query(
        param_name, sync_type=None, filter=None, start_time=None, end_time=None
    ):
        """returns the query for each objects
        :param start_time: start time of the interval for fetching the documents
        :param end_time: end time of the interval for fetching the documents
        Returns:
            query: query for each object"""
        query = ""
        time_filter = f"(LastItemModifiedDate ge datetime'{start_time}') and (LastItemModifiedDate le datetime'{end_time}')"
        drive_time_filter = f"(Modified ge datetime'{start_time}') and (Modified le datetime'{end_time}')"
        if param_name == "sites":
            if sync_type == "full":
                query = f"?$filter=({filter})" if filter else ""
            else:
                query = (
                    f"?$filter={time_filter} and ({filter})"
                    if filter
                    else f"?$filter={time_filter}"
                )
        elif param_name == "lists":
            expand_str = "?$expand=RootFolder"
            if sync_type == "full":
                query = (
                    f"{expand_str}&$filter=({filter}) and (Hidden eq false)"
                    if filter
                    else f"{expand_str}&$filter=(Hidden eq false)"
                )
            else:
                query = (
                    f"{expand_str}&$filter={time_filter} and (Hidden eq false) and ({filter})"
                    if filter
                    else f"{expand_str}&$filter={time_filter} and (Hidden eq false)"
                )
        else:
            if sync_type == "full":
                query = f"&$filter=({filter})" if filter else ""
            else:
                query = (
                    f"&$filter={drive_time_filter} and ({filter})"
                    if filter
                    else f"&$filter={drive_time_filter}"
                )
        return query
