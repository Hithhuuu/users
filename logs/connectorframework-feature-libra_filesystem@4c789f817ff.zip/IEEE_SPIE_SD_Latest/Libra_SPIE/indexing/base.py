import os
import sys
from abc import ABC, abstractmethod


class AbstractClass(ABC):

    def template_method(self,chunked_docs) -> None:
        """
        The template method defines the skeleton of an algorithm.
        """
        try:
            self.method_first(chunked_docs)
        except Exception as e:
            raise Exception (e)

    @abstractmethod
    def method_first(self,chunked_docs) -> None:
        pass

    # @abstractmethod
    # def method_second(self) -> None:
    #     pass