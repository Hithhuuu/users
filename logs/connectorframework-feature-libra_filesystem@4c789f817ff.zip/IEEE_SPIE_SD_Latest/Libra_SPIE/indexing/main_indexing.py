from indexing.base import AbstractClass
from indexing.doc_indexing import Indexing

class IndexingRun():

    def run(self,chunked_docs):
        try:
            self.method_call(Indexing(),chunked_docs)
        except Exception as e:
            raise Exception (e)

    def method_call(self, abstract_class: AbstractClass,chunked_docs):
        try:
            abstract_class.template_method(chunked_docs)
        except Exception as e:
            raise Exception (e)