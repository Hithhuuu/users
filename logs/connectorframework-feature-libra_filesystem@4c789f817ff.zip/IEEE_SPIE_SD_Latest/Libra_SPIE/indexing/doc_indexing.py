import os
from indexing.base import AbstractClass
from langchain.docstore.document import Document
from indexing.cognitive_search import vector_store


class Indexing(AbstractClass):
    def __init__(self):
        # print("Indexing constructor created")
        pass

    def method_first(self,chunked_docs):
        # print("Indexing main method")
        try:
            docs = vector_store(chunked_docs)
            docs.process_blob_storage(chunked_docs)
        except Exception as e:
            raise Exception (e)