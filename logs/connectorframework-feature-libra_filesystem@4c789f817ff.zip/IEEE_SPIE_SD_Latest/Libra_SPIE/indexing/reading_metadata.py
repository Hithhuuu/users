import os
import yaml
import json
from azure.search.documents.indexes.models import SearchField, SearchFieldDataType, SimpleField, SearchableField
from langchain.docstore.document import Document
from utils import logger
from contextvars import ContextVar
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
context = {}
import argparse

parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
    "--file_path", default="config.yaml", help="Path to the config.yaml file"
)
args = parser.parse_args()
CONFIG_FILE = args.file_path

def get_env_config():
    """Return the config read from config.yaml file"""
    try:
        env = os.getenv("env")
        if env is None:
            env = "local"
        with open(CONFIG_FILE) as file:
            try:
                config = yaml.load(
                    file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader
                )
            except Exception as e:
                config = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
        return config
    except Exception as e:
        raise Exception(e)

# os.environ.update(config)
try:
    config = get_env_config()
except Exception as e:
    raise Exception (e)

filter_fields = config['vector_db'].get("filter_fields", [])
metadata_fields_list = config['vector_db'].get("metadata_fields", [])
mandatory_fields_list = config['vector_db'].get("mandatory_fields", [])
int_filed= config['vector_db'].get("int_filed", [])

# Define a dictionary with a key and multiple values
metadata_fields_list_key_value = {}
for field in metadata_fields_list:
    if ':' in field:
        values = field.split(':')
        metadata_fields_list_key_value[values[0]] = ", ".join(str(value) for value in values[1:]).split(',')
    else:
        metadata_fields_list_key_value[field] = [field]
      
mandatory_fields_list_key_value = {}        
for field in mandatory_fields_list:
    if ':' in field:
        values = field.split(':')
        mandatory_fields_list_key_value[values[0]] = ", ".join(str(value) for value in values[1:]).split(',')
    else:
        mandatory_fields_list_key_value[field] = [field]        

# Used for adding new columns to Schema if matches with metadata
separator_fields = config['vector_db'].get("separator_fields", [])


class ReadingMetadata:   

    def reading_metadata(self, file_path,filename):
        try:
            with open(file_path, 'r') as read_file:
                data = json.load(read_file)
                filtered_data = []
                for item in data:
                    if item['file_name'] == filename:
                        metadata_essentials = {}
                        for key, value in metadata_fields_list_key_value.items():
                            for metadata_name in value:
                                if metadata_name in item:
                                    metadata_essentials[key] = item[metadata_name]
                                    break
                                # Changes for ET indexing
                                # elif metadata_name in item.get('metadata'):
                                #     metadata_essentials[key] = item.get('metadata')[metadata_name]
                                #     break
                                metadata_essentials[key] = ""                            
                        filtered_data.append(
                            {
                                **item,
                                'metadata': {
                                    **metadata_essentials,
                                    **item.get('metadata', {})
                                }
                            }
                        )
            metadata = filtered_data[0]['metadata']
            context['Component'] = "Indexing"
            context['file_name'] = filename
            app_log.info('Reading Metadata from json file', extra=context)
            return metadata
        except Exception as e:
            raise Exception (e)
        
    def reading_mandatory(self, file_path,filename):
        try:
            with open(file_path, 'r') as read_file:
                data = json.load(read_file)
                filtered_data = []
                for item in data:
                    if item['file_name'] == filename:
                        metadata_essentials = {}
                        for key, value in mandatory_fields_list_key_value.items():
                            for metadata_name in value:
                                if metadata_name in item:
                                    metadata_essentials[key] = item[metadata_name]
                                    break
                                metadata_essentials[key] = ""                            
                        filtered_data.append(
                            {
                                **item,
                                'metadata': {
                                    **item.get('metadata', {}),
                                    **metadata_essentials   
                                }
                            }
                        )
            mandatory_fields = filtered_data[0]['metadata']
            context['Component'] = "Indexing"
            context['file_name'] = filename
            app_log.info('Reading mandatory_fields from json file', extra=context)
            return mandatory_fields
        except Exception as e:
            raise Exception (e)    

    def create_dynamic_schema(self,key, value, separator_fields):

        schema_config=[]
        try:    
            if key in separator_fields:
                schema_config.append(
                    SearchField(
                        name=key,
                        type=SearchFieldDataType.Collection(SearchFieldDataType.String),
                        searchable=True,
                        filterable=True
                    )
                )
            elif key in int_filed:
                schema_config.append(
                    SearchField(
                        name=key,
                        type=SearchFieldDataType.Int32,
                        searchable=False,
                        filterable=True
                    )
                )
            elif isinstance(value, int):
                schema_config.append(
                    SearchField(
                        name=key,
                        type=SearchFieldDataType.Int32,
                        searchable=False,
                        filterable=True
                    )
                )
            elif isinstance(value, str):
                schema_config.append(
                    SearchField(
                        name=key,
                        type=SearchFieldDataType.String,
                        searchable=True,
                        filterable=True
                    )
                )
            else:
                schema_config.append(
                    SearchField(
                        name=key,
                        type=SearchFieldDataType.String,
                        searchable=True,
                        filterable=True
                    )
                )
            return schema_config
        except Exception as e:  
            raise Exception (e)
        
    def define_dynamic_schema(self, schema, metadata):
        try:
            dynamic_schema = []
            for key, value in metadata.items():
                if key in filter_fields:
                    # print(key, '\t', type(value))
                    dynamic_schema.extend(self.create_dynamic_schema(key, value, separator_fields))
                        
            if len(dynamic_schema) > 0:
                schema.extend(dynamic_schema)
            # print(schema)
            return schema
        except Exception as e:
            raise Exception (e)