from __future__ import annotations
import argparse
import calendar
import datetime

import tiktoken
import yaml
import json
import os
from multiprocessing import Pool
from abc import ABC, abstractmethod
from typing import Optional, Any
import requests
# from connectors.main_connector import ConnectorRun
from chunking_method.main_chunking import ChunkingRun
from parsers.main_parser import ParserRun
from indexing.main_indexing import IndexingRun
from utils import logger
from contextvars import ContextVar
import time
from indexing.cognitive_search import get_env_config

import socket
from metrics.main_metrics import MetricsRun
import sys
from datetime import datetime


parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
    "--file_path", default="config.yaml", help="Path to the config.yaml file"
)
args = parser.parse_args()
file_path = args.file_path
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
index_time = None
index_list = []
index_total = 0

with open(file_path, 'r') as file:
    config_data = yaml.safe_load(file)

class Handler(ABC):
    @abstractmethod
    def set_next(self, handler: Handler) -> Handler:
        pass

    @abstractmethod
    def handle(self, request, data) -> Optional[str]:
        pass


class AbstractHandler(Handler):
    _next_handler: Handler = None

    def set_next(self, handler: Handler) -> Handler:
        self._next_handler = handler
        return handler

    @abstractmethod
    def handle(self, request: Any, data) -> str:
        if self._next_handler:
            return self._next_handler.handle(request, data)

        return None


class ParserHanlder(AbstractHandler):
    try:
        def handle(self, request: Any,  data: Any = None):
            if request == "Parser":
                parser = ParserRun()
                res = parser.run(data)
                return res
            else:
                return super().handle(request, data)
    except Exception as e:
            raise Exception (e)


class ChunkingHanlder(AbstractHandler):
    try:
        def handle(self, request: Any, data: Any) -> dict:
            if request == "Chunking":
                chunking = ChunkingRun()
                output = chunking.run(data)
                return output
            else:
                return super().handle(request, data)

    except Exception as e:
            raise Exception (e)


class IndexingHanlder(AbstractHandler):
    def handle(self, request: Any, data: Any = None) -> str:
        try:
            if request == "Indexing":
                indexing = IndexingRun()
                indexing.run(data)
            else:
                return super().handle(request, data)
        except Exception as e:
            raise Exception(e)

global file_metrics
file_metrics = []

def chain_call(handler: Handler, data, config_data):
    global index_time
    global index_total
    global index_list

    try:
        projectid = data['projectid']
    except Exception as e:
        projectid = config_data["connector"]["type"]  + "_" + str(calendar.timegm(time.gmtime()))

    try:
        dict_data = {
            "appname" : config_data['common']['appname'],
            "loadtype" : config_data['connector']['type'],
            "filename" : data['file_name'],
            "sourceurl" : data['file_url'],
            "jobid" : data['job_id'],
            "actual_filesize": int(data['file_size']),
            "file_id" : data['file_id'],
            "is_last" : data['is_last'],
            # ET config code  : 
            # "abstractfile_name":data['metadata'].get("abstractfileName"),
            # "abstractfile_url":data['metadata'].get("abstractfileUrl"),
            "isabstract": "false",
            "ispresentation": "true",
            
            "shared_file_path":data['shared_file_path']

        }
        indexing_time = 0
        chunk_size = 0
        status = ''
        chunk_status = 'Failure'
        parsing_status = 'Failure'
        indexing_status = 'Failure'
        raw_filesize = 0
        compression_ratio = 0
        total_tokens = 0
        cost = 0
        adi_cost = 0
        for component in ["Parser", "Chunking", "Indexing"]:
            context = {}
            context['component'] = component
            app_log.info(f"Running for component: {component}", extra=context)
            start_time = time.time()
            if component == 'Indexing' and index_time is None:
                index_time = time.time()
            if component == 'Indexing':
                if index_total >= get_env_config()['vector_db']['batch_limit'] or dict_data['is_last'] == True:
                    try:
                        output = handler.handle(component, data = index_list)
                        index_list.clear()
                        index_total = 0
                        indexing_time = (time.time() - index_time) * 1000
                        index_time = None
                        app_log.info(f"{component} component completed in {indexing_time}", extra=context)
                        MetricsRun().run_filestats_metrics(file_metrics)
                        file_metrics.clear()
                    except Exception as e:
                        app_log.info(f"Failed with error {str(e)}")
                        index_list.clear()
                        index_total = 0
                       # print('Exception in processing file ',data['file_name'])
                        # udpate the status as failed
                        for metric in file_metrics:
                            metric[15] = "Failed"
                        MetricsRun().run_filestats_metrics(file_metrics)
                        file_metrics.clear()
                        raise Exception (e)
                else :
                    output = None
            else:
                data['job_id'] = dict_data['jobid']
                output = handler.handle(component, data)

            # if ((output is None) or (len(list(output.values())[0]) == 0)) and component != 'Indexing':
            if ((output is None) or (isinstance(output, int) and output == 0)) and component != 'Indexing':
                dict_data['component'] = component
                if(os.path.basename(dict_data['shared_file_path'])==dict_data['filename'] and dict_data['ispresentation'] =='true' ):
                    
                    file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['filename'], dict_data['actual_filesize'], raw_filesize,
                    config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                    dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, indexing_status , config_data['common']['appname'],
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['sourceurl'], adi_cost]

                elif(dict_data.get('isabstract') is not None and os.path.basename(dict_data['shared_file_path'])!=dict_data['filename'] and dict_data['isabstract'] =='true' ):
                    
                    file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['abstractfile_name'], str(os.path.getsize(dict_data['shared_file_path'])), raw_filesize,
                    config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                    dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, indexing_status , config_data['common']['appname'],
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['abstractfile_url'], adi_cost]
                else:
                    file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['filename'], dict_data['actual_filesize'], raw_filesize,
                    config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                    dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, indexing_status , config_data['common']['appname'],
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['sourceurl'], adi_cost]


                file_metrics_issue = []
                #print("file",file_metric)
                file_metrics_issue.append(file_metric)
                MetricsRun().run_filestats_metrics(file_metrics_issue)
                return dict_data
            elif output is None:
                dict_data['component'] = component
                return dict_data

            if component in ["Parser", "Chunking"]:
                context['exec_time'] = (time.time() - start_time) * 1000
                if component == 'Parser':
                    dict_data['raw_filesize'] = output['raw_filesize']
                    parsing_status = 'Success'
                    compression_ratio = (int(data['file_size'])-int(output['raw_filesize']))*100/int(data['file_size'])
                    raw_filesize = output['raw_filesize']
                else:
                    dict_data['chunk_size'] = len(output['chunked_docs'])
                    index_list.append(output)
                    index_total = index_total + len(output['chunked_docs'])

                    chunk_status = 'Success'
                    for i in output['chunked_docs']:
                        encoding = tiktoken.get_encoding("cl100k_base")
                        num_tokens = len(encoding.encode(i["ParagraphText"]))
                        total_tokens += num_tokens
                    cost = (total_tokens * 0.0001) / 1000
                    if config_data['parser'].get("ADI_parser", False):
                        if(int(output['pages'])>0):
                            no_of_pages = int(output['pages'].split(',')[-1])
                        else:
                            no_of_pages=0
                        adi_cost = no_of_pages*0.009
                    
                    # actual_file='_'.join(os.path.basename(dict_data['shared_file_path']).split('_')[1:]) Used for ET changes needed
                    actual_file=os.path.basename(dict_data['shared_file_path'])
                    if(actual_file==dict_data['filename'] and dict_data['ispresentation'] =='true' ):
                    
                        file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['filename'], dict_data['actual_filesize'], raw_filesize,
                        config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                        dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, "Success", config_data['common']['appname'],
                                   datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['sourceurl'],adi_cost]
                    
                    elif(dict_data.get('isabstract') is not None and actual_file!=dict_data['filename'] and dict_data['isabstract'] =='true' and dict_data['isabstract'] ):
                        
                        file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['abstractfile_name'], str(os.path.getsize(dict_data['shared_file_path'])), raw_filesize,
                        config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                        dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, "Success", config_data['common']['appname'],
                                   datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['abstractfile_url'],adi_cost]
                        
                    else:
                        file_metric = [projectid, dict_data['jobid'], dict_data['file_id'], dict_data['filename'], dict_data['actual_filesize'], raw_filesize,
                        config_data['chunks']['type'], config_data['chunks']['chunksize'], compression_ratio , parsing_status, config_data['embeddings']['model'],
                        dict_data.get('chunk_size', 0), chunk_status, total_tokens, cost, "Success", config_data['common']['appname'],
                                   datetime.now().strftime('%Y-%m-%d %H:%M:%S'), dict_data['sourceurl'],adi_cost]

                    file_metrics.append(file_metric)
            data = output
            app_log.info(f"{component} component completed successfully", extra=context)

    except Exception as e:
        status = 'failed'
        dict_data['component'] = component
        error = {
            "error": e,
            "job_status": dict_data
        }
        raise Exception (error)
    finally:
        pass
        #print('finally')
        # file = open("C:\\Users\\x0131462\\Downloads\\css-indexing\\processing_stats.csv",'a')
        # file.write(dict_data['filename']+','+str(dict_data['actual_filesize'])+','+str(dict_data.get('raw_filesize', 0))+','+str(chunk_size)+','+str(indexing_time)+','+status+'\n')

def main_call(data):
    status = []

    parser = ParserHanlder()
    indexing = IndexingHanlder()
    chunking = ChunkingHanlder()

    parser.set_next(chunking).set_next(indexing)


    with open(data) as json_file:
        json_data = json.load(json_file)

    for i in json_data:
        if i == json_data[-1]:
            is_last = True
        else:
            is_last = False
        context = {}
        try:
            i['json_path'] = data
            i['is_last'] = is_last
            app_log.info("sending data to parser component", extra=context)
            if i.get('shared_file_path').split('.')[-1] in ['pdf','pptx','ppt','docs','doc','docx','txt','xlsx','csv','cs','xml','cpp','h','ectd','ecti','json']:
                context['file_name'] = i['file_name']
                context['actual_filesize'] = i['file_size']
                dit = chain_call(parser,i,config_data)
                dit['status'] = 'Success'
                context['component'] = dit['component']
                context['appname'] = dit['appname']
                context['file_name'] = dit['filename']
                context['jobid'] = str(dit['jobid'])
                context['actual_filesize'] = str(dit['actual_filesize'])

                context['raw_filesize'] = str(dit.get('raw_filesize', 0))
                context['record_count'] = str(dit.get('chunk_size', 0))
                context['status'] = dit['status']
                app_log.info(f"Task completed for {dit['filename']}", extra=context)
                status.append(dit)
        except Exception as e:
            app_log.info("Exception occurred while processing the file : ",str(e))
            dit = e.args[0].get('job_status')
            dit['status'] = 'Failure'
            context['component'] = dit['component']
            context['appname'] = dit['appname']
            context['file_name'] = dit['filename']
            context['jobid'] = str(dit['jobid'])
            context['actual_filesize'] = str(dit['actual_filesize'])
            context['raw_filesize'] = str(dit['raw_filesize']) if 'raw_filesize' in dit.keys() else None
            context['status'] = dit['status']
            app_log.info(f"Task failed for {dit['filename']}", extra=context)
            status.append(dit)

    if index_total > 0:
        indexing.handle("Indexing", index_list)
    # url = "http://dcilpb1805/dev/test/update_status"
    # payload = {
    #     "batch": status
    # }
    # response = requests.post(url, json=payload)




