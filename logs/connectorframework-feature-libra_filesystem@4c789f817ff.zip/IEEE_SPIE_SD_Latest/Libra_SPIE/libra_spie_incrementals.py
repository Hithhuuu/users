import glob
import os
import sqlite3
import csv
import yaml
from utils import logger
from contextvars import ContextVar
import time

import json
import csv
import requests
import re
import datetime
import shutil
import yaml
import pandas as pd
from requests.auth import HTTPBasicAuth
from fastapi import APIRouter, Request
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from bs4 import BeautifulSoup
from connectors.main_connector import ConnectorRun
from requests.auth import HTTPBasicAuth
import xml.etree.ElementTree as ET



def read_yaml(file_path):
    if file_path is None:
        raise ValueError("Invalid file path")
    with open(file_path, 'r') as yaml_file:
        config = yaml.safe_load(yaml_file)
    return config

folder_path = "/path"
main_folder_paths = [
    folder_path + r"/libra_SD/libra-incremental/",
    folder_path + r"/libra_SD/csv/",
]

for folder_path in main_folder_paths:
    os.makedirs(folder_path, exist_ok=True)
for folder_path in main_folder_paths:
    os.makedirs(folder_path, exist_ok=True)

# Example usage
NAS_PATH = "/libra_SD/libra_SD/libra_incremental/"
USERNAME = "chatgptkb"
PASSWORD = "dkO3+aZYD8W"

dir_path = os.path.dirname(os.path.abspath(__file__))
# CONFIG_PATH = os.path.join(dir_path, "connectors\Libra_SPIE\config_libra_spie_file_system_incrementals.yaml")


yaml_files = glob.glob(os.path.join(dir_path, "**", "*.yaml"), recursive=True)

CONFIG_PATH = next((f for f in yaml_files if os.path.basename(f) == "config_libra_spie_file_system_incremental.yaml"), None)


def extract_json_data(url, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
 
    if response.status_code == 200:
        try:
            json_data = response.json()
            return json_data
        except ValueError as e:
            print("Error parsing JSON:", e)
    else:
        print("Error:", response.status_code)
 
 
def download_content(url, save_path, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
    if response.status_code == 200:
        with open(save_path, "wb") as file:
            file.write(response.content)
        print("Content downloaded successfully.")
    else:
        print(f"Failed to download content. Status Code: {response.status_code}")
 
 
 
# def flat_dir(root_dir):
#     subfolders = [f.path for f in os.scandir(root_dir) if f.is_dir()]
#     for subfolder in subfolders:
#         subfolder_name = os.path.basename(subfolder)
#         for file_name in os.listdir(subfolder):
#             if file_name.endswith('.txt') or file_name.endswith('.json') or file_name.endswith('.pdf'):
#                 file_path = os.path.join(subfolder, file_name)
#                 new_file_name = subfolder_name + '_' + file_name
#                 new_file_path = os.path.join(root_dir, new_file_name)
#                 shutil.move(file_path, new_file_path)
 

def delete_file(directory_path):
    if os.path.exists(directory_path):
        shutil.rmtree(directory_path)
        print(f"The directory {directory_path} has been deleted.")
    else:
        print(f"The directory {directory_path} does not exist.")


def check_updated_files(file_path, reference_time, endpoint, index_name, api_key):
    file_modified_time = os.path.getmtime(file_path)
    modified_datetime = datetime.datetime.fromtimestamp(file_modified_time)
    if modified_datetime > reference_time:
        print("File {} has been updated.".format(file_path))

        update_file_in_azure(file_path, endpoint, index_name, api_key)
        
    else:
        print("File {} has not been updated.".format(file_path))

def get_file_size(file_path):
    return os.path.getsize(file_path)

CSV_FILENAME = 'updated_latest_data.csv'
CSV_QUOTECHAR = '"'

def libra_spie_incremental(folder_path, endpoint, index_name, api_key, time_delay):
    files = [os.path.join(root, name)
             for root, dirs, files in os.walk(folder_path)
             for name in files
             if name.endswith(".xml")]
    file_created_time = [(file_path, os.path.getctime(file_path))
                         for file_path in files]
    current_time = datetime.datetime.now()
    reference_time = current_time - datetime.timedelta(seconds=time_delay)
    
    if files and file_created_time:
        latest_modified_file = max(file_created_time, key=lambda x: x[1])
        if datetime.datetime.fromtimestamp(latest_modified_file[1]) > reference_time:
            print("Files need to be updated")
            check_updated_files(latest_modified_file[0], reference_time, endpoint, index_name, api_key)
        
        for file, created_time in file_created_time:
            file_name = os.path.basename(file)
            if is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
                delete_file_from_azure(file_name, endpoint, index_name, api_key)
            if not is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
                new_files = [file[0] for file in file_created_time if datetime.datetime.fromtimestamp(file[1]) > reference_time]
        
        if new_files:
            data = []
            if os.path.isfile(CSV_FILENAME):
                with open(CSV_FILENAME, 'r') as csv_file:
                    csv_reader = csv.reader(csv_file, delimiter=',', quotechar=CSV_QUOTECHAR)
                    data = list(csv_reader)
            updated_data = []
            for row in data:
                if row and row[0] in new_files:
                    file_path = os.path.join(folder_path, row[0])
                    sourcesize = get_file_size(file_path)
                    tree = ET.parse(file_path)
                    root = tree.getroot()
                    rawsize = len(ET.tostring(root))
                    latest_modified_file_time_stamp = next(file[1] for file in file_created_time if file[0] == row[0])
                    updated_row = [row[0], str(sourcesize), str(rawsize), str(latest_modified_file_time_stamp)]
                    new_files.remove(row[0])
                    updated_data.append(updated_row)
                else:
                    updated_data.append(row)
            for new_file in new_files:
                file_path = os.path.join(folder_path, new_file)
                sourcesize = get_file_size(file_path)
                tree = ET.parse(file_path)
                root = tree.getroot()
                rawsize = len(ET.tostring(root))
                latest_modified_file_time_stamp = next(file[1] for file in file_created_time if file[0] == new_file)
                updated_data.append([new_file, str(sourcesize), str(rawsize), str(latest_modified_file_time_stamp)])
            
            with open(CSV_FILENAME, 'w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file, delimiter=',', quotechar=CSV_QUOTECHAR, quoting=csv.QUOTE_MINIMAL)
                csv_writer.writerows(updated_data)
            # Call the connector to update the new files
            for data in updated_data:
                if data is not None:
                    config = read_yaml(CONFIG_PATH)
                    Connector = ConnectorRun(config.get("connector"))
                    Connector.filesystem_run()                
        else:
            print("No new files found")
    else:
        print("No files found in the folder.")

        
def is_file_existing_in_azure(file_name, endpoint, index_name, api_key):
    credential = AzureKeyCredential(api_key)
    client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)
    filter_condition = "filename eq '{}'".format(file_name)
    response = client.search(search_text="", filter=filter_condition)
    results = list(response)
    return len(results) > 0

def delete_file_from_azure(file_name, endpoint, index_name, api_key):
    credential = AzureKeyCredential(api_key)
    client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)
    filter_condition = "filename eq '{}'".format(file_name)
    response = client.search(search_text="", filter=filter_condition)
    updated_documents = []
    for result in response:
        updated_document = {
            "id": result["id"],
        }
        updated_documents.append(updated_document)
    if len(updated_documents) > 0:
        client.delete_documents(updated_documents)

def update_file_in_azure(file_path, endpoint, index_name, api_key):
    credential = AzureKeyCredential(api_key)
    client = SearchClient(endpoint=endpoint, index_name=index_name, credential=credential)
    with open(file_path, "r") as file:
        content = file.read()
    document = {
        "id": os.path.basename(file_path),
        "content": content
    }
    client.upload_documents(documents=[document])

# endpoint = "https://az-cogsearch-uswst3-dev-openai01.search.windows.net"
# index_name = "science-direct-spie-v2"
# api_key = "6L22P7O2GhqPrOnYfA22sGN8QwMOgllOAtnmpAJSTQAzSeACocFY"

# libra_spie_incremental(folder_path, endpoint, index_name, api_key)


# def libra_incremental(self):
#      folder_path = 'C:\\Users\\x0150217\\Downloads\\xml_files_data'
#      latest_modified_file = None
#      latest_timestamp = 0
#      CONFIG_PATH = "connectors\\config_et_libra_science_direct_file_system_incremental.yaml"
#      CSV_PATH = "Sciencedirect-2024.csv"
#      context_vars = ContextVar('context', default={})
#      app_log = logger.getLogger(context_vars.get())
#      files = glob.glob(os.path.join(folder_path, '*.xml'))
#      if files:
#         for file in files:
#             timestamp = os.path.getmtime(file)
#             if timestamp > latest_timestamp:
#                 latest_timestamp = timestamp
#                 latest_modified_file = file
#             if latest_modified_file:
#                 app_log.info("Latest modified file")
#                 app_log.info("Latest modified file: %s", latest_modified_file)
#                 older_files_exist = len(files) > 1
#             if older_files_exist:
#                 app_log.info("Older files exist.")
#             else:
#                     app_log.info("No older files found.")
            
#                 # log_file_path = 'logs\\connectorframework.log'
#                 # file_already_read = False
#                 # with open(log_file_path, 'r') as log_file:
#                 #     for line in log_file:
#                 #         if latest_modified_file in line:
#                 #             file_already_read = True
#                 #             break
#                 # try:
#                 #     conn = db_connection()
#                 #     cursor = conn.cursor()
#                 #     cursor.execute("SELECT * FROM filestats_metrics WHERE fileid = %s", (latest_modified_file,))
#                 #     if cursor.fetchone():
#                 #         file_already_read = True
#                 #         os.remove(latest_modified_file)
#                 #         app_log.info("Duplicate file deleted.")
#                 #         cursor.execute("DELETE FROM filestats_metrics WHERE fileid = %s", (latest_modified_file,))
#                 #         conn.commit()
#                 #         app_log.info("Duplicate entry removed from the database.")
#                 #     else:
#                 #         cursor.execute("INSERT INTO filestats_metrics (fileid) VALUES (%s)", (latest_modified_file,))
#                 #         conn.commit()
#                 #         app_log.info("File marked as read in the database.")
#                 #     conn.close()
#                 # except Exception as e:
#                 #     app_log.error(e)
#                 # if file_already_read:
#                 #     app_log.info("The latest modified file has already been read.")
#                 # else:
#                 #     app_log.info("The latest modified file has not been read yet.")
#                 # Read YAML configuration file
#             config = self.read_yaml(CONFIG_PATH)
#             file_system_path = config.get("file_system_path")
#             Connector = ConnectorRun(config.get("connector"))
#             Connector.filesystem_run()
#             if file_system_path:
#                     # Construct the full file path using the file_system_path
#                 latest_modified_file = os.path.join(file_system_path, latest_modified_file)
#                 # Read CSV file
#             csv_files = self.read_csv(CSV_PATH)
#             if latest_modified_file not in csv_files:
#                     # Write the file path to the CSV file
#                 with open(CSV_PATH, 'a') as csv_file:
#                     csv_writer = csv.writer(csv_file)
#                     csv_writer.writerow([latest_modified_file])

# def delete_article_data(file_name):
#     endpoint = "https://az-cogsearch-uswst3-dev-openai01.search.windows.net"
#     index_name = "science-direct-rag-v2"
#     api_version = "2020-06-30"
  
#     api_key = "6L22P7O2GhqPrOnYfA22sGN8QwMOgllOAtnmpAJSTQAzSeACocFY"

#     credential = AzureKeyCredential(api_key)
#     client = SearchClient(
#         endpoint=endpoint, index_name=index_name, credential=credential
#     )

#     updated_documents = []
#     filter_condition = "filename eq '{}'".format(file_name)
#     response = client.search(search_text="", filter=filter_condition)
#     for result in response:
#         updated_document = {
#             "id": result["id"],
#         }
#         updated_documents.append(updated_document)
#     if len(updated_documents) > 0:
#         client.delete_documents(updated_documents)
#     print("Documents updated successfully.")