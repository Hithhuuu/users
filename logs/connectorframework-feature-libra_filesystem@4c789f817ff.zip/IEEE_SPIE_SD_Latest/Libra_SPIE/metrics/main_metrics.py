import csv
from metrics.base import AbstractClass
from metrics.doc_metrics import Metrics

class MetricsRun():

    def run(self,file_metrics):
        try:
            self.method_call(Metrics(),file_metrics)
        except Exception as e:
            raise Exception (e)
        
    def run_source_metrics(self, file_metrics):
        try:
            data = Metrics().source_metrics(file_metrics)   
        except Exception as e:
            raise Exception(e)

    def run_filestats_metrics(self, file_metrics):
        try:
            
            data = Metrics().filestats_metrics(file_metrics)
        except Exception as e:
            raise Exception(e)
        
    def run_filestats_metric(self, file_metric):
        try:
            
            data = Metrics().filestats_metric(file_metric)
        except Exception as e:
            raise Exception(e)

    def run_index_metrics(self, file_metrics):
        try:
            data = Metrics().indexing_metrics(file_metrics)
        except Exception as e:
            raise Exception(e)

    def method_call(self, abstract_class: AbstractClass,file_metrics):
        try:
            abstract_class.template_method(file_metrics)
        except Exception as e:
            raise Exception (e)