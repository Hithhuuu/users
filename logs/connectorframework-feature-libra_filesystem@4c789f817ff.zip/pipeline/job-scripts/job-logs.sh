#!/bin/bash

echo "Below are the resource info for this service..."
sh ./pipeline/scripts/oc-cmd-exec.sh get all | grep $SERVICE_NAME

JOB_NAME="connector-svc-job"

POD_NAME=$(sh ./pipeline/scripts/oc-cmd-exec.sh get pods --selector=job-name=$JOB_NAME --output=jsonpath='{.items[*].metadata.name}')

if [[ -z $POD_NAME ]]; then
  echo "No pod found for job: $JOB_NAME"
  exit 1
fi
sh ./pipeline/scripts/oc-cmd-exec.sh logs pod/"$POD_NAME" -f