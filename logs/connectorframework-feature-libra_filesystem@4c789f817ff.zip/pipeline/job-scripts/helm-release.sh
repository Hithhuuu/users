#!/bin/sh

echo 'Generating helm command'

if [ -z "${NAMESPACE}" ] || [ -z "${SERVICE_NAME}" ] || [ -z "${SOURCE_REPOSITORY_URL}" ] || [ -z "${SOURCE_REPOSITORY_REF}" ]; then
  echo "Value override env variables are missing..exiting with error."
  exit 1
fi

APP_VERSION=$SERVICE_NAME-1.$BUILD_NUMBER

PARAMS="--set namespace=$NAMESPACE \
     --set fullnameOverride=$SERVICE_NAME \
     --set buildConfig.sourceRepoUrl=$SOURCE_REPOSITORY_URL \
     --set buildConfig.sourceRepoRef=$SOURCE_REPOSITORY_REF \
     --set resources.limits.cpu=$CPU_LIMIT \
     --set resources.limits.memory=$MEMORY_LIMIT \
     --set environment=$ENVIRONMENT \
     --set job.labels.appVersion=$APP_VERSION \
     --set dockerRepo=$DOCKER_REPO/"

if [ ! -z "${POD_REPLICAS}" ]; then
  PARAMS="$PARAMS --set deploymentConfig.replicaCount=${POD_REPLICAS} \
        --set autoscaling.minReplicas=${POD_REPLICAS}"
  if [ ! -z "${POD_MAX_REPLICAS}" ]; then
    PARAMS="$PARAMS --set autoscaling.maxReplicas=${POD_MAX_REPLICAS}"
  else
    PARAMS="$PARAMS --set autoscaling.maxReplicas=${POD_REPLICAS}"
  fi
else
  PARAMS="$PARAMS --set deploymentConfig.replicaCount=1 --set autoscaling.minReplicas=1"
  if [ ! -z "${POD_MAX_REPLICAS}" ]; then
    PARAMS="$PARAMS --set autoscaling.maxReplicas=${POD_MAX_REPLICAS}"
  else
    PARAMS="$PARAMS --set autoscaling.maxReplicas=1"
  fi
fi

CMD="helm upgrade --install $SERVICE_NAME $1 "

if [ "$ENVIRONMENT" = "prod" ]; then
  PHASE="1"
  if [ ! -z "$PROJECT_PHASE" ]; then
    PHASE="$PROJECT_PHASE"
  fi
  PARAMS="$PARAMS --set deploymentConfig.container.image.tag=rel_$PHASE.$BUILD_NUMBER"
fi

GENERIC_EXTRA_VALUES=./pipeline/variables/extras/generics-$ENVIRONMENT.yml
if [ -e "$GENERIC_EXTRA_VALUES" ]; then
  PARAMS="${PARAMS} -f $GENERIC_EXTRA_VALUES"
fi

EXTRA_VALUES=./pipeline/variables/extras/$SERVICE_NAME-$ENVIRONMENT.yml
if [ -e "$EXTRA_VALUES" ]; then
  PARAMS="${PARAMS} -f $EXTRA_VALUES"
fi

#OCP3 URLs need tls certificates based on environment
if [ "$QA_OCP" = "true" ]
then
    TLS_VALUES=/home/bhprd/values-tls-$ENVIRONMENT-ocp.yml
    if [ ! -z "${MIGRATED}" ]; then
       PARAMS="${PARAMS} -f $TLS_VALUES"
    fi
else  
   TLS_VALUES=/home/bhprd/values-tls-$ENVIRONMENT.yml
   if [ ! -z "${MIGRATED}" ]; then
      PARAMS="${PARAMS} -f $TLS_VALUES"
   fi
fi
# SECRETS FILE via JENKINS CREDENTIALS FILE
if [ -e "$SECRETS_FILE" ]; then
  if [ -e ./secrets.yml ]; then
    rm ./secrets.yml
  fi
  cp $SECRETS_FILE ./secrets.yml
  PARAMS="${PARAMS} -f ./secrets.yml"
fi

if [ "$HELM_DRY_RUN" = "true" ]; then
  PARAMS="${PARAMS} --dry-run"
fi

CMD="$CMD $PARAMS"

sh ./pipeline/scripts/oc-login.sh
echo "switching to the project..."
oc project "$NAMESPACE"
echo "running helm dependency update"
helm dep up "${1}"

echo "check if helm diff plugin exists"
if helm plugin list | grep diff; then
  echo "helm diff plugin exists, compare the changes before running helm upgrade.."
  HELM_DIFF_CMD="helm diff upgrade $SERVICE_NAME $1 $PARAMS --allow-unreleased"
  echo "Running helm diff CMD: $HELM_DIFF_CMD"

  HELM_DIFF_RESPONSE=$(eval "$HELM_DIFF_CMD")
  if [ $? -eq 0 ]; then
    if [ -z "$HELM_DIFF_RESPONSE" ]; then
      echo "no differences found..exiting"
      exit 0
    else
      echo "Helm differences found: $HELM_DIFF_RESPONSE"
      echo "continue to perform helm upgrade"
    fi
  else
    echo "Error response from helm diff command, continue to perform helm upgrade/install"
  fi
else
  echo "helm diff plugin does not exist. Cannot compare the upgrade changes, no other option except to perform release. Install helm diff plugin to improve this feature!!"
fi

set -e

echo "Running CMD: $CMD"
eval "$CMD"
sh ./pipeline/scripts/oc-logout.sh