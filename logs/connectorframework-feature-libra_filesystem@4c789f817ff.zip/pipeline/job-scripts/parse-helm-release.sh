#!/bin/bash
set -xe
sed -i '9iAPP_VERSION=$SERVICE_NAME-1.$BUILD_NUMBER' ./pipeline/scripts/helm-release.sh

sed -i '16i--set job.labels.appVersion=$APP_VERSION \\' ./pipeline/scripts/helm-release.sh

cat ./pipeline/scripts/helm-release.sh