#!groovy
def call(Map pipelineParams) {

    pipeline {
         agent {
            node {
                label "A2V-OCP-BUILDHOST"
            }
        }
        stages {
            stage("Initialize") {
                steps {
                    script {
                        def envfile = ""
                        env.SERVICE_NAME = "${pipelineParams.serviceName}"
                        env.SERVICE_CONTEXT_DIR = "${pipelineParams.serviceContextDir}"
                        env.DOCKERFILE = "${pipelineParams.dockerFile}"
                        env.TECHNOLOGY = "${pipelineParams.technology}"
                        switch(GIT_BRANCH) {
                            case "origin/release/dev":
                            case "origin/release/dev-aro":
                                envfile = "dev-op-env.yml"
                                break
                            case "origin/release/qa":
                                envfile = "qa-env.yml"
                                break
                            case "origin/feature/metrics_data_reconciliation":
                                envfile = "dev-op-env.yml"
                                break    
                            case "origin/release/prod":
                                envfile = "prod-env.yml"
                                break
                            default:
                                envfile = ""
                                break
                        }
                        def props = readYaml file: "./pipeline/variables/${envfile}"
                    for (elem in props)
                            env."${elem.key}" = elem.value                    
                    }
                    sh "sh ./pipeline/download-scripts.sh"
                }
                
            }
            stage("Build Docker Img & Push to Jfrog") {
                steps {
                      sh 'ls -lrt'
                      echo "Context Dir= ${SERVICE_CONTEXT_DIR}"
                      sh "sh ./pipeline/scripts/docker-build.sh"
                }
            }
            stage("OCP HELM Release") {
                steps {
                        sh "sh ./pipeline/scripts/create-namespace.sh"
                        sh "sh ./pipeline/job-scripts/helm-release.sh ./pipeline/helm/${SERVICE_NAME}"
                        // sh "sh ./pipeline/scripts/helm-release.sh ./pipeline/helm/${SERVICE_NAME}"
            }
            }
//             stage("Job Log") {
//                 steps {
//                     sh "sh ./pipeline/job-scripts/job-logs.sh"
//                 }
//             }
            stage("Git Tag") {
                when {
                    expression {
                        return GIT_BRANCH == 'origin/release/qa' || GIT_BRANCH == 'origin/release/prod'
                    }
                }
                steps {
                    sh "sh ./pipeline/scripts/git-tag.sh"
                }
            }
        }
    }
}

return this
