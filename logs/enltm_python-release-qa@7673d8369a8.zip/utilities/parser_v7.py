import os
import re
import sys
import json
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.utils import get_logger, get_column_details

app_log = get_logger("parserv7")


async def process_header_meta_v7(records):
    meta_dict_v7 = {}
    pattern = re.compile(r"[\"]")
    pattern_2 = re.compile(r"[^a-zA-Z0-9-\w]")
    for i, j in records.items():
        if i == "FileVersion":
            meta_dict_v7[i] = ".".join([str(elem) for elem in j.split()])
        if i == "InspectionStationID":
            meta_dict_v7[i] = re.sub(
                pattern, "", " ".join([str(elem) for elem in j.split()[1:]])
            )
        if i in ["ResultTimestamp", "FileTimestamp"]:
            meta_dict_v7[i] = j
        if i in ["DeviceID", "StepID", "LotID", "WaferID"]:
            j = re.sub(pattern, "", j)
            meta_dict_v7[i] = re.sub(pattern_2, "", j)

        if i in ["DiePitch", "SampleCenterLocation", "DieOrigin"]:
            meta_dict_v7[i] = ",".join([str(elem) for elem in j.split()])
        if i in [
            "Slot",
            "SampleOrientationMarkType",
            "OrientationMarkLocation",
            "SampleType",
            "TiffFileName",
        ]:
            meta_dict_v7[i] = j
        if i == "SampleSize":
            meta_dict_v7[i] = j.split()[-1]
        if i == "SetupID":
            j = re.sub(pattern, "", j.split()[0])
            meta_dict_v7[i] = re.sub(pattern_2, "", j)
    return meta_dict_v7


async def microns_to_nm(main_df, meta_data):
    app_log.info("Converting microns to nm.")
    meta_data["DiePitch"] = ",".join(
        [str(float(i) * 1000) for i in meta_data.get("DiePitch").split(",")]
    )
    meta_data["SampleCenterLocation"] = ",".join(
        [str(float(i) * 1000) for i in meta_data.get("SampleCenterLocation").split(",")]
    )
    meta_data["SampleSize"] = str(int(meta_data["SampleSize"]) * 1000000)
    change_dict = {"xrel": float, "yrel": float, "dsize": float}
    main_df = main_df.astype(change_dict)
    main_df["xrel"] *= 1000
    main_df["yrel"] *= 1000
    main_df["dsize"] *= 1000
    app_log.info("Converting microns to nm done.")
    return main_df, meta_data


def clean_list_data(data):
    """
    This function is used to clean each row of the data frame.
    param: raw row level input
    return: cleaned row
    """
    try:
        if len(data.split(" ")) > 20:
            imgIndex = data.lower().find("images")
            if imgIndex >= 0:
                imgList = data[imgIndex:]
                imgList = imgList.split(" ")[1].split(",")[:-1]
                data = data[0:imgIndex][:-1] + "|" + ",".join(imgList)
    except Exception as e:
        app_log.error(f"*********ERROR: clean list data------{e}")

    data = (
        data.strip()
        .replace('""', "NA")
        .replace(";", "")
        .strip()
        .split(" ")
    )
    out = []
    flag = None
    for i in data:
        if '"' in i:
            if '"' == i[-1] and '"' == i[0]:
                out.append(i.replace('"', ""))
            elif flag:
                out.append(flag + " " + i.replace('"', ""))
                flag = None
            else:
                flag = i.replace('"', "")
        elif flag:
            flag = flag + " " + i
        else:
            out.append(i)
    return out


def format_dynamic(row):
    return "{{{}}}".format(
        ",".join(["'{}':'{}'".format(k, v) for k, v in row.to_dict().items()])
    )


async def parse_klarf(lines):
    meta_data = {}
    defect_df = []
    class_df = {}
    export_dict = {}
    prefix =""
    suffix=""
    columnsname=""
    main_cols = get_column_details("columns")

    try:
        app_log.info("Reading file now.")
        # with open(filename, "r") as handle:
        #     lines = handle.readlines()

        app_log.info("Extracting metadata.")
        for i in lines:
                prefix += i
                if "DefectList" in i:
                    break
        ls = [i for i in range(0, len(lines)) if "SummarySpec " in lines[i]]
        for i in lines[ls[0]:]:
            suffix += i
        ls = [i for i in range(0, len(lines)) if "DefectRecordSpec" in lines[i]]
        for i in lines[ls[0]:ls[0] + 1]:
            columnsname += i
        export_dict["fileversion"] = "1.7"
        export_dict["prefixdata"] = prefix
        export_dict["suffixdata"] = suffix
        export_dict["columnsname"] = columnsname

        meta_pattern = re.compile(r"[\";]")
        class_lookup_start = 0
        class_lookup_stop = 0
        class_lookup_data = []
        lines = list(map(str.strip, lines))
        for index, line in enumerate(lines):
            l = line.strip()
            l = re.sub(meta_pattern, "", l).split(" ", 1)
            if "classlookup" in line.lower():
                class_lookup_start = index
                for line_no in range(class_lookup_start + 1, len(lines)):
                    if ";" in lines[line_no]:
                        class_lookup_stop = line_no
                        break
            meta_data[l[0]] = l[-1]
        class_lookup_data = list(
            map(clean_list_data, lines[class_lookup_start + 1 : class_lookup_stop + 1])
        )
        meta_data = await process_header_meta_v7(meta_data)
        app_log.info("Meta data Extraction completed.")
        app_log.info("Extracting main dataframe.")
        defect_list_data_index = lines.index("DefectList")
        defect_header = lines[defect_list_data_index - 1]
        cols = defect_header.lower().strip().strip(";").strip().split(" ")[2:]
        for index, line in enumerate(lines[::-1]):
            if "summaryspec" in line.lower():
                defect_list_end_index = len(lines) - (index + 1)
            else:
                try:
                    if (
                        len(line.strip().split(" ")) >= 20
                        and int(line.split(" ")[-2]) > 0
                    ):
                        img_count = int(line.split(" ")[-2])
                        lines[-index - 1] = lines[-index - 1] + " Images "
                        for i in range(1, img_count + 1):
                            image_list = lines[-index - 1 + i].strip()
                            a = image_list.replace(" ", "-") + ","
                            lines[-index - 1] = lines[-index - 1] + a
                            lines[-index - 1] = (
                                lines[-index - 1].strip()
                            )
                except Exception as e:
                    continue
        defect_df = lines[defect_list_data_index + 1 : defect_list_end_index]
        defect_df[-1] = defect_df[-1].replace(";", "")
        defect_df = list(map(clean_list_data, defect_df))
    except Exception as e:
        app_log.exception(
            f"something is wrong while parsing file. {e}",
        )
        raise RuntimeError("something is wrong while parsing file")
    main_df = pd.DataFrame(defect_df, columns=cols)

    if class_lookup_data:
        class_df = pd.DataFrame(class_lookup_data, columns=["classnumber", "classname"])

    dynamic_col = list(set(main_df.columns) - set(main_cols.get("main_cols").keys()))
    main_df.insert(loc=0, column="dynamic", value="")
    app_log.info("Inserting dynamic columns.")
    main_df["dynamic"] = main_df[dynamic_col].to_dict('records')
    app_log.info("Done Inserting dynamic columns.")
    main_df.drop(dynamic_col, axis=1, inplace=True)
    main_df = main_df.dropna(thresh=5).reset_index(drop=True)
    app_log.info(f"Main df is processed. Shape: {main_df.shape}")
    meta_data["test"] = list(map(int, main_df["test"].unique().tolist()))

    return main_df, meta_data, class_df, export_dict


async def parser_v7(file):
    """
    This is a caller function for parse_klarf. This returns the main_df and metadata to the data_processing.
    """
    app_log.info("Parsing file with v7 code.")
    # app_log.info(f"Parsing file at: {file}")
    intermediate_df, meta_data, class_df, export_dict = await parse_klarf(file)
    intermediate_df, meta_data = await microns_to_nm(intermediate_df, meta_data)
    app_log.info(f"Main DataFrame and Meta data has been parsed. Returning now.")

    meta_df = pd.DataFrame(
        meta_data.values(), index=[x.lower() for x in meta_data.keys()]
    ).T
    return intermediate_df, meta_df, class_df, export_dict