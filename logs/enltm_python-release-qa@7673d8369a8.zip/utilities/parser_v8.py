import os
import re
import sys
import json
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.utils import get_logger, get_column_details

app_log = get_logger("parserv8")
# header_v8 = get_column_details('v8')


def clean_list_data(data):
    """
    This function is used to clean each row of the data frame.
    param: raw row level input
    return: cleaned row
    """
    ### Image list load===>
    img_index = data.lower().find("images")
    if img_index >= 0:
        data = data.replace(";", "").replace('""', "NA")
        img_list = data[img_index:]
        img_list = (
            img_list.split("{")[1].replace("}", "").replace(" ", "-").replace('"', "")
        )
        data = data[0:img_index] + img_list
    ###<=== end of change
    data = data.replace(";", "").replace('""', "NA").split(" ")
    out = []
    flag = None
    for i in data:
        if '"' in i:
            if '"' == i[-1] and '"' == i[0]:
                out.append(i.replace('"', ""))
            elif flag:
                out.append(flag + " " + i.replace('"', ""))
                flag = None
            else:
                flag = i.replace('"', "")
        elif flag:
            flag = flag + " " + i
        else:
            out.append(i)
    return out


async def parse_field(data):
    """
    This function is used to parse the field type rows.
    """
    data = data.split(" ", 3)
    name = data[1]
    pattern = re.compile(r"[^_@.:\-,\w]")
    actual_data = re.sub(pattern, "", data[3]).split(",")
    return name, actual_data


async def parse_record(data):
    """
    This function is used to parse the record type rows.
    """
    data = data.split(" ", 2)
    le = len(data)
    l = []
    if (3 - le) != 0:
        l = ["NaN"] * (3 - le)
    data += l
    data[-1] = data[-1].replace('"', "")
    return data[1:]


async def process_header_meta_v8(data_record, data_file):
    """
    This function is used to create the header meta data from record and field.
    param: data_record, data_file
    return: final header meta data
    """
    meta_dict_rec = {
        i[0]: i[1]
        for i in data_record
        if i[0] in ["FileRecord", "LotRecord", "WaferRecord"]
    }
    meta_dict_file = {}
    for i, j in data_file:
        if i in ["ResultTimeStamp", "FileTimeStamp"]:
            meta_dict_file[i] = " ".join([str(elem) for elem in j])
        # if i == "InspectionStationID":
        #     meta_dict_file[i] = j[1]
        #     meta_dict_file["InspectionStationMode"] = j[2]
        if i == "DiePitch":
            meta_dict_file["DIEPITCH"] = ",".join(j)
        if i == "RecipeID":
            meta_dict_file["RecipeID"] = j[0]
            # meta_dict_file["RecipeTimeStamp"] = f"{j[1]} {j[2]}"
        if i in ["SampleCenterLocation", "DieOrigin", "DieStreetCenter"]:
            meta_dict_file[i] = ",".join([str(elem) for elem in j])
        if i in ["InspectionStationID"]:
            meta_dict_file["InspectionStationID"] = " ".join(j[1:3])
        if i in [
            "DeviceID",
            "StepID",
            "SlotNumber",
            "SampleSize",
            "SampleOrientationMarkType",
            "OrientationMarkLocation",
            "SampleType",
        ]:
            meta_dict_file[i] = j[0]
    meta_dict_file.update(meta_dict_rec)
    meta_df = pd.DataFrame.from_dict(data=meta_dict_file, orient="index").T
    return meta_df


async def parser_v8(lines1):
    """
    This is main driver function which iterate over file and parse it.
    param: filename
    return: main df and meta data
    """
    all_field_type = []
    all_list_type = []
    all_record_type = []
    export_dict={'fileversion': "1.8"}
    prefix=""
    suffix=""
    columnsname=""
    main_cols = get_column_details("columns")
    app_log.info("Reading file now.")
    # with open(filename, "r") as handle:
    #     lines1 = handle.readlines()

    lines = list(map(str.strip, lines1))
    app_log.info("Parsing file now.")
    try:
        for index, data in enumerate(lines):
            if data.startswith("Field"):
                parsed_field = await parse_field(lines[index])
                all_field_type.append(parsed_field)
            if data.startswith("List"):
                df_name = lines[index].replace("\n", "").split(" ")[-1]
                column_data = lines[index:]
                column_end = lines[index:].index("}")
                columns = " ".join(column_data[2:column_end])

                columns = columns.split("{ ")[-1]
                columns = columns.split(", ")
                columns = tuple(
                    map(
                        lambda x: x.split(" ")[-1].lower()
                        if not x.split(" ")[-1] == "ImageInfo"
                        else "imagelist",
                        columns,
                    )
                )
                main_data = column_data[column_end + 1 :]
                data_end = main_data.index("}")
                main_data = main_data[2:data_end]
                main_data = list(map(clean_list_data, main_data))
                if df_name == "ClassLookupList":
                    all_list_type.append(
                        {"df_name": df_name, "columns": columns, "main_data": main_data}
                    )
                if df_name == "DefectList":
                    all_list_type.append(
                        {"df_name": df_name, "columns": columns, "main_data": main_data}
                    )
                    for i in lines1[:index + 10]:
                        prefix += i
                    export_dict['prefixdata'] = prefix
                    for i in [i.strip() for i in lines1[index+2:index+15]]:
                        if "}" in i:
                            break
                        else:
                            columnsname += i

                    export_dict["columnsname"] = str(columnsname)
                else:
                    continue
            if data.startswith('Record TestRecord'):
                for i in lines1[index-2:]:
                    suffix+=i
                export_dict['suffixdata']=suffix

            if data.startswith("Record"):
                parsed_record = await parse_record(lines[index])
                all_record_type.append(parsed_record)
            else:
                continue
    except Exception as e:
        app_log.error(
            f"something is wrong while parsing file. {e}",
        )
        raise RuntimeError("something is wrong while parsing file")
    main_data_ind = next(
        (i for i, item in enumerate(all_list_type) if item["df_name"] == "DefectList"),
        None,
    )
    app_log.info(main_data_ind)
    main_df = pd.DataFrame(
        data=[i for i in all_list_type[main_data_ind]["main_data"]],
        columns=all_list_type[main_data_ind]["columns"],
    )
    """dynamic column addition """
    # main_df = main_df[[x.lower() for x in get_column_details("v8")]]
    dynamic_col = list(set(main_df.columns) - set(main_cols.get("main_cols").keys()))
    main_df.insert(loc=0, column="dynamic", value="")
    main_df["dynamic"] = main_df[dynamic_col].to_dict('records') if len(dynamic_col) else {}
    main_df.insert(loc=0, column="aspectratio", value="")
    for i in range(0, len(main_df)):
        try:
            main_df.at[i, "aspectratio"] = float(
                min(float(main_df["xsize"].iloc[i]), float(main_df["ysize"].iloc[i]))
                / max(float(main_df["xsize"].iloc[i]), float(main_df["ysize"].iloc[i]))
            )
        except ZeroDivisionError:
            main_df.at[i, "aspectratio"] = 0.0
    main_df["aspectratio"] = main_df["aspectratio"].astype(float)
    main_df.drop(dynamic_col, axis=1, inplace=True)
    # main_df = main_conversion(main_df)
    class_data_ind = next(
        (
            i
            for i, item in enumerate(all_list_type)
            if item["df_name"] == "ClassLookupList"
        ),
        None,
    )
    app_log.info(class_data_ind)
    class_df = pd.DataFrame(
        data=[k for k in all_list_type[class_data_ind]["main_data"]],
        columns=all_list_type[class_data_ind]["columns"],
    )
    meta_df = await process_header_meta_v8(all_record_type, all_field_type)
    app_log.info(f"Header meta data prepard.")
    app_log.info(main_df.info())
    meta_df.columns = map(str.lower, meta_df.columns)
    meta_df["test"] = [list(map(int, main_df["test"].unique().tolist()))]
    app_log.info(meta_df)
    return main_df, meta_df, class_df, export_dict


async def header_conversion(meta_df):
    # meta_df["XDIEPITCH"] = float(meta_df["XDIEPITCH"].astype(float)) / 1000
    # meta_df["YDIEPITCH"] = float(meta_df["YDIEPITCH"].astype(float)) / 1000
    orient = {0: "DOWN", 90: "LEFT", 180: "UP", 270: "RIGHT"}
    meta_df["ResultTimeStamp"] = pd.to_datetime(meta_df["ResultTimeStamp"]).dt.strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    # meta_df["RecipeTimeStamp"] = pd.to_datetime(meta_df["RecipeTimeStamp"]).dt.strftime(
    #     "%Y-%m-%d %H:%M:%S"
    # )
    meta_df["OrientationMarkLocation"] = orient[
        int(float(meta_df["OrientationMarkLocation"]))
    ]
    meta_df.columns = meta_df.columns.str.lower()
    return meta_df


def main_conversion(main_df):
    main_cols = get_column_details("columns").get("main_cols")
    for i, k in main_cols.items():
        if i in get_column_details("columns").get("v8_conversion"):
            main_df[i] = (main_df[i].astype(k)) / 1000
        else:
            main_df[i] = main_df[i].astype(k)
    return main_df
