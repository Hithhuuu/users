import os
import asyncio
import sys
from io import BytesIO
from PIL import Image

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.utils import env_config, get_logger
from api.utils.common import move_file, move_tiff_file,process_tiff


app_log = get_logger("enlight_watchdog")
watch_path = env_config["watchdog_pick_location"]["src"]
tool_list = env_config["tools"]
queue = env_config["celery_settings"]["from_db"]["queue"]
routing_key = env_config["celery_settings"]["from_db"]["routing_key"]


async def process_klarf(filename, file_type, file_path, tool, retry=False, job_id=None):
    """
    Function to pick the records from DB and push it to upload handler
    """
    from api.upload.upload_api.upload_model import Upload
    uploadmodel = Upload(toolupload=True)
    payload = {
        "filename": filename,
        "file_type": file_type,
        "job_type":  'tool_upload',
        "overwrite":  1,
        "file_path": file_path,
        "is_master": 0,
        "tool": tool
    }
    if retry:
        payload['job_id'] = job_id
        payload['retry'] = retry
    if file_type == 'klarf' or file_type == '001':
        with open(file_path, "r") as file:
            lines = file.readlines()
            lines = list(map(str.strip, lines))
    else:
        with open(file_path,"rb") as file:
            data=file.read()
        lines = BytesIO(data)
        os.remove(file_path)

    await uploadmodel.upload(file=lines, data=payload)
    app_log.info(f" file upload is completed for {0}".format(
        file_path.split('/')[-1]))


async def file_watcher():
    """Watches for klarf files and moves it to archive"""
    try:
        from api.utils.tool_app import get_query_with_pool
        app_log.info("Looking for new log files now.")
        # fetch_tools = os.popen(f'ls {watch_path}').read()
        # tool_list = fetch_tools.splitlines()
        watch_path = r'/Application/local/motor/data/wizer'
        loop = asyncio.get_running_loop()
        for tool in tool_list:
            if tool in ['images', 'userload']:
                continue
            file_path = os.path.join(watch_path, tool, "lz/today/reports/")
            files = os.popen(f'find {file_path}/*.001').read()
            file_list = files.splitlines()
            app_log.info(f"Klarf files: {file_list}")
            failed_query = f"""
                SELECT
                    id,
                    file_path,
                    re_try
                FROM
                    enlight_job_log FINAL
                WHERE
                    job_type = 'tool_upload'
                    AND job_status = 'failed'
                    AND re_try < 3
                    AND job_start_time >= subtractMinutes(NOW(), 30)
                    AND tool_name = '{tool}'
                ORDER BY cdt DESC
            """
            failed_files = await get_query_with_pool(failed_query, "dict")
            failed_dict = {i.get('file_path'): i.get('id') for i in failed_files}
            file_list = file_list + list(failed_dict.keys())
            for fp in file_list:
                jobid = None
                retry = False
                if fp in list(failed_dict.keys()):
                    jobid = failed_dict.get(fp)
                    retry = True
                else:
                    fp = await move_file(fp, tool, "archive")
                filename = os.path.basename(fp)
                file_type = "klarf"
                loop.create_task(process_klarf(filename, file_type, fp, tool, retry= retry,job_id = jobid))


    except Exception as e:
        app_log.error(f"Something went wrong in copying file.. {repr(e)}")
        app_log.exception(e)

async def tiff_watcher():
    """Watch for tiff file in directory"""
    try:
        app_log.info("Check for tiff file")
        fetch_tif = os.popen(f'find {watch_path}/images/* -maxdepth 0 | grep -i -E ".i01|.tiff|.tif"').read().strip().split("\n")
        for tif in fetch_tif:
            try:
                if tif == '':
                    continue
                filename = os.path.basename(tif)
                file_type = filename.split(".")[1]
                tool = 'NA'
                with open(tif,"rb") as file:
                    data=file.read()
                lines = BytesIO(data)
                im = Image.open(lines)
                n_frame = im.n_frames

                file_path = await move_tiff_file(tif, filename)
                with open(file_path,"rb") as file:
                    data=file.read()
                lines = BytesIO(data)
                await process_tiff(lines, filename)
                os.remove(file_path)
            except Exception as e:
                if str(e).find('unknown data organization'):
                    continue
                else:
                    app_log.exception(e)

    except Exception as e:
        app_log.exception(e)


if __name__ == "__main__":
    app_log.info(f"Path for Watchdog watch directory: {watch_path}")
    # file_watcher()
    asyncio.run(tiff_watcher())
    app_log.info(f"{'*'*10} PROCESS COMPLETED {'*'*10}")
