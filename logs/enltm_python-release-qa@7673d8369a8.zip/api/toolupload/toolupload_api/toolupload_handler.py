"""This handler executes tool upload for enlight"""
import os
import datetime
import asyncio

from fastapi import APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
from api.utils.scheduler import scheduler_cron
from api.utils.utils import get_logger
from api.utils.tool_app import  app
from utilities.enlight_watchdog import   file_watcher

router = APIRouter(tags=["Toolupload"],dependencies=[Depends(verify_jwt)])

app_log = get_logger("toolhandler")


@app.on_event("startup")
@scheduler_cron(interval=True,minutes=1)
# @router.get('/tool')
async def tool_upload():
    """
    Main function to look for new files in the given tools and accept a directory loc as input and checks for any addition
    or receiver of new file in the same, as it gets one, starts the execution for the file.
    Watcher will check for FileSystem event, which will only check for "*.001" creation.
    """
    app_log.info(datetime.datetime.now())
    await file_watcher()

# @app.on_event("startup")
# @scheduler_cron(interval=True,minutes=1)
# async def tool_tiff_upload():
#     """
#     Main function to look for new files in the given tools and accept a directory loc as input and checks for any addition
#     or receiver of new file in the same, as it gets one, starts the execution for the file.
#     Watcher will check for FileSystem event, which will only check for "*.001" creation.
#     """
#     app_log.info(datetime.datetime.now())
#     await tiff_watcher()