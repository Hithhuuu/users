from api.utils.tool_app import app
from api.toolupload.toolupload_api import toolupload_handler

app.include_router(toolupload_handler.router)