import os
import sys
import io
import json
import time
import img2pdf
import fitz
import smtplib
import shutil
import numpy as np
from tqdm import trange
from pptx import Presentation
from pptx.util import Cm
from pathlib import Path
from pyppeteer import launch
from promise import Promise
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.utils import queries, get_logger, env_config
from api.utils.fastapi_app import get_query_with_pool
from api.alert.alert_api.alerthistory import AlertHistory
from html2image import Html2Image
hti = Html2Image()


app_log = get_logger("alerts_scheduler")


class AlertScheduler():
    def __init__(self):
        self.queries = queries["alert"]

    async def daily_alerts(self):
        try:
            query_data = {}
            query_data['frequency'] = '"{}"'.format('Daily')
            app_log.info("Fetching files for past 1 day")
            # max_date = datetime.combine(datetime.now().date(), datetime.min.time()) + timedelta(hours=18)
            # min_date = max_date - timedelta(days=2)

            # query_data['max_date'] = max_date
            # query_data['min_date'] = min_date
            query_data['day'] = 1
            fetch_query = self.queries['fetch_files'].format(**query_data)
            file_list = await get_query_with_pool(fetch_query)
            query_data['day'] = '"{}"'.format(datetime.today().strftime("%A"))
            fetch_alerts = self.queries['fetch_alert'].format(**query_data)
            alert_list = await get_query_with_pool(fetch_alerts,resp_type="dict")

            if len(file_list) and alert_list:

                for alert in alert_list:
                    dashboard = []
                    dashboard_name = []
                    alert_filter = json.loads(alert['dataselectionfilters'])
                    for chart in alert_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = alert
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(alert_filter[i]):
                            query_data[i] = f"and {i} in {tuple(alert_filter[i])}"
                        else:
                            query_data[i] = ""
                    query_data['filename'] = tuple(file_list['file_name'].to_list())
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr)
                    if len(plr_data):
                        query_data["product"] = tuple(plr_data['product'].unique().tolist())
                        query_data["layer"] = tuple(plr_data['layer'].unique().tolist())
                        query_data["recipeid"] = tuple(plr_data['recipeid'].unique().tolist())
                        query_data['mapid'] = tuple(plr_data['mapid'].to_list())
                        query_data['dashboard'] = tuple(data['dashboard'])
                        query_data['APP_SERVER'] = os.environ['APP_SERVER']

                        alert_limit = self.queries['alert_limit'].format(**query_data)
                        alert_limit_df = await get_query_with_pool(alert_limit)

                        merge_na = alert_limit_df[alert_limit_df['tool'] == 'NA']
                        merge_tool = alert_limit_df[alert_limit_df['tool']!= 'NA']

                        merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
                        merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

                        control_limit = merge_tool.combine_first(merge_na)
                        control_limit.reset_index(inplace=True)

                        control_limit= control_limit.replace({np.nan: "null"})
                        query_data["control_limit"] = str(
                            [
                                tuple(x)
                                for x in control_limit[
                                    [
                                        "product",
                                        "layer",
                                        "recipeid",
                                        "dc_lcl",
                                        "dc_ucl",
                                        "gr_lcl",
                                        "gr_ucl",
                                        "vl_lcl",
                                        "vl_ucl",
                                        "sl_lcl",
                                        "sl_ucl",
                                        "tl_lcl",
                                        "tl_ucl",
                                        "cr_lcl",
                                        "cr_ucl",
                                        "test",
                                        "tool",
                                    ]
                                ].to_numpy()
                            ]
                        ).replace("'null'", "null")

                        limit_query = self.queries['limit_validation'].format(**query_data)
                        limit_validate_df = await get_query_with_pool(limit_query)
                        limit_validate = limit_validate_df.to_dict(orient='records')
                        result = limit_validate_df[data['dashboard']].max().max()
                        self.plr_data =  plr_data.to_dict(orient='records')
                        self.data = data
                        if result >0:
                            app_log.info("email triggered for alert")
                            await self.trigger_email(limit_validate,data,plr_data)

            app_log.info("Fetching Daily Alerts for a 1day data")

        except Exception as err:
            app_log.exception(err)

    async def add_history(self,**kwargs):
        plr_data =  self.plr_data
        data =  self.data
        history = AlertHistory()
        if not len(plr_data):
            return
        for i in plr_data:
            payload = {
                    "alertid": data.get("id"),
                    "reportname": data.get("reportname"),
                    "filename": i.get("filename"),
                    "username": data.get("username"),
                    "product" : i.get("product"),
                    "layer" :i.get("layer"),
                    "recipeid": i.get("recipeid"),
                    "tool": i.get("tool"),
                    "status": "success" if not kwargs.get("failed") else "failed",
                    "timetaken": 100,
                    "email": json.loads(data['reportinvitees']),
                    "url": f'http://{os.environ["APP_SERVER"]}/enlight/#/qc?product={data["product"]}&layer={data["layer"]}&recipeid={data["recipeid"]}'
            }
            resp = await history.create_alerthistory(payload)
            app_log.info(resp)


    async def weekly_alerts(self):
        try:
            query_data = {}
            query_data['frequency'] = '"{}"'.format('Weekly')
            app_log.info("Fetching files for past 7 day")
            # max_date = datetime.combine(datetime.now().date(), datetime.min.time()) + timedelta(hours=2)

            # min_date = max_date - timedelta(days=7)
            query_data['day'] = 7
            fetch_query = self.queries['fetch_files'].format(**query_data)
            file_list = await get_query_with_pool(fetch_query)

            query_data['day'] = '"{}"'.format(datetime.today().strftime("%A"))
            fetch_alerts = self.queries['fetch_alert'].format(**query_data)
            alert_list = await get_query_with_pool(fetch_alerts,resp_type="dict")

            if len(file_list) and alert_list:

                for alert in alert_list:
                    dashboard = []
                    dashboard_name = []
                    alert_filter = json.loads(alert['dataselectionfilters'])
                    for chart in alert_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = alert
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(alert_filter[i]):
                            query_data[i] = f"and {i} in {tuple(alert_filter[i])}"
                        else:
                            query_data[i] = ""
                    query_data['filename'] = tuple(file_list['file_name'].to_list())
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr)
                    if len(plr_data):
                        query_data["product"] = tuple(plr_data['product'].unique().tolist())
                        query_data["layer"] = tuple(plr_data['layer'].unique().tolist())
                        query_data["recipeid"] = tuple(plr_data['recipeid'].unique().tolist())
                        query_data['mapid'] = tuple(plr_data['mapid'].to_list())
                        query_data['dashboard'] = tuple(data['dashboard'])
                        query_data['APP_SERVER'] = os.environ['APP_SERVER']

                        alert_limit = self.queries['alert_limit'].format(**query_data)
                        alert_limit_df = await get_query_with_pool(alert_limit)

                        merge_na = alert_limit_df[alert_limit_df['tool'] == 'NA']
                        merge_tool = alert_limit_df[alert_limit_df['tool']!= 'NA']

                        merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
                        merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

                        control_limit = merge_tool.combine_first(merge_na)
                        control_limit.reset_index(inplace=True)

                        control_limit= control_limit.replace({np.nan: "null"})
                        query_data["control_limit"] = str(
                            [
                                tuple(x)
                                for x in control_limit[
                                    [
                                        "product",
                                        "layer",
                                        "recipeid",
                                        "dc_lcl",
                                        "dc_ucl",
                                        "gr_lcl",
                                        "gr_ucl",
                                        "vl_lcl",
                                        "vl_ucl",
                                        "sl_lcl",
                                        "sl_ucl",
                                        "tl_lcl",
                                        "tl_ucl",
                                        "cr_lcl",
                                        "cr_ucl",
                                        "test",
                                        "tool",
                                    ]
                                ].to_numpy()
                            ]
                        ).replace("'null'", "null")

                        limit_query = self.queries['limit_validation'].format(**query_data)
                        limit_validate_df = await get_query_with_pool(limit_query)
                        limit_validate = limit_validate_df.to_dict(orient='records')
                        result = limit_validate_df[data['dashboard']].max().max()
                        self.plr_data =  plr_data.to_dict(orient='records')
                        self.data = data
                        if result >0:
                            await self.trigger_email(limit_validate,data,plr_data)

            app_log.info("Fetching Daily Alerts for a 1day data")
        except Exception as err:
            app_log.exception(err)

    async def trigger_email(self, limit_validation, data, plr_data):
        try:
            alert_id = str(data['id'])
            watch_path = env_config["report_path"]["alert"]
            report_path = os.path.join(watch_path, alert_id, str(int(time.time())))
            os.makedirs(report_path, exist_ok=True)

            img_path = await self.app_screenshot(limit_validation,data,plr_data,report_path)
            pdf_path = await self.pdf_create(img_path,data, report_path, plr_data)
            if json.loads(data['reportdownloadformat']) == 'PPT':
                path = await self.convert_pdf2pptx(pdf_path)
                await self.send_email(data,limit_validation,path)
            else:
                await self.send_email(data,limit_validation,pdf_path)
        except Exception as err:
            app_log.exception(err)

    async def app_screenshot(self, limit_validate,data,plr_data ,report_path):
        try:
            img_list = []
            browser = await launch({
            'executablePath': "/bin/chromium-browser",
            'autoClose': False,
            })

            for i in range(0, len(limit_validate)):
                req_df = plr_data[(plr_data['product'] == limit_validate[i]['product']) & (plr_data['layer'] == limit_validate[i]['layer']) & (plr_data['recipeid'] == limit_validate[i]['recipeid'])]
                data['product'] = limit_validate[i]['product']
                data['layer'] = limit_validate[i]['layer']
                data['recipeid'] = limit_validate[i]['recipeid']
                data['resulttimestamp'] = ",".join(req_df['resulttimestamp'].to_list())
                data['tool'] = ",".join(req_df['tool'].unique().tolist())
                data['lot'] = ",".join(req_df['lot'].unique().tolist())
                data['waferid'] = ",".join(req_df['waferid'].unique().tolist())
                data['filename'] = ",".join(req_df['filename'].to_list())
                if i == 0:
                    page = await browser.newPage()
                    await page.setViewport({
                    'width': 2220,
                    'height': 1080,
                    })

                    url = limit_validate[i]['link']
                    await page.goto(url,waitUntil='networkidle0')
                    await page.type('#username', 'report')
                    await page.type('#password', 'Amat@123')
                    await Promise.all([
                    page.click("button[type='submit']",{'waitUntil': 'networkidle0'}),
                    ])
                    await page.setViewport({
                    'width': 2220,
                    'height': 1080,
                    })
                else:
                    page = await browser.newPage()
                    await page.setViewport({
                    'width': 2220,
                    'height': 1080,
                    })
                    url = limit_validate[i]['link']
                    await page.goto(url,waitUntil='networkidle0')

                await page.waitForSelector(selector='.circle-group',timeout=60000)
                await page.waitFor(2000)
                if 'dc' in data['dashboard'] and limit_validate[i]['dc']:
                    dc_path = f'{i}_dc.png'
                    dc_path = os.path.join(report_path, dc_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const element = document.querySelector('#Defect');
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': dc_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'Defect Count'
                    data['value'] =  ",".join(str(x) for x in limit_validate[i]['dc_value'])
                    data['lcl'] =",".join(str(x) for x in limit_validate[i]['dc_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['dc_ucl_final'])

                    await self.html_to_image(data,dc_path,chart= 'dc')
                    img_list.append(dc_path)

                if 'cr' in data['dashboard'] and limit_validate[i]['cr']:
                    cr_path = f'{i}_cr.png'
                    cr_path = os.path.join(report_path, cr_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const element = document.querySelector('#Capture');
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': cr_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'Capture Rate'

                    data['value'] = ",".join(str(x) for x in limit_validate[i]['cr_value'])
                    data['lcl'] = ",".join(str(x) for x in limit_validate[i]['cr_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['cr_ucl_final'])

                    await self.html_to_image(data,cr_path,chart= 'cr')
                    img_list.append(cr_path)


                time_trend = await page.querySelectorAll('circle.circle')
                if time_trend:
                    # Hide all elements
                    await page.evaluate('''() => {
                        const elements = document.querySelectorAll('line.limitLine');
                        elements.forEach((element) => {
                            element.style.display = 'none';
                        });
                    }''')
                    # other code..
                    await time_trend[0].click()
                    # Unhide all elements
                    await page.evaluate('''() => {
                        const elements = document.querySelectorAll('line.limitLine');
                        elements.forEach((element) => {
                            element.style.display = '';
                        });
                    }''')

                await page.click('#Defect-Launch')
                await page.waitFor(2000)
                await page.click('#detailAnalysis')
                await page.click('#close-wafer-view')

                await page.waitForSelector(selector='#gr-time-trend')
                time_trend = await page.querySelectorAll('.circle.circle')
                if time_trend:
                    await page.waitFor(1000)
                    time_trend = await page.querySelectorAll('.circle.circle')
                    await time_trend[0].click({'waitUntil': 'networkidle0'})
                    await page.click('#svg-id-gr-time-trend')

                if 'gr' in data['dashboard'] and limit_validate[i]['gr']:
                    gr_path = f'{i}_gr.png'
                    gr_path = os.path.join(report_path, gr_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const element = document.querySelector('#Grade');
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': gr_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'Grade Ratio'
                    data['value'] = ",".join(str(x) for x in limit_validate[i]['gr_value'])
                    data['lcl'] = ",".join(str(x) for x in limit_validate[i]['gr_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['gr_ucl_final'])

                    await self.html_to_image(data,gr_path,chart= 'gr')
                    img_list.append(gr_path)

                if 'vl' in data['dashboard'] and limit_validate[i]['vl']:
                    vl_path = f'{i}_vl.png'
                    vl_path = os.path.join(report_path, vl_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const elements = document.querySelectorAll('.time-trend-split-container-filter');
                            const element = elements[1]
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': vl_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'Volume Ratio'

                    data['value'] = ",".join(str(x) for x in limit_validate[i]['vl_value'])
                    data['lcl'] = ",".join(str(x) for x in limit_validate[i]['vl_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['vl_lcl_final'])

                    await self.html_to_image(data,vl_path,chart= 'vl')
                    img_list.append(vl_path)


                selfi = await page.querySelectorAll('.card-option.UT-selfi-tlf-tab')
                if selfi:
                    await selfi[0].click({'waitUntil': 'networkidle0'})
                slf_chart = await page.querySelectorAll(selector='#sf-time-trend')
                if slf_chart:
                    if 'sf' in data['dashboard'] and limit_validate[i]['sf']:
                        await page.waitForSelector('#sf-time-trend',{'timeout': 60000})
                else:
                    await page.waitFor(1500)

                if 'sf' in data['dashboard'] and limit_validate[i]['sf']:
                    sl_path = f'{i}_sl.png'
                    sl_path = os.path.join(report_path,sl_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const elements = document.querySelectorAll('.time-trend-split-container-filter');
                            const element = elements[1]
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': sl_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'SELFI Score Avg'

                    data['value'] = ",".join(str(x) for x in limit_validate[i]['sl_value'])
                    data['lcl'] = ",".join(str(x) for x in limit_validate[i]['sl_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['sl_lcl_final'])

                    await self.html_to_image(data,sl_path, chart= 'sl')
                    img_list.append(sl_path)

                tlf = await page.querySelectorAll('.select-lov-sub__indicators.css-1wy0on6')
                if tlf:
                    await tlf[0].click({'waitUntil': 'networkidle0'})
                    await page.waitForSelector(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
                    await page.waitFor(1000)
                    drop = await page.querySelectorAll(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
                    await drop[0].click({'waitUntil': 'networkidle0'})
                    tlf_chart = await page.querySelectorAll(selector='#tf-time-trend')

                    if tlf_chart:
                        if 'tf' in data['dashboard'] and limit_validate[i]['tf']:
                            await page.waitForSelector('#tf-time-trend', {'timeout': 60000})
                    else:
                        await page.waitFor(1500)

                if 'tf' in data['dashboard'] and limit_validate[i]['tf']:
                    tl_path = f'{i}_tl.png'
                    tl_path = os.path.join(report_path,tl_path)
                    dimensions = await page.evaluate('''
                        () => {
                            const elements = document.querySelectorAll('.time-trend-split-container-filter');
                            const element = elements[1]
                            const {x, y, width, height} = element.getBoundingClientRect();
                            return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                        }
                    ''')
                    await page.screenshot({
                        'path': tl_path,
                        'clip': {
                            'x': dimensions['left'],
                            'y': dimensions['top'],
                            'width': dimensions['width'],
                            'height': dimensions['height'],
                        }
                    })
                    data['Kpi'] = 'TLF Score Avg'
                    data['value'] = ",".join(str(x) for x in limit_validate[i]['tl_value'])
                    data['lcl'] = ",".join(str(x) for x in limit_validate[i]['tl_lcl_final'])
                    data['ucl'] = ",".join(str(x) for x in limit_validate[i]['tl_lcl_final'])

                    await self.html_to_image(data,tl_path, chart='tl')
                    img_list.append(tl_path)

            await browser.close()
            app_log.info(img_list)
            return img_list

        except Exception as err:
            app_log.exception(err)
            await browser.close()
            raise Exception(err)

    async def pdf_create(self,img_path, data,report_path, plr_data):
        img = r'img/alert.png'
        a4inpt = (850,460)
        layout_fun = img2pdf.get_layout_fun(a4inpt)
        pdf_data = img2pdf.convert(img, layout_fun=layout_fun)
        pdf_path = os.path.join(report_path, r'alert.pdf')
        with open(pdf_path, "wb") as file:
            file.write(pdf_data)

        pdf_file = open(pdf_path, 'rb')
        # Create a PDF reader object
        pdf_reader = PdfReader(pdf_file)
        # Create a PDF writer object
        pdf_writer = PdfWriter()
        dashboard_name = data['dashboard_name']
        report_name = data['reportname']
        report_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        username = data['username']
        frequency = json.loads(data['reportfrequency'])

        # Loop through all the pages in the PDF
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            can_pdf = f'overlay_{str(int(time.time()))}.pdf'
            overlay = canvas.Canvas(can_pdf, pagesize=(850,460))

            # Add text to the canvas
            overlay.setFont("Times-Roman",size=13.5)
            overlay.setFillColorRGB(255,255,255)
            overlay.drawString(357, 327, report_name)

            overlay.setFont("Times-Roman",size=9)
            overlay.drawString(338, 301, report_date)
            overlay.drawString(464, 301, username)

            # Save the canvas to the overlay PDF
            overlay.setFillColorRGB(0,0,0.2)
            overlay.setFont("Times-Roman",size=7.3)
            overlay.drawString(290, 230.65, dashboard_name)
            overlay.drawString(290, 180.65, frequency)

            overlay.save()
            # Merge the overlay PDF with the original page
            overlay_pdf = open(can_pdf, 'rb')
            overlay_reader = PdfReader(overlay_pdf)
            overlay_page = overlay_reader.pages[0]
            page.merge_page(overlay_page)

            # Add the modified page to the PDF writer
            pdf_writer.add_page(page)

        pdf_data = img2pdf.convert(img_path, layout_fun=layout_fun)
        temp_path = f'screenshot_{str(int(time.time()))}.pdf'
        with open(temp_path, "wb") as file:
            file.write(pdf_data)
        ss = open(temp_path, 'rb')
        pdf_writer.append(ss)
        datetime_str = datetime.now().strftime('%Y%m%d%H%M%S')
        filename = f"{data.get('reportname')}_{datetime_str}.pdf"
        pdf_path = os.path.join(report_path, filename)
        output_file = open(pdf_path, 'wb')
        pdf_writer.write(output_file)

        # Close all the files
        pdf_file.close()
        overlay_pdf.close()
        output_file.close()
        os.remove(temp_path)
        os.remove(can_pdf)
        return pdf_path

    async def convert_pdf2pptx(self,pdf_file, output_file=None, resolution=300, start_page=0, page_count=None, quiet=True):
        doc = fitz.open(pdf_file)
        if not quiet:
            print(pdf_file, 'contains', doc.page_count, 'slides')

        if page_count is None:
            page_count = doc.page_count

        # transformation matrix: slide to pixmap
        zoom = resolution / 72
        matrix = fitz.Matrix(zoom, zoom, 0)

        # create pptx presentation
        prs = Presentation()
        blank_slide_layout = prs.slide_layouts[6]

        # configure presentation aspect ratio
        page = doc.load_page(0)
        aspect_ratio = page.rect.width / page.rect.height
        prs.slide_width = int(prs.slide_height * aspect_ratio)

        # create page iterator
        if not quiet:
            page_iter = trange(start_page, start_page + page_count)
        else:
            page_iter = range(start_page, start_page + page_count)

        # iterate over slides
        for page_no in page_iter:
            page = doc.load_page(page_no)

            # write slide as a pixmap
            pixmap = page.get_pixmap(matrix=matrix)
            image_data = pixmap.tobytes(output='PNG')
            image_file = io.BytesIO(image_data)

            # add a slide
            slide = prs.slides.add_slide(blank_slide_layout)
            left = top = Cm(0)
            slide.shapes.add_picture(image_file, left, top, height=prs.slide_height)

        if output_file is None:
            output_file = Path(pdf_file).with_suffix('.pptx')

        # save presentation
        prs.save(output_file)
        return output_file

    async def html_to_image(self,data, img_path, chart):
        try:
            html = f"""
                <!DOCTYPE html>
                <html>

                <head>
                <style>
                    body {{
                    width: 1950px;
                    height: 890px;
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    }}

                    .main-container {{
                    padding: 30px 20px;
                    background-color: white;
                    }}

                    table {{
                    margin-top: 15px;
                    width: 100%;
                    }}

                    th,
                    td {{
                    padding: 5px;
                    }}

                    th {{
                    background-color: #6195C9;
                    color: white;
                    }}

                    td {{
                    background-color: #EDF1F6;
                    /* word-break: break-word; */
                    }}

                    .image-wrapper {{
                    margin-top: 50px;
                    }}

                    img {{
                    width: 100%;
                    height: 70%;
                    }}
                </style>
                </head>

                <body>
                <div class="main-container">
                    <table>
                    <thead>
                        <tr>
                        <th>Product</th>
                        <th>Layer</th>
                        <th>Recipe</th>
                        <th>Inspection Time Stamp</th>
                        <th>Inspection Tool</th>
                        <th>Lot</th>
                        <th>Wafer</th>
                        <th>KPI</th>
                        <th>Value</th>
                        <th>LCL</th>
                        <th>UCL</th>
                        <th>Klarf Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <td>{data['product']}</td>
                        <td>{data['layer']}</td>
                        <td>{data['recipeid']}</td>
                        <td>{data['resulttimestamp']}</td>
                        <td>{data['tool']}</td>
                        <td>{data['lot']}</td>
                        <td>{data['waferid']}</td>
                        <td>{data['Kpi']}</td>
                        <td>{data['value']}</td>
                        <td>{data['lcl']}</td>
                        <td>{data['ucl']}</td>
                        <td>{data['filename']}</td>
                    </tbody>
                    </table>
                    <div class="image-wrapper">
                        </br>
                        </br>
                    <img src="{img_path}" />
                    </div>
                </div>
                </body>

                </html>
            """
            path = f'{chart}_{str(int(time.time()))}.png'
            hti.screenshot(html_str=html,save_as=path)
            shutil.move(path, img_path)
        except Exception as e:
            app_log.exception(e)

    async def send_email(self,data,limit_validate,path):
        try:
            EMAIL_SIGNATURE  =  "<div><br/><br/>Thanks<br/> Enlight Alerts</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
            table_rows = ""
            for row in limit_validate:
                table_rows += f"<tr><td>{row['product']}</td><td>{row['layer']}</td><td>{row['recipeid']}</td><td>{data['dashboard_name']}</td><td><a href = '{row['link']}'>{row['link']}</a></td></tr>"
            # Include the table in the email content
            email_content  = f""" <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        table {{
                        border-collapse: collapse;
                        width: 50%;
                        border:  0.5px solid #e0e6f0;
                        }}
                        th,
                        td {{
                        text-align: center;
                        padding: 8px;
                        border-right: 0.5px solid #a3a0a0;
                        }}
                        th {{
                        background-color: #4472c4;
                        color: white;
                        }}
                        tr:nth-child(even) {{
                        background-color: white;
                        }}
                        tr:nth-child(odd) {{
                        background-color: #D9E4F5;
                        }}
                        /* Remove the last vertical border on the last column */
                        th:last-child,
                        td:last-child {{
                        border-right: none;
                        }}
                    </style>
                </head>
                <body>
                Hello {data['username']},
                <div>
                <br/>
                <br/>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Layer</th>
                            <th>Recipe</th>
                            <th>Selected KPI</th>
                            <th>Link</th>
                        </tr>
                    </thead>
                    <tbody>
                        {table_rows}
                    </tbody>
                </table>
                {EMAIL_SIGNATURE}
                </body>
                </html>
                """

            your_smtp_port = env_config['smtp_port']
            host  =  env_config['host']
            msg = MIMEMultipart()
            invitees = json.loads(data['reportinvitees'])
            msg["From"] = env_config['server_mail']
            msg["To"] = ", ".join(invitees)
            msg["Subject"] = f'Alerts :- {data["reportname"]}'

            for attach_file_name in [path]:
                with open(attach_file_name, "rb") as file:
                    attachment_content = MIMEApplication(file.read())
                    attachment_content.add_header(
                            "Content-Disposition", "attachment", filename=os.path.basename(attach_file_name)
                        )
                    msg.attach(attachment_content)
            msg.attach(MIMEText(email_content, "html"))
            with smtplib.SMTP(host, your_smtp_port) as server:
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.send_message(msg)
                server.quit()
        except Exception as err:
            await self.add_history(failed = True)
            app_log.error(err)
        await self.add_history()



