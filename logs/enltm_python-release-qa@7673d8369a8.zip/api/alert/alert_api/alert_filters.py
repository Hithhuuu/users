import os
import sys
import pandas as pd
import numpy as np

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from utils.utils import queries, get_logger
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("alertsfilter")

class alertfilter():
    def __init__(self):
        self.queries = queries["alert"]

    async def getfilter(self, data):
        try:
            app_log.info('get filter')
            query_data = await self.get_query_data(data)

            query_to_execute = self.queries["alert_filter"].format(**query_data)
            result = await get_query_with_pool(query_to_execute)

            respone = {
                "product": result["product"].unique().tolist(),
                "layer": result["layer"].unique().tolist(),
                "recipeid": result["recipeid"].unique().tolist()
            }
            return respone
        except Exception as e:
            app_log.exception(e)
            return {"error": "Failed to Get Filters"}

    async def get_query_data(self, data):
        try:
            query_data = {}
            query_condition = []
            for col_name, col_data in data.items():
                query_str = ""
                if isinstance(col_data, list) and col_data:
                    query_str = f"{col_name} in {tuple(col_data)}"
                else:
                    query_str = f"date({col_name}) between '{col_data['min']}' and '{col_data['max']}'"
                query_condition.append(query_str)
            query_cdtn = " and ".join(query_condition)
            query_data["filter_cdtn"] = f"and {query_cdtn}" if len(query_condition) >= 1 else ""
            return query_data
        except Exception as e:
            app_log.exception(e)
            raise Exception(e)

    async def getlimits(self, data):
        try:
            timetrend_type = data.pop('timetrend')
            query_data = await self.get_query_data(data)
            query_data['timetrend'] = tuple(timetrend_type)
            limit_query = self.queries['new_limit'].format(**query_data)
            result_df = await get_query_with_pool(limit_query)

            timetrend_dict = {
                "dc": "Defect Count",
                "cr": "Capture Rate",
                "vl": "Volume Ratio",
                "gr": "Grade Ratio",
                "sf": "SELFI Score Avg",
                "tf": "TLF Score Avg",
            }
            result_df['KPI'] = result_df['KPI'].map(timetrend_dict)
            result_df = result_df.replace({np.nan: 'NA'})
            limit_dict = result_df.to_dict(orient="records")
            return limit_dict
        except Exception as e:
            app_log.exception(e)
            return {"error": "Failed to Get Limits"}

    def add_comment(self, row):
        if 'NA' in (row['LCL'], row['UCL']):
            return "No Limit Defined. Alert can't be triggerd for this KPI"
        else:
            return ''
