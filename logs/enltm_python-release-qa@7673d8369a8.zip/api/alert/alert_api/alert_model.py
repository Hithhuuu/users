import os
import sys
import traceback
import json

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from alert.alert_api.alert_utils import prepare_data, get_data
from utils.utils import queries, get_logger
from utils.common import make_query
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("alerts")

class Alerts:
    """This class provides methods to get/add/update/delete user account"""

    def __init__(self):
        """Initializing ALERT instance"""
        self.queries = queries["alert"]

    async def format_alert_jsons(self,response):
        """Format jsons in the alert details"""
        for resp in response:
            resp["dashboardcount"] = json.loads(
                resp["dashboardcount"]
            )
            resp["dashboarddetails"] =json.loads(
                resp["dashboarddetails"]
            )
        return response

    async def get(self, data):
        """GET the list of Alerts Created"""
        try:
            app_log.info("Preparing response to get autoalert data")
            query_to_execute = self.queries["get_alerts"].format(**data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_alert_jsons(response)
            return response
        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}


    async def create(self, data):
        """Create the new alert"""
        try:
            app_log.info("Preparing to create new alert")
            query_data = prepare_data(data, "insert")

            query_to_execute = self.queries["save_alert"].format(**query_data)
            await get_query_with_pool(query_to_execute)
            return {"msg": "Alert Saved Successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to save alert"}

    async def delete(self, data):
        """ALERT DELETE Method"""
        try:
            query_data = {}
            query_data["userid"] = data.get('username')
            query_data["id"] = tuple(data.get("id"))

            query_to_execute = self.queries["delete_alert"].format(**query_data)
            await get_query_with_pool(query_to_execute)

            query_to_execute = self.queries["get_alerts"].format(**query_data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_alert_jsons(response)

            return response

        except Exception as e:
            app_log.exception(e)
            return {"error": "Failed to Delete Report"}

    async def update_alert(self, data):
        """Update the data for alert"""
        try:
            app_log.info("Updating alert...")
            query_data = prepare_data(data, "update")
            query_to_execute = self.queries["update_alert"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")

            # get the remaining list of reports
            query_data["userid"] = data["username"]
            query_to_execute = self.queries["get_alerts"].format(**query_data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_alert_jsons(response)

            return response
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to update alert"}

    async def get_alert_details(self, data):
        """ return alert data  """
        try:
            app_log.info("Preparing response to get autoalert data")
            query_to_execute = self.queries["read_alert"].format(**data)
            data_output = await get_query_with_pool(query_to_execute, "dict")
            data_output = get_data(data_output)
            return data_output
        except Exception as err:
            app_log.exception(err)
            return {"error": "Get Alert Details API Failed"}

    async def get_history(self,data):
        try:
            response ={
                    "data": [
                        {
                        "autoreportid": 771558150,
                        "status": "Success",
                        "datetime": "2023-10-27 02:22:09",
                        "url": "http://dcilpb1805/enlight/#/qc?product=QCT001&layer=QCT001&recipeid=QCT001",
                        "timetaken": "1 Sec",
                        "filename": "test_slotid_tlupload.001",
                        "numberoffiles": 1,
                        "emailstatus": "Success",
                        },
                        {
                    "autoreportid": 771558150,
                    "status": "Success",
                    "datetime": "2023-10-27 02:22:09",
                    "url": "http://dcilpb1805/enlight/#/qc?product=QCT001&layer=QCT001&recipeid=QCT001",
                    "timetaken": "1 Sec",
                    "filename": "test_slotid_tlupload.001",
                    "numberoffiles": 1,
                    "emailstatus": "Success",
                    },
                    {
                    "autoreportid": 771558150,
                    "status": "Success",
                    "datetime": "2023-10-27 02:20:08",
                    "url": "http://dcilpb1833/wizer/#/favload/2349408661,",
                    "timetaken": "1 Sec",
                    "filename": "test_slotid_tlupload.001",
                    "numberoffiles": 1,
                    "emailstatus": "Success",
                    }
                ],
                "Total": 3
                }
            return response
        except Exception as e:
            app_log.exception(e)
            return {"error": "History API Failed"}
