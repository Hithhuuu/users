import json
import pandas as pd
import datetime



def prepare_data(data, op_type):
    try:
        datetime_format = '%Y-%m-%d %H:%M:%S'
        if op_type == "insert":
            day_list = []
            reportdayselected = data.get('reportdayselected', '')
            if reportdayselected.get('days'):
                day_list.extend(reportdayselected.get('days'))
                reportrunday = f"{json.dumps(day_list)}"
            else:
                reportrunday = f'{json.dumps([""])}'


            data_dict = {
                "reportname": f"{data.get('reportname')}",
                "username":data.get('username'),
                "dashboardcount": f"{json.dumps(data.get('dashboardcount',''))}",
                "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                "reportdayselected": f"{json.dumps(data.get('reportdayselected', ''))}",
                "reportrunday": reportrunday,
                "reportfrequency": f"{json.dumps(data.get('reportfrequency', ''))}",
                "reportstatus": f"{json.dumps(data.get('reportstatus', ''))}",
                "reportdownloadformat": f"{json.dumps(data.get('reportdownloadformat', ''))}",
                "reportinvitees": f"{json.dumps(data.get('reportinvitees', ''))}",
                "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}"
            }
            data_dict = {
                "reportname": f"{data.get('reportname')}",
                "username":data.get('username'),
                "dashboardcount": f"{data.get('dashboardcount','')}",
                "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                "reportdayselected": f"{json.dumps(data.get('reportdayselected', ''))}",
                "reportrunday": reportrunday,
                "reportfrequency": f"{json.dumps(data.get('reportfrequency', ''))}",
                "reportstatus": f"{json.dumps(data.get('reportstatus', ''))}",
                "reportdownloadformat": f"{json.dumps(data.get('reportdownloadformat', ''))}",
                "reportinvitees": f"{json.dumps(data.get('reportinvitees', ''))}",
                "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}"
            }

        elif op_type == "update":
            day_list = []
            reportrunday = None
            reportdayselected = data.get('reportdayselected', None)
            if reportdayselected:
                if reportdayselected.get('days',None):
                    day_list.extend(reportdayselected.get('days'))
                    reportrunday = f"{json.dumps(day_list)}"
            data_dict = {
                "id": data.get("id"),
                "reportname": f"{json.dumps(data.get('reportname'))}" if data.get('reportname') else "reportname",
                "username": f"'{data.get('username')}'" if data.get('username') else 'username',
                "dashboardcount": f"{json.dumps(data.get('dashboardcount'))}" if data.get('dashboardcount') else "dashboardcount",
                "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                "reportdayselected": f"'{json.dumps(data.get('reportdayselected'))}'" if data.get('reportdayselected') else "reportdayselected",
                "reportrunday": f"'{reportrunday}'" if reportrunday else "reportrunday",
                "reportfrequency": f"'{json.dumps(data.get('reportfrequency'))}'" if data.get('reportfrequency') else "reportfrequency",
                "reportstatus": f"'{json.dumps(data.get('reportstatus'))}'" if data.get('reportstatus') else "reportstatus",
                "reportdownloadformat": f"'{json.dumps(data.get('reportdownloadformat'))}'" if data.get('reportdownloadformat') else "reportdownloadformat",
                "reportinvitees": f"'{json.dumps(data.get('reportinvitees'))}'" if data.get('reportinvitees') else "reportinvitees",
                "dataselectionfilters": f"'{json.dumps(data.get('dataselectionfilters'))}'" if data.get('dataselectionfilters') else "dataselectionfilters",
                "rfg" : data.get('rfg') if data.get('rfg',[]) else "rfg"
            }
        return data_dict
    except Exception as err:
        return {"error": f"Error while preparing data {err}"}

def get_data(data_output, filterdata=False):
    """Get alert data formatted with jsons"""
    resp_list = []
    for data in data_output:
        if filterdata:
            day_dict = json.loads(data.get('reportdayselected'))
            selected_day_check = str(datetime.datetime.now().strftime('%A')) in day_dict.get("days")
        else:
            selected_day_check = True
        if selected_day_check:
            resp_dict = {}
            for k in data:
                try:
                    val = json.loads(data.get(k))
                    if k == "reportname" and isinstance(val, int):
                        val = str(val)
                except Exception:
                    val = data.get(k)
                resp_dict.update({
                    f"{k}":val
                })
            resp_list.append(resp_dict)
    return sorted(resp_list, key = lambda i: i['reportcreateddate'],reverse=True)