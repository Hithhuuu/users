import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.alert.alert_api.alert_model import Alerts
from api.alert.alert_api.alert_filters import alertfilter
from api.alert.alert_api.alert_scheduler import AlertScheduler
from api.alert.alert_api.alerthistory import AlertHistory
from api.utils.common import get_user
from api.utils.scheduler import scheduler_cron
from api.utils.fastapi_app import app


router = APIRouter(tags=['Alert'],prefix="/alert", dependencies=[Depends(verify_jwt)])
alert_model = Alerts()
alert_filter = alertfilter()
alert_history = AlertHistory()

@router.get("")
async def get(request: Request):
    """GET Method for alert """
    data = {}
    data["userid"] = get_user(request)["userid"]
    response = await alert_model.get(data)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return response

@router.post("")
async def create(request: Request, body : dict):
    """POST Method for alert """
    body["username"] = get_user(request)["userid"]
    response = await alert_model.create(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.delete("")
async def delete(request: Request, body: dict):
    """DELETE Method for alert """
    body["username"] = get_user(request)["userid"]
    response = await alert_model.delete(body)

    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.put("")
async def update(request: Request, body: dict):
    """UPDATE Method for alert """
    body["username"] = get_user(request)["userid"]
    response = await alert_model.update_alert(body)

    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/filter")
async def getfilter(request: Request, body: dict):
    """FILTER Method for alert """
    response = await alert_filter.getfilter(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/limit")
async def limitfilter(request: Request, body: dict):
    """FILTER Method for alert """
    response = await alert_filter.getlimits(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/alertdetails")
async def filter(request: Request, body: dict):
    """FILTER Method for alert """
    response = await alert_model.get_alert_details(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
# @router.get("/alert/daily")
async def daily_trigger():
    """Trigger alert daily """
    await AlertScheduler().daily_alerts()
    print("daily alert trigger")



@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
# @router.get("/alert/weekly")
async def weekly_trigger():
    await AlertScheduler().weekly_alerts()
    """Trigger alert weekly """
    print("weekly alert trigger")

@router.post("/history")
async def gethistory(request: Request, body: dict):
    """FILTER Method for alert """
    response = await alert_history.get_alerthistory(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.put("/history")
async def create_history(body: dict):
    """FILTER Method for alert """
    response = await alert_history.create_alerthistory(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)







