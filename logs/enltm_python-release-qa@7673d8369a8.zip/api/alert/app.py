from api.utils.fastapi_app import app
from api.alert.alert_api import alert_handler


app.include_router(alert_handler.router)