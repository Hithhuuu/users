from api.utils.fastapi_app import app
from api.autoreport.report_api import report_handler


app.include_router(report_handler.router)