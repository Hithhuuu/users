import os
import sys
import traceback
import json
import time
import io
import shutil
import img2pdf
import fitz
import smtplib
from tqdm import trange
from pptx import Presentation
from pptx.util import Cm
from pathlib import Path
from pyppeteer import launch
from promise import Promise
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PIL import Image
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from autoreport.report_api.report_utils import prepare_data, get_data, trigger_report
from utils.utils import queries, get_logger, env_config
from utils.common import make_query
from api.utils.fastapi_app import get_query_with_pool
from html2image import Html2Image
hti = Html2Image()

app_log = get_logger("report")

class AutoReport:
    """This class provides methods to get/add/update/delete report"""

    def __init__(self):
        """Initializing REPORT instance"""
        self.queries = queries["report"]


    async def format_report_jsons(self,response):
        """Format jsons in the alert details"""
        for resp in response:
            resp["dashboardcount"] = json.loads(
                resp["dashboardcount"]
            )
            resp["dashboarddetails"] =json.loads(
                resp["dashboarddetails"]
            )
        return response

    async def get(self, data):
        """GET the list of Autoreport Created"""
        try:
            app_log.info("Preparing response to get autoreport data")
            query_to_execute = self.queries["get_reports"].format(**data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_report_jsons(response)
            return response
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            return {'error': f"Get Report api failed"}


    async def create(self, data):
        """Create the new autoreport"""
        try:
            app_log.info("Preparing to create new report")
            query_data = prepare_data(data, "insert")

            query_to_execute = self.queries["save_report"].format(**query_data)
            await get_query_with_pool(query_to_execute)
            return {"msg": "Report Saved Successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to save report"}

    async def delete(self, data):
        """AutoReport DELETE Method"""
        try:
            query_data = {}
            query_data["userid"] = data.get('username')
            query_data["id"] = tuple(data.get("id"))

            query_to_execute = self.queries["delete_report"].format(**query_data)
            await get_query_with_pool(query_to_execute)

            query_to_execute = self.queries["get_reports"].format(**query_data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_report_jsons(response)

            return response

        except Exception as e:
            app_log.exception(e)
            return {"error": "Failed to Delete Report"}

    async def update_report(self, data):
        """Update the data for alert"""
        try:
            app_log.info("Updating report...")
            query_data = prepare_data(data, "update")
            query_to_execute = self.queries["update_report"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")

            # get the remaining list of reports
            query_data["userid"] = data["username"]
            query_to_execute = self.queries["get_reports"].format(**query_data)
            response = await get_query_with_pool(query_to_execute, "dict")
            await self.format_report_jsons(response)

            return response
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to update report"}

    async def get_report_details(self, data):
        """ return alert data  """
        try:
            app_log.info("Preparing response to get autoreport data")
            query_to_execute = self.queries["read_report"].format(**data)
            data_output = await get_query_with_pool(query_to_execute, "dict")
            data_output = get_data(data_output)
            return data_output
        except Exception as err:
            app_log.exception(err)
            return {"error": "Get Report Details API Failed"}

    async def get_history(self,data):
        try:
            response ={
                    "data": [
                        {
                        "autoreportid": 771558150,
                        "status": "Success",
                        "datetime": "2023-10-27 02:22:09",
                        "url": "http://dcilpb1805/enlight/#/qc?product=QCT001&layer=QCT001&recipeid=QCT001",
                        "timetaken": "1 Sec",
                        "filename": "test_slotid_tlupload.001",
                        "numberoffiles": 1,
                        "emailstatus": "Success",
                        "history": "2023-12-11 06:40:19"
                        },
                        {
                    "autoreportid": 771558150,
                    "status": "Success",
                    "datetime": "2023-10-27 02:22:09",
                    "url": "http://dcilpb1805/enlight/#/qc?product=QCT001&layer=QCT001&recipeid=QCT001",
                    "timetaken": "1 Sec",
                    "filename": "test_slotid_tlupload.001",
                    "numberoffiles": 1,
                    "emailstatus": "Success",
                    "history": "2023-12-12 06:40:19"
                    },
                    {
                    "autoreportid": 771558150,
                    "status": "Success",
                    "datetime": "2023-10-27 02:20:08",
                    "url": "http://dcilpb1833/wizer/#/favload/2349408661,",
                    "timetaken": "1 Sec",
                    "filename": "test_slotid_tlupload.001",
                    "numberoffiles": 1,
                    "emailstatus": "Success",
                    "history": "2023-12-11 06:40:19"
                    }
                ],
                "Total": 3
                }
            return response
        except Exception as e:
            app_log.exception(e)
            return {"error": "History API Failed"}

    async def run_report(self, data):
        """"Run an instant Report"""
        try:
            query_data = {}
            app_log.info("Run Auto Report Triggered")
            report_query = self.queries['read_report'].format(**data)
            report_list = await get_query_with_pool(report_query, resp_type="dict")
            query_data['APP_SERVER'] = os.environ['APP_SERVER']
            if report_list:
                for report in report_list:
                    dashboard = []
                    dashboard_name = []
                    report_filter = json.loads(report['dataselectionfilters'])
                    for chart in report_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = report
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(report_filter[i]):
                            query_data[i] = f"and {i} in {tuple(report_filter[i])}"
                        else:
                            query_data[i] = ""
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr, resp_type="dict")
                    await trigger_report(plr_data, data, invoke='from_ui')
        except Exception as err:
            app_log.exception(err)
