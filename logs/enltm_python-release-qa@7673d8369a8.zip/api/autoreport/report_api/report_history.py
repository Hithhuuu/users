"""Model for Alert history """
import json
import traceback
from datetime import datetime
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, queries



app_log = get_logger("reporthistory")

class ReportHistory():
    """this class provides methods for Report History"""

    def __init__(self):
        """initialisation of rca queries """
        self.queries = queries['report']

    async def get_reporthistory(self, data):
        """this method creates alert history"""
        try:
            strptime_str = "%Y-%m-%d"
            strftime_str= "%Y-%m-%d"
            app_log.info(f"get report history paylaod {data}")
            resp = {"data":[],"numFound":0}
            start_date = datetime.strptime(data.get('startDate'), strptime_str).strftime(strftime_str)
            end_date = datetime.strptime(data.get('endDate'), strptime_str).strftime(strftime_str)
            query_data = {
                'startDate':start_date,
                'endDate':end_date,
                'reportid':data.get('id')
            }
            query_data["limit"] = f'LIMIT {data.get("offset", 0)}, {data.get("limit", 10)}'
            query_to_execute = self.queries['read_report_history'].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            if len(data_output):
                total = int(data_output['total'].iloc[0])
                data_output = data_output.drop(columns=['total', 'reporttime'])
                result_dict = data_output.to_dict('records')
                resp = {"data":result_dict, "total":total}
            else:
                resp = {"data": [], "total": 0}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            resp={'error':f"error while preparing data {err}"}

        return resp

    async def create_reporthistory(self, data):
        """this method updates Report history"""
        try:
            app_log.info(f"Create Report history paylaod {data}")
            query_data = {
                "autoreportid": data.get('autoreportid'),
                "reportname": data.get('reportname'),
                "username": data.get('username'),
                "status": data.get('status'),
                "invokefrom": data.get('invoke', 'script'),
                "timetaken": data.get('timetaken'),
                "email": json.dumps(data.get('email')),
                "url": data.get('url', '')
                }
            query_to_execute = self.queries['create_report_hist'].format(
                **query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"msg": "Report history updated Successfully"}

        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': f"alert history api failed"}
        return resp
