import json
import pandas as pd
import datetime
import os
import time
import io
import shutil
import img2pdf
import fitz
import smtplib

from tqdm import trange
from pptx import Presentation
from pptx.util import Cm
from pathlib import Path
from pyppeteer import launch
from promise import Promise
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PIL import Image
from html2image import Html2Image
hti = Html2Image()

from api.utils.utils import queries
from utils.utils import queries, get_logger, env_config
from api.autoreport.report_api.report_history import ReportHistory
app_log = get_logger("report_utils")


def prepare_data(data, op_type):
    try:
        datetime_format = '%Y-%m-%d %H:%M:%S'
        if op_type == "insert":
            day_list = []
            reportdayselected = data.get('reportdayselected', '')
            if reportdayselected.get('days'):
                day_list.extend(reportdayselected.get('days'))
                reportrunday = f"{json.dumps(day_list)}"
            else:
                reportrunday = f'{json.dumps([""])}'


            data_dict = {
                "reportname": f"{data.get('reportname')}",
                "username":data.get('username'),
                "dashboardcount": f"{json.dumps(data.get('dashboardcount',''))}",
                "reportcreateddate": pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                "reportdayselected": f"{json.dumps(data.get('reportdayselected', ''))}",
                "reportrunday": reportrunday,
                "reportfrequency": f"{json.dumps(data.get('reportfrequency', ''))}",
                "reportstatus": f"{json.dumps(data.get('reportstatus', ''))}",
                "reportdownloadformat": f"{json.dumps(data.get('reportdownloadformat', ''))}",
                "reportinvitees": f"{json.dumps(data.get('reportinvitees', ''))}",
                "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}"
            }

        elif op_type == "update":
            day_list = []
            reportrunday = None
            reportdayselected = data.get('reportdayselected', None)
            if reportdayselected:
                if reportdayselected.get('days',None):
                    day_list.extend(reportdayselected.get('days'))
                    reportrunday = f"{json.dumps(day_list)}"
            data_dict = {
                "id": data.get("id"),
                "reportname": f"{json.dumps(data.get('reportname'))}" if data.get('reportname') else "reportname",
                "username": f"'{data.get('username')}'" if data.get('username') else 'username',
                "dashboardcount": f"{json.dumps(data.get('dashboardcount'))}" if data.get('dashboardcount') else "dashboardcount",
                "reportcreateddate": pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                "reportdayselected": f"'{json.dumps(data.get('reportdayselected'))}'" if data.get('reportdayselected') else "reportdayselected",
                "reportrunday": f"'{reportrunday}'" if reportrunday else "reportrunday",
                "reportfrequency": f"'{json.dumps(data.get('reportfrequency'))}'" if data.get('reportfrequency') else "reportfrequency",
                "reportstatus": f"'{json.dumps(data.get('reportstatus'))}'" if data.get('reportstatus') else "reportstatus",
                "reportdownloadformat": f"'{json.dumps(data.get('reportdownloadformat'))}'" if data.get('reportdownloadformat') else "reportdownloadformat",
                "reportinvitees": f"'{json.dumps(data.get('reportinvitees'))}'" if data.get('reportinvitees') else "reportinvitees",
                "dataselectionfilters": f"'{json.dumps(data.get('dataselectionfilters'))}'" if data.get('dataselectionfilters') else "dataselectionfilters",
                "rfg" : data.get('rfg') if data.get('rfg',[]) else "rfg"
            }
        return data_dict
    except Exception as err:
        return {"error": f"Error while preparing data {err}"}

def get_data(data_output, filterdata=False):
    """Get alert data formatted with jsons"""
    resp_list = []
    for data in data_output:
        if filterdata:
            day_dict = json.loads(data.get('reportdayselected'))
            selected_day_check = str(datetime.now().strftime('%A')) in day_dict.get("days")
        else:
            selected_day_check = True
        if selected_day_check:
            resp_dict = {}
            for k in data:
                try:
                    val = json.loads(data.get(k))
                    if k == "reportname" and isinstance(val, int):
                        val = str(val)
                except Exception:
                    val = data.get(k)
                resp_dict.update({
                    f"{k}":val
                })
            resp_list.append(resp_dict)
    return sorted(resp_list, key = lambda i: i['reportcreateddate'],reverse=True)


async def trigger_report(plr_data, data, invoke='script'):
    """Trigger the report"""
    try:
        start_time = time.time()
        app_log.info("Triggering the report")
        report_id = str(data['id'])
        watch_path = env_config['report_path']['report']
        report_path = os.path.join(watch_path,report_id,str(int(time.time())))
        os.makedirs(report_path, exist_ok=True)
        img_path = await app_screenshot(plr_data, data, report_path)
        pdf_path = await pdf_create(img_path, data, report_path)
        if json.loads(data['reportdownloadformat']) == 'PPT':
            path = await convert_pdf2pptx(pdf_path)
            url = await send_email(data,path)
        else:
            url = await send_email(data,pdf_path)
        execution_time = time.time() - start_time
        data['timetaken'] = f'{execution_time:.0f} sec'
        data['invoke'] = invoke
        data['status'] = 'Success'
        data['url'] = url
        await add_history(data)
    except Exception as err:
        app_log.exception(err)
        execution_time = time.time() - start_time
        data['invoke'] = invoke
        data['url'] = 'NA'
        data['timetaken'] = f'{execution_time:.0f} sec'
        data['status'] = 'Failed'
        await add_history(data)
        raise Exception(err)

async def app_screenshot(plr_data, data, report_path):
    """Screenshot the report"""
    try:
        app_log.info("Taking the screenshot of report")
        img_list = []
        browser = await launch({
        'executablePath': "/bin/chromium-browser",
        'autoClose': False,
        })
        for iter,plr in enumerate(plr_data):

            data['product'] = plr['product']
            data['layer'] = plr['layer']
            data['recipeid'] = plr['recipeid']

            if iter == 0:
                page = await browser.newPage()
                await page.setViewport({
                'width': 2220,
                'height': 1080,
                })
                url = plr['link']
                await page.goto(url, waitUntil='networkidle0')
                await page.type('#username', 'report')
                await page.type('#password', 'Amat@123')
                await Promise.all([
                page.click("button[type='submit']",{'waitUntil': 'networkidle0'}),
                ])
                await page.setViewport({
                'width': 2220,
                'height': 1080,
                })
            else:
                page = await browser.newPage()
                await page.setViewport({
                'width': 2220,
                'height': 1080,
                })
                url = plr['link']
                await page.goto(url,waitUntil='networkidle0')

            await page.waitForSelector(selector='.circle-group',timeout=60000)
            await page.waitFor(2000)
            if 'dc' in data['dashboard']:
                dc_path = f'{iter}_dc.png'
                dc_path = os.path.join(report_path, dc_path)
                dimensions = await page.evaluate('''
                    () => {
                        const element = document.querySelector('#Defect');
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': dc_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'Defect Count'
                await html_to_image(data,dc_path,chart= 'dc')
                img_list.append(dc_path)

            if 'cr' in data['dashboard']:
                cr_path = f'{iter}_cr.png'
                cr_path = os.path.join(report_path, cr_path)
                dimensions = await page.evaluate('''
                    () => {
                        const element = document.querySelector('#Capture');
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': cr_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'Capture Rate'
                await html_to_image(data,cr_path,chart= 'cr')
                img_list.append(cr_path)


            time_trend = await page.querySelectorAll('circle.circle')
            if time_trend:
                # Hide all elements
                await page.evaluate('''() => {
                    const elements = document.querySelectorAll('line.limitLine');
                    elements.forEach((element) => {
                        element.style.display = 'none';
                    });
                }''')
                # other code..
                await time_trend[0].click()
                # Unhide all elements
                await page.evaluate('''() => {
                    const elements = document.querySelectorAll('line.limitLine');
                    elements.forEach((element) => {
                        element.style.display = '';
                    });
                }''')

            await page.click('#Defect-Launch',{'waitUntil': 'networkidle0'})
            await page.waitFor(2000)
            await page.click('#detailAnalysis',{'waitUntil': 'networkidle0'})
            await page.click('#close-wafer-view',{'waitUntil': 'networkidle0'})

            await page.waitForSelector(selector='#gr-time-trend')
            time_trend = await page.querySelectorAll('.circle.circle')

            if time_trend:
                await page.waitFor(1000)
                time_trend = await page.querySelectorAll('.circle.circle')
                await time_trend[0].click({'waitUntil': 'networkidle0'})
                await page.click('#gr-time-trend')
            if 'gr' in data['dashboard']:
                gr_path = f'{iter}_gr.png'
                gr_path = os.path.join(report_path, gr_path)
                dimensions = await page.evaluate('''
                    () => {
                        const element = document.querySelector('#Grade');
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': gr_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'Grade Ratio'
                await html_to_image(data,gr_path,chart= 'gr')
                img_list.append(gr_path)

            if 'vl' in data['dashboard']:
                vl_path = f'{iter}_vl.png'
                vl_path = os.path.join(report_path, vl_path)
                dimensions = await page.evaluate('''
                    () => {
                        const elements = document.querySelectorAll('.time-trend-split-container-filter');
                        const element = elements[1]
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': vl_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'Volume Ratio'
                await html_to_image(data,vl_path,chart= 'vl')
                img_list.append(vl_path)


            selfi = await page.querySelectorAll('.card-option.UT-selfi-tlf-tab')
            if selfi:
                await selfi[0].click({'waitUntil': 'networkidle0'})
            slf_chart = await page.querySelectorAll(selector='#sf-time-trend')

            if slf_chart:
                await page.waitForSelector('#sf-time-trend',{'timeout': 60000})
            else:
                await page.waitFor(1500)

            if 'sf' in data['dashboard']:
                sl_path = f'{iter}_sl.png'
                sl_path = os.path.join(report_path,sl_path)
                dimensions = await page.evaluate('''
                    () => {
                        const elements = document.querySelectorAll('.time-trend-split-container-filter');
                        const element = elements[1]
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': sl_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'SELFI Score Avg'
                await html_to_image(data,sl_path, chart= 'sl')
                img_list.append(sl_path)

            tlf = await page.querySelectorAll('.select-lov-sub__indicators.css-1wy0on6')
            if tlf:
                await tlf[0].click({'waitUntil': 'networkidle0'})
                await page.waitForSelector(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
                await page.waitFor(1000)
                drop = await page.querySelectorAll(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
                await drop[0].click({'waitUntil': 'networkidle0'})
                tlf_chart = await page.querySelectorAll(selector='#tf-time-trend')

                if tlf_chart:
                    await page.waitForSelector('#tf-time-trend', {'timeout': 60000})
                else:
                    await page.waitFor(1500)
            if 'tf' in data['dashboard']:
                tl_path = f'{iter}_tl.png'
                tl_path = os.path.join(report_path,tl_path)
                dimensions = await page.evaluate('''
                    () => {
                        const elements = document.querySelectorAll('.time-trend-split-container-filter');
                        const element = elements[1]
                        const {x, y, width, height} = element.getBoundingClientRect();
                        return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                    }
                ''')
                await page.screenshot({
                    'path': tl_path,
                    'clip': {
                        'x': dimensions['left'],
                        'y': dimensions['top'],
                        'width': dimensions['width'],
                        'height': dimensions['height'],
                    }
                })
                data['Kpi'] = 'TLF Score Avg'
                await html_to_image(data,tl_path, chart='tl')
                img_list.append(tl_path)

        await browser.close()
        app_log.info(img_list)
        return img_list

    except Exception as err:
        tlf_path = f'{iter+20}_error.png'
        tlf_path = os.path.join(report_path,tlf_path)
        await page.screenshot({'path': tlf_path})
        await browser.close()
        app_log.exception(err)
        app_log.exception(tlf_path)
        raise Exception(err)

async def html_to_image(data, img_path, chart):
    try:
        html = f"""
            <!DOCTYPE html>
            <html>

            <head>
            <style>
                body {{
                width: 1950px;
                height: 890px;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                }}

                .main-container {{
                padding: 30px 20px;
                background-color: white;
                }}

                table {{
                margin-top: 15px;
                margin: auto;
                width: 50%;
                }}

                th,
                td {{
                padding: 5px;
                }}

                th {{
                background-color: #6195C9;
                color: white;
                }}

                td {{
                background-color: #EDF1F6;
                /* word-break: break-word; */
                }}

                .image-wrapper {{
                margin-top: 50px;
                }}

                img {{
                width: 100%;
                height: 70%;
                }}
            </style>
            </head>

            <body>
            <div class="main-container">
                <table>
                <thead>
                    <tr>
                    <th>Product</th>
                    <th>Layer</th>
                    <th>Recipe</th>
                    <th>KPI</th>
                    </tr>
                </thead>
                <tbody>
                    <td>{data['product']}</td>
                    <td>{data['layer']}</td>
                    <td>{data['recipeid']}</td>
                    <td>{data['Kpi']}</td>
                </tbody>
                </table>
                <div class="image-wrapper">
                    </br>
                    </br>
                <img src="{img_path}" />
                </div>
            </div>
            </body>

            </html>
        """
        path = f'{chart}_{str(int(time.time()))}.png'
        hti.screenshot(html_str=html,save_as=path)
        shutil.move(path, img_path)
    except Exception as e:
        app_log.exception(e)

async def pdf_create(img_path, data,report_path):
    img = r'img/report.png'
    a4inpt = (850,460)
    layout_fun = img2pdf.get_layout_fun(a4inpt)
    pdf_data = img2pdf.convert(img, layout_fun=layout_fun)
    pdf_path = os.path.join(report_path, r'alert.pdf')
    with open(pdf_path, "wb") as file:
        file.write(pdf_data)

    pdf_file = open(pdf_path, 'rb')
    # Create a PDF reader object
    pdf_reader = PdfReader(pdf_file)
    # Create a PDF writer object
    pdf_writer = PdfWriter()
    dashboard_name = data['dashboard_name']
    report_name = data['reportname']
    report_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    username = data['username']
    frequency = json.loads(data['reportfrequency'])

    # Loop through all the pages in the PDF
    for page_num in range(len(pdf_reader.pages)):
        page = pdf_reader.pages[page_num]
        can_pdf = f'overlay_{str(int(time.time()))}.pdf'
        overlay = canvas.Canvas(can_pdf, pagesize=(850,460))

        # Add text to the canvas
        overlay.setFont("Times-Roman",size=13.5)
        overlay.setFillColorRGB(255,255,255)
        overlay.drawString(357, 327, report_name)

        overlay.setFont("Times-Roman",size=9)
        overlay.drawString(338, 301, report_date)
        overlay.drawString(464, 301, username)

        # Save the canvas to the overlay PDF
        overlay.setFillColorRGB(0,0,0.2)
        overlay.setFont("Times-Roman",size=7.3)
        overlay.drawString(290, 230.65, dashboard_name)
        overlay.drawString(290, 180.65, frequency)
        overlay.save()
        overlay_pdf = open(can_pdf, 'rb')
        overlay_reader = PdfReader(overlay_pdf)
        overlay_page = overlay_reader.pages[0]
        page.merge_page(overlay_page)

        # Add the modified page to the PDF writer
        pdf_writer.add_page(page)

    pdf_data = img2pdf.convert(img_path, layout_fun=layout_fun)
    temp_path = f'screenshot_{str(int(time.time()))}.pdf'
    with open(temp_path, "wb") as file:
        file.write(pdf_data)

    ss = open(temp_path, 'rb')
    pdf_writer.append(ss)
    datetime_str = datetime.now().strftime('%Y%m%d%H%M%S')
    filename = f"{data.get('reportname')}_{datetime_str}.pdf"
    pdf_path = os.path.join(report_path, filename)
    output_file = open(pdf_path, 'wb')
    pdf_writer.write(output_file)

    # Close all the files
    pdf_file.close()
    overlay_pdf.close()
    output_file.close()
    os.remove(temp_path)
    os.remove(can_pdf)
    return pdf_path

async def convert_pdf2pptx(pdf_file, output_file=None, resolution=300, start_page=0, page_count=None, quiet=True):
    doc = fitz.open(pdf_file)
    if not quiet:
        print(pdf_file, 'contains', doc.page_count, 'slides')

    if page_count is None:
        page_count = doc.page_count

    # transformation matrix: slide to pixmap
    zoom = resolution / 72
    matrix = fitz.Matrix(zoom, zoom, 0)

    # create pptx presentation
    prs = Presentation()
    blank_slide_layout = prs.slide_layouts[6]

    # configure presentation aspect ratio
    page = doc.load_page(0)
    aspect_ratio = page.rect.width / page.rect.height
    prs.slide_width = int(prs.slide_height * aspect_ratio)

    # create page iterator
    if not quiet:
        page_iter = trange(start_page, start_page + page_count)
    else:
        page_iter = range(start_page, start_page + page_count)

    # iterate over slides
    for page_no in page_iter:
        page = doc.load_page(page_no)

        # write slide as a pixmap
        pixmap = page.get_pixmap(matrix=matrix)
        image_data = pixmap.tobytes(output='PNG')
        image_file = io.BytesIO(image_data)

        # add a slide
        slide = prs.slides.add_slide(blank_slide_layout)
        left = top = Cm(0)
        slide.shapes.add_picture(image_file, left, top, height=prs.slide_height)

    if output_file is None:
        output_file = Path(pdf_file).with_suffix('.pptx')

    # save presentation
    prs.save(output_file)
    return output_file

async def send_email(data,path):
    try:
        path = path if isinstance(path,str) else str(path)
        path_parts = path.split(os.sep)
        specific_path = os.sep.join(path_parts[-3:])
        current_date_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        doc_link = f'http://{os.environ["APP_SERVER"]}/enlight_report/{specific_path}'
        EMAIL_SIGNATURE  =  "<div><br/><br/>Thanks<br/> Enlight Auto Reports</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
        # Include the table in the email content
        email_content  = f""" <!DOCTYPE html>
            <html>
            <head>
                <style>
                    table {{
                    border-collapse: collapse;
                    width: 50%;
                    border:  0.5px solid #e0e6f0;
                    }}
                    th,
                    td {{
                    text-align: center;
                    padding: 8px;
                    border-right: 0.5px solid #a3a0a0;
                    }}
                    th {{
                    background-color: #4472c4;
                    color: white;
                    }}
                    tr:nth-child(even) {{
                    background-color: white;
                    }}
                    tr:nth-child(odd) {{
                    background-color: #D9E4F5;
                    }}
                    /* Remove the last vertical border on the last column */
                    th:last-child,
                    td:last-child {{
                    border-right: none;
                    }}
                </style>
            </head>
            <body>
            Hello {data['username']},
            <div>
            <br/>
            </div>
            <div>
            Please find the link of the report generated at {current_date_time}
            </br>
            <a href="{doc_link}">{os.path.basename(path)}</a></p>
            </div>
            {EMAIL_SIGNATURE}
            </body>
            </html>
            """

        your_smtp_port = env_config['smtp_port']
        host  =  env_config['host']
        msg = MIMEMultipart()
        invitees = json.loads(data['reportinvitees'])
        msg["From"] = env_config['server_mail']
        msg["To"] = ", ".join(invitees)
        msg["Subject"] = f'Auto Report :- {data["reportname"]}'

        for attach_file_name in [path]:
            with open(attach_file_name, "rb") as file:
                attachment_content = MIMEApplication(file.read())
                attachment_content.add_header(
                        "Content-Disposition", "attachment", filename=os.path.basename(attach_file_name)
                    )
                msg.attach(attachment_content)
        msg.attach(MIMEText(email_content, "html"))
        with smtplib.SMTP(host, your_smtp_port) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.send_message(msg)
            server.quit()
        return doc_link
    except Exception as err:
        app_log.error(err)
        raise Exception(err)

async def add_history(data):
    try:
        if not len(data):
            return
        history = ReportHistory()
        payload = {
            "autoreportid": data.get("id"),
            "reportname": data.get("reportname"),
            "username": data.get('username'),
            "url": data.get('url', ''),
            "timetaken": data['timetaken'],
            "invoke": data.get('invoke', 'script'),
            "email": json.loads(data['reportinvitees']),
            "status": data.get('status')
        }
        await history.create_reporthistory(payload)
    except Exception as err:
        app_log.exception(err)

