import os
import sys
import asyncio
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends, BackgroundTasks
from api.utils.fastapi_app import verify_jwt
from api.autoreport.report_api.report_model import AutoReport
from api.autoreport.report_api.report_filters import reportfilter
from api.autoreport.report_api.report_history import ReportHistory
from api.autoreport.report_api.report_scheduler import ReportScheduler
from utils.common import get_user
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.scheduler import scheduler_cron
from api.utils.fastapi_app import app


queue = asyncio.Queue()
router = APIRouter(tags=['Report'],prefix="/report", dependencies=[Depends(verify_jwt)])
report_model = AutoReport()
report_filter = reportfilter()
report_history = ReportHistory()
report_scheduler = ReportScheduler()


@router.get("")
async def get(request: Request):
    """GET Method for report """
    data = {}
    data["userid"] = get_user(request)["userid"]
    response = await report_model.get(data)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return response

@router.post("")
async def create(request: Request, body : dict):
    """POST Method for report """
    body["username"] = get_user(request)["userid"]
    response = await report_model.create(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.delete("")
async def delete(request: Request, body: dict):
    """DELETE Method for report """
    body["username"] = get_user(request)["userid"]
    response = await report_model.delete(body)

    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.put("")
async def update(request: Request, body: dict):
    """UPDATE Method for report """
    body["username"] = get_user(request)["userid"]
    response = await report_model.update_report(body)

    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/filter")
async def filter(request: Request, body: dict):
    """FILTER Method for report """
    response = await report_filter.getfilter(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/limit")
async def filter(request: Request, body: dict):
    """FILTER Method for report """
    response = await report_filter.getlimits(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/reportdetails")
async def filter(request: Request, body: dict):
    """FILTER Method for report """
    response = await report_model.get_report_details(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("/run")
async def run_autoreport(background_tasks: BackgroundTasks, body :dict):
    """POST method to generate autoreport """
    try:
        loop = asyncio.get_running_loop()
        if len(body['ids']) == 0:
            response  = {"error": "Auto Report Id's is empty"}
        else:
            response = {"success": f"Pushed Auto-Report Id to Execution -> {body['ids']}"}
        loop.create_task(run_reports(body['ids']))
    except Exception :
        response = {'error': "Run AutoReport API Failed"}
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

async def worker():
    while True:
        id = await queue.get()  # Get an id from the queue
        report_data = {'id': str(id)}
        await report_model.run_report(report_data)
        queue.task_done()  # Indicate that the task is done

async def main():
    # Create 4 worker tasks
    tasks = [asyncio.create_task(worker()) for _ in range(4)]
    # Wait for all tasks in the queue to be processed
    await queue.join()
    # Cancel the worker tasks
    for task in tasks:
        task.cancel()
    # Wait for all worker tasks to finish
    await asyncio.gather(*tasks, return_exceptions=True)

async def run_reports(ids):
    for id in ids:
        await queue.put(id)
    await main()

@router.post("/history")
async def history(request: Request, body: dict):
    """History Method for Report """
    response = await report_history.get_reporthistory(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
# @router.get("/daily")
async def daily_trigger():
    """Trigger alert daily """
    print("daily report trigger")
    await report_scheduler.daily_report()
    # return {"Success"}

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
# @router.get("/weekly")
async def weekly_trigger():
    """Trigger alert weekly """
    print("weekly report trigger")
    await report_scheduler.weekly_report()
    # return {"Success"}

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
# @router.get("/monthly")
async def monthly_trigger():
    """Trigger alert monthly """
    print("Monthly report trigger")
    await report_scheduler.monthly_report()
    # return {"Success"}
