import os
import sys
import json

from datetime import datetime, timedelta
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from autoreport.report_api.report_utils import trigger_report
from api.utils.utils import queries, get_logger
from api.utils.fastapi_app import get_query_with_pool




app_log = get_logger("report_scheduler")


class ReportScheduler():
    def __init__(self):
        self.queries = queries["report"]

    async def daily_report(self):
        try:
            query_data = {}
            query_data['frequency'] = '"{}"'.format('Daily')

            query_data['day'] = '"{}"'.format(datetime.today().strftime("%A"))
            fetch_alerts = self.queries['fetch_report'].format(**query_data)
            report_list = await get_query_with_pool(fetch_alerts,resp_type="dict")
            query_data['APP_SERVER'] = os.environ['APP_SERVER']
            if report_list:
                for report in report_list:
                    dashboard = []
                    dashboard_name = []
                    report_filter = json.loads(report['dataselectionfilters'])
                    for chart in report_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = report
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(report_filter[i]):
                            query_data[i] = f"and {i} in {tuple(report_filter[i])}"
                        else:
                            query_data[i] = ""
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr, resp_type="dict")
                    await trigger_report(plr_data, data)

            app_log.info("Fetching Daily Reports")

        except Exception as err:
            app_log.exception(err)

    async def weekly_report(self):
        try:
            app_log.info("Fetching Weekly Reports")
            query_data = {}
            query_data['frequency'] = '"{}"'.format('Weekly')

            query_data['day'] = '"{}"'.format(datetime.today().strftime("%A"))
            fetch_alerts = self.queries['fetch_report'].format(**query_data)
            report_list = await get_query_with_pool(fetch_alerts,resp_type="dict")
            query_data['APP_SERVER'] = os.environ['APP_SERVER']
            if report_list:
                for report in report_list:
                    dashboard = []
                    dashboard_name = []
                    report_filter = json.loads(report['dataselectionfilters'])
                    for chart in report_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = report
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(report_filter[i]):
                            query_data[i] = f"and {i} in {tuple(report_filter[i])}"
                        else:
                            query_data[i] = ""
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr, resp_type="dict")
                    await trigger_report(plr_data, data)

        except Exception as err:
            app_log.exception(err)

    async def monthly_report(self):
        try:
            app_log.info("Fetching Weekly Reports")
            query_data = {}
            query_data['frequency'] = '"{}"'.format('Monthly')
            query_data['month_day'] = datetime.now().day
            query_data['day'] = datetime.today().strftime("%A")
            query_data['placement'], query_data['placement_val'] = await self.check_placement()
            fetch_alerts = self.queries['fetch_report_monthly'].format(**query_data)
            report_list = await get_query_with_pool(fetch_alerts,resp_type="dict")
            query_data['APP_SERVER'] = os.environ['APP_SERVER']
            if report_list:
                for report in report_list:
                    dashboard = []
                    dashboard_name = []
                    report_filter = json.loads(report['dataselectionfilters'])
                    for chart in report_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = report
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    for i in ['product', 'layer', 'recipeid']:
                        if len(report_filter[i]):
                            query_data[i] = f"and {i} in {tuple(report_filter[i])}"
                        else:
                            query_data[i] = ""
                    fetch_plr = self.queries["fetch_plr"].format(**query_data)
                    plr_data = await get_query_with_pool(fetch_plr, resp_type="dict")
                    await trigger_report(plr_data, data)

        except Exception as err:
            app_log.exception(err)

    async def check_placement(self):
        """Check Placement of the today day"""
        try:
            date = datetime.now()
            occurrence = (date.day - 1) // 7 + 1

            # Check if the date is the last occurence day of the month
            next_week = date + timedelta(weeks=1)

            if next_week.month != date.month:
                placement = 'last'
                placement_val = placement
                if occurrence == 4:
                    placement_val = 'fourth'
            else:
                suffixes = {1: 'first', 2: 'second', 3: 'third', 4:'fourth'}
                placement = suffixes.get(occurrence % 10,'')
                placement_val = placement
            return placement, placement_val
        except Exception as err:
            app_log.exception(err)
            raise Exception(err)



