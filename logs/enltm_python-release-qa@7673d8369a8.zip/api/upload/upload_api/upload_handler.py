import os
import sys
import datetime

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, File, Form,Depends
from api.utils.fastapi_app import verify_jwt
from io import BytesIO

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.upload.upload_api.upload_model import Upload
from api.utils.utils import get_logger


router = APIRouter(tags=['Upload'],prefix="/upload",dependencies=[Depends(verify_jwt)])
uploadmodel = Upload()
app_log = get_logger("toolupload")

@router.post("")
async def post( request: Request):
    """On POST request upload a file"""
    data = {}
    form_data = await request.form()
    data["filename"] = form_data.get('filename')
    data["file_type"] = form_data.get('filetype', "klarf")
    data["endpoint"] = request.url.path
    data["job_type"] = "ui_upload"
    data["product"] = form_data.get('product', None)
    data["layer"] = form_data.get('layer', None)
    data["recipeid"] = form_data.get('recipeid', None)
    data["overwrite"] = form_data.get('overwrite', 0)
    data["tool"] = form_data.get('tool', 'NA')
    data["is_master"] = 1
    if data["overwrite"] == 0:
        file = form_data.get('file')
        file = await file.read()
        file = file.decode("utf-8").splitlines(keepends=True) if  data["file_type"] == 'klarf' or data["file_type"] == '001'  else BytesIO(file)
    else:
        file = ''
    resp_json = await uploadmodel.upload(file, data)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()):
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)


@router.post("/gettools")
async def get_tools(request: Request, body: dict):
    """On POST request get tools"""
    resp_json = await uploadmodel.get_tools(body)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()):
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)

@router.post("/masterinfo")
async def get_masterdata(request: Request, body: dict):
    """On POST request get tools"""
    resp_json = await uploadmodel.master_data(body)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()):
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)




