import os
import sys
import shutil
from io import BytesIO

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from utils.utils import queries, env_config, get_logger
from api.utils.data_processing import UploadUtils
app_log = get_logger("upload")


class Upload:
    def __init__(self, toolupload=False):
        """Initializing User instance"""
        self.toolupload = toolupload
        self.queries = queries["upload"]

    async def upload(self, file, data):
        try:
            response = {"status": "Upload Successful"}
            obj = UploadUtils(self.toolupload,file, data)
            await obj.process_file()

        except Exception as excep:
            app_log.exception(excep)
            response = {"upload": "failed", "error": str(excep)}
            if str(excep) == "The file already exists":
                response["errorcode"] = 1
            app_log.exception(f"Returned Json response is: {response}")

        return response

    async def get_tools(self,data):
        try:
           tool_list = env_config["tools"]
           return tool_list
        except Exception as err:
            app_log.exception(err)
            return {"error": "Failed to get tools", "message": str(err)}

    async def master_data(self, data):
        try:
            queries = self.queries['get_masterdata'].format(**data)
            result = await get_query_with_pool(queries, "dict")
            return result
        except Exception as e:
            return {"error": "Failed to get master data", "message": str(e)}
