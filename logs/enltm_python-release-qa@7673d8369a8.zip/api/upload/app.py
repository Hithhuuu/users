from api.utils.fastapi_app import app
from api.upload.upload_api import upload_handler


app.include_router(upload_handler.router)
