from api.utils.fastapi_app import app
from api.commonality.commonality_api import commonality_handler

app.include_router(commonality_handler.router)
