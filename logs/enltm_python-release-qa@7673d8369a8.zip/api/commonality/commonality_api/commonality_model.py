import os
import sys
import csv
from datetime import datetime
import asyncio
# import aiofiles.os
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from utils.utils import queries, get_logger, get_columns_info
from utils.common import make_query
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("commonality")


class Commonality:
    """This class provides methods to get/add/update/delete user account"""

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["commonality"]
        self.cols1, self.cols2, self.cols3 = [], [], []
        self.columns = get_columns_info()
        self.prefixdata = ""

    async def get_commonality(self, data):
        """Get the Common/Missing/Adders defects"""
        try:
            app_log.info("Get Commonality")
            axis_clm = {
                "wafer": {"xaxis": "xsite", "yaxis": "ysite"},
                "field": {"xaxis": "fieldrelx", "yaxis": "fieldrely"},
                "die": {"xaxis": "xrel", "yaxis": "yrel"},
            }

            commonality_condtn = {
                "common": {
                    "cm_condition": "IN",
                    "clm_mapid": "smapid",
                    "clm_defectid": "sdefectid",
                },
                "adders": {
                    "cm_condition": "NOT IN",
                    "clm_mapid": "smapid",
                    "clm_defectid": "sdefectid",
                },
                "missing": {
                    "cm_condition": "NOT IN",
                    "clm_mapid": "rmapid",
                    "clm_defectid": "rdefectid",
                },
            }

            inputs = data.get("inputs", {})
            cm_type = inputs.get("commonality", "common")
            chart_type = inputs.get("charttype", "wafer").lower()
            if len(tuple(inputs.get("selectedruns"))) == 0:
                return {}
            xaxis = axis_clm[chart_type]["xaxis"]
            yaxis = axis_clm[chart_type]["yaxis"]

            query_data = make_query(data)

            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)

            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]
            query_data["zoom_cdtn"] = (
                f"AND {xaxis} Between {inputs.get(xaxis).get('min')} and {inputs.get(xaxis).get('max')} \
            AND {yaxis} Between {inputs.get(yaxis).get('min')} and {inputs.get(yaxis).get('max')} "
                if inputs.get(xaxis, None) and inputs.get(yaxis, None)
                else ""
            )
            if inputs.get('tool', None):
                tool = ["NA"]
                tool.append(inputs.get('tool'))
                query_data['tool'] = tuple(tool)
            master_map = self.queries["fetch_master_map"].format(**query_data)
            master_map = await get_query_with_pool(master_map, resp_type="tuple")

            if len(master_map) == 0:
                raise Exception("Please upload master map.")

            if cm_type != "missing":
                query_data["mapid"] = tuple(inputs.get("selectedruns"))
                query_data["is_master"] = 0
            else:
                query_data["mapid"] = master_map[0]
                query_data["is_master"] = 1

            query_data["selectedruns"] = tuple(inputs.get("selectedruns"))
            query_data["xaxis"] = axis_clm[chart_type]["xaxis"]
            query_data["yaxis"] = axis_clm[chart_type]["yaxis"]
            query_data["diepitch_x"] = inputs.get("diepitch_x", 1)
            query_data["diepitch_y"] = inputs.get("diepitch_y", 1)
            query_data["fieldx"] = inputs.get("fieldstacking", {"fieldx": 1})["fieldx"]
            query_data["fieldy"] = inputs.get("fieldstacking", {"fieldy": 1})["fieldy"]
            query_data["orientation"] = inputs.get("orientation", "down")
            query_data["clm_mapid"] = commonality_condtn[cm_type]["clm_mapid"]
            query_data["clm_defectid"] = commonality_condtn[cm_type]["clm_defectid"]
            query_data["cm_condition"] = commonality_condtn[cm_type]["cm_condition"]
            query_data["commonality"] = self.queries["commonality"].format(**query_data)
            if inputs.get('prep_column'):
                query_data['xprep_cols'] = [i for i in inputs.get('prep_column') if 'xsite' in i ][0]
                query_data['yprep_cols'] = [i for i in inputs.get('prep_column') if 'ysite' in i ][0]
            else:
                query_data['xprep_cols'] = f'xsite_{inputs.get("orientation", "down")}'
                query_data['yprep_cols'] = f'ysite_{inputs.get("orientation", "down")}'

            get_coordinates = self.queries["get_coordinates"].format(**query_data)
            app_log.info(f"Get Coordinates query: {get_coordinates}")
            response = await get_query_with_pool(get_coordinates, "dict")

        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}
        return response

    async def get_export(self, body):
        try:
            commonality_condtn = {
                "common": {
                    "cm_condition": "IN",
                    "clm_mapid": "smapid",
                    "clm_defectid": "sdefectid",
                },
                "adders": {
                    "cm_condition": "NOT IN",
                    "clm_mapid": "smapid",
                    "clm_defectid": "sdefectid",
                },
                "missing": {
                    "cm_condition": "NOT IN",
                    "clm_mapid": "rmapid",
                    "clm_defectid": "rdefectid",
                },
            }
            tasks = []
            for export in body['selected_runs']:
                query_data = {}
                query_data['mapid'] = export['mapid']
                meta_data_query = self.queries['export_metadata'].format(**query_data)
                meta_data = await get_query_with_pool(meta_data_query)
                if len(meta_data) == 0:
                    continue
                tasks.append(self.handle_export(export['mapid'], body, query_data, meta_data, commonality_condtn, export['runid']))
            results = await asyncio.gather(*tasks)
            export_dict = {k: v for result in results for k, v in result.items()}
            return export_dict
        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}

    async def handle_export(self, mapid, body, query_data, meta_data, commonality_condtn, runid):
            export_dict = {}
            for feature in body['exports']:
                try:
                    cols1, cols2, cols3 = [], [], []
                    filename = None
                    timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                    master_meta_data = None
                    main_df = None
                    if feature == 'run_klarf':
                        query_data['mapid'] = mapid
                        filename = f"QC_{meta_data['recipeid'].iloc[0]}_{meta_data['tool'].iloc[0]}_Run_{runid}_{timestamp}.001"
                        run_query = self.queries['export_rundata'].format(**query_data)
                        main_df = await get_query_with_pool(run_query)
                    elif feature == 'mastermap':
                        tool = ['NA']
                        filename = f"QC_{meta_data['recipeid'].iloc[0]}_MasterMap_{timestamp}.001"
                        query_data['product'] = meta_data['product'].iloc[0]
                        query_data['layer'] = meta_data['layer'].iloc[0]
                        query_data['recipeid'] = meta_data['recipeid'].iloc[0]
                        tool.append(meta_data['tool'].iloc[0])
                        query_data['tool'] = tuple(tool)
                        master_map_query = self.queries['mastermap_run'].format(**query_data)
                        main_df = await get_query_with_pool(master_map_query)
                        query_data['mapid'] = main_df['mapid'].iloc[0]
                        master_metadata_query = self.queries['export_metadata'].format(**query_data)
                        master_meta_data = await get_query_with_pool(master_metadata_query)
                    else:
                        tool = ['NA']
                        query_data["clm_mapid"] = commonality_condtn[feature]["clm_mapid"]
                        query_data["clm_defectid"] = commonality_condtn[feature]["clm_defectid"]
                        query_data["cm_condition"] = commonality_condtn[feature]["cm_condition"]
                        query_data['product'] = meta_data['product'].iloc[0]
                        query_data['layer'] = meta_data['layer'].iloc[0]
                        query_data['map'] = mapid
                        query_data['mapid'] = mapid
                        query_data['mmapid'] = ''
                        query_data['recipeid'] = meta_data['recipeid'].iloc[0]
                        filename = f"QC_{meta_data['recipeid'].iloc[0]}_{feature.capitalize()}_{timestamp}.001"
                        tool.append(meta_data['tool'].iloc[0])
                        query_data['tool'] = tuple(tool)
                        master_map = self.queries['fetch_master'].format(**query_data)
                        master_map = await get_query_with_pool(master_map)
                        query_data['master_mapid'] = master_map['mapid'].iloc[0]
                        query_data['commonality']  = self.queries["export_commonality"].format(**query_data)
                        if feature == 'missing':
                            query_data['mapid'] = master_map['mapid'].iloc[0]
                            master_metadata_query = self.queries['export_metadata'].format(**query_data)
                            master_meta_data = await get_query_with_pool(master_metadata_query)
                            query_data['mmapid'] = master_map['mapid'].iloc[0]
                            query_data['mapid'] = ''
                        commonality_run_query = self.queries['commonality_data'].format(**query_data)
                        main_df = await get_query_with_pool(commonality_run_query)
                        if len(main_df) == 0:
                            continue
                    df1 = meta_data if master_meta_data is None else master_meta_data
                    if df1.at[0, 'fileversion'].rstrip('\x00') in ["1.7", "1.1"]:
                        columns = df1.at[0, 'columnsname'].lower().strip().strip(';').split(' ')[2:]
                        for col in columns:
                            if col in main_df.columns:
                                cols1.append(col)
                            else:
                                for key, value in self.columns['alias_dict'].items():
                                    if col == key:
                                        cols1.append(value)
                                        cols3.append(key)
                                    else:
                                        cols2.append(col)
                        self.prefixdata = df1.at[0, 'prefixdata']
                        self.prefixdata = self.prefixdata.replace('DefectRecordSpec ' + str(len(columns)),
                                                                'DefectRecordSpec ' + str(len(cols1)))
                        main_data = main_df[[col for col in cols1]]
                        for i in cols2:
                            if i not in cols3 and i != "":
                                self.prefixdata = self.prefixdata.replace(" " + i.upper(), "")
                        m = self.prefixdata.split("\n")
                        s = "\n".join(m)
                        if 'xrel' in cols1:
                            main_data.loc[:, "xrel" ] = main_data["xrel"].apply(lambda x: x/1000)

                        if 'yrel' in cols1:
                            main_data.loc[:, "xrel"] = main_data["yrel"].apply(lambda x: x/1000)
                        if 'dsize' in cols1:
                            main_data.loc[:, 'dsize'] = main_data['dsize'].apply(lambda x: x/1000)

                        main_data.loc[:,'xindex'] = main_data['xindex'].astype(int)
                        main_data.loc[:, 'yindex'] = main_data['yindex'].astype(int)

                        csv_obj = main_data.to_csv(sep=' ', index=False, header=False, quoting=csv.QUOTE_NONE, quotechar="", escapechar="\\")
                        csv_list = [data.strip() for data in csv_obj.split("\n")]
                        export_path = f"export/{filename}"
                        with open(export_path, 'w') as f:
                            f.write(s)
                            for i in range(len(csv_list) - 1):
                                if i < len(csv_list) - 2:
                                    f.write(csv_list[i].replace('\\', '') + "\n")
                                elif i == len(csv_list) - 2:
                                    f.write(csv_list[i].replace('\\', '') + ";\n")

                            f.write(df1.at[0, 'suffixdata'])
                            f.close()
                        with open(export_path, 'r') as f:
                            export_dict[filename.split('.')[0]] = f.read()

                        if os.path.exists(export_path):
                            # await aiofiles.os.remove(export_path)
                            os.remove(export_path)

                    elif df1.at[0, 'fileversion'].rstrip('\x00') == '1.8':
                        main_df.drop(['imageinfo'], axis=1, inplace=True)
                        main_df.rename(columns = {'imagelist':'imageinfo'}, inplace = True)
                        ls = [i.replace("defects.", "") for i in main_df.columns]
                        main_df.columns = ls
                        columns = df1.at[0, 'columnsname'].split("{")[-1].split(",")
                        columns = list(map(lambda x: x.split(" ")[-1].lower(), columns))
                        for i in columns:
                            if i in ls:
                                cols1.append(i)
                            else:
                                for key, value in self.columns['alias_dict'].items():
                                    if i == key:
                                        cols1.append(value)
                                        cols3.append(key)
                                    elif i not in cols2:
                                        cols2.append(i)
                        self.prefixdata = df1.at[0, 'prefixdata']
                        for i in cols2:
                            if i not in cols3 and i != "":
                                self.prefixdata = self.prefixdata.replace(
                                    self.prefixdata[self.prefixdata[:self.prefixdata.index(
                                        i.upper())].rindex(","):self.prefixdata.index(i.upper())] + i.upper(), "")

                        self.prefixdata = self.prefixdata.replace('Columns ' + str(len(columns)),
                                                                  'Columns ' + str(len(cols1)))

                        self.prefixdata = self.prefixdata.replace(
                            self.prefixdata[self.prefixdata.rindex("}") + 1:],
                            f"\n    Data {main_df.shape[0]}\n {'{'}\n")

                        main_data = main_df[[col for col in cols1]]
                        main_data.loc[:, cols1[-1]] = main_data[cols1[-1]]
                        m = self.prefixdata.split("\n")
                        s = "\n".join(m)
                        main_data['xindex'] = main_data['xindex'].astype(int)
                        main_data['yindex'] = main_data['yindex'].astype(int)

                        csv_obj = main_data.to_csv(sep=' ', index = False, header = False, quoting=csv.QUOTE_NONE, quotechar="", escapechar="\\")
                        csv_list = [data.strip() for data in csv_obj.split("\n")]
                        export_path = f"export/{filename}"
                        with open(export_path, 'w') as f:
                            f.write(s.replace("\r", ''))
                            for i in range(len(csv_list) - 1):
                                f.write(csv_list[i].replace('\\', '') + ';\n')
                            f.write(df1.at[0, 'suffixdata'])
                            f.close()
                        with open(export_path, 'r', encoding = 'utf-8') as f:
                            export_dict[filename.split('.')[0]] = f.read().encode('utf-8')

                        if os.path.exists(export_path):
                            # await aiofiles.os.remove(export_path)
                            os.remove(export_path)

                except Exception as e:
                    app_log.exception(e)
                    if os.path.exists(export_path):
                        # await aiofiles.os.remove(export_path)
                        os.remove(export_path)
                    continue
            return export_dict