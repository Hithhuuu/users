import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from starlette.responses import Response
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from commonality_api.commonality_model import Commonality
from api.utils.fastapi_app import app


router = APIRouter(tags=['Commonality'],prefix="/commonality", dependencies=[Depends(verify_jwt)])


@router.post("")
async def auth(request: Request, body: dict):
    """On post request return the Common/Missing/Adders"""
    commonality = Commonality()
    response = await commonality.get_commonality(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)

@router.post("/export")
async def auth(request: Request, body: dict):
    """On post request return the Common/Missing/Adders"""
    commonality = Commonality()
    response = await commonality.get_export(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    elif len(response.keys()) == 0:
        return Response(status_code=204)
    return response
