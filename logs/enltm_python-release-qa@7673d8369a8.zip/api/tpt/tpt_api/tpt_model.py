"""TPT API Model File"""
import time
import os
import pandas as pd
import numpy as np
import pandas as pd
from datetime import timedelta
from datetime import datetime
from dateutil.relativedelta import relativedelta
from openpyxl import load_workbook
from openpyxl.styles import Font
import asyncio
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import queries, get_logger, get_tpt_gfilter_config
from api.tpt.tpt_api.tpt_utils import get_tpt_data, get_filter_data, get_scanset_data


app_log = get_logger("tpt")


class Tpt:
    """This class provides methods to get TPT Dashboard Data"""

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["tpt"]
        self.light_factor_mapping = {
            0.53: "High",
            0.75: "Moderate",
            1.0: "Normal"
        }
        self.sampling_factor_mapping = {
            1.0: "STD",
            1.2: "Moderate",
            1.35: "High",
            1.36: "High",
            1.54: "Ultra"
        }

    async def get_table_data(self, data):
        """GET TPT Table Data"""
        try:
            start_time = time.time()
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            date =  data['filters']['periodfilter']['resulttimestamp']['date']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            root_task = []
            if current_date == max_date:
                return []
            # token = await get_token()
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["recipe_payload"].format(**payload_data)
                tasks.append(get_tpt_data(payload))

            result = await asyncio.gather(*tasks)
            # root_result = await asyncio.gather(*root_task)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]
            # root_dfs = [df for df in root_result if isinstance(df, pd.DataFrame)]
            end_time = time.time()
            app_log.info(f'Time for fss recipe api execution for {date}: {end_time - start_time} seconds')
            # Concatenate all dataframes
            resp = pd.concat(dfs)
            # root_resp = pd.concat(root_dfs)
            if len(resp):
               resp['runs'] = 1  # Add a new column 'runs' with all values as 1
               grouped_df = resp.groupby(['product', 'layer', 'recipeid']).agg(
                   total_runs=('runs', 'sum'),  # Total for each group
                   outlier=('status', lambda x: (x==1).sum()),  # Count of 1s in 'status'
                   outlier_percentage=('status', lambda x: ((x==1).sum()/len(x))*100),
                   median=('result', 'median')  # Median of 'result'
               ).reset_index()
               last_target = resp.dropna(subset=['target']).groupby(['product', 'layer', 'recipeid']).apply(
                    lambda group: group.sort_values('last_time', ascending=False)['target'].iloc[0]
                )
               if len(last_target):
                    last_target = last_target.reset_index()
                    last_target.columns = ['product', 'layer', 'recipeid', 'target']

               else:
                   last_target = last_target.reset_index(drop=True)
                   last_target = last_target[['product', 'layer', 'recipeid', 'target']]

            #    root_grouped_df = root_resp.groupby(['product', 'layer', 'recipeid'])
            #    rootcause_df = root_grouped_df.apply(self.count_family_rows)

            #    rootcause_df['root_cause'] = rootcause_df.apply(lambda row: row[['scan', 'pre_scan', 'result', 'gdr']].to_dict(), axis=1)
            #    rootcause_df = rootcause_df[['root_cause']]
            #    rootcause_df = rootcause_df.reset_index()
               grouped_df_tool = resp.groupby(['product', 'layer', 'recipeid', 'tool']).agg(
                runs=('runs', 'sum'),  # Total number of rows for each group
                outlier=('status', lambda x: (x==1).sum())  # Number of outliers
                ).reset_index()
               grouped_df_tool['tooltip_info'] = grouped_df_tool.apply(lambda row: {'toolid': row['tool'], 'runs': row['runs'], 'outlier': row['outlier']}, axis=1)
               grouped_df_tool = grouped_df_tool.groupby(['product', 'layer', 'recipeid'])['tooltip_info'].apply(list).reset_index()
               grouped_df = pd.merge(grouped_df, grouped_df_tool, on=['product', 'layer', 'recipeid'], how='left')
               grouped_df = pd.merge(grouped_df, last_target, on=['product', 'layer', 'recipeid'], how='left')
            #    grouped_df = pd.merge(grouped_df, rootcause_df, on=['product', 'layer', 'recipeid'], how='left')
               grouped_df = grouped_df.replace({np.nan:'null'})
               grouped_df = grouped_df.sort_values(by=['outlier', 'outlier_percentage'], ascending=False)
               grouped_df['root_cause'] = [{}] * len(grouped_df)
               result = grouped_df.to_dict(orient='records')
            else:
                return []
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}
        return result

    def count_family_rows(self, group):
        group['scan'] = np.where((group[['status_scan_set_post', 'status_scan_set_scan', 'status_af_slice', 'status_scan_devices_prepare']] > 0).any(axis=1), 1, 0)
        group['pre_scan'] = np.where((group[['status_oil_shading', 'status_oil_histograms', 'status_alignment', 'status_dcf', 'status_null_review', 'status_null_scan']] > 0).any(axis=1), 1, 0)
        group['result'] = np.where((group[['status_global_filters', 'status_unified_save_results']] > 0).any(axis=1), 1, 0)
        group['gdr'] = np.where(group['status_gdr'] > 0, 1, 0)
        return group.sum()

    async def get_filter(self, data):
        try:
            start_time = time.time()
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            date =  data['filters']['periodfilter']['resulttimestamp']['date']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            data_output = {}
            if current_date == max_date:
                g_filter = get_tpt_gfilter_config()
                for key, val in g_filter.items():
                    data_output[key] = {
                        "type": val[0]["type"],
                        "filterlabel": val[1]["label"],
                        "options": []
                    }
                return data_output
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["filter_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))
            result = await asyncio.gather(*tasks)
            end_time = time.time()
            app_log.info(f'Time for fss filter api execution for {date}: {end_time - start_time} seconds')
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            # Concatenate all dataframes
            resp = pd.concat(dfs)
            if len(resp):
                g_filter = get_tpt_gfilter_config()
                for key, val in g_filter.items():
                    data_output[key] = {
                        "type": val[0]["type"],
                        "filterlabel": val[1]["label"],
                        "options": [
                            {"label": data, "value": data} for data in sorted(resp[key].unique().tolist())
                        ],
                    }
            else:
                g_filter = get_tpt_gfilter_config()
                for key, val in g_filter.items():
                    data_output[key] = {
                        "type": val[0]["type"],
                        "filterlabel": val[1]["label"],
                        "options": []
                    }
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}
        return data_output

    async def get_timetrend(self, data):
        try:
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["recipe_payload"].format(**payload_data)
                tasks.append(get_tpt_data(payload))

            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            # Concatenate all dataframes
            resp = pd.concat(dfs)
            if len(resp):
                resp = resp.sort_values('last_time')
                resp['runid'] = range(1, len(resp) + 1)
                resp = resp.replace({np.nan: None})
                query_data = {
                    "product": resp['product'].iloc[0],
                    "layer": resp['layer'].iloc[0],
                    "recipeid": resp['recipeid'].iloc[0],
                }
                query = self.queries['get_limit'].format(**query_data)
                limit_data = await get_query_with_pool(query)
                if len(limit_data):
                    result = {
                        "product": resp['product'].iloc[0],
                        "layer":   resp['layer'].iloc[0],
                        "recipeid": resp['recipeid'].iloc[0],
                        "limit": {
                            "lcl": limit_data['lcl'].iloc[0],
                            "ucl": limit_data['ucl'].iloc[0],
                            "baseline": limit_data['target'].iloc[0]
                        }
                    }
                else:
                    result = {
                        "product": resp['product'].iloc[0],
                        "layer":   resp['layer'].iloc[0],
                        "recipeid": resp['recipeid'].iloc[0],
                        "limit": {
                            "lcl": resp['lcl'].iloc[0],
                            "ucl": resp['ucl'].iloc[0],
                            "baseline": resp['target'].iloc[0]
                        }
                    }
                resp['recipe_time'] = pd.to_datetime(resp['recipe_time']).dt.floor('S')
                resp['last_time'] = pd.to_datetime(resp['last_time'], unit= 'ms').dt.floor('S')
                result['data'] = resp[['tool','waferid', 'lotid', 'slotid', 'result', 'pdcrun' ,'runid','pdcrun' ,'last_time', 'recipe_time']].to_dict(orient='records')
                return result
            else:
                return []
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong" }

    async def get_optical_data(self, data):
        try:
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["optical_payload"].format(**payload_data)
                tasks.append(get_scanset_data(payload))

            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]
            resp = pd.concat(dfs)
            if len(resp):
                resp = resp.drop_duplicates()
                resp[['light_factor', 'sampling_factor']] = resp.apply(self.assign_factor, axis=1)
                resp.drop(['product', 'layer', 'recipeid', 'light'],axis=1 ,inplace=True)
                result = resp.to_dict(orient='records')
            return result
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}

    def assign_factor(self,row):
        light_factor = self.light_factor_mapping.get(row['light'], 'Custom')
        sampling_factor = self.sampling_factor_mapping.get(row['light'], 'Custom')
        return pd.Series({'light_factor': light_factor, 'sampling_factor': sampling_factor})

    async def get_export(self, data):
        try:
            epoch_time = int(time.time())
            filename = f'output_{epoch_time}.xlsx'
            app_log.info("TPT Scan Set API")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            payload_data['pdcrun'] = data.get('filters').get('run_id')
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            data_output = {}
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["export_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))
            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]
            resp = pd.concat(dfs)
            if len(resp):
                if resp['flf_defects'].iloc[0] is None and resp['slf_defects'].iloc[0] is None and resp['post_defects'].iloc[0] is None:
                    return {}
                run_data_resp = resp[['parent_run_start_time','lot', 'slot','product','layer','recipeid', 'waferid']]
                run_data_resp = run_data_resp.drop_duplicates()
                run_data_resp['parent_run_start_time'] = pd.to_datetime(run_data_resp['parent_run_start_time'], unit='ms').dt.floor('S')

                run_data_resp.loc[-1] = ['Started on:', 'Lot ID:', 'Slot ID:', 'Product:', 'Layer:', 'Recipe:', 'Wafer ID:']
                run_data_resp.index = run_data_resp.index + 1
                run_data_resp = run_data_resp.sort_index()
                run_data_resp.reset_index(drop=True, inplace=True)


                #Scanset Data Details to be exported
                resp['total_defects'] = resp[['flf_defects', 'slf_defects', 'post_defects']].sum(axis=1, skipna=True)
                scan_set_data = resp[['run_name','total_defects' ,'flf_defects','flf_alarm','slf_defects','slf_alarm', 'post_defects', 'post_alarm']]

                scanset_slice = resp[['run_name','slice_string','flf_defect_slice','flf_alarm_slice', 'slf_defect_slice','slf_alarm_slice', 'post_defect_slice','post_alarm_slice']]
                scan_set_data.columns = ['Scan Set ID','Scan Set Final Defect Count', 'Scan Set FLF Defects Count','Scan Set FLF Alarm Count', 'Scan Set SLF Defects Count', 'Scan Set SLF Alarm Count', 'Scan Set Post Processor Defects Count', 'Scan Set Post Processor Alarm Count']

                with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                    run_data_resp.transpose().to_excel(writer, sheet_name='Combined Data', index=False, startrow=0)
                    scan_set_data.to_excel(writer, sheet_name='Combined Data', index=False, startrow=11, startcol=1)

                start_row = len(scan_set_data) + 14
                col_list = ['Scan Set ID','Slice ID','FLF Defects','FLF Alarm','SLF Defects','SLF Alarm','Post Processor Defects ','Post Processor Alarm']
                for data in scanset_slice.to_dict(orient='records'):
                    run_name = data.pop('run_name')
                    data = {k: (v.split(',') if v is not None else ['']) for k, v in data.items()}
                    df = pd.DataFrame(data)
                    df['run_name'] = run_name
                    df['slice_string'] = df['slice_string'].astype(int)
                    df = df.sort_values(by='slice_string', ascending=True)
                    df = df[['run_name','slice_string','flf_defect_slice','flf_alarm_slice', 'slf_defect_slice','slf_alarm_slice', 'post_defect_slice','post_alarm_slice']]
                    df.columns = col_list
                    with pd.ExcelWriter(filename, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                        df.to_excel(writer, sheet_name='Combined Data', index=False, startrow=start_row, startcol=1)
                    start_row += len(df) + 2
                workbook = load_workbook(filename)
                sheet = workbook['Combined Data']
                sheet.delete_rows(1)
                sheet['A10'] = 'Scan Set Level Statistics -'
                sheet[f'A{13+len(scan_set_data)}'] = 'Slice Level Statistics -'
                for cell in sheet[11]:
                    cell.font = Font(bold=True)

                for cell in sheet['A']:
                    cell.font = Font(bold=True)

                workbook.save(filename)
                return filename
            else:
                return {}
        except Exception as err:
            if os.path.exists(filename):
                os.remove(filename)
            app_log.exception(err)
            return {"error": "Something went wrong"}

    async def empty_response(self, min_date_str, max_date_str, limit_type):
        result = {
                        "limit_type": limit_type,
                        "time_range":{
                            "min_date": min_date_str,
                            "max_date": max_date_str
                        },
                        "limits": {
                            "alignment": None,
                            "pre-scan": None,
                            "scan": None,
                            "result": None,
                            "target": {
                                "lcl": None,
                                "ucl": None,
                                "baseline": None
                            }
                        }
                    }
        return result

    async def get_segment_data(self, data):
        try:
            app_log.info("Segment Pareto API")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            payload_data['runid'] = data.get('run_id')
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            data_output = {}
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["segment_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))
            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            resp = pd.concat(dfs)
            if len(resp):
                categories = {
                    'pre-scan': ['null_review', 'null_scan', 'dcf', 'oil_shading', 'oil_histogram'],
                    'scan': ['prepare_scan', 'af_slice', 'scanset_scan_duration', 'post_scanset_duration'],
                    'result': ['save_results', 'global_filters', 'unified_save_results']
                }

                for category in categories:
                    resp[category] = 0

                # Calculate the sum for each category and assign it to the new columns
                for category, columns in categories.items():
                    valid_columns = [col for col in columns if col in resp.columns]
                    if valid_columns:
                        resp[category] = resp[valid_columns].sum(axis=1)

                sub_run = resp[resp['parent_tool_runid'] != 0]
                overall_run = resp[resp['parent_tool_runid'] == 0]
                result = []
                for i in range(0, len(sub_run)):
                    temp_dict = {}
                    temp_dict['scanset_name'] = sub_run['run_name'].iloc[i]
                    temp_dict['alignment'] = overall_run['alignment'].iloc[0]
                    temp_dict['gdr'] = sub_run['gdr'].iloc[i]
                    if data.get('adv_cust'):
                        for attribute, sub_attr in categories.items():
                            temp_dict[attribute] = {}
                            for sub_attribute in sub_attr:
                                if attribute != 'result':
                                        temp_dict[attribute]['total'] = sub_run[attribute].iloc[i]
                                        temp_dict[attribute][sub_attribute] = sub_run[sub_attribute].iloc[i]
                                else:
                                    temp_dict[attribute]['total'] = overall_run[attribute].iloc[0] + sub_run[attribute].iloc[i]
                                    temp_dict[attribute]['unified_result'] = overall_run['unified_save_results'].iloc[0]
                                    temp_dict[attribute]['global_filters'] = overall_run['global_filters'].iloc[0]
                                    temp_dict[attribute]['save_results'] = sub_run['save_results'].iloc[i]
                                    break
                    else:
                        temp_dict['pre-scan'] = sub_run['pre-scan'].iloc[i]
                        temp_dict['scan'] = sub_run['scan'].iloc[i]
                        temp_dict['result'] = sub_run['result'].iloc[i] + overall_run['result'].iloc[0]
                    self.replace_nan_with_none(temp_dict)
                    result.append(temp_dict)
            else:
                result = []
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}
        return result

    async def calculate_tpt_limit(self,data):
        try:
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["limit_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))

            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            # Concatenate all dataframes
            if not len(dfs):
                return []
            resp = pd.concat(dfs)
            if len(resp):
                overall_run = resp[resp['parent_tool_runid'] == 0]
                sub_run = resp[resp['parent_tool_runid'] != 0]
                sub_run['pre-scan']= sub_run[['null_review', 'null_scan', 'dcf', 'shading', 'oil']].sum(axis=1, skipna=True)
                sub_run['scan'] = sub_run[['prepare_scan', 'af_slice', 'scan_duration', 'post_scan']].sum(axis=1, skipna=True)
                overall_run['result'] = overall_run[['result_duration', 'global_filters']].sum(axis=1, skipna=True)
                overall_run = overall_run.replace({np.Nan: None})
                sub_run = sub_run.replace({np.Nan: None})
                result = {}
                result['alignment'] = overall_run['alignment'].iloc[0]
                result['target'] = overall_run['target'].iloc[0]
                result['pre-scan'] = sub_run['pre-scan'].iloc[0]
                result['scan'] = sub_run['scan'].iloc[0]
                result['result'] = overall_run['result'].iloc[0]
                return result
            else:
                return []

        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}

    def replace_nan_with_none(self,d):
        """Recursively replace NaN values with None in a dictionary."""
        for k, v in d.items():
            if isinstance(v, dict):
                self.replace_nan_with_none(v)
            elif isinstance(v, float) and np.isnan(v):
                d[k] = None

    async def tpt_limit(self,data, color=False):
        try:
            app_log.info("Getting the required limits")
            get_limit_query = self.queries['limit_config'].format(**data)
            limit_config_data = await get_query_with_pool(get_limit_query)
            if len(limit_config_data):
                if limit_config_data['limit_type'].iloc[0] in ['calculated', 'predicted']:
                    limit_data_query = self.queries['limit_data'].format(**data)
                    limit_data = await get_query_with_pool(limit_data_query)
                    limit_data = limit_data.replace({np.NaN: None})
                    response = {
                        "limit_type": limit_config_data['limit_type'].iloc[0],
                        "time_range":{
                            "min_date": limit_config_data['min_date'].iloc[0].strftime('%Y-%m-%d'),
                            "max_date": limit_config_data['max_date'].iloc[0].strftime('%Y-%m-%d')
                        },
                        "deviation": limit_config_data['std'].iloc[0]
                    }
                    limit = limit_data[['alignment', 'result', 'pre-scan', 'scan']].to_dict(orient='records')
                    limit[0]['target'] = {
                        "lcl": limit_data['target_lcl'].iloc[0],
                        "ucl": limit_data['target_ucl'].iloc[0],
                        "baseline": limit_data['target_base'].iloc[0]
                    }
                    response['limits'] = limit[0]
                    if color:
                        return limit[0]
                    return response
                else:
                    limit_data_query = self.queries['manual_limit_data'].format(**data)
                    limit_data = await get_query_with_pool(limit_data_query)
                    response = {
                        "limit_type": limit_config_data['limit_type'].iloc[0],
                    }
                    limit = {}
                    for key in ['alignment', 'pre-scan', 'scan', 'result', 'gdr']:
                        limit[key] = {
                            "yellow": limit_data[f'{key}_yellow'].iloc[0],
                            "red": limit_data[f'{key}_red'].iloc[0]
                        }
                    limit['target'] = {
                        "lcl": limit_data['target_lcl'].iloc[0],
                        "ucl": limit_data['target_ucl'].iloc[0],
                        "baseline": limit_data['target_base'].iloc[0]
                    }
                    if color:
                        return limit
                    response['limits'] = limit
                    return response
            else:
                app_log.info("Getting PLR for the required timestamp")
                max_date = datetime.today()
                min_date = max_date - relativedelta(months=6)

                # min_date =  min_date.strftime('%Y-%m-%d')
                # max_date = max_date.strftime('%Y-%m-%d')
                data['time_range'] = {
                    "min_date": (max_date - relativedelta(months=1)).strftime('%Y-%m-%d'),
                    "max_date": max_date.strftime('%Y-%m-%d'),
                }
                result = await self.get_predicted(data=data, check=True)
                if result:
                    result['time_range'] = {}
                    result['time_range']['min_date'] =  data['time_range']['min_date']
                    result['time_range']['max_date'] = max_date.strftime('%Y-%m-%d')
                    return result
                filters = ['product', 'layer', 'recipeid']
                payload_data = {}
                for i in filters:
                    payload_data[i] = '"' + str(data[i]) + '"'
                current_date = min_date
                tasks = []
                if current_date == max_date:
                    return []
                while current_date < max_date:
                    next_date = min(current_date + timedelta(days=14), max_date)
                    payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                    payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                    current_date = next_date
                    payload = self.queries["limit_payload"].format(**payload_data)
                    tasks.append(get_filter_data(payload))

                result = await asyncio.gather(*tasks)
                dfs = [df for df in result if isinstance(df, pd.DataFrame)]
                min_date_str = min_date.strftime('%Y-%m-%d')
                max_date_str = max_date.strftime('%Y-%m-%d')
                # Concatenate all dataframes
                if not len(dfs):
                    return []
                resp = pd.concat(dfs)
                if len(resp):
                    overall_run = resp[resp['parent_tool_runid'] == 0]
                    sub_run = resp[resp['parent_tool_runid'] != 0]

                    overall_medians = overall_run[['alignment', 'global_filters', 'unified_save_results', 'total_inspect_duration']].median()
                    sub_median = sub_run[['null_review', 'null_scan', 'dcf', 'oil_shading', 'oil_histogram', 'prepare_scan', 'af_slice', 'scanset_scan_duration', 'post_scanset_duration', 'save_results']].median()
                    target_mad = overall_run[['total_inspect_duration']].apply(lambda x: np.median(np.abs(x.dropna() - np.median(x.dropna()))))
                    result = {}
                    result['pre-scan'] = sub_median['null_review'] + sub_median['null_scan'] + sub_median['dcf'] + sub_median['oil_shading'] + sub_median['oil_histogram']
                    result['scan'] = sub_median['prepare_scan'] + sub_median['af_slice'] + sub_median['scanset_scan_duration'] + sub_median['post_scanset_duration']
                    result['result'] = sub_median['save_results'] + overall_medians['unified_save_results'] + overall_medians['global_filters']
                    result['alignment'] = overall_medians['alignment']
                    result['target'] = {
                        'lcl':  round(overall_medians['total_inspect_duration'] - (data.get('deviation', 3) * target_mad['total_inspect_duration']), 2),
                        'baseline': round(overall_medians['total_inspect_duration'], 2),
                        'ucl': round(overall_medians['total_inspect_duration'] + (data.get('deviation', 3) * target_mad['total_inspect_duration']), 2)
                    }
                    self.replace_nan_with_none(result)
                    result = {
                        "limit_type": "calculated",
                        "time_range": {
                            "min_date": min_date_str,
                            "max_date": max_date_str
                        },
                        "deviation": 3,
                        "limits": result
                    }
                    if color:
                        return result['limits']
                    return result
                else:
                    result = {
                        "limit_type": "calculated",
                        "time_range":{
                            "min_date": min_date_str,
                            "max_date": max_date_str
                        },
                        "limits": {
                            "alignment": None,
                            "pre-scan": None,
                            "scan": None,
                            "result": None,
                            "target": {
                                "lcl": None,
                                "ucl": None,
                                "baseline": None
                            }
                        }
                    }
                    if color:
                        return []
                    return result
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}

    async def get_calculated(self,data):
        try:
            app_log.info("Getting the required limits")
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['time_range']
            filters = ['product', 'layer', 'recipeid']
            payload_data = {}
            for i in filters:
                payload_data[i] = '"' + str(data[i]) + '"'

            min_date = datetime.strptime(date_data['min_date'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max_date'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return await self.empty_response(min_date, max_date, limit_type='calculated')
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["limit_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))

            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            # Concatenate all dataframes
            if not len(dfs):
                return await self.empty_response(min_date, max_date, limit_type='calculated')
            resp = pd.concat(dfs)
            if len(resp):
                overall_run = resp[resp['parent_tool_runid'] == 0]
                sub_run = resp[resp['parent_tool_runid'] != 0]

                overall_medians = overall_run[['alignment', 'global_filters', 'unified_save_results', 'total_inspect_duration']].median()
                sub_median = sub_run[['null_review', 'null_scan', 'dcf', 'oil_shading', 'oil_histogram', 'prepare_scan', 'af_slice', 'scanset_scan_duration', 'post_scanset_duration', 'save_results']].median()
                target_mad = overall_run[['total_inspect_duration']].apply(lambda x: np.median(np.abs(x.dropna() - np.median(x.dropna()))))
                # overall_medians = overall_medians.replace({np.NaN: None})
                # sub_median = sub_median.replace({np.NaN: None})
                result = {}
                result['pre-scan'] = sub_median['null_review'] + sub_median['null_scan'] + sub_median['dcf'] + sub_median['oil_shading'] + sub_median['oil_histogram']
                result['scan'] = sub_median['prepare_scan'] + sub_median['af_slice'] + sub_median['scanset_scan_duration'] + sub_median['post_scanset_duration']
                result['result'] = sub_median['save_results'] + overall_medians['unified_save_results'] + overall_medians['global_filters']
                result['alignment'] = overall_medians['alignment']
                result['target'] = {
                    'lcl':  round(overall_medians['total_inspect_duration'] - (data.get('deviation', 3) * target_mad['total_inspect_duration']),2),
                    'baseline': round(overall_medians['total_inspect_duration'], 2),
                    'ucl': round(overall_medians['total_inspect_duration'] + (data.get('deviation', 3) * target_mad['total_inspect_duration']),2)
                }
                self.replace_nan_with_none(result)
                response = {
                    "limit_type": "calculated",
                    "limits": result
                }
            else:
                response = await self.empty_response(min_date, max_date, limit_type='calculated')

        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}
        return response

    async def get_predicted(self,data, check=False):
        try:
            app_log.info("Getting the required limits")
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['time_range']
            filters = ['product', 'layer', 'recipeid']
            payload_data = {}
            for i in filters:
                payload_data[i] = '"' + str(data[i]) + '"'

            min_date = datetime.strptime(date_data['min_date'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max_date'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["predicted_payload"].format(**payload_data)
                tasks.append(get_filter_data(payload))

            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]

            if not len(dfs):
                return await self.empty_response(min_date, max_date, limit_type='predicted')
            # Concatenate all dataframes
            resp = pd.concat(dfs)
            if len(resp):
                overall_run = resp[resp['parent_tool_runid'] == 0]
                sub_run = resp[resp['parent_tool_runid'] != 0]

                sub_run['pre-scan']= sub_run[['null_review', 'null_scan', 'dcf', 'shading', 'oil']].sum(axis=1, skipna=True)
                sub_run['scan'] = sub_run[['prepare_scan', 'af_slice', 'scan_duration', 'post_scan']].sum(axis=1, skipna=True)

                overall_run['result'] = overall_run[['result_duration', 'global_filters']].sum(axis=1, skipna=True)

                overall_run = overall_run.replace({np.NaN: None})
                sub_run = sub_run.replace({np.NaN: None})

                result = {}
                result['alignment'] = overall_run['alignment'].iloc[0]*1000
                result['target'] = {
                    "lcl": round(overall_run['target'].iloc[0]*0.5, 2),
                    "ucl": round(overall_run['target'].iloc[0]*1.75, 2),
                    "baseline": round(overall_run['target'].iloc[0]*1.25,2)
                }
                result['pre-scan'] = sub_run['post_scan'].sum()*1000
                result['scan'] = sub_run['scan'].sum()*1000
                result['result'] = overall_run['result'].iloc[0]*1000
                response = {
                    "limit_type": "predicted",
                    "limits": result
                }
                return response
            else:
                if check:
                    return False
                response = await self.empty_response(min_date, max_date, limit_type='predicted')
        except Exception as e:
            app_log.exception(e)
            if check:
                return []
            return {"error": "Something went wrong"}
        return response

    async def save_calculated(self, data):
        try:
            app_log.info('Saving Calculated Limits')

            overwrite_query = self.queries['overwrite_limit'].format(**data)
            await get_query_with_pool(overwrite_query)
            overwrite_query_config = self.queries['overwrite_limit_config'].format(**data)
            await get_query_with_pool(overwrite_query_config)
            query_data = {}
            query_data['product'] = data['product']
            query_data['layer'] = data['layer']
            query_data['recipeid'] = data['recipeid']
            query_data['limit_type'] = data['limit_type']
            query_data['alignment'] = data['limits']['alignment'] if data['limits'].get('alignment') else 'Null'
            query_data['pre-scan'] = data['limits']['pre-scan'] if data['limits'].get('pre-scan') else 'Null'
            query_data['scan'] = data['limits']['scan'] if data['limits'].get('scan') else 'Null'
            query_data['result'] = data['limits']['result'] if data['limits'].get('result') else 'Null'
            query_data['target_lcl'] = data['limits']['target']['lcl'] if data['limits'].get('target', {}).get('lcl') else 'Null'
            query_data['target_ucl'] = data['limits']['target']['ucl'] if data['limits'].get('target', {}).get('ucl') else 'Null'
            query_data['target_base'] = data['limits']['target']['baseline'] if data['limits'].get('target', {}).get('baseline') else 'Null'

            insert_query = self.queries['save_calculated'].format(**query_data)
            await get_query_with_pool(insert_query)

            sec_query_data = {}
            sec_query_data['product'] = data['product']
            sec_query_data['layer'] = data['layer']
            sec_query_data['recipeid'] = data['recipeid']
            sec_query_data['limit_type'] = data['limit_type']
            sec_query_data['std'] = data.get('deviation', 'Null')
            sec_query_data['min_date'] = "'"+data['time_range']['min_date']+"'"
            sec_query_data['max_date'] = "'"+data['time_range']['max_date']+"'"

            insert_config_query = self.queries['save_calculated_config'].format(**sec_query_data)
            await get_query_with_pool(insert_config_query)

            return {"message": "Limits saved successfully"}
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}

    async def save_manual(self, data):
        try:
            app_log.info('Saving Manual Limits')

            overwrite_query = self.queries['overwrite_limit'].format(**data)
            await get_query_with_pool(overwrite_query)

            overwrite_query_config = self.queries['overwrite_limit_config'].format(**data)
            await get_query_with_pool(overwrite_query_config)
            query_data = {}
            query_data['product'] = data['product']
            query_data['layer'] = data['layer']
            query_data['recipeid'] = data['recipeid']
            query_data['limit_type'] = data['limit_type']
            for i in ['alignment', 'scan', 'pre-scan', 'result', 'gdr']:
                query_data[f'{i}_yellow'] = data['limits'][i]['yellow'] if data['limits'].get(i, {}).get('yellow') is not None  else 'Null'
                query_data[f'{i}_red'] = data['limits'][i]['red'] if data['limits'].get(i, {}).get('red') is not None else 'Null'
            query_data['target_lcl'] = data['limits']['target']['lcl'] if data['limits'].get('target', {}).get('lcl') is not None  else 'Null'
            query_data['target_ucl'] = data['limits']['target']['ucl'] if data['limits'].get('target', {}).get('ucl') is not None  else 'Null'
            query_data['target_base'] = data['limits']['target']['baseline'] if data['limits'].get('target', {}).get('baseline') is not None else 'Null'

            insert_query = self.queries['save_manual'].format(**query_data)
            await get_query_with_pool(insert_query)

            sec_query_data = {}
            sec_query_data['product'] = data['product']
            sec_query_data['layer'] = data['layer']
            sec_query_data['recipeid'] = data['recipeid']
            sec_query_data['limit_type'] = data['limit_type']
            sec_query_data['std'] = 'Null'
            sec_query_data['min_date'] = 'Null'
            sec_query_data['max_date'] = 'Null'

            insert_config_query = self.queries['save_calculated_config'].format(**sec_query_data)
            await get_query_with_pool(insert_config_query)

            return {"message": "Limits saved successfully"}
        except Exception as err:
            app_log.exception(err)
            return  {"error": "Something went wrong"}



