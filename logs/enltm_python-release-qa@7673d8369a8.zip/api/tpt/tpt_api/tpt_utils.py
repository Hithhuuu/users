import pandas as pd
import aiohttp
from api.utils.utils import get_logger,env_config

app_log = get_logger("wra")

async def get_token():
    try:
        """Get the token from the wra auth server"""
        wra_api = env_config['wra_api']
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f'http://{wra_api["host"]}:{wra_api["port"]}/appserver/api/wra/login',
                json={"username": wra_api['username'], "password": wra_api['password']},
            ) as response:
                if response.status != 200:
                    return {"error": "Failed to get token", "status_code": {response.status}}
                resp = await response.json()
        return resp['token']
    except Exception as err:
        return {"error": "Failed to get token", "message": str(err)}

async def get_tpt_data(payload):
    try:
        """Get the oil data"""
        wra_api = env_config['wra_api']
        token = await get_token()
        headers = {
        'Authorization': f'{token}',
        'Content-Type': 'application/json'
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f'http://{wra_api["host"]}:{wra_api["port"]}/appserver/api/wra/runsData',
                data=payload,
                headers=headers,
            ) as response:
                if response.status != 200:
                    return {"error": "Failed to get tpt data", "status_code": {response.status}}
                resp = await response.json()
                if not resp['data']:
                    return {"error": "No data found"}
                columns = [col['text'] for col in resp['data'][0]['columns']]
                # columns = ['tool_runid', 'tool', 'last_time', 'pdcrun', 'recipeid', 'layer','product','waferid', 'lotid', 'recipe_time', 'slotid', 'lcl', 'status', 'ucl', 'target', 'result']
                rows = resp['data'][0]['rows']
                df = pd.DataFrame(rows, columns=columns)
                return df
    except Exception as err:
        return {"error": "Failed to get oil data", "message": str(err)}

async def get_filter_data(payload):
    try:
        """Get the oil data"""
        wra_api = env_config['wra_api']
        token = await get_token()
        headers = {
        'Authorization': f'{token}',
        'Content-Type': 'application/json'
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f'http://{wra_api["host"]}:{wra_api["port"]}/appserver/api/wra/runsData',
                data=payload,
                headers=headers,
            ) as response:
                if response.status != 200:
                    return {"error": "Failed to get tpt data", "status_code": {response.status}}
                resp = await response.json()
                if not resp['data']:
                    return {"error": "No data found"}
                # columns = ['tool', 'recipeid', 'layer', 'product']
                columns = [col['text'] for col in resp['data'][0]['columns']]
                rows = resp['data'][0]['rows']
                df = pd.DataFrame(rows, columns=columns)
                return df
    except Exception as err:
        return {"error": "Failed to get oil data", "message": str(err)}

async def get_scanset_data(payload):
    try:
        """Get Scanset data"""
        wra_api = env_config['wra_api']
        token = await get_token()
        headers = {
        'Authorization': f'{token}',
        'Content-Type': 'application/json'
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f'http://{wra_api["host"]}:{wra_api["port"]}/appserver/api/wra/runsData',
                data=payload,
                headers=headers,
            ) as response:
                if response.status != 200:
                    return {"error": "Failed to get tpt data", "status_code": {response.status}}
                resp = await response.json()
                if not resp['data']:
                    return {"error": "No data found"}
                # columns = ['product', 'layer', 'recipeid', 'scanset_name', 'sensitive_wafer', 'illumination_polarization', 'bf_collection_polarization', 'gf_collection', 'magnification', 'spot_control', 'gf_clc', 'bf_clc', 'light_factor', 'thining_value']
                columns = [col['text'] for col in resp['data'][0]['columns']]
                rows = resp['data'][0]['rows']
                df = pd.DataFrame(rows, columns=columns)
                return df
    except Exception as err:
        return {"error": "Failed to get oil data", "message": str(err)}
