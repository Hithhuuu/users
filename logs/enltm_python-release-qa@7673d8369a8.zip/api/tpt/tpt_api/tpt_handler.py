"""OIL API Handler File"""
from fastapi.responses import JSONResponse, Response
from fastapi import  APIRouter,Depends
import io
import os
from api.tpt.tpt_api.tpt_model import Tpt
from api.utils.fastapi_app import verify_jwt



router = APIRouter(tags=['TPT'],prefix="/tpt", dependencies=[Depends(verify_jwt)])


@router.post("/recipetable")
async def oil_table(body: dict):
    """
    Endpoint to retrieve Common/Missing/Adders.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the Common/Missing/Adders data.
    """
    tpt_data = Tpt()
    response = await tpt_data.get_table_data(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)

@router.post("/filter")
async def oil_table(body: dict):
    """
    Endpoint to retrieve Common/Missing/Adders.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the Common/Missing/Adders data.
    """
    tpt_data = Tpt()
    response = await tpt_data.get_filter(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)

@router.post("/timetrend")
async def timetrend_handler(body: dict):
    """
    Endpoint to retrieve Timetrend data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    response = await tpt_data.get_timetrend(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.post("/optical")
async def timetrend_handler(body: dict):
    """
    Endpoint to retrieve Timetrend data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    response = await tpt_data.get_optical_data(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response


@router.post("/export")
async def export_handler(body: dict):
    """
    Endpoint to retrieve Scan Set Export data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    filename = await tpt_data.get_export(body)
    if isinstance(filename, dict):
        if "error" in filename:
            return JSONResponse(status_code=400, content=filename)
        else:
            return Response(status_code=204)
    else:
        with open(filename, "rb") as fi:
            contents = fi.read()
        if os.path.exists(filename):
            os.remove(filename)
        blob_data = io.BytesIO(contents)
        response = Response(content=blob_data.getvalue(), media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        return response

@router.post("/segment")
async def segment_handler(body: dict):
    """
    Endpoint to retrieve Segment data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    response = await tpt_data.get_segment_data(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.post("/segment/calculated")
async def callimit_handler(body: dict):
    """
    Endpoint to retrieve Calculate Limit data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    if body['limit_type'] == 'calculated':
        response = await tpt_data.get_calculated(body)
    else:
        response = await tpt_data.get_predicted(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.post("/segment/set")
async def limit_handler(body: dict):
    """
    Endpoint to retrieve Limit data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    if body['limit_type'] != 'manual':
        response = await tpt_data.save_calculated(body)
    else:
        response = await tpt_data.save_manual(body)
    if "error" in response:
        return Response(content=response)
    return response

@router.get("/segment/limit")
async def limit_handler(product: str, layer: str, recipeid: str):
    """
    Endpoint to retrieve Limit data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    data = {
        "product": product,
        "layer": layer,
        "recipeid": recipeid
    }
    response = await tpt_data.tpt_limit(data)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.get("/segment/color")
async def limit_handler(product: str, layer: str, recipeid: str):
    """
    Endpoint to retrieve Limit data.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the timetrend data.
    """
    tpt_data = Tpt()
    data = {
        "product": product,
        "layer": layer,
        "recipeid": recipeid
    }
    response = await tpt_data.tpt_limit(data, color=True)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response