"""FAST API Router File"""
from api.utils.fastapi_app import app
from api.tpt.tpt_api import tpt_handler

app.include_router(tpt_handler.router)