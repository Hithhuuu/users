import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from otf_api.otf_model import Otf, OtfSingleViewModel

router = APIRouter(tags=['OTF'],prefix="/otf",dependencies=[Depends(verify_jwt)])
otf = Otf()

@router.post("/images")
async def post(request: Request, body: dict):
    """On post request give the image path as a response"""
    respone = await otf.get(body)
    if "error" in respone:
        return JSONResponse(status_code=400, content=respone)

    return JSONResponse(content=respone)

@router.post("/singleview")
async def post(request: Request, body: dict):
    """On post request give the image path as a response"""
    singleview = OtfSingleViewModel()
    respone = await singleview.get(data=body)
    if "error" in respone:
        return JSONResponse(status_code=400, content=respone)

    return JSONResponse(content=respone)

@router.post("/histogram")
async def post(request: Request, body: dict):
    """On post request give the image path as a response"""
    singleview = OtfSingleViewModel()
    respone = await singleview.get_histogram_data(data=body)
    if "error" in respone:
        return JSONResponse(status_code=400, content=respone)

    return JSONResponse(content=respone)




