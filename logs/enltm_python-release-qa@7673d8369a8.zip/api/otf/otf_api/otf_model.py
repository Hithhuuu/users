import os
import sys
import numpy as np
import re
from PIL import Image
import copy
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from utils.utils import (
    queries,
    get_logger,
    env_config,
    columns_info
)
from api.utils.common import make_query

app_log = get_logger("otf")


class Otf:
    """This class provide functionality of singleview, histogram for OTF """

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["otf"]

    async def get(self, data):
        try:
            if len(data.get('inputs').get('selectedruns', [])) == 0:
                return({
                    'data': [],
                    'limit': 0,
                    'offset': 0,
                    'total': 0
                })
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            query_data = make_query(data)
            query_data['mapid'] = tuple(data.get("inputs").get('selectedruns'))
            master_check = self.queries["master_check"].format(**query_data)
            master_count = await get_query_with_pool(master_check)

            runs_data = master_count[master_count['is_master'] == 0]
            runs_data = runs_data.set_index('mapid').to_dict(orient='index')
            master_count = master_count[master_count['is_master'] == 1]

            inputs = data.get('inputs')
            orientation = inputs.get('orientationmarklocation', 'DOWN').lower()
            image_data = data.get("inputs").get("images")
            selected_column = image_data.get("filteredImageDisplay") if tuple(image_data.get(
                "filteredImageDisplay")) else columns_info['image_code'].values()

            query_data['imagecode'] = selected_column[0]
            query_data['orientation'] = orientation
            query_data['diepitch_x'] = inputs.get('diepitch_x')
            query_data['diepitch_y'] = inputs.get('diepitch_y')
            query_data['fieldx'] = inputs.get('fieldx')
            query_data['fieldy'] = inputs.get('fieldy')
            query_data['appserver'] = os.environ['APP_SERVER']

            if query_data['mapid']:
                limit, offset = image_data.get(
                    'limit', 10), image_data.get('offset', 10)
                query_data['limit_cdtn'] = f" LIMIT {offset}, {limit}"

                ids_condition = f" and ((imagelist LIKE '%-{selected_column[0]},%') OR (imagelist LIKE '%-{selected_column[0]}'))"
                query_data['ids_condition'] = ids_condition

                if len(master_count) == 0:
                    query = self.queries['read_tifffile_name'].format(**query_data)
                    app_log.info(f"OTF query: {query}")
                    result = await get_query_with_pool(query, "df")
                    if len(result):
                        resp = result['otf'].to_list()
                        total = int(result['total'].iloc[0])
                        resp_data = {
                            'data': resp,
                            'isref': 0,
                            'limit': limit,
                            'offset': offset,
                            'total': total
                        }
                    else:
                        resp_data = {
                            "data": [],
                            "isref": 0,
                            'limit': limit,
                            'offset': offset,
                            'total': 0

                        }

                else:
                    common_query = self.queries['commonality'].format(**query_data)
                    commonality_df = await get_query_with_pool(common_query, "df")
                    commonality_dict = commonality_df.to_dict(orient='records')

                    smapid = commonality_df['smapid'].unique().tolist() if len(commonality_df) else list(query_data['mapid'])
                    rmapid = commonality_df['rmapid'].iloc[0] if len(commonality_df) else master_count['mapid'].iloc[0]

                    rtimestamp =  master_count['resulttimestamp'].iloc[0]
                    rlot =  master_count['lot'].iloc[0]
                    rwaferid = master_count['waferid'].iloc[0]

                    smapid.append(rmapid)
                    sec_runs = query_data['mapid']

                    query_data['mapid'] = tuple(smapid)
                    query_data['sdefectmap'] = tuple(commonality_df['sdefectmap'].tolist()) if len(commonality_df) else '(null,null)'

                    query_data['mmapid'] = rmapid
                    query_data['rdefectid'] = tuple(commonality_df['rdefectid'].tolist()) if len(commonality_df) else '(null)'

                    otf_query = self.queries['otf_query'].format(**query_data)
                    otf_df = await get_query_with_pool(otf_query, "df")
                    otf_dict = otf_df.to_dict(orient='records')
                    if len(otf_df) or len(commonality_df):
                        total = int(otf_df['total'].iloc[0])
                        sec_default_sorted_dict = {}
                        secondary_dict = {}

                        for id in  sec_runs:
                            sec_default_sorted_dict[f"{id}"] = {
                                "defectId": '',
                                "imageUrl": '',
                                "mapId": f"{id}",
                                "lot": f'{runs_data[id]["lot"]}',
                                "waferid": f'{runs_data[id]["waferid"]}',
                                "resulttimestamp": f'{runs_data[id]["resulttimestamp"]}',
                                "isref": '0',
                                "rmapid": f"{rmapid}",
                                "rdefectid": ''
                            }

                        for d in commonality_dict:
                            if f"{d['rdefectid']}" not in secondary_dict.keys():
                                secondary_dict[f"{d['rdefectid']}"] = {}

                            secondary_dict[f"{d['rdefectid']}"][f"{d['smapid']}"] = {
                                        "defectId": f"{d['sdefectid']}",
                                        "imageUrl": f"{d['imagepath']}",
                                        "mapId": f"{d['smapid']}",
                                        "lot": f"{d['lot']}",
                                        "waferid":f"{d['waferid']}",
                                        "resulttimestamp": f"{d['resulttimestamp']}",
                                        "isref": '0',
                                        "xrel":f"{d['sxrel']}",
                                        "xindex": f"{d['sxindex']}",
                                        "yrel": f"{d['syrel']}",
                                        "yindex":f"{d['syindex']}",
                                        "xsite":f"{d['sxsite']}",
                                        "ysite":f"{d['sysite']}",
                                        "fieldrelx":f"{d['sfieldrelx']}",
                                        "fieldrely":f"{d['sfieldrely']}",
                                        "xsize":f"{d['sxsize']}",
                                        "ysize":f"{d['sysize']}",
                                        "grade":f"{d['sgrade']}",
                                        "rmapid": f"{d['rmapid']}",
                                        "rdefectid": f"{d['rdefectid']}"
                                    }

                        sec_default_sorted_dict = dict(sorted(sec_default_sorted_dict.items()))
                        resp = []
                        for d in otf_dict:
                            if d['isref']:
                                tmp = {
                                        f"{d['mapid']}": {
                                            "defectId": f"{d['defectid']}",
                                            "imageUrl": f"{d['imagepath']}",
                                            "mapId": f"{d['mapid']}",
                                            "lot": f"{d['lot']}",
                                            "waferid":f"{d['waferid']}",
                                            "resulttimestamp": f"{d['resulttimestamp']}",
                                            "isref": '1',
                                            "xrel": f"{d['xrel']}",
                                            "xindex": f"{d['xindex']}",
                                            "yrel": f"{d['yrel']}",
                                            "yindex":f"{d['yindex']}",
                                            "xsite":f"{d['xsite']}",
                                            "ysite":f"{d['ysite']}",
                                            "fieldrelx":f"{d['fieldrelx']}",
                                            "fieldrely":f"{d['fieldrely']}",
                                            "xsize":f"{d['xsize']}",
                                            "ysize":f"{d['ysize']}",
                                            "grade":f"{d['grade']}",
                                            "rmapid": f"{d['mapid']}",
                                            "rdefectid": f"{d['defectid']}"
                                        }
                                    }
                                tmp.update(sec_default_sorted_dict)
                                for key, val in secondary_dict.get(f"{d['defectid']}", {}).items():
                                    tmp[key] = val
                            else:
                                tmp = {
                                        f"{rmapid}": {
                                            "defectId": '',
                                            "imageUrl": '',
                                            "mapId": f"{rmapid}",
                                            "lot": f'{rlot}',
                                            "waferid": f'{rwaferid}',
                                            'resulttimestamp': f'{rtimestamp}',
                                            "isref": '1',
                                            "rmapid": f"{rmapid}",
                                            "rdefectid": ''
                                        }
                                    }
                                tmp.update(sec_default_sorted_dict)
                                tmp[f"{d['mapid']}"] = {
                                    "defectId": f"{d['defectid']}",
                                    "imageUrl": f"{d['imagepath']}",
                                    "mapId": f"{d['mapid']}",
                                    "lot": f"{d['lot']}",
                                    "waferid":f"{d['waferid']}",
                                    "resulttimestamp": f"{d['resulttimestamp']}",
                                    "isref": '0',
                                    "xrel": f"{d['xrel']}",
                                    "xindex": f"{d['xindex']}",
                                    "yrel": f"{d['yrel']}",
                                    "yindex":f"{d['yindex']}",
                                    "xsite":f"{d['xsite']}",
                                    "ysite":f"{d['ysite']}",
                                    "fieldrelx":f"{d['fieldrelx']}",
                                    "fieldrely":f"{d['fieldrely']}",
                                    "xsize":f"{d['xsize']}",
                                    "ysize":f"{d['ysize']}",
                                    "grade":f"{d['grade']}",
                                    "rmapid": f"{rmapid}",
                                    "rdefectid": ""
                                }

                            tmp = {
                                "refDefectId": f"{d['defectid']}",
                                "refDefectClass": d['classname'],
                                "otfImageList": list(tmp.values())
                            }
                            resp.append(tmp)

                        resp_data = {
                            'data': resp,
                            'isref': 1,
                            'limit': limit,
                            'offset': offset,
                            'total': total
                        }
                    else:
                        resp_data = {
                            'data': [],
                            'isref': 1,
                            'limit': limit,
                            'offset': offset,
                            'total': 0
                        }

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}

        return(resp_data)

class OtfSingleViewModel():
    def __init__(self):
        self.queries = queries["otf"]
        self.defectid = ''
        self.mapid = ''
        self.tiff_file_name = ''
        self.hover_singleview = False

    def get_pixel_data(self, imgsrc):
        try:
            img_stats = {}

            # Open the image
            im = Image.open(imgsrc)

            if im.mode != 'L':
                im = im.convert('L')

            # Get the size of the image
            width, height = im.size

            pixel_data = {}
            # Iterate over all the pixels
            for y in range(height):
                for x in range(width):
                    # Get the pixel value at position (x, y)
                    pixel_data[f"{x}-{y}"] = im.getpixel((x, y))

            im_np_array = np.asarray(im)

            img_stats = {
                "pixel_data": pixel_data,
                "min": int(im_np_array.min()),
                "max": int(im_np_array.max()),
                "avg": int(im_np_array.mean()),
                "median": int(np.median(im_np_array)),
                "standardDeviation": int(im_np_array.std())
            }
        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
        return img_stats

    def grayscale_stretch(self, image_src, prefix):
        image_type = prefix.split('_', 1)[1] if 'gf' in prefix or 'bf' in prefix else prefix
        image_perspective = prefix.split('_', 1)[0] if 'gf' in prefix or 'bf' in prefix else 'unknown'

        filename, ext = os.path.splitext(self.tiff_file_name)
        filename = re.sub(r'[^a-zA-Z0-9]', '_', filename)
        watch_path = env_config["watchdog_pick_location"]["src"]
        base_path = os.path.join(watch_path, 'images')
        dest_path = os.path.join(base_path, filename)
        image_name = f"{filename}_{prefix}_{self.defectid}.jpg"
        image_path = os.path.join(dest_path, image_name)

        if not(os.path.exists(image_path)):
            im = Image.open(image_src)
            if im.mode != 'L':
                im = im.convert('L')

            minimum = im.getextrema()[0]
            maximum = im.getextrema()[1]
            factor = 0

            if maximum != minimum:
                factor = 255 / (maximum - minimum)
            stretched_image = Image.new('L', im.size)

            for x in range(im.width):
                for y in range(im.height):
                    value = im.getpixel((x, y))
                    stretched_value = int((value - minimum) * factor)
                    stretched_image.putpixel((x, y), stretched_value)

            stretched_image.save(image_path, 'JPEG', subsampling=0 , quality = 95)
            app_log.info(f"Diff stretched image has been created at: {image_path}")

        image_details = {
                "mapid": self.mapid,
                "defectid": self.defectid,
                "image": f"{env_config['image_location']}/{filename}/{image_name}",
                "image_code": None,
                "image_path": image_path,
                "imageType": image_type,
                "imagePerspective": image_perspective
        }

        if(not self.hover_singleview):
            img_stats = self.get_pixel_data(image_path)
            image_details["min"] = img_stats["min"]
            image_details["max"] = img_stats["max"]
            image_details["avg"] = img_stats["avg"]
            image_details["median"] = img_stats["median"]
            image_details["standardDeviation"] = img_stats["standardDeviation"]
            image_details["pixelData"] = img_stats["pixel_data"]

        return image_details


    async def get_diff_image(self, cur_img, ref_img, prefix):
        image_codes = copy.copy(columns_info['image_code'])

        image_type = prefix.split('_', 1)[1] if 'gf' in prefix or 'bf' in prefix else prefix
        image_perspective = prefix.split('_', 1)[0] if 'gf' in prefix or 'bf' in prefix else 'unknown'

        filename, ext = os.path.splitext(self.tiff_file_name)
        filename = re.sub(r'[^a-zA-Z0-9]', '_', filename)
        base_path = os.path.join(env_config['watchdog_pick_location']['src'], 'images')
        dest_path = os.path.join(base_path, filename)
        diff_image_name = f"{filename}_{prefix}_{self.defectid}.jpg"
        complete_tiff_path = os.path.join(dest_path, diff_image_name)

        if not(os.path.exists(complete_tiff_path)):
            cur_img = Image.open(cur_img)
            ref_img = Image.open(ref_img)

            # Convert both images to 8-bit grayscale
            if cur_img.mode != 'L':
                cur_img = cur_img.convert('L')

            if ref_img.mode != 'L':
                ref_img = ref_img.convert('L')

            # Create a new image to hold the difference image
            difference_image = Image.new('L', cur_img.size)

            # # Iterate over the pixels in both images
            for x in range(cur_img.width):
                for y in range(cur_img.height):
                    # Calculate the difference between the pixel values
                    cur_pixel = cur_img.getpixel((x, y))
                    ref_pixel = ref_img.getpixel((x, y))
                    difference = cur_pixel - ref_pixel
                    # Set the pixel value of the difference image to the calculated difference
                    difference_image.putpixel((x, y), difference if difference > 0 else 0)

            difference_image.save(complete_tiff_path, 'JPEG', subsampling=0 , quality = 95)
            app_log.info(f"Diff image has been created at: {complete_tiff_path}")

        diff_details = {
                "mapid": self.mapid,
                "defectid": self.defectid,
                "image": f"{env_config['image_location']}/{filename}/{diff_image_name}",
                "image_code": image_codes[prefix],
                "image_path": complete_tiff_path,
                "imageType": image_type,
                "imagePerspective": image_perspective,
         }
        if(not self.hover_singleview):
            img_stats = self.get_pixel_data(complete_tiff_path)
            diff_details["min"]= img_stats["min"]
            diff_details["max"]= img_stats["max"]
            diff_details["avg"]= img_stats["avg"]
            diff_details["median"]= img_stats["median"]
            diff_details["standardDeviation"]= img_stats["standardDeviation"]
            diff_details["pixelData"]= img_stats["pixel_data"]

        return diff_details


    async def get(self, data):
        '''
            get image based on mapid and defectid
        '''
        try:
            resp_data = {}
            self.defectid = data.get('defectid', False)
            self.mapid = data.get('mapid', False)
            self.hover_singleview = data.get('hoverSingleView', False)

            image_codes = copy.copy(columns_info['image_code'])
            image_codes.pop('ref')
            image_codes = dict((v,k) for k,v in image_codes.items())
            data['appserver'] = os.environ['APP_SERVER']
            image_combos = {
                1 : ('cur', 'prev', 'prev_diff', 'prev_diff_stretch'),
                2 : ('bf_cur', 'bf_prev', 'bf_prev_diff', 'bf_prev_diff_stretch'),
                3 : ('gf_cur', 'gf_prev', 'gf_prev_diff', 'gf_prev_diff_stretch'),
                4 : ('cur', 'next', 'next_diff', 'next_diff_stretch'),
                5 : ('bf_cur', 'bf_next', 'bf_next_diff', 'bf_next_diff_stretch'),
                6 : ('gf_cur', 'gf_next', 'gf_next_diff', 'gf_next_diff_stretch'),
            }

            if not(self.mapid) and not(self.defectid):
                raise Exception("mapid and defectid are must.")

            read_img_details = self.queries['read_image_details'].format(**data)
            app_log.info(f"Read image details query: {read_img_details}")
            img_data = await get_query_with_pool(read_img_details, resp_type='df')

            if img_data.empty:
                # raise Exception("No image data found")
                return {}

            image_list = img_data['image_data'].iloc[0]
            self.tiff_file_name = image_list[0]['tifffilename']

            image_dict = {}
            image_count = len(image_list)
            watch_path = env_config["watchdog_pick_location"]["src"]
            base_path = os.path.join(watch_path, 'images')
            for img in image_list:
                complete_tiff_path = os.path.join(base_path, img['image_path'])
                if os.path.exists(complete_tiff_path):
                    img_data = copy.copy(img)
                    img_data["image_path"] = complete_tiff_path
                    img_type_pr = image_codes[int(img_data['image_code'])]
                    img_data["imageType"] = img_type_pr.split('_', 1)[1] if 'gf' in img_type_pr or 'bf' in img_type_pr else img_type_pr
                    img_data["imagePerspective"] = img_type_pr.split('_', 1)[0] if 'gf' in img_type_pr or 'bf' in img_type_pr else 'unknown'

                    if not self.hover_singleview:
                        img_stats = self.get_pixel_data(complete_tiff_path)
                        img_data["min"] = img_stats["min"]
                        img_data["max"] = img_stats["max"]
                        img_data["avg"] = img_stats["avg"]
                        img_data["median"] = img_stats["median"]
                        img_data["standardDeviation"] = img_stats["standardDeviation"]
                        img_data["pixelData"] = img_stats["pixel_data"]

                    img_data.pop('tifffilename')
                    image_dict[img_type_pr] = img_data
                else:
                    image_count -= 1
            if image_count == 0:
                # raise Exception("No image found. Please upload tiff.")
                return {}

            image_list = {}
            pushed_img = []
            available_refs = []
            for k, v in image_combos.items():
                if image_dict.get(v[0], False) and image_dict.get(v[1], False):
                    cur_img = copy.copy(image_dict[v[0]])
                    ref_img = copy.copy(image_dict[v[1]])

                    # Create stretch image
                    if image_dict.get(v[2], False) == False:
                        # Create diff images
                        image_dict[v[2]] = await self.get_diff_image(cur_img["image_path"], ref_img["image_path"], prefix = v[2])
                    diff_img = copy.copy(image_dict[v[2]])

                    if(not self.hover_singleview):
                        diff_img_stretch = self.grayscale_stretch(image_dict[v[2]]["image_path"], prefix = v[3])

                    if v[0] not in pushed_img:
                        pushed_img.append(v[0])
                        cur_img.pop("image_path")
                        img_type = f"{cur_img['imageType']}_{cur_img['imagePerspective']}"
                        image_list[img_type] = cur_img

                    if v[1] not in pushed_img:
                        pushed_img.append(v[1])
                        ref_img.pop("image_path")
                        img_type = f"{ref_img['imageType']}_{ref_img['imagePerspective']}"
                        image_list[img_type] = ref_img
                        available_refs.append('next' if 'next' in v[1] else 'prev')

                    diff_img.pop("image_path")
                    img_type = f"{diff_img['imageType']}_{diff_img['imagePerspective']}"
                    image_list[img_type] = diff_img
                    if(not self.hover_singleview):
                        diff_img_stretch.pop("image_path")
                        img_type = f"{diff_img_stretch['imageType']}_{diff_img_stretch['imagePerspective']}"
                        image_list[img_type] = diff_img_stretch

            if "prev" in available_refs and "next" in available_refs and self.hover_singleview:
                image_list = {x:image_list[x]  for x in image_list.keys() if "next" not in x}

            resp_data = {
                "defectId": self.defectid,
                "mapid": self.mapid,
                "availablePrevNextRef": list(set(available_refs)),
                "selectedPrevNextRef": "prev" if "prev" in available_refs else available_refs[0],
                "imageList": image_list
            }

        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
            return {"error": str(e)}
        return (resp_data)


    async def get_histogram_data(self, data):
        try:
            '''
                This method will fetch data for histogram and cross section graphs
            '''
            resp_data = {}
            line_coords = data.get('lineCoords', None)
            line_direction = data.get('lineDirection', 'x').lower()
            selections = data.get('selections', ["cur_bf", "prev_bf", "prev_diff_bf", "prev_diff_stretch_bf", "next_bf", "next_diff_bf", "next_diff_stretch_bf", "cur_gf", "prev_gf", "prev_diff_gf", "prev_diff_stretch_gf", "next_gf", "next_diff_gf", "next_diff_stretch_gf", "cur_unknown", "prev_unknown", "prev_diff_unknown", "prev_diff_stretch_unknown", "next_unknown", "next_diff_unknown", "next_diff_stretch_unknown"])
            image_data = await self.get(data)

            if line_coords:
                x_from = min(line_coords["x1"],line_coords["x2"])
                x_to = max(line_coords["x1"],line_coords["x2"])
                y_from = min(line_coords["y1"],line_coords["y2"])
                y_to = max(line_coords["y1"],line_coords["y2"])
                for im, val in image_data["imageList"].items():
                    if(im in selections):
                        resp_data[im] = []
                        for x in range(x_from, x_to+1):
                            for y in range(y_from, y_to+1):
                                x_axis = x if line_direction == 'x' else y
                                resp_data[im].append({'x': int(x_axis), 'y': int(val['pixelData'][f'{x}-{y}'])})
            else:
                for im, val in image_data["imageList"].items():
                    if(im in selections):
                        histogram, bin_edges  = np.histogram(list(val['pixelData'].values()), bins=256, range=(0, 255))
                        resp_data[im] = []
                        for i, v in np.ndenumerate(histogram):
                            resp_data[im].append({'x': int(i[0]), 'y': int(v)})

            resp_data = {
                'data': resp_data,
                'selections': selections
            }
        except Exception as e:
            app_log.error(f"Something went wrong: {str(e)}")
            app_log.exception(e)
            return {"error": str(e)}
        return resp_data
