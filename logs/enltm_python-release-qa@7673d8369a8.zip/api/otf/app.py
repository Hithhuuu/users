from api.utils.fastapi_app import app
from api.otf.otf_api import otf_handler


app.include_router(otf_handler.router)