from api.utils.fastapi_app import app
from api.wafermap.wafermap_api import wafermap_handler

app.include_router(wafermap_handler.router)
