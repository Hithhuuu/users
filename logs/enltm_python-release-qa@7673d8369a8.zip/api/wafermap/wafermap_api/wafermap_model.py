"""Model to fetch global and secondary filters"""
import os
import sys
import json
import copy

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import queries, get_logger
from api.utils.common import make_query, make_queries, update_query, get_prep_level

app_log = get_logger("wafermap")


class WaferMap:
    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["wafermap"]

    def get_offset_columns(self, query_data):
        if "xindex" in query_data["condition"]:
            query_data["condition"] = query_data["condition"].replace(
                "xindex", "xindex_offset"
            )
        if "yindex" in query_data["condition"]:
            query_data["condition"] = query_data["condition"].replace(
                "yindex", "yindex_offset"
            )

    def prepare_query_inputs(self, data):
        """Prepare Query inputs with inputs data"""
        inputs = data["inputs"]
        query_c = ""
        wafermap = inputs["wafermap"]
        query = make_queries(data, alias="defects.")
        if data["inputs"].get("isCallSplit"):
            data_c = copy.deepcopy(data)
            data_c["inputs"].pop("xsite")
            data_c["inputs"].pop("ysite")
            query_c = make_queries(data_c, alias="defects.")
        orientation = inputs.get("orientationmarklocation", "down").lower()
        mapid = tuple(inputs.get("selectedruns"))

        query_inputs = {
            "query_c": query_c,
            "mapid": mapid,
            "xsite": f"xsite_{orientation}",
            "ysite": f"ysite_{orientation}",
            "shape_by": wafermap["shape_by"],
            "volume_by": wafermap["volume_by"],
            "issmall": inputs.get("issmall"),
            "fieldx": inputs.get("field_stacking").get("fieldx", 1)
            if inputs.get("field_stacking", None)
            else 1,
            "fieldy": inputs.get("field_stacking").get("fieldy", 1)
            if inputs.get("field_stacking", None)
            else 1,
            "diepitch_x": inputs.get("diepitch_x", 1),
            "diepitch_y": inputs.get("diepitch_y", 1),
            "query": update_query(query, orientation),
            "orientation": orientation,
            "waferView": inputs.get("waferView", "stack"),
        }
        return query_inputs

    def get_selected_maps(self, data, query):
        query_count = query
        if data["inputs"].get("selectedruns", None):
            selected_maps = str(tuple(data["inputs"]["selectedruns"]))
            maps = str(tuple(data["inputs"]["selectedruns"]))
            query_count = query.replace(maps, selected_maps)
            # + ' group by mapid order by count(1) desc limit 1'

    async def get(self, data):
        try:
            """Returns wafer map data on query"""
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            filter_data = make_query(data)
            mmap = []
            if data["inputs"].get("tool", None):
                tool = ["NA"]
                tool.append(data["inputs"].get('tool'))
                filter_data['tool'] = tuple(tool)
                fetch_master_map = self.queries["fetch_master_map"].format(**filter_data)
                mmap = await get_query_with_pool(fetch_master_map, resp_type="tuple")

            data["inputs"]["selectedruns"].append(mmap[0][0]) if len(mmap) else ""
            query_data = self.prepare_query_inputs(data)
            query_data["header_cdtn"] = filter_data["header_cdtn"]
            query_data["defect_cdtn"] = filter_data["defect_cdtn"]

            """ Prepare / Update query string on query_data condition """
            orientation = query_data["orientation"]
            query = query_data["query"]
            _query = query.replace("defects", "m")
            query_data.update({"condition": _query})
            count_condition_query = _query
            query_data.update(
                {"count_condition": count_condition_query.replace("m.", "defects.")}
            )
            query_data["condition"] = query_data["condition"][4:]

            app_log.info("Query Processsing for Wafer map")
            query_count = self.get_selected_maps(data, query)
            query_data_count = query_data
            query_data_count["count_condition"] = f" {query_count}"
            query_data_count["query_count"] = query_count
            query_data_count["mapid"] = (
                str(tuple(data["inputs"]["selectedMaps"]))
                if data["inputs"].get("selectedMaps", None)
                else query_data["mapid"]
            )
            query_data_count["offset"] = (
                self.queries["offset_join"].format(
                    **{
                        "mapid": query_data_count["mapid"],
                        "orientation": orientation,
                        "header_cdtn": query_data["header_cdtn"],
                        "defect_cdtn": query_data["defect_cdtn"],
                    }
                )
                if data["inputs"].get("waferView", "stack")
                and data["inputs"].get("waferView", "stack") != "multi1"
                else ""
            )
            query_data["isCallSplit"] = data["inputs"].get("isCallSplit", None)

            prep_columns = await get_prep_level(query_data_count)
            query_data["xsite"] = prep_columns["xsite"]
            query_data["ysite"] = prep_columns["ysite"]
            query_data["value_mapid"] = tuple(data["inputs"].get("selectedruns"))
            query_data["offset"] = (
                self.queries["offset_join"].format(
                    **{
                        "mapid": query_data_count["mapid"],
                        "orientation": orientation,
                        "header_cdtn": query_data["header_cdtn"],
                        "defect_cdtn": query_data["defect_cdtn"],
                    }
                )
                if data["inputs"].get("waferView", "stack")
                and data["inputs"].get("waferView", "stack") != "multi1"
                else ""
            )

            if (
                data["inputs"].get("waferView", "stack")
                and data["inputs"].get("waferView", "stack") != "multi1"
            ):
                query_data["offset_columns"] = self.queries["offset_columns"].format(
                    **{
                        "xsite": query_data["xsite"],
                        "ysite": query_data["ysite"],
                        "orientation": orientation,
                        "fieldx": query_data["fieldx"],
                        "fieldy": query_data["fieldy"],
                        "diepitch_x": query_data["diepitch_x"],
                        "diepitch_y": query_data["diepitch_y"],
                    }
                )
            else:
                query_data["offset_columns"] = self.queries["no_offset_columns"].format(
                    **{
                        "xsite": query_data["xsite"],
                        "ysite": query_data["ysite"],
                        "orientation": orientation,
                        "fieldx": query_data["fieldx"],
                        "fieldy": query_data["fieldy"],
                        "diepitch_x": query_data["diepitch_x"],
                        "diepitch_y": query_data["diepitch_y"],
                    }
                )
            self.get_offset_columns(query_data)
            query_data["mmap"] = mmap[0][0] if len(mmap) else 0
            if query_data["xsite"] == f"xsite_{orientation}":
                query_to_execute = self.queries["read_defects_level0"].format(
                    **query_data
                )
            else:
                query_to_execute = self.queries["read_defects"].format(**query_data)

            self.get_offset_columns(query_data)
            app_log.info(f"WAFER MAP FINAL QUERY: {query_to_execute}")

            key2 = await get_query_with_pool(query_to_execute, "dict")

            resp = dict()
            for i in key2:
                if i["mapid"] in resp:
                    resp[i["mapid"]].append(
                        {
                            "defectid": i["defectid"],
                            "classnumber": i["classnumber"],
                            "xsite": i["xsite"],
                            "ysite": i["ysite"],
                            "shape_by": i["shape_by"],
                            "volume_by": i["volume_by"],
                            "ismaster": i["is_master"]
                        }
                    )
                else:
                    resp[i["mapid"]] = [
                        {
                            "defectid": i["defectid"],
                            "classnumber": i["classnumber"],
                            "xsite": i["xsite"],
                            "ysite": i["ysite"],
                            "shape_by": i["shape_by"],
                            "volume_by": i["volume_by"],
                            "ismaster": i["is_master"]
                        }
                    ]
        except Exception as e:
            import traceback

            app_log.info(traceback.format_exc())
            return {"error": str(e)}
        return {"data": resp, "prep_column": [query_data["xsite"], query_data["ysite"]]}

    async def get_waferdetails(self, data):
        """Get wafermap details based on the requested data"""
        try:
            data["orientation"] = (
                data["inputs"].get("orientationmarklocation", "down").lower()
            )
            data["mapid"] = tuple(data["inputs"].get("selectedruns"))
            wafer_detail_query = self.queries["read_waferdetails"].format(**data)
            app_log.info(f"WAFER MAP DETAIL QUERY: {wafer_detail_query}")
            df = await get_query_with_pool(wafer_detail_query, "df")
            df = df.drop_duplicates()
            degree_mapping = {"0": "down", "90": "left", "180": "top", "270": "right"}
            df["orientationmarklocation"] = data["orientation"]
            df["orientationmarklocation"] = (
                df["orientationmarklocation"].str.split(".", expand=True)[0].str.upper()
            )
            df.replace(degree_mapping, inplace=True)
            df = df[df["diearea"].isin([df["diearea"].max()])]
            df.drop(["diearea"], axis=1, inplace=True)
            resp = df.iloc[0].to_json()
            resp = json.loads(resp)

        except Exception as e:
            return {"error": str(e)}
        return resp

    async def get_legends(self, data):
        try:
            """Returns map legend data"""
            """ Generate query_data from requested data """
            query_data = self.prepare_query_inputs(data)
            filter_data = make_query(data)
            query_data["header_cdtn"] = filter_data["header_cdtn"]
            query_data["defect_cdtn"] = filter_data["defect_cdtn"]
            query = self.queries["read_legends"].format(**query_data)
            app_log.info(f"WAFER MAP LEGENDS QUERY: {query}")
            key = await get_query_with_pool(query, resp_type="")
            data = dict()
            data["legends"] = [i[0] for i in key]
        except Exception as e:
            return {"error": str(e)}
        return data

    async def get_metric(self, data):
        try:
            """Return metric table data"""
            query_data = make_query(data)
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)
            tool = ["NA"]
            if data.get("inputs").get('tool', None):
                tool.extend(data.get("inputs").get('tool'))
            query_data['tool'] = tuple(tool)
            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]

            query_data["mapid"] = tuple(data.get("inputs").get("selectedruns"))
            metric_query = self.queries["read_metric_data"].format(**query_data)
            app_log.info(f"READ METRIC DATA QUERY: {metric_query}")
            result = await get_query_with_pool(metric_query, "df")
            if len(tool)>2:
                result = result[result['ismaster'] == 0]
            mapid = tuple(result["smapid"].unique().tolist())
            result = result.to_dict(orient='records')

            otf_config = await self.get_defualt_otf_config(mapid)
            resp = {
                "data": result,
                "otf_default_config": otf_config
            }
        except Exception as e:
            return {"error": str(e)}
        return resp

    async def get_defualt_otf_config(self, mapid):
        image_list = {
            'cur_bf': 300,
            'cur_gf': 301,
            'cur_unknown': 30
        }
        for key,code in image_list.items():
            read_query = self.queries['read_imagelist'].format(**{'mapid':mapid ,'code':code})
            result = await get_query_with_pool(read_query,"df")
            if not result.empty:
                return {'code': code, 'key': key}

        return {'code': 300, 'key': 'cur_bf'}
