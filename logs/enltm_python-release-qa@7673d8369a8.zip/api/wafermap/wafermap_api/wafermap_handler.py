"""Handler to fetch Filters"""
import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.wafermap.wafermap_api.wafermap_model import WaferMap


router = APIRouter(tags=['Wafermap'],dependencies=[Depends(verify_jwt)])
wafermap = WaferMap()

@router.post("/wafermap")
async def wafermap_post(request: Request, body: dict):
    """On post request get the wafermap"""
    resp = await wafermap.get(body)

    if "error" in resp:
        return JSONResponse(status_code=400, content=resp)
    return JSONResponse(content=resp)


@router.post("/waferdetails")
async def wafermap_details(request: Request, body: dict):
    """On post request get the wafermap"""
    resp = await wafermap.get_waferdetails(body)

    if "error" in resp:
        return JSONResponse(status_code=400, content=resp)
    return JSONResponse(content=resp)


@router.post("/legend")
async def wafermap_legend(request: Request, body: dict):
    """On post request get the wafermap"""
    resp = await wafermap.get_legends(body)

    if "error" in resp:
        return JSONResponse(status_code=400, content=resp)
    return JSONResponse(content=resp)


@router.post("/metric")
async def metric_data(request: Request, body: dict):
    """On post request get the metric data"""
    resp = await wafermap.get_metric(body)

    if "error" in resp:
        return JSONResponse(status_code=400, content=resp)
    return JSONResponse(content=resp)


@router.post("/metric")
async def metric_data(request: Request, body: dict):
    """On post request get the metric data"""
    resp = await wafermap.get_metric(body)

    if "error" in resp:
        return JSONResponse(status_code=400, content=resp)
    return JSONResponse(content=resp)
