"""Model for time trends in QC"""
import os
import sys
import calendar
import numpy as np
import pandas as pd
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from api.utils.common import make_query
from api.utils.utils import (
    queries,
    get_logger,
)

app_log = get_logger("timetrend")


class TimeTrend:
    """This class provides methods to fetch data for time trend"""

    def __init__(self):
        """Initializing timetrend instance"""
        self.queries = queries["timetrend"]

    async def post(self, data):
        """Post request for timetrend"""
        try:
            resp = {}
            tool_keys = []
            result = {
                "data": {},
                "limitdata": {
                    "base": "",
                    "lcl": "",
                    "ucl": "",
                },
            }

            app_log.info(f"Plot time trend {data.get('inputs').get('charttype', 'dc')}")
            runs = data.get("filters").get("periodfilter", {})
            query_data = make_query(data)
            master_list = []
            if runs.get("resulttimestamp", {}):
                query_data["lower_run"] = data.get("inputs", {}).get("run_value", 0)
                query_data["upper_run"] = (
                    data.get("inputs", {}).get("run_value", 0) + 100
                )
            else:
                query_data["lower_run"] = 0
                query_data["upper_run"] = runs["runs"]["data"]

            chart_type = data.get("inputs", {}).get("charttype", "dc")
            limit_data = {
                "product": data.get("filters")
                .get("gfilter")
                .get("product", {})
                .get("data", [""])[0],
                "layer": data.get("filters")
                .get("gfilter")
                .get("layer", {})
                .get("data", [""])[0],
                "recipeid": data.get("filters")
                .get("gfilter")
                .get("recipeid", {})
                .get("data", [""])[0],
                "charttype": chart_type,
            }
            if data.get('inputs').get('tool'):
                limit_data['tool'] = f'AND tool in {tuple(data.get("inputs").get("tool"))}'
            else:
                limit_data['tool'] = ''
                query_data['tool_cdtn'] = ''

            master_check = self.queries["master_check"].format(**limit_data)
            master_df = await get_query_with_pool( master_check)
            if chart_type == "dc":
                read_query = self.queries[data.get("chartType", "dc")].format(
                    **query_data
                )
                resp = await get_query_with_pool(read_query)
                tool_keys = resp['tool'].unique().tolist()
                tool_list = tool_keys.copy()

            else:
                if len(master_df) == 0:
                    return {"status_code": 204, "error": "Please upload Master map"}

                get_runs = self.queries["get_runs"].format(**query_data)
                runs_df = await get_query_with_pool( get_runs)

                if len(runs_df):
                    tool_keys = runs_df['tool'].unique().tolist()
                    tool_list = tool_keys.copy()
                    data["filters"].pop("periodfilter", None)
                    data["filters"]["gfilter"].pop("tool", None)
                    master_cdtn = make_query(data)
                    query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
                    query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]
                    query_data['tool'] = limit_data['tool']
                    if chart_type == 'mgt':
                        query_data['orientation'] = data.get("inputs", {}).get("orientationmarklocation", "DOWN").lower()
                        query_data['diepitch_x'] = data.get("inputs", {}).get("diepitch_x", 0)
                        query_data['diepitch_y'] = data.get("inputs", {}).get("diepitch_y", 0)
                        query_data["fieldx"] = data.get("inputs", {}).get("fieldx", 1)
                        query_data["fieldy"] = data.get("inputs", {}).get("fieldy", 1)
                    if chart_type == 'agr':
                        query_data['defectid_filter'] = f'AND defectid in {tuple(data.get("inputs").get("defectids", None))}' if data.get("inputs", {}).get("defectids", None) else ""
                    query_data["smapids"] = tuple(runs_df["mapid"].tolist())
                    read_query = self.queries[chart_type].format(**query_data)
                    trend_df = await get_query_with_pool( read_query)
                    resp = pd.merge(
                        runs_df,
                        trend_df,
                        how="inner",
                        left_on="mapid",
                        right_on="smapid",
                    )
                    if chart_type in ['sf', 'tf']:
                        resp['xaxis_na'] = resp['smapid'].isna()

                    resp = resp.drop("smapid", axis=1)
                    if chart_type == 'mgt':
                        resp['defects'] = resp['defects'].apply(lambda x: [] if np.any(pd.isna(x)) else [{'defectid': y[0], 'xsite': y[1], 'ysite': y[2], "xrel": y[3], "yrel": y[4], "fieldrelx": y[5], "fieldrely": y[6] } for y in x])

                    if chart_type == 'agr':
                        resp['allgrade'] = resp['allgrade'].apply(lambda x: [] if np.any(pd.isna(x)) else [{'grade': y[0], 'defectid': y[1]} for y in x])
                    resp = resp.replace({np.nan: 0})
            if len(resp) and chart_type != "agr":
                # resp = resp.sort_values(by=['tool', 'runid'], ascending=[True, False])
                # resp['runid'] = resp.groupby('tool').cumcount()+1
                event_result = {}
                event_data = {}
                event_data["inspectiontoolid"] = tuple(resp["tool"].unique().tolist())
                event_data["min_date"] = resp["resulttimestamp"].min()
                event_data["max_date"] = resp["resulttimestamp"].max()
                read_query = self.queries["read_event"].format(**event_data)

                event_df = await get_query_with_pool( read_query, "df")
                event_result = {
                    tool: group.to_dict(orient="records")
                    for tool, group in event_df.groupby("tool")
                }
                result["data"] = {
                    tool: {
                        "data": group.to_dict(orient="records"),
                        "eventdata": event_result.get(tool, []),
                    }
                    for tool, group in resp.groupby("tool")
                }
                limit_data['test'] = data.get('filters').get('gfilter').get('test').get('data')[0] if data.get('filters').get('gfilter').get('test', {}).get('data') else ""
                if chart_type == "mgt":
                    limit_data['charttype'] = 'gr'
                limit_data["test_cdtn"] = f"AND test = {limit_data.get('test')}" if limit_data.get("test", "") else "and test = -1"
                limit_query = self.queries["timetrend_limit"].format(**limit_data)
                limit_result = await get_query_with_pool(limit_query, "dict")
                if data.get('filters', {}).get('gfilter', {}).get('tool', {}):
                    tool = ['NA']
                    tool.extend(data.get('filters', {}).get('gfilter', {}).get('tool', {}).get('data'))
                    limit_result = [x for x in limit_result if x.get('tool') in tool]
                else:
                    tool_list.append('NA')
                    limit_result = [x for x in limit_result if x.get('tool') in tool_list]
                result["limitdata"] = limit_result
            elif len(resp) and chart_type == "agr":
                result["data"] = {
                    tool: {
                        "data": group.to_dict(orient="records")
                    }
                    for tool, group in resp.groupby("tool")
                }
            result['tool_key'] = tool_keys
            master_list = master_df['tool'].to_list()
            result['master_info'] =  list(result['data'].keys()) if 'NA' in master_list else master_list
        except Exception as err:
            app_log.exception(f"Error in Time trend:{err}")
            return {"error": str(err)}

        return result

    async def get_limits(self, data):
        try:
            app_log.info("Getting manual limits from the Db")
            data['charttype'] = 'gr' if data.get("charttype") == 'mgt' else data.get("charttype")
            chart_type = f'{data.get("charttype")}_limit'
            app_log.info("Check for manual limits")

            data["test_cdtn"] = f"AND test = {data.get('test')}" if data.get("test", "") else "and test = -1"
            if data.get('tool', '') == '':
                data['tool'] = data.get('tool', ('NA', ))
                manual_limit_query = self.queries["read_limit"].format(**data)
                manual_result = await get_query_with_pool(
                    manual_limit_query, "dict"
                )

                read_limit_query = self.queries[chart_type].format(**data)
                app_log.info("Read Auto limits Query")
                app_log.info(read_limit_query)
                auto_result_df = (
                    await get_query_with_pool( read_limit_query, "df")
                )[["lcl", "ucl", "base"]]
                auto_result_df.replace({np.nan: None})
                if len(auto_result_df):
                    auto_result = auto_result_df.to_dict(orient="records")[0]
                else:
                        auto_result = {"lcl": 0, "ucl": 0, "base": 0}
                dt_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                result = {
                    "limittype": "manual" if manual_result else "auto",
                    "udt": manual_result[0].pop("cdt") if manual_result else dt_str,
                    "manual": manual_result[0]
                    if manual_result
                    else {"lcl": "", "ucl": "", "base": ""},
                    "auto": auto_result,
                }
            else:
                data['tool'] = tuple(data.get('tool', ('NA')))
                manual_limit_query = self.queries["read_limit"].format(**data)
                manual_result = await get_query_with_pool(manual_limit_query, "dict")
                read_limit_query = self.queries[chart_type].format(**data)
                app_log.info("Read Auto limits Query")
                app_log.info(read_limit_query)
                auto_result_df = (
                    await get_query_with_pool( read_limit_query, "df")
                )[["tool", "lcl", "ucl", "base"]]
                auto_result_df.replace({np.nan: None}, inplace=True)
                if len(auto_result_df):
                    auto_result = auto_result_df.to_dict(orient="records")
                else:
                    auto_result = {"lcl": 0, "ucl": 0, "base": 0}
                dt_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                result = {
                    "limittype": "manual" if manual_result else "auto",
                    "udt": manual_result[0].pop("cdt") if manual_result else dt_str,
                    "manual": manual_result
                    if manual_result
                    else {"lcl": "", "ucl": "", "base": ""},
                    "auto": auto_result,
                }
        except Exception as excep:
            app_log.exception(excep)
            return {"error": str(excep)}
        return result

    async def update_limit(self, data):
        try:
            app_log.info("Updating the Control Limits")
            app_log.info("Check if limit exist")
            data["charttype"] = 'gr' if data.get("charttype") == 'mgt' else data.get("charttype")
            data["test_cdtn"] = f"AND test = {data.get('test')}" if data.get("test", "") else "AND test = -1"
            data['set_limit'] = 1
            data["test"] =  data.get("test") if data.get("test", "") else "-1"
            tool = ['NA']
            tool.extend(data.get('tool')) if data.get('tool') else tool
            set_limit_query = self.queries["set_limit"].format(**data)
            app_log.info(set_limit_query)
            await get_query_with_pool(set_limit_query)
            if isinstance(data.get('limit', ''), str):
                data["lcl"] = data.get("lcl") if data.get("lcl") != '' else 'Null'
                data["base"] = data.get("base") if data.get("base") != '' else 'NULL'
                data["ucl"] = data.get("ucl") if data.get("ucl") != '' else 'NULL'
                data['tool'] = data.get('tool', 'NA')
                app_log.info("Adding New limits Query")
                add_query = self.queries["add_limit"].format(**data)
                await get_query_with_pool(add_query)
                result = {"mssg": "Limit Updated Successfully"}
            else:
                for limit_data in data.get('limit'):
                    data['tool'] = limit_data.get('tool', 'NA')
                    data["lcl"] = limit_data.get("lcl") if limit_data.get("lcl") != '' else 'Null'
                    data["base"] = limit_data.get("base") if limit_data.get("base") != '' else 'NULL'
                    data["ucl"] = limit_data.get("ucl") if limit_data.get("ucl") != '' else 'NULL'
                    app_log.info("Adding New limits Query")
                    add_query = self.queries["add_limit"].format(**data)
                    await get_query_with_pool(add_query)
                result = {"mssg": "Limit Updated Successfully"}
        except Exception as excep:
            app_log.exception(excep)
            return {"error": str(excep)}

        return result

    async def export_limit(self, data):
        try:

            app_log.info("Exporting limits started")
            current_time = datetime.now()
            file_time = calendar.timegm(current_time.timetuple())
            filename = f"LimitExport_{file_time}.csv"
            app_log.info("Exporting limit Query")
            export_query = self.queries["export_limit"]
            export_df = await get_query_with_pool(export_query)
            timetrend_dict = {
                "dc": "Defect Count",
                "cr": "Capture Rate",
                "vl": "Volume Ratio",
                "gr": "Grade Ratio",
                "sf": "SELFI Score Avg",
                "tf": "TLF Score Avg",
            }
            export_df['KPI'] = export_df['KPI'].map(timetrend_dict)
            export_df = export_df.replace({np.nan: "NA"})
            export_df.to_csv(f"export/{filename}", header=True, index=False)
            resp = {"filename": filename}
        except Exception as excep:
            app_log.exception(excep)
            return {"error": str(excep)}
        return resp
