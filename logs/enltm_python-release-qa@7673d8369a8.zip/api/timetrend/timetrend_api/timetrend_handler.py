import os
import sys
import io

"""Handler for time trends in QC"""
from fastapi.responses import JSONResponse, Response
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.timetrend.timetrend_api.timetrend_model import TimeTrend


router = APIRouter(tags=['Timetrend'],prefix="/timetrend",dependencies=[Depends(verify_jwt)])
timetrend = TimeTrend()

@router.post("")
async def post(request: Request, body: dict):
    """On post request return the respective timetrend data as JSON"""
    response = await timetrend.post(data=body)
    if response.get("status_code", False):
        return Response(status_code=204)
    elif "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)


@router.post("/limit")
async def get(request: Request, body: dict):
    """On GET request return the respective control limit data as JSON"""
    response = await timetrend.get_limits(data=body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)


@router.put("/limit")
async def put(request: Request, body: dict):
    """On PUT Reuqest change the limits for the respective timetrend"""
    response = await timetrend.update_limit(data=body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)


@router.post("/exportlimit")
async def post(request: Request, body: dict):
    """On Post API return the export limit file"""
    resp = await timetrend.export_limit(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    filename = f"export/{resp['filename']}"
    with open(filename, "rb") as fi:
        contents = fi.read()

    blob_data = io.BytesIO(contents)
    if os.path.exists(f"{filename}"):
        os.remove(f"{filename}")
    response = Response(content=blob_data.getvalue())
    response.headers['Content-Type'] = 'application/octet-stream'
    return response