from api.utils.fastapi_app import app
from api.timetrend.timetrend_api import timetrend_handler

app.include_router(timetrend_handler.router)
