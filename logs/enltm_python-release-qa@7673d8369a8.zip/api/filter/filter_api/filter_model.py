"""Model to fetch global and secondary filters"""
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from utils.utils import queries, get_logger, get_gfilter_config, get_sfilter_config
from utils.common import make_query

app_log = get_logger("filter")


class Filter:
    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["filter"]

    async def get_gfilter(self, data):
        """Function to fetch Global Filters"""
        try:
            app_log.info("Get the filters value")
            query_data = {}

            query_data = make_query(data)
            filter_query = self.queries["read_gfilters"].format(**query_data)
            data_out = await get_query_with_pool( filter_query)
            g_filter = get_gfilter_config()
            data_output = {}

            for key, val in g_filter.items():
                data_output[key] = {
                    "type": val[0]["type"],
                    "filterlabel": val[1]["label"],
                    "options": [
                        {"label": data, "value": data} for data in data_out[key].iloc[0]
                    ],
                }

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return data_output

    async def get_sfilter(self, data):
        """Function to fetch Secondary Filters"""
        try:
            app_log.info("Get the secondary filter value")
            gfilter = data.get("filters").get("gfilter",{})
            query_data = make_query(data)

            filter_query = self.queries["read_sfilters"].format(**query_data)
            data_out = await get_query_with_pool(filter_query)

            s_filter = get_sfilter_config()
            data_output = {}
            data_output["sfilter"] = {}
            data_output["fieldconfig"] = {}
            for key, val in s_filter.items():
                data_output["sfilter"][key] = {
                    "type": val[0]["type"],
                    "filterlabel": val[1]["label"],
                    "options": [
                        {"label": data, "value": data} for data in data_out[key].iloc[0]
                    ],
                }

            result = []
            if gfilter.get("recipeid", {}) and gfilter.get("product", {}) and gfilter.get("layer", {}):
                field_data = dict()
                field_data["recipeid"] = tuple(
                    data.get("filters").get("gfilter").get("recipeid").get("data")
                )
                field_data["product"] = tuple(
                    data.get("filters").get("gfilter").get("product").get("data")
                )
                field_data["layer"] = tuple(
                    data.get("filters").get("gfilter").get("layer").get("data")
                )
                field_query = self.queries["get_stacking"].format(**field_data)
                result = await get_query_with_pool(field_query, "dict")

            if len(result) == 0:
                data_output["fieldconfig"]["fieldx"] = 1
                data_output["fieldconfig"]["fieldy"] = 1
                data_output["fieldconfig"]["fieldoriginx"] = 0
                data_output["fieldconfig"]["fieldoriginy"] = 0
            else:
                data_output["fieldconfig"] = result[0]

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return data_output
