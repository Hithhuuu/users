"""Handler to fetch Filters"""
import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.filter.filter_api.filter_model import Filter


router = APIRouter(tags=['Filter'],dependencies=[Depends(verify_jwt)])
filters = Filter()

@router.post("/gfilter")
async def post(request: Request, body: dict):
    """On post request fetch Global Filters"""
    resp = await filters.get_gfilter(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/sfilter")
async def post(request: Request, body: dict):
    """On post request fetch Secondary Filters"""
    resp = await filters.get_sfilter(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)
