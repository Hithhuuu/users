from api.utils.fastapi_app import app
from api.filter.filter_api import filter_handler


app.include_router(filter_handler.router)
