"""FAST API Router File"""
from api.utils.fastapi_app import app
from api.oil.oil_api import oil_handler

app.include_router(oil_handler.router)