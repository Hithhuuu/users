"""OIL API Model File"""
import time
import pandas as pd
import numpy as np
import asyncio
from datetime import timedelta, datetime
from api.utils.utils import queries, get_logger
from api.utils.common import make_query
from api.utils.fastapi_app import get_query_with_pool
from api.oil.oil_api.oil_utils import get_oil_data


app_log = get_logger("oil")


class Oil:
    """This class provides methods to get OIL Dashboard Data"""

    def __init__(self):
        """Initializing OIL instance"""
        self.queries = queries["oil"]

    async def get_table_data(self, data, pareto=False):
        """GET OIL Table Data"""
        try:
            app_log.info("Getting PLR for the required timestamp")
            date_data = data['filters']['periodfilter']['resulttimestamp']['data']
            gfilter = data['filters']['gfilter']
            filters = ['product', 'layer', 'recipeid', 'tool']
            payload_data = {}
            for i in filters:
                if i in gfilter.keys():
                    payload_data[i] = ', '.join('"' + str(data) + '"' for data in gfilter[i]['data'])
                else:
                    payload_data[i] = '"*"'

            min_date = datetime.strptime(date_data['min'], '%Y-%m-%d')
            max_date = datetime.strptime(date_data['max'], '%Y-%m-%d')
            current_date = min_date
            tasks = []
            if current_date == max_date:
                return []
            while current_date < max_date:
                next_date = min(current_date + timedelta(days=14), max_date)
                payload_data['from_time'] = int(time.mktime(current_date.timetuple())*1000)
                payload_data['to_time'] = int(time.mktime(next_date.timetuple())*1000)
                current_date = next_date
                payload = self.queries["oil_payload"].format(**payload_data)
                tasks.append(get_oil_data(payload))
            result = await asyncio.gather(*tasks)
            dfs = [df for df in result if isinstance(df, pd.DataFrame)]
            if len(dfs[0])==0:
                return []
            resp = pd.concat(dfs)
            if len(resp):
                dc_resp = resp[['product', 'layer', 'recipeid', 'pdcrun','tool_runid' ,'parent_tool_runid' ,'lcl', 'ucl', 'base']]
                dc_resp = dc_resp[dc_resp['parent_tool_runid'] == 0]

                resp = resp[resp['parent_tool_runid'] != 0]
                resp = resp.drop(['lcl', 'ucl', 'base'], axis=1)

                dc_resp = dc_resp.drop(['parent_tool_runid'], axis=1)
                dc_resp.rename(columns={'tool_runid': 'parent_tool_runid'}, inplace=True)

                merged_df = pd.merge(dc_resp, resp, on=['product', 'layer', 'recipeid', 'pdcrun', 'parent_tool_runid'], how='inner')
                merged_df['oil_status'] = merged_df.apply(self.check_status, axis=1)
                merged_df['oil_issue'] = merged_df.apply(self.check_oil_issue, axis=1)
                merged_df['oil_issue'] = merged_df['oil_issue'].map({True: 'Yes', False: 'No'})
                merged_df['timestamp'] = pd.to_datetime(merged_df['timestamp'], unit='ms')
                merged_df['timestamp'] = merged_df['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')
                merged_df = merged_df[['timestamp', 'tool', 'product', 'layer', 'recipeid', 'lotid','scansetname' ,'dc', 'oil_status', 'oil_issue']]
                if pareto:
                    return merged_df
                merged_df = merged_df.replace({np.nan: None})
                return merged_df.to_dict(orient="records")
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}

    async def get_pareto_data(self, data):
        try:
            resp = await self.get_table_data(data, pareto=True)
            if len(resp):
                result = {}
                tool_issues_count = resp.groupby('tool')['oil_issue'].apply(lambda x: (x == 'Yes').sum()).reset_index(name='oil_issue_count')
                tool_issues_count.sort_values('oil_issue_count', ascending=False, inplace=True)
                tool_issues_count['id'] = range(1, len(tool_issues_count) + 1)
                tool_response = tool_issues_count.to_dict('records')
                recipe_issues_count = resp.groupby('recipeid')['oil_issue'].apply(lambda x: (x == 'Yes').sum()).reset_index(name='oil_issue_count')
                recipe_issues_count.sort_values('oil_issue_count', ascending=False, inplace=True)
                recipe_issues_count['id'] = range(1, len(recipe_issues_count) + 1)
                recipe_response = recipe_issues_count.to_dict('records')

                result['tool'] = tool_response
                result['recipe'] = recipe_response
                return result
        except Exception as err:
            app_log.exception(err)
            return {"error": "Something went wrong"}
        return []

    def check_oil_issue(self, row):
        if pd.isnull(row['dc']):
            if (not pd.isnull(row['lcl'])) | (not pd.isnull(row['ucl'])):
                return (row['oil_status'] == 'Fail') & True
            return False
        else:
            row['lcl'] = 0 if pd.isnull(row['lcl']) else row['lcl']
            row['ucl'] = 0 if pd.isnull(row['ucl']) else row['ucl']
            return (row['oil_status'] == 'Fail') & ((row['dc'] < row['lcl']) | (row['dc'] > row['ucl']))

    def check_status(self,row):
        gf_bright_values = [float(x) for x in row['gf_bright'].split(',') if x] if pd.notnull(row['gf_bright']) else []
        gf_gray_values = [float(x) for x in row['gf_gray'].split(',') if x] if pd.notnull(row['gf_gray']) else []
        ff_bright_values = [float(x) for x in row['ff_bright'].split(',') if x] if pd.notnull(row['ff_bright']) else []
        ff_gray_values = [float(x) for x in row['ff_gray'].split(',') if x] if pd.notnull(row['ff_gray']) else []

        gf_bright_count = sum(1 for x in gf_bright_values if x > 2.8 or x < 0.35)
        gf_gray_count = sum(1 for x in gf_gray_values if x > 2.8 or x < 0.35)
        ff_bright_count = sum(1 for x in ff_bright_values if x > 2.8 or x < 0.35)
        ff_gray_count = sum(1 for x in ff_gray_values if x > 2.8 or x < 0.35)
        reset_count_bright = ff_bright_values.count(1.0)
        reset_count_gray = ff_gray_values.count(1.0)

        if gf_bright_count >= 6 or gf_gray_count >= 6 or ff_bright_count >= 6 or ff_gray_count >= 6 or reset_count_bright >= 30 or reset_count_gray >= 30:
            return "Fail"
        else:
            return "Pass"

