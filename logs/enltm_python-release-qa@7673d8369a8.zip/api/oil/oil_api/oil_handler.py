"""OIL API Handler File"""
from fastapi.responses import JSONResponse, Response
from fastapi import  APIRouter,Depends

from api.oil.oil_api.oil_model import Oil
from api.utils.fastapi_app import verify_jwt



router = APIRouter(tags=['OIL'],prefix="/oil", dependencies=[Depends(verify_jwt)])


@router.post("/table")
async def oil_table(body: dict):
    """
    Endpoint to retrieve Common/Missing/Adders.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the Common/Missing/Adders data.
    """
    oil_data = Oil()
    response = await oil_data.get_table_data(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.post("/pareto")
async def oil_table(body: dict):
    """
    Endpoint to retrieve Common/Missing/Adders.

    Args:
        request (Request): The incoming request object.
        body (dict): The request body.

    Returns:
        JSONResponse: The response containing the Common/Missing/Adders data.
    """
    oil_data = Oil()
    response = await oil_data.get_pareto_data(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)
