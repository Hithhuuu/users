import jwt
from typing import Tuple
from api.utils.utils import env_config


secret_key = env_config["secret_key"]
options = {
    "verify_signature": True,
    "verify_exp": True,
    "verify_nbf": False,
    "verify_iat": True,
    "verify_aud": False,
}


class AuthUtil:
    @staticmethod
    def get_authorization_scheme_param(
        authorization_header_value: str,
    ) -> Tuple[str, str]:
        if not authorization_header_value:
            return "", ""
        scheme, _, param = authorization_header_value.partition(" ")
        return scheme, param

    @staticmethod
    async def get_current_user(token: str):
        try:
            _, token = token.split()
            payload = jwt.decode(token, secret_key, algorithms=["HS256"],options=options)
            return payload.get('userid'), payload.get('usertype')
        except Exception as e:
            raise e
