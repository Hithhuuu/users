import base64
import logging
import os
import shutil
import sys
import itertools
import pandas as pd
from glob import glob
from hashlib import md5
from logging.handlers import TimedRotatingFileHandler

from Crypto import Random
from Crypto.Cipher import AES
from asynch import pool as pool_async

import yaml
import numpy as np


FORMATTER = logging.Formatter(
    "%(asctime)s — %(name)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s"
)
LOG_FILE = "logs/enlight.log"

# os.environ['APP_SERVER']="dcilpb1805"
# os.environ['DB_SERVER']="dcilpb1806"

CONFIG_FILE = "configs/config.yaml"
COLUMNS_FILE = "configs/columns.yaml"


def get_config():
    """Return the config read from config.yaml file"""
    with open(CONFIG_FILE) as file:
        config = yaml.load(
            file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader
        )
        file.close()
    return config


def get_env_config():
    """Return the config read from config.yaml file"""
    # env = os.getenv('env')
    # if env is None:
    #     env = 'local'
    with open(CONFIG_FILE) as file:
        config = yaml.load(
            file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader
        )
        file.close()

    return config


def get_repeated_strings():
    """Return the repeated strings from config.yaml file"""
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["repeated_strings"]

def unpad(data):
    """doing unpaddling"""
    return data[: -(data[-1] if isinstance(data[-1], int) else ord(data[-1]))]


def bytes_to_key(data, salt, output=48):
    """creates key_iv"""
    assert len(salt) == 8, len(salt)
    data += salt
    key = md5(data).digest()
    final_key = key
    while len(final_key) < output:
        key = md5(key + data).digest()
        final_key += key
    return final_key[:output]


def pad(data):
    bs = 16
    return data + (bs - len(data) % bs) * chr(bs - len(data) % bs)


def encrypt(password, key):
    """Encrypts password"""
    data = pad(password)
    salt = Random.new().read(8)
    key_iv = bytes_to_key(key, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return base64.b64encode(b"Salted__" + salt + aes.encrypt(bytes(data, "utf-8")))


def decrypt(encrypted, passphrase):
    """decrypting password"""
    encrypted = base64.b64decode(encrypted)
    assert encrypted[0:8] == b"Salted__"
    salt = encrypted[8:16]
    key_iv = bytes_to_key(passphrase, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return unpad(aes.decrypt(encrypted[16:]))


def get_columns_info():
    """Return the config read from columns.yaml file"""
    with open(COLUMNS_FILE) as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return columns


def create_directories():
    """Initialize all required directories"""
    for d in get_env_config()["directories"].values():
        if not os.path.isdir(d):
            os.mkdir(d)
    return True


def clean_directories(config):
    """Clean all required directories"""
    try:
        shutil.rmtree("upload")
    finally:
        create_directories()


async def get_async_connection_pool():
    """Creates and returns a Connection Pool"""
    return await pool_async.create_pool(
        minsize=6,
        maxsize=10,
        host=env_config["db_hostname"],
        port=9000,
        database="enlight",
        user= decrypt(env_config["db_userid"], bytes(env_config["password_secret_key"], "utf-8")).decode("utf-8"),
        password=decrypt(env_config["db_password"], bytes(env_config["password_secret_key"], "utf-8")).decode("utf-8")
    )


def get_queries():
    path = os.path.abspath(os.getcwd())
    query_files = glob(path + "/api/*/*.yaml", recursive=True)
    queries_dict = {}
    for qfile in query_files:
        key = os.path.splitext(os.path.basename(qfile))[0]
        with open(qfile) as file:
            queries_dict[key] = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
    return queries_dict


def get_console_handler():
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def get_file_handler(log_file):
    file_count = 3 if os.environ['env'] in ('dev','demo') else 10
    file_handler = TimedRotatingFileHandler(log_file, when="midnight", backupCount=file_count)
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_logger(logger_name):
    """
    Creates a logger for the api's
    param: logger name
    return: logger object
    """
    create_directories()
    logger = logging.getLogger(logger_name)
    # better to have too much log than not enough
    logger.setLevel(logging.DEBUG)
    # if not logger.hasHandlers():
    logger.addHandler(get_console_handler())
    logger.addHandler(get_file_handler(f"logs/{logger_name}.log"))
    # with this pattern, it's rarely necessary to propagate the error up to parent
    logger.propagate = False
    return logger


def get_header_v8():
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["header_meta_for_v8_file"]


def get_filter_config():
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["filter_dict"]


def get_alias_config():
    with open(COLUMNS_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["alias_dict"]


def get_header_columns():
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["header_cols"]


def get_common_query():
    path = os.path.abspath(os.getcwd())
    query_file = path + "/queries/common.yaml"
    with open(query_file) as file:
        common_queries = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return common_queries


def get_column_details(key):
    """Gets the details from columns file in config"""
    with open(COLUMNS_FILE) as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
    key_map = {
        "v7": f"header_meta_for_v7_file",
        "v8": f"header_meta_for_v8_file",
        "filter": "filter_dict",
        "alias": "alias_dict",
        "header_cols": "header_cols",
    }

    if key != "columns":
        return columns[key_map[key]]

    return columns


def get_filter_config():
    config = columns_info
    root_dict = {}
    for item in config["filter_col"]:
        root_dict.update(item)
    return root_dict


def get_gfilter_config():
    config = columns_info
    root_dict = {}
    for item in config["global_filter"]:
        root_dict.update(item)
    return root_dict

def get_tpt_gfilter_config():
    config = columns_info
    root_dict = {}
    for item in config["tpt_global_filter"]:
        root_dict.update(item)
    return root_dict


def get_sfilter_config():
    config = columns_info
    root_dict = {}
    for item in config["secondary_filter"]:
        root_dict.update(item)
    return root_dict


async def execute_query(query, resp_type="df"):
    try:
        get_pool = await get_async_connection_pool()
        conn =  await get_pool.acquire()
        memory_executor_settings = ["4G", "10G"]
        async with conn.cursor() as cur:
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")

            if resp_type != "None":
                data = await cur.fetchall()
                col = cur._columns
                if resp_type == "df":
                    data = pd.DataFrame(data, columns=col)
                elif resp_type == "dict":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(col), row)),
                            data,
                        )
                    )
                    if len(data) != 0:
                        data = [
                            {
                                k: " ".join(val.split("\x00")).strip()
                                if isinstance(val, str)
                                else val
                                for k, val in d.items()
                            }
                            for d in data
                        ]
                elif resp_type == "list":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(cur._columns), row)),
                            data,
                        )
                    )
                elif resp_type == "tuple":
                    data = tuple(data)
                await get_pool.release(conn)
                get_pool.close()
                await get_pool.wait_closed()
                await get_pool.terminate()
                return data
            await get_pool.release(conn)
    except Exception as err:
        await get_pool.release(conn)
        get_pool.close()
        await get_pool.wait_closed()
        await get_pool.terminate()
        raise err

# reused variables
env_config = get_env_config()
queries = get_queries()
common_queries = get_common_query()
dtypes = {
    "str": str,
    "float": np.float64,
    "int": np.int64,
    "bool": bool,
    "object": object,
}
columns_info = get_columns_info()
columns_info["main_cols"] = {
    key: dtypes[val] for key, val in columns_info["main_cols"].items()
}
columns_info["header_cols"] = {
    key: dtypes[val] for key, val in columns_info["header_cols"].items()
}
