import time
import itertools
import pandas as pd
import jwt
import datetime

from jwt import decode
from api.utils.utils import env_config
from fastapi import FastAPI, Request,HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from api.utils.auth import AuthUtil
from api.utils.utils import get_async_connection_pool, get_logger
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials


secret_key=env_config['secret_key']
auth_scheme = HTTPBearer()
app_log = get_logger("fastapi")
app = FastAPI()


@app.on_event("startup")
async def startup():
    try:
        app.state.pool = await get_async_connection_pool()
        print("startup done")
    except Exception as e:
        print(e)


@app.on_event("shutdown")
async def shutdown():
    try:
        app.state.pool.close()
        await app.state.pool.wait_closed()
        await app.state.pool.terminate()
        print(f"Pool size = {app.state.pool.size}")
        print("shutdown done")
    except Exception as e:
        print(e)


async def get_query_with_pool(query, resp_type="df"):
    """Run query using async"""
    try:
        conn = await app.state.pool.acquire()
        app_log.info("Connection Established")
        app_log.debug(f"Query to be executed:\n{query}")
        start_time = datetime.datetime.now()
        memory_executor_settings = ["4G", "10G"]
        async with conn.cursor() as cur:
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    time_taken = datetime.datetime.now() - start_time
                    app_log.info(
                        f"QUERY EXECUTED SUCCESSFULLY\nMEMORY SETTING: {memory}B\nTime taken to run the query: {time_taken}"
                    )
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        app_log.error(
                            f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                        )
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")
                    app_log.warning(
                        f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                    )
            if resp_type != "None":
                data = await cur.fetchall()
                col = cur._columns
                if resp_type == "df":
                    data = pd.DataFrame(data, columns=col)
                elif resp_type == "dict":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(col), row)),
                            data,
                        )
                    )
                    if len(data) != 0:
                        data = [
                            {
                                k: " ".join(val.split("\x00")).strip()
                                if isinstance(val, str)
                                else val
                                for k, val in d.items()
                            }
                            for d in data
                        ]
                
                await app.state.pool.release(conn)
                return data
            await app.state.pool.release(conn)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:%s", str(err))
        raise err


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

async def verify_jwt(request: Request ,authorization: HTTPAuthorizationCredentials = Depends(auth_scheme)):
    if not (request.url.path.endswith("/auth")):
        jwt_token = authorization.credentials
        try:
            decode(jwt_token, secret_key, algorithms="HS256")
        except (

                jwt.exceptions.ExpiredSignatureError,

                jwt.exceptions.DecodeError,

                jwt.exceptions.InvalidTokenError,

            ):
            raise HTTPException(
                    status_code=401,

                    detail={"message": "Invalid header authorization"},

                )
        except Exception as err:
            raise HTTPException(status_code=401, detail={"message": "Invalid header authorization",
                                                          "error":err},)


async def insert_data(query, list_data):
    """Insert data from list of tuples or list of dicts.."""
    conn = await app.state.pool.acquire()
    app_log.debug("Inserting data using query:\n%s", query)
    start_time = datetime.datetime.now()
    try:
        async with conn.cursor() as cursor:
            cursor.set_settings({"max_memory_usage": "10G"})
            await cursor.execute(query, list_data)
        time_taken = datetime.datetime.now() - start_time
        app_log.info("Data inserted successfully in %s", time_taken)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:\n%s", str(err))
        raise err
    await app.state.pool.release(conn)

# @app.middleware("http")
# async def validate_authenticity(request: Request, call_next):
#     if not request.url.path.endswith("/auth"):
#         authorization: str = request.headers.get("Authorization")
#         scheme, param = AuthUtil.get_authorization_scheme_param(authorization)
#         if not authorization or scheme.lower() != "bearer":
#             return JSONResponse(
#                 status_code=401,
#                 content={"message": "Missing authorization"},
#             )
#         try:
#             payload = AuthUtil.get_current_user(str(param))
#             request.state.security_context = payload
#             return await call_next(request)
#         except (
#             jwt.exceptions.ExpiredSignatureError,
#             jwt.exceptions.DecodeError,
#             jwt.exceptions.InvalidTokenError,
#         ):
#             return JSONResponse(
#                 status_code=401,
#                 content={"message": "Invalid header authorization"},
#             )
#         except Exception as e:
#             return JSONResponse(
#                 status_code=500,
#                 content={"message": f"{e}"},
#             )
#     else:
#         return await call_next(request)


app.add_middleware(GZipMiddleware, minimum_size=1000)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
