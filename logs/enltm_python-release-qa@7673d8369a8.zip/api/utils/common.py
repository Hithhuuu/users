import os
import shutil
import smtplib
import img2pdf
import fitz
import io
import time
import json
import aiohttp
import copy
import pandas as pd
import re
import itertools
from tqdm import trange
from pptx import Presentation
from pptx.util import Cm
from pathlib import Path
from pyppeteer import launch
from promise import Promise
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PIL import Image
from datetime import datetime
from jwt import decode
from html2image import Html2Image
hti = Html2Image()



from api.utils.utils import (
    get_logger,
    env_config,
    get_filter_config,
    common_queries,
    execute_query
)


app_log = get_logger("common")


def get_user(request):
    """Get auth data"""
    auth = request.headers.get("Authorization")
    options = {
        "verify_signature": True,
        "verify_exp": True,
        "verify_nbf": False,
        "verify_iat": True,
        "verify_aud": False,
    }
    token = auth.split()[1]
    return decode(token, env_config["secret_key"], algorithms=["HS256"],options=options)


async def move_file(src_path, tool, status="archive"):
    """Function to move the file"""
    try:
        dst_path = "rejected" if status == "failed" else "archive"
        # watch_path = env_config["watchdog_pick_location"]["src"]
        watch_path = r'/Application/local/motor/data/wizer'
        dst_path = os.path.join(
            watch_path, tool, dst_path, datetime.strftime(datetime.today(), "%d%b%Y")
        )

        if not os.path.exists(dst_path):
            os.makedirs(dst_path)

        filename = os.path.basename(src_path)

        # if os.path.isfile(os.path.join(dst_path, filename)):
        basename, ext = os.path.splitext(filename)
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        filename = f"{basename}_{timestamp}{ext}"
        dst_path = os.path.join(dst_path, filename)
        shutil.move(src_path, dst_path)
        app_log.info(f"Successfully moved {src_path} to {dst_path}.")
        return dst_path
        # shutil.move(src_path, dst_path)
        # app_log.info(f"Successfully moved {src_path} to {dst_path}.")
        # return os.path.join(dst_path, filename)
    except Exception as e:
        app_log.error(f"Unable to copy this file.")
        app_log.exception(e)

    return None

async def trigger_email(data):
    """Function to trigger email"""
    try:
        app_log.info("trigger email")
        path = await report_generation(data)
        await send_mail(path, data)
    except Exception as err:
        app_log.error(err)

async def html_to_image(data, img_path, chart):
    try:
        html = f"""
            <!DOCTYPE html>
            <html>

            <head>
            <style>
                body {{
                width: 1950px;
                height: 890px;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                }}

                .main-container {{
                padding: 30px 20px;
                background-color: white;
                }}

                table {{
                margin-top: 15px;
                width: 100%;
                }}

                th,
                td {{
                padding: 5px;
                }}

                th {{
                background-color: #6195C9;
                color: white;
                }}

                td {{
                background-color: #EDF1F6;
                /* word-break: break-word; */
                }}

                .image-wrapper {{
                margin-top: 50px;
                }}

                img {{
                width: 100%;
                height: 70%;
                }}
            </style>
            </head>

            <body>
            <div class="main-container">
                <table>
                <thead>
                    <tr>
                    <th>Product</th>
                    <th>Layer</th>
                    <th>Recipe</th>
                    <th>Inspection Time Stamp</th>
                    <th>Inspection Tool</th>
                    <th>Lot</th>
                    <th>Wafer</th>
                    <th>KPI</th>
                    <th>Value</th>
                    <th>LCL</th>
                    <th>UCL</th>
                    <th>Klarf Name</th>
                    </tr>
                </thead>
                <tbody>
                    <td>{data['product']}</td>
                    <td>{data['layer']}</td>
                    <td>{data['recipeid']}</td>
                    <td>{data['resulttimestamp']}</td>
                     <td>{data['tool']}</td>
                    <td>{data['lot']}</td>
                    <td>{data['waferid']}</td>
                    <td>{data['Kpi']}</td>
                    <td>{data[chart]['value']}</td>
                    <td>{data[chart]['lcl']}</td>
                    <td>{data[chart]['ucl']}</td>
                    <td>{data['filename']}</td>
                </tbody>
                </table>
                <div class="image-wrapper">
                    </br>
                    </br>
                <img src="{img_path}" />
                </div>
            </div>
            </body>

            </html>
        """
        path = f'{chart}_{str(int(time.time()))}.png'
        hti.screenshot(html_str=html,save_as=path)
        shutil.move(path, img_path)
    except Exception as e:
        app_log.exception(e)

async def report_generation(data):
    """Function to generate report"""
    try:
        app_log.info("report generation")
        alert_id = str(data['id'])
        watch_path = env_config["report_path"]["alert"]
        report_path = os.path.join(watch_path, alert_id, str(int(time.time())))
        os.makedirs(report_path, exist_ok=True)
        img_path = await app_screenshot(data, report_path)
        pdf_path = await pdf_create(img_path,data, report_path)
        app_log.info(report_path, pdf_path)
        if json.loads(data['reportdownloadformat']) == 'PPT':
            ppt_path = await convert_pdf2pptx(pdf_path)
            return ppt_path
        else:
            return pdf_path
    except Exception as err:
        app_log.error(err)

async def app_screenshot(data, report_path):
    try:
        """Function to take screenshot"""
        img_list = []
        browser = await launch({
        'executablePath': "/bin/chromium-browser",
        'autoClose': False,
        })
        page = await browser.newPage()
        await page.setViewport({
        'width': 2220,
        'height': 1080,
        })
        url = data['link']
        await page.goto(url,waitUntil='networkidle0')
        await page.type('#username', 'report')
        await page.type('#password', 'Amat@123')
        await Promise.all([
        page.click("button[type='submit']"),
        ])
        # await page.waitFor(3000)

        await page.waitForSelector(selector='.circle-group', timeout=60000)
        await page.waitFor(2000)
        if 'dc' in data['dashboard'] and data['dc']['outlier']:
            dc_path = 'dc.png'
            dc_path = os.path.join(report_path, dc_path)
            dimensions = await page.evaluate('''
                () => {
                    const element = document.querySelector('#Defect');
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': dc_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'Defect Count'
            await html_to_image(data,dc_path, chart= 'dc')
            img_list.append(dc_path)
        if 'cr' in data['dashboard'] and data['cr']['outlier']:
            cr_path = 'cr.png'
            cr_path = os.path.join(report_path, cr_path)
            dimensions = await page.evaluate('''
                () => {
                    const element = document.querySelector('#Capture');
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': cr_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'Capture Rate'
            await html_to_image(data,cr_path,chart= 'cr')
            img_list.append(cr_path)

        time_trend = await page.querySelectorAll('.circle.circle')
        if time_trend:
            await time_trend[0].click()
        await page.click('#Defect-Launch')
        await page.waitForSelector(selector='#wafer-map-svg-undefined')

        await page.click('#detailAnalysis')
        await page.click('#close-wafer-view')
        await page.waitForSelector(selector='#Grade')
        await page.waitForSelector(selector='#gr-time-trend')
        time_trend = await page.querySelectorAll('.circle.circle')
        if time_trend:
            time_trend = await page.querySelectorAll('.circle.circle')
            await time_trend[0].click({'waitUntil': 'networkidle0'})
            await page.click('#svg-id-gr-time-trend')

        if 'gr' in data['dashboard'] and data['gr']['outlier']:
            gr_path = 'gr.png'
            gr_path = os.path.join(report_path, gr_path)
            dimensions = await page.evaluate('''
                () => {
                    const element = document.querySelector('#Grade');
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': gr_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'Grade Ratio'
            await html_to_image(data,gr_path,chart= 'gr')
            img_list.append(gr_path)
        await page.waitForSelector('#vl-time-trend')
        if 'vl' in data['dashboard'] and data['vl']['outlier']:
            vl_path = 'vl.png'
            vl_path = os.path.join(report_path, vl_path)
            dimensions = await page.evaluate('''
                () => {
                    const elements = document.querySelectorAll('.time-trend-split-container-filter');
                    const element = elements[1];
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': vl_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'Volume Ratio'
            await html_to_image(data,vl_path, chart='vl')
            img_list.append(vl_path)

        selfi = await page.querySelectorAll('.card-option.UT-selfi-tlf-tab')
        if selfi:
            await selfi[0].click({'waitUntil': 'networkidle0'})

        slf_chart = await page.querySelectorAll(selector='#sf-time-trend')
        if slf_chart:
            if 'sf' in data['dashboard'] and data['sf']['outlier']:
                await page.waitForSelector('#sf-time-trend',{'timeout': 60000})
        else:
            await page.waitFor(1500)

        if 'sf' in data['dashboard'] and data['sf']['outlier']:
            sl_path = 'sl.png'
            sl_path = os.path.join(report_path,sl_path)
            dimensions = await page.evaluate('''
                () => {
                    const elements = document.querySelectorAll('.time-trend-split-container-filter');
                    const element = elements[1];
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': sl_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'SELFI Score Avg'
            await html_to_image(data,sl_path, chart= 'sf')
            img_list.append(sl_path)

        tlf = await page.querySelectorAll('.select-lov-sub__indicators.css-1wy0on6')
        if tlf:
            await tlf[0].click({'waitUntil': 'networkidle0'})
            await page.waitForSelector(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
            await page.waitFor(1000)
            drop = await page.querySelectorAll(selector='.select-lov-sub__menu.css-1nmdiq5-menu')
            await drop[0].click({'waitUntil': 'networkidle0'})
            tlf_chart = await page.querySelectorAll(selector='#tf-time-trend')
            if tlf_chart:
                if 'tf' in data['dashboard'] and data['tf']['outlier']:
                    await page.waitForSelector('#tf-time-trend',{'timeout': 60000})
            else:
                await page.waitFor(1500)

        if 'tf' in data['dashboard'] and data['tf']['outlier']:
            tl_path = 'tl.png'
            tl_path = os.path.join(report_path,tl_path)
            dimensions = await page.evaluate('''
                () => {
                    const elements = document.querySelectorAll('.time-trend-split-container-filter');
                    const element = elements[1];
                    const {x, y, width, height} = element.getBoundingClientRect();
                    return {left: x, top: y, width: Math.ceil(width), height: Math.ceil(height), id: element.id};
                }
            ''')
            await page.screenshot({
                'path': tl_path,
                'clip': {
                    'x': dimensions['left'],
                    'y': dimensions['top'],
                    'width': dimensions['width'],
                    'height': dimensions['height'],
                }
            })
            data['Kpi'] = 'TLF Score Avg'
            await html_to_image(data,tl_path, chart='tf')
            img_list.append(tl_path)

        await browser.close()
        app_log.info(img_list)
        return img_list
    except Exception as err:
        app_log.exception(err)
        await browser.close()
        raise Exception(err)

async def pdf_create(img_path, data,report_path):

    img = r'img/alert.png'
    a4inpt = (850,460)
    layout_fun = img2pdf.get_layout_fun(a4inpt)
    pdf_data = img2pdf.convert(img, layout_fun=layout_fun)
    pdf_path = os.path.join(report_path, r'alert.pdf')
    with open(pdf_path, "wb") as file:
        file.write(pdf_data)

    pdf_file = open(pdf_path, 'rb')
    # Create a PDF reader object
    pdf_reader = PdfReader(pdf_file)
    # Create a PDF writer object
    pdf_writer = PdfWriter()
    dashboard_name = data['dashboard_name']
    report_name = data['reportname']
    report_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    username = data['username']
    frequency = json.loads(data['reportfrequency'])

    # Loop through all the pages in the PDF
    for page_num,k in enumerate(pdf_reader.pages):
        page = pdf_reader.pages[page_num]
        can_pdf = f'overlay_{str(int(time.time()))}.pdf'
        overlay = canvas.Canvas(can_pdf, pagesize=(850,460))

        # Add text to the canvas
        overlay.setFont("Times-Roman",size=13.5)
        overlay.setFillColorRGB(255,255,255)
        overlay.drawString(357, 327, report_name)

        overlay.setFont("Times-Roman",size=9)
        overlay.drawString(338, 301, report_date)
        overlay.drawString(464, 301, username)

        # Save the canvas to the overlay PDF
        overlay.setFillColorRGB(0,0,0.2)
        overlay.setFont("Times-Roman",size=7.3)
        overlay.drawString(290, 230.65, dashboard_name)
        overlay.drawString(290, 180.65, frequency)


        overlay.save()
        # Merge the overlay PDF with the original page
        overlay_pdf = open(can_pdf, 'rb')
        overlay_reader = PdfReader(overlay_pdf)
        overlay_page = overlay_reader.pages[0]
        page.merge_page(overlay_page)

        # Add the modified page to the PDF writer
        pdf_writer.add_page(page)

    pdf_data = img2pdf.convert(img_path, layout_fun=layout_fun)
    temp_path = f'screenshot_{str(int(time.time()))}.pdf'
    with open(temp_path, "wb") as file:
        file.write(pdf_data)

    ss = open(temp_path, 'rb')
    pdf_writer.append(ss)
    datetime_str = datetime.now().strftime('%Y%m%d%H%M%S')
    filename = f"{data.get('reportname')}_{datetime_str}.pdf"
    pdf_path = os.path.join(report_path, filename)
    output_file = open(pdf_path, 'wb')
    pdf_writer.write(output_file)

    # Close all the files
    pdf_file.close()
    overlay_pdf.close()
    output_file.close()
    os.remove(temp_path)
    os.remove(can_pdf)
    return pdf_path

async def convert_pdf2pptx(pdf_file, output_file=None, resolution=300, start_page=0, page_count=None, quiet=True):
    doc = fitz.open(pdf_file)
    if not quiet:
        print(pdf_file, 'contains', doc.page_count, 'slides')

    if page_count is None:
        page_count = doc.page_count

    # transformation matrix: slide to pixmap
    zoom = resolution / 72
    matrix = fitz.Matrix(zoom, zoom, 0)

    # create pptx presentation
    prs = Presentation()
    blank_slide_layout = prs.slide_layouts[6]

    # configure presentation aspect ratio
    page = doc.load_page(0)
    aspect_ratio = page.rect.width / page.rect.height
    prs.slide_width = int(prs.slide_height * aspect_ratio)

    # create page iterator
    if not quiet:
        page_iter = trange(start_page, start_page + page_count)
    else:
        page_iter = range(start_page, start_page + page_count)

    # iterate over slides
    for page_no in page_iter:
        page = doc.load_page(page_no)

        # write slide as a pixmap
        pixmap = page.get_pixmap(matrix=matrix)
        image_data = pixmap.tobytes(output='PNG')
        image_file = io.BytesIO(image_data)

        # add a slide
        slide = prs.slides.add_slide(blank_slide_layout)
        left = top = Cm(0)
        slide.shapes.add_picture(image_file, left, top, height=prs.slide_height)

    if output_file is None:
        output_file = Path(pdf_file).with_suffix('.pptx')

    # save presentation
    prs.save(output_file)
    return output_file

async def send_mail(path, data):
    EMAIL_SIGNATURE  =  "<div><br/><br/>Thanks<br/> Enlight Alerts</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
    table_rows = ""
    # for row in data['table_data']:
    table_rows += f"<tr><td>{data['product']}</td><td>{data['layer']}</td><td>{data['recipeid']}</td><td>{data['dashboard_name']}</td><td><a href = '{data['link']}'>{data['link']}</a></td></tr>"

    # Include the table in the email content
    email_content  = f""" <!DOCTYPE html>
        <html>
         <head>
            <style>
                table {{
                border-collapse: collapse;
                width: 50%;
                border:  0.5px solid #e0e6f0;
                }}
                th,
                td {{
                text-align: center;
                padding: 8px;
                border-right: 0.5px solid #a3a0a0;
                }}
                th {{
                background-color: #4472c4;
                color: white;
                }}
                tr:nth-child(even) {{
                background-color: white;
                }}
                tr:nth-child(odd) {{
                background-color: #D9E4F5;
                }}
                /* Remove the last vertical border on the last column */
                th:last-child,
                td:last-child {{
                border-right: none;
                }}
            </style>
        </head>
        <body>
        Hello {data['username']},
        <div>
        <br/>
        <br/>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Layer</th>
                    <th>Recipe</th>
                    <th>Selected KPI</th>
                    <th>Link</th>
                </tr>
            </thead>
            <tbody>
                {table_rows}
            </tbody>
        </table>
        {EMAIL_SIGNATURE}
        </body>
        </html>
        """

    your_smtp_port = env_config['smtp_port']
    host  =  env_config['host']
    msg = MIMEMultipart()
    invitees = json.loads(data['reportinvitees'])
    msg["From"] = env_config['server_mail']
    msg["To"] = ", ".join(invitees)
    msg["Subject"] = f'Alerts :- {data["reportname"]}'

    for attach_file_name in [path]:
        with open(attach_file_name, "rb") as file:
            attachment_content = MIMEApplication(file.read())
            attachment_content.add_header(
                    "Content-Disposition", "attachment", filename=os.path.basename(attach_file_name)
                )
            msg.attach(attachment_content)
    msg.attach(MIMEText(email_content, "html"))
    with smtplib.SMTP(host, your_smtp_port) as server:
        server.starttls()
        server.send_message(msg)

def update_job_status(kwargs):
    """This function is used update the status in job_log table"""
    try:
        job_dict = {}
        db_conn = '' #get_dbconnection()
        db_cur = db_conn.cursor()

        job_dict["job_id"] = kwargs.get("job_id", None)
        job_dict["job_status"] = kwargs.get("job_status", "created")
        job_dict["job_type"] = kwargs.get("job_type", "tool_upload")
        job_dict["tool_name"] = kwargs.get("tool_name", "NA")
        job_dict["file_path"] = kwargs.get("file_path").replace("\\", "/")
        job_dict["file_name"] = kwargs.get("file_name").replace("\\", "/")
        job_dict["file_type"] = (
            "klarf" if job_dict["file_path"].endswith(".001") else "tif"
        )

        if job_dict["job_id"] is None:
            job_dict["file_name"] = os.path.basename(job_dict["file_path"])
            # Update status: queued
            insert_query = """
                INSERT INTO enlight_job_log (
                    tool_name,
                    file_name,
                    file_type,
                    job_type,
                    job_status,
                    file_path,
                    cdt
                ) VALUES (
                    '{tool_name}',
                    '{file_name}',
                    '{file_type}',
                    '{job_type}',
                    'created',
                    '{file_path}',
                    NOW()
                )
            """
            insert_query = insert_query.format(**job_dict)
            db_cur.execute(insert_query)
            # db_cur.commit()
            db_cur.close()
        elif job_dict["job_id"]:
            # Update status: picked/Success/Failed
            job_dict["job_start_time"] = "job_start_time"
            job_dict["job_end_time"] = (
                "NOW()" if job_dict["job_status"] != "created" else "job_end_time"
            )

            job_dict["job_duration"] = (
                "TIMESTAMPDIFF(SECOND, job_start_time, NOW())"
                if job_dict["job_status"] != "picked"
                else "job_duration"
            )

            job_dict["err_message"] = kwargs.get("err_message", "").replace("'", "")

            job_dict["re_try"] = (
                "re_try + 1" if job_dict["job_status"] == "failed" else "re_try"
            )

            update_query = """
                INSERT INTO enlight_job_log
                SELECT
                    id,
                    tool_name,
                    file_name,
                    file_type,
                    job_type,
                    {job_start_time} AS job_start_time,
                    {job_end_time} AS job_end_time,
                    {job_duration} AS job_duration,
                    '{job_status}' AS job_status,
                    '{err_message}' AS err_message,
                    '{file_path}' AS file_path,
                    cdt,
                    {re_try} AS re_try
                FROM
                    enlight_job_log FINAL
                WHERE
                    id = {job_id}
            """
            update_query = update_query.format(**job_dict)
            db_cur.execute(update_query)
            # db_cur.commit()
            db_cur.close()
        else:
            raise ValueError("Missing Job id.")

    except Exception as e:
        app_log.error("Failed to update job status.")
        app_log.exception(e)


async def move_tiff_file(src_path, filename):
    """Function to move the file"""
    try:
        watch_path = env_config["watchdog_pick_location"]["src"]
        dst_path = os.path.join(watch_path,'images','temp')
        path = os.path.join(dst_path, filename)
        if os.path.exists(path):
            os.remove(path)
        shutil.move(src_path, dst_path)
        return os.path.join(dst_path, filename)
    except Exception as e:
        app_log.exception(e)
        raise Exception(e)

def prep_multidropdown_query(data, alias=""):
    """Prepare query string for multi dropdown
    columns in multiDropdown payload
    eg: alias => defects.
    """
    query_string = ""
    if data.get("inputs", {}).get("selectedruns", None):
        values = data.get("inputs", {}).get("selectedruns")
        query_string = f' and {" and ".join([f"{alias}mapid in {tuple(values)}"])}'
    return query_string


def make_queries(data, alias=""):
    multi_drop_down_query = ""

    multi_drop_down_query = prep_multidropdown_query(data, alias)
    if data["inputs"].get("singleMapSelection", None):
        query_string = f"{multi_drop_down_query}"
    else:
        range_query = prep_range_query(data, alias)
        query_string = f"{multi_drop_down_query}{range_query}"
    return query_string


def prep_range_query(data, alias=""):
    """
    Prepare query string for range filter inputs
    """
    """ Removing attribute_filters from the inputs, this not part of main table columns """
    range_items = (
        ["xsite", "ysite"] if data.get("inputs", {}).get("xsite", None) else []
    )
    inputs = data.get("inputs")
    offset_x = ""
    offset_y = ""
    if data["inputs"].get("waferView") and data["inputs"].get("waferView") != "multi":
        offset_x = f"+ rtn.offset_x"
        offset_y = f"+ rtn.offset_y"

    query_string = ""
    if range_items:
        range_query_list = []
        for range_item in range_items:
            if isinstance(inputs[range_item], dict):
                if range_item in ["xsite", "ysite"]:
                    if range_item == "xsite":
                        range_query_list.append(
                            f" ({alias}{range_item} {offset_x}) {' BETWEEN ' if inputs[range_item].get('include', True) else ' Not BETWEEN ' } {inputs[range_item]['min']} and {inputs[range_item]['max']}"
                        )
                    else:
                        range_query_list.append(
                            f" ({alias}{range_item} {offset_y}) {' BETWEEN ' if inputs[range_item].get('include', True) else ' Not BETWEEN ' } {inputs[range_item]['min']} and {inputs[range_item]['max']}"
                        )

        query_string = f' and ({" and ".join(range_query_list)})'
    return query_string


def make_query(data):
    """This function is used to create queries"""
    query_data = {}
    header_cdtn = []
    defect_cdtn = []
    limit_cdtn = []
    gfilter_cdtn = prep_query(data.get("filters").get("gfilter", {}))
    sfilter_cdtn = prep_query(data.get("filters").get("sfilter", {}))
    dfilter_cdtn = prep_query(data.get("filters").get("periodfilter", {}))

    for cdtn in gfilter_cdtn + sfilter_cdtn + dfilter_cdtn:
        if "defect" in cdtn:
            defect_cdtn.append(cdtn)
        elif "header" in cdtn:
            header_cdtn.append(cdtn)
        else:
            limit_cdtn.append(cdtn)

    header_query = " and ".join(header_cdtn)
    defect_query = " and ".join(defect_cdtn)
    limit_query = "and".join(limit_cdtn)

    query_data["header_cdtn"] = f"and {header_query}" if len(header_cdtn) >= 1 else ""
    query_data["defect_cdtn"] = f"and {defect_query}" if len(defect_cdtn) >= 1 else ""
    query_data["limit_cdtn"] = f"{limit_query}" if len(limit_cdtn) >= 1 else ""
    return query_data


def prep_query(data):
    """This function to prepare the clauses from the filters"""
    query_condition = []
    filter_cols = get_filter_config()
    for col_name, col_data in data.items():
        query_str = ""
        col_alias = filter_cols.get(col_name, "")
        if (
            col_data["type"] in ["singleselect", "multiselect"]
            and len(col_data["data"]) >= 1
        ):
            if col_data.get("include", True) == False:
                query_str = f'{col_alias}.{col_name} not in {tuple(col_data["data"])}'
            else:
                query_str = f'{col_alias}.{col_name} in {tuple(col_data["data"])}'
            query_condition.append(query_str)

        elif col_name == "resulttimestamp" and len(col_data["data"]) >= 1:
            query_str = f"date({col_alias}.{col_name}) between '{col_data['data']['min']}' and '{col_data['data']['max']}' "
            query_condition.append(query_str)

        elif col_data["type"] == "range" and len(col_data["data"]) >= 1:
            if col_data.get("include", True) == False:
                query_str = f'{col_alias}.{col_name} not between {col_data["data"]["min"]} and {col_data["data"]["max"]}'
            else:
                query_str = f'{col_alias}.{col_name} between {col_data["data"]["min"]} and {col_data["data"]["max"]}'
            query_condition.append(query_str)

        elif col_name == "runs" and len(col_data["data"]) >= 1:
            query_str = f"Order by resulttimestamp desc Limit {col_data['data']}"
            query_condition.append(query_str)

    return query_condition


def update_query(query, orientation):
    """Updating columns with orientation"""
    columns = [
        "xsite_prep0",
        "ysite_prep0",
        "xsite",
        "ysite",
        "xsite_prep1",
        "ysite_prep1",
        "xsite_prep2",
        "xrel",
        "yrel",
        "xsite_prep_cm",
        "ysite_prep_cm",
    ]
    for col in columns:
        if col in query:
            query = query.replace(col, f"{col}_{orientation}")
    return query


async def get_prep_level(data, limit=25000):
    resp = {}
    if not data.get("prep_column"):
        orientation = data["orientation"]
        app_log.info("prep_column is empty in payload. Calculating Prep Level")
        resp = {"xsite": f"{data['xsite']}", "ysite": f"{data['ysite']}"}
        app_log.info("............Prep Calculation started...............")
        if data.get("isCallSplit"):
            data["count_condition"] = data["query_c"]
        defect_count_0_query = common_queries["read_defects_count_level0"]
        read_defect_count = common_queries["read_defects_count"]
        if data["count_condition"].find(" and  ( (toString(appearances") >= 0:
            data["count_condition"] = str.split(
                data["count_condition"], " and  ( (toString(appearances"
            )[0]
        all_count_query = f"{defect_count_0_query.format(**data)} union all {read_defect_count.format(**data)}"
        app_log.info(all_count_query)
        all_count = await execute_query(all_count_query, "tuple")
        count_level0 = all_count[0][0] if all_count is not None else 0
        count_level2 = all_count[1][0] if all_count is not None else 0
        resp["count"] = count_level0
        # cursor.close()
        app_log.info(f"COUNT LEVEL 0: {count_level0}")
        if count_level0 > limit:
            resp["xsite"] = f"xsite_prep2_{orientation}"
            resp["ysite"] = f"ysite_prep2_{orientation}"
            resp["count"] = count_level2
            app_log.info(f"COUNT 2: {count_level2}")
            if count_level2 > limit:
                if data.get("waferView", None) == "multi" and count_level2 > 25000:
                    resp["xsite"] = f"xsite_prep0_{orientation}"
                    resp["ysite"] = f"ysite_prep0_{orientation}"
                else:
                    resp["xsite"] = f"xsite_prep1_{orientation}"
                    resp["ysite"] = f"ysite_prep1_{orientation}"
                resp["count"] = count_level2
                app_log.info(f"SET PREP LEVEL AS X and Y PREP1_{orientation}")
        app_log.info(f"PREPING VALUES ARE {resp['xsite'], resp['ysite']}")
        app_log.info("............Prep Calculation End...............")
    else:
        app_log.info(f"The Prep column already in payload")
        resp = {"xsite": data["prep_column"][0], "ysite": data["prep_column"][1]}
    return resp

async def extract_tif_file(file_byte, filename):
    start_time = datetime.now()
    n_frame = 0
    dest_path = await get_image_folder(filename)
    file_title_name = str(filename.split('.')[0])
    im = Image.open(file_byte)
    n_frame = im.n_frames
    index = 0
    for i in range(im.n_frames):
        index = i+1
        im.seek(i)
        if im.mode != 'L':
            im.mode = 'I'
            im.point(lambda i:i*(1./256)).convert('L').save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
        else:
            im.save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
    app_log.info(f'Extracted {index} JPEGs')
    app_log.info(f"Tiff file processing time: {datetime.now() - start_time}")
    return n_frame

async def get_image_folder(filename):
    tiff_file_name_split, ext = os.path.splitext(filename)
    app_log.info(f"image_folder_creation_unix: process start")
    base_path = env_config['watchdog_pick_location']['src']

    forward_path = os.path.join('images', tiff_file_name_split)
    complete_report_path = os.path.join(base_path, forward_path)
    try:
        if os.path.exists(complete_report_path):
            app_log.info('Deleting previously added folder : {0}'.format(
                complete_report_path))
            shutil.rmtree(complete_report_path)

        os.makedirs(complete_report_path, mode=0o777)
        app_log.info('Image Path is created in the this location')
        return complete_report_path
    except Exception as e:
            app_log.exception(
                "Command to create the tiff image folder Failed : {0}".format(repr(e)))

async def process_tiff(file, filename):
        """
        validate tiff file
        """
        try:
            app_log.info("Checking if Klarf exist for tiff")
            queries = common_queries["upload"]
            tiff_check = queries['check_tiff'].format(**{"filename": filename})
            app_log.info(f"Query: {tiff_check}")
            tiff_check = await execute_query(tiff_check, resp_type='dict')
            if len(tiff_check):
                n_frame = await extract_tif_file(file, filename)
                if n_frame:
                    # Populate has_tif column
                    has_tiff = queries['update_has_tiff'].format(**{"filename": filename})
                    app_log.info(f"Update has_tif query: {has_tiff}")
                    await execute_query(has_tiff, resp_type=None)
            else:
                raise Exception("Please upload Klarf First")
        except Exception as excep:
            app_log.exception(excep)
            raise Exception(excep)

async def req_url(url, payload, headers,method, resp_type=False,payload_type = False):
    if payload_type:
        payload =  json.dumps(payload)
    resp= resp_type
    async with aiohttp.ClientSession() as session:
        if method == 'post':
            async with session.post(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
        elif method == 'put':
            async with session.put(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
        elif  method == 'get':
            async with session.get(url,  headers=headers) as response:
                sh_report_resp = response.status
        if resp_type:
            resp = await response.json()
    return sh_report_resp, resp
