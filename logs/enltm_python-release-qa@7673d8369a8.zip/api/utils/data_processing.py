import os
import re
import math
import traceback
import asyncio
import json
import time
import copy
from PIL import Image
from datetime import datetime

import numpy as np
import pandas as pd
from utilities.parser_v7 import parser_v7
from utilities.parser_v8 import parser_v8
from api.utils.fastapi_app import get_query_with_pool, insert_data
from api.utils.utils import (
    get_logger,
    env_config,
    columns_info,
    get_alias_config,
    common_queries,
)
from api.utils.common import trigger_email


app_log = get_logger("data_load")
alias_info = get_alias_config()
queries = common_queries["upload"]
DEFAULT_BATCH_SIZE = env_config["DEFAULT_BATCH_SIZE"]
MAX_NUM_PROCESSES = env_config["MAX_NUM_PROCESSES"]
UPLOAD_PATH = env_config["ui_upload"]["src"]

# app = Celery("tasks", broker=env_config["broker"], backend=env_config["backend"])


class UploadUtils:
    """this class provides methods for upload utils"""

    def __init__(self,toolupload,file, data):
        global get_query_with_pool
        global insert_data
        if toolupload:
            from api.utils.tool_app import get_query_with_pool, insert_data
        else:
            from api.utils.fastapi_app import get_query_with_pool, insert_data
        self.file = file
        self.data = data
        self.job_type = data.get('job_type', 'ui_upload')
        self.main_df = None
        self.header_df = None
        self.class_df = None
        self.mapid = None
        self.export_dict = None
        self.job_id = data.get('job_id', None)
        self.filename = data.get('filename')
        self.file_type = data.get('file_type', 'klarf')
        self.file_path = data.get('file_path', f'{UPLOAD_PATH}/{data.get("filename")}')
        self.product = data.get('product', None)
        self.layer = data.get('layer', None)
        self.recipeid = data.get('recipeid', None)
        self.overwrite = int(data.get('overwrite', 0))
        self.tool = data.get('tool', "NA")
        self.is_master = data.get('is_master', 0)
        self.master_tool_check = [0]
        self.rfg = 1
        self.version = None

    async def parse_file(self):
        if "1.8" in self.file[0]:
                app_log.info("Processing file for 1.8 version")

                self.main_df, self.header_df, self.class_df, self.export_dict = await parser_v8(self.file)
        elif (
            "1 7" in self.file[0]
            or "1 1" in self.file[0]
            or "1 2" in self.file[0]
        ):
            app_log.info("Processing file for 1.7 version")
            self.main_df, self.header_df, self.class_df, self.export_dict = await parser_v7(self.file)

    async def get_defect_count(self, mapid):
        """Check header defectcnt is equal total cnt from enlight_defect_main"""
        main_query = (
            f"select count(1) from enlight_defect_main_wip final where mapid={mapid}"
        )
        # con = connection_pool.connect()
        # count = execute_query(con, main_query, "one")
        count = await get_query_with_pool(main_query, "list")
        app_log.info(f"Defect count fro {mapid} is {count}")
        if count:
            count = count[0]
        else:
            count = 0
        return {"main_table": count}

    async def process_header_df(self):
        """This function will process header data and format them in required form."""
        try:
            datetime_format = "%Y-%m-%d %H:%M:%S"
            self.header_df.columns = self.header_df.columns.str.lower()
            self.header_df[["diepitch_x", "diepitch_y"]] = self.header_df["diepitch"].str.split(
                ",", expand=True
            ).astype(np.float64)
            self.header_df[["dieorigin_x", "dieorigin_y"]] = self.header_df["dieorigin"].str.split(
                ",", expand=True
            )
            self.header_df[["scl_x", "scl_y"]] = self.header_df["samplecenterlocation"].str.split(
                ",", expand=True
            )
            self.header_df = self.header_df.drop(
                ["diepitch", "dieorigin", "samplecenterlocation"], axis=1
            )
            self.header_df = self.header_df.rename(columns=alias_info)
            diff_cols = set(columns_info["header_cols"].keys()).difference(
                self.header_df.columns
            )
            for col in diff_cols:
                if columns_info["header_cols"][col] == np.int64:
                    self.header_df[col] = -999999999
                else:
                    self.header_df[col] = pd.Series(dtype=columns_info["header_cols"][col])

            self.header_df = self.header_df.astype(columns_info["header_cols"])

            if not self.header_df.at[0, "orientationmarklocation"] in [
                "TOP",
                "RIGHT",
                "DOWN",
                "LEFT",
            ]:
                self.header_df["orientationmarklocation"] = self.header_df.at[
                    0, "orientationmarklocation"
                ].split(".")[0]
            self.header_df["orientationmarklocation"] = self.header_df[
                "orientationmarklocation"
            ].replace(columns_info["orientation_data"])

            if self.header_df.at[0, "tifffilename"].lower().endswith(("tiff", "tif", "i01")):
                tiff_file_name_split, ext = os.path.splitext(
                    self.header_df.at[0, "tifffilename"]
                )
                tiff_file_name_split = re.sub(r"[^a-zA-Z0-9]", "_", tiff_file_name_split)
                self.header_df["tifffilename"] = f"{tiff_file_name_split}{ext}"

            self.header_df["cdt"] = pd.to_datetime(str(datetime.now()))
            self.header_df["cdt"] = self.header_df["cdt"].dt.strftime(datetime_format)
            self.header_df["filetimestamp"] = pd.to_datetime(self.header_df["filetimestamp"])
            self.header_df["filetimestamp"] = self.header_df["filetimestamp"].dt.strftime(
                datetime_format
            )
            self.header_df["resulttimestamp"] = pd.to_datetime(self.header_df["resulttimestamp"])
            self.header_df["resulttimestamp"] = self.header_df["resulttimestamp"].dt.strftime(
                datetime_format
            )
        except Exception as e:
            app_log.exception(e)
            raise Exception("File Upload error in while processing header data")

    async def add_oriented_col(self):
        """Adding oriented columns in header dataframe"""
        self.header_df["diepitch_x_up"] = np.select(
            [
                (self.header_df.orientationmarklocation == "RIGHT")
                | (self.header_df.orientationmarklocation == "LEFT")
            ],
            [self.header_df["diepitch_y"]],
            default=self.header_df["diepitch_x"],
        )
        self.header_df["diepitch_y_up"] = np.select(
            [
                (self.header_df.orientationmarklocation == "RIGHT")
                | (self.header_df.orientationmarklocation == "LEFT")
            ],
            [self.header_df["diepitch_x"]],
            default=self.header_df["diepitch_y"],
        )

        self.header_df["scl_x_up"] = np.select(
            [
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "DOWN",
            ],
            [
                (
                    self.header_df["scl_x"] * round(math.cos(-90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(-90 * math.pi / 180), 0)
                ),
                (
                    self.header_df["scl_x"] * round(math.cos(90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(90 * math.pi / 180), 0)
                ),
                self.header_df["scl_x"],
                (
                    self.header_df["scl_x"] * round(math.cos(math.pi), 0)
                    + self.header_df["scl_y"] * round(math.sin(math.pi), 0)
                ),
            ],
            default = self.header_df["scl_x"],
        )

        self.header_df["scl_y_up"] = np.select(
            [
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "DOWN",
            ],
            [
                - self.header_df["scl_x"] * round(math.sin(-90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(-90 * math.pi / 180), 0),
                - self.header_df["scl_x"] * round(math.sin(90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(90 * math.pi / 180), 0),
                self.header_df["scl_y"],
                - self.header_df["scl_x"] * round(math.sin(math.pi), 0)
                + self.header_df["scl_y"] * round(math.cos(math.pi), 0),
            ],
            default = self.header_df["scl_y"],
        )

        self.header_df["diepitch_x_down"] = np.select(
            [
                (self.header_df.orientationmarklocation == "RIGHT")
                | (self.header_df.orientationmarklocation == "LEFT")
            ],
            [self.header_df["diepitch_y"]],
            default=self.header_df["diepitch_x"],
        )
        self.header_df["diepitch_y_down"] = np.select(
            [
                (self.header_df.orientationmarklocation == "RIGHT")
                | (self.header_df.orientationmarklocation == "LEFT")
            ],
            [self.header_df["diepitch_x"]],
            default=self.header_df["diepitch_y"],
        )

        self.header_df["scl_x_down"] = np.select(
            [
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "UP",
            ],
            [
                (
                    self.header_df["scl_x"] * round(math.cos(-90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(-90 * math.pi / 180), 0)
                ),
                (
                    self.header_df["scl_x"] * round(math.cos(90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(90 * math.pi / 180), 0)
                ),
                self.header_df["scl_x"],
                (
                    self.header_df["scl_x"] * round(math.cos(math.pi), 0)
                    + self.header_df["scl_y"] * round(math.sin(math.pi), 0)
                ),
            ],
            default=self.header_df["scl_x"],
        )

        self.header_df["scl_y_down"] = np.select(
            [
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "UP",
            ],
            [
                - self.header_df["scl_x"] * round(math.sin(-90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(-90 * math.pi / 180), 0),
                - self.header_df["scl_x"] * round(math.sin(90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(90 * math.pi / 180), 0),
                self.header_df["scl_y"],
                - self.header_df["scl_x"] * round(math.sin(math.pi), 0)
                + self.header_df["scl_y"] * round(math.cos(math.pi), 0),
            ],
            default = self.header_df["scl_y"],
        )

        self.header_df["diepitch_x_left"] = np.select(
            [
                (self.header_df.orientationmarklocation == "UP")
                | (self.header_df.orientationmarklocation == "DOWN")
            ],
            [self.header_df["diepitch_y"]],
            default = self.header_df["diepitch_x"],
        )
        self.header_df["diepitch_y_left"] = np.select(
            [
                (self.header_df.orientationmarklocation == "UP")
                | (self.header_df.orientationmarklocation == "DOWN")
            ],
            [self.header_df["diepitch_x"]],
            default = self.header_df["diepitch_y"],
        )

        self.header_df["scl_x_left"] = np.select(
            [
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "RIGHT",
            ],
            [
                (
                    self.header_df["scl_x"] * round(math.cos(-90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(-90 * math.pi / 180), 0)
                ),
                (
                    self.header_df["scl_x"] * round(math.cos(90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(90 * math.pi / 180), 0)
                ),
                self.header_df["scl_x"],
                (
                    self.header_df["scl_x"] * round(math.cos(math.pi), 0)
                    + self.header_df["scl_y"] * round(math.sin(math.pi), 0)
                ),
            ],
            default = self.header_df["scl_x"],
        )

        self.header_df["scl_y_left"] = np.select(
            [
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "LEFT",
                self.header_df.orientationmarklocation == "RIGHT",
            ],
            [
                - self.header_df["scl_x"] * round(math.sin(-90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(-90 * math.pi / 180), 0),
                - self.header_df["scl_x"] * round(math.sin(90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(90 * math.pi / 180), 0),
                self.header_df["scl_y"],
                - self.header_df["scl_x"] * round(math.sin(math.pi), 0)
                + self.header_df["scl_y"] * round(math.cos(math.pi), 0),
            ],
            default = self.header_df["scl_y"],
        )

        self.header_df["diepitch_x_right"] = np.select(
            [
                (self.header_df.orientationmarklocation == "UP")
                | (self.header_df.orientationmarklocation == "DOWN")
            ],
            [self.header_df["diepitch_y"]],
            default = self.header_df["diepitch_x"],
        )
        self.header_df["diepitch_y_right"] = np.select(
            [
                (self.header_df.orientationmarklocation == "UP")
                | (self.header_df.orientationmarklocation == "DOWN")
            ],
            [self.header_df["diepitch_x"]],
            default = self.header_df["diepitch_y"],
        )

        self.header_df["scl_x_right"] = np.select(
            [
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "LEFT",
            ],
            [
                (
                    self.header_df["scl_x"] * round(math.cos(-90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(-90 * math.pi / 180), 0)
                ),
                (
                    self.header_df["scl_x"] * round(math.cos(90 * math.pi / 180), 0)
                    + self.header_df["scl_y"] * round(math.sin(90 * math.pi / 180), 0)
                ),
                self.header_df["scl_x"],
                (
                    self.header_df["scl_x"] * round(math.cos(math.pi), 0)
                    + self.header_df["scl_y"] * round(math.sin(math.pi), 0)
                ),
            ],
            default = self.header_df["scl_x"],
        )
        self.header_df["scl_y_right"] = np.select(
            [
                self.header_df.orientationmarklocation == "DOWN",
                self.header_df.orientationmarklocation == "UP",
                self.header_df.orientationmarklocation == "RIGHT",
                self.header_df.orientationmarklocation == "LEFT",
            ],
            [
                - self.header_df["scl_x"] * round(math.sin(-90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(-90 * math.pi / 180), 0),
                - self.header_df["scl_x"] * round(math.sin(90 * math.pi / 180), 0)
                + self.header_df["scl_y"] * round(math.cos(90 * math.pi / 180), 0),
                self.header_df["scl_y"],
                - self.header_df["scl_x"] * round(math.sin(math.pi), 0)
                + self.header_df["scl_y"] * round(math.cos(math.pi), 0),
            ],
            default=self.header_df["scl_y"],
        )

    async def process_main_df(self):
        """This function processes the main data and adds prep columns
        and format them in required form."""
        self.main_df.columns = [col.lower() for col in self.main_df.columns]
        self.main_df = self.main_df.apply(pd.to_numeric, errors="ignore")

        self.main_df["xsite"] = self.header_df["diepitch_x"][0].astype(np.float64) * self.main_df[
            "xindex"
        ].astype(np.int32) + self.main_df["xrel"].astype(np.float64)

        self.main_df["ysite"] = self.header_df["diepitch_y"][0].astype(np.float64) * self.main_df[
            "yindex"
        ].astype(np.int32) + self.main_df["yrel"].astype(np.float64)

        self.main_df.loc[self.main_df["xsite"] < 0, "xsite_prep0"] = (
            self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs()
            - self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs().mod(3000000)
        ) * -1
        self.main_df.loc[self.main_df["xsite"] >= 0, "xsite_prep0"] = self.main_df.loc[
            self.main_df["xsite"] >= 0, "xsite"
        ].abs() - self.main_df.loc[self.main_df["xsite"] >= 0, "xsite"].abs().mod(3000000)
        self.main_df.loc[self.main_df["ysite"] < 0, "ysite_prep0"] = (
            self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs()
            - self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs().mod(3000000)
        ) * -1
        self.main_df.loc[self.main_df["ysite"] >= 0, "ysite_prep0"] = self.main_df.loc[
            self.main_df["ysite"] >= 0, "ysite"
        ].abs() - self.main_df.loc[self.main_df["ysite"] >= 0, "ysite"].abs().mod(3000000)

        # Prepareing xsite, ysite prep1 data
        self.main_df.loc[self.main_df["xsite"] < 0, "xsite_prep1"] = (
            self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs()
            - self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs().mod(2000000)
        ) * -1
        self.main_df.loc[self.main_df["xsite"] >= 0, "xsite_prep1"] = self.main_df.loc[
            self.main_df["xsite"] >= 0, "xsite"
        ].abs() - self.main_df.loc[self.main_df["xsite"] >= 0, "xsite"].abs().mod(2000000)

        self.main_df.loc[self.main_df["ysite"] < 0, "ysite_prep1"] = (
            self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs()
            - self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs().mod(2000000)
        ) * -1
        self.main_df.loc[self.main_df["ysite"] >= 0, "ysite_prep1"] = self.main_df.loc[
            self.main_df["ysite"] >= 0, "ysite"
        ].abs() - self.main_df.loc[self.main_df["ysite"] >= 0, "ysite"].abs().mod(2000000)

        # Prepareing xsite, ysite prep2 data
        self.main_df.loc[self.main_df["xsite"] < 0, "xsite_prep2"] = (
            self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs()
            - self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs().mod(15000)
        ) * -1
        self.main_df.loc[self.main_df["xsite"] >= 0, "xsite_prep2"] = self.main_df.loc[
            self.main_df["xsite"] >= 0, "xsite"
        ].abs() - self.main_df.loc[self.main_df["xsite"] >= 0, "xsite"].abs().mod(15000)

        self.main_df.loc[self.main_df["ysite"] < 0, "ysite_prep2"] = (
            self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs()
            - self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs().mod(15000)
        ) * -1
        self.main_df.loc[self.main_df["ysite"] >= 0, "ysite_prep2"] = self.main_df.loc[
            self.main_df["ysite"] >= 0, "ysite"
        ].abs() - self.main_df.loc[self.main_df["ysite"] >= 0, "ysite"].abs().mod(15000)

        # Prepareing xsite, ysite prep_cm data
        self.main_df.loc[self.main_df["xsite"] < 0, "xsite_prep_cm"] = (
            self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs()
            - self.main_df.loc[self.main_df["xsite"] < 0, "xsite"].abs().mod(150000)
        ) * -1
        self.main_df.loc[self.main_df["xsite"] >= 0, "xsite_prep_cm"] = self.main_df.loc[
            self.main_df["xsite"] >= 0, "xsite"
        ].abs() - self.main_df.loc[self.main_df["xsite"] >= 0, "xsite"].abs().mod(150000)

        self.main_df.loc[self.main_df["ysite"] < 0, "ysite_prep_cm"] = (
            self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs()
            - self.main_df.loc[self.main_df["ysite"] < 0, "ysite"].abs().mod(150000)
        ) * -1
        self.main_df.loc[self.main_df["ysite"] >= 0, "ysite_prep_cm"] = self.main_df.loc[
            self.main_df["ysite"] >= 0, "ysite"
        ].abs() - self.main_df.loc[self.main_df["ysite"] >= 0, "ysite"].abs().mod(150000)
        self.main_df["dm_id"] = -1
        self.main_df.rename(columns_info["alias_dict"], inplace=True)

        for i in self.main_df.columns:
            if i in columns_info["main_cols"].keys():
                if columns_info["main_cols"][i] in [np.int64, np.float64]:
                    self.main_df[i] = (
                            self.main_df[i]
                            .replace([np.nan], [-9999999])
                            .astype(columns_info["main_cols"][i])
                            .replace([-9999999], [None])
                        )
                else:
                    self.main_df[i] = self.main_df[i].astype(columns_info["main_cols"][i])
        app_log.info(self.main_df["dm_id"].head())
        diff_cols = set(columns_info["main_cols"].keys()).difference(self.main_df.columns)
        diff_cols.remove("mapid")
        for col in diff_cols:
            if columns_info["main_cols"][col] == np.int64:
                self.main_df[col] = None
            else:
                self.main_df[col] = pd.Series(dtype=columns_info["main_cols"][col])
        if self.main_df['dynamic'].isna().any():
            self.main_df['dynamic'] = [{} for i in range(0,len(self.main_df))]
        self.main_df = self.main_df.replace(np.NaN, None)
        return self.main_df

    async def update_job_status(self , kwargs):
        """This function is used update the status in job_log table"""
        try:
            job_dict = {}
            job_dict["job_id"] = kwargs.get("job_id", None)
            job_dict["job_status"] = kwargs.get("job_status", "created")
            job_dict["job_type"] = kwargs.get("job_type", "tool_upload")
            job_dict["tool_name"] = kwargs.get("tool_name", "NA")
            job_dict["file_path"] = kwargs.get("file_path").replace("\\", "/")
            job_dict["file_name"] = self.filename
            job_dict["file_type"] = (
                "klarf" if job_dict["file_path"].endswith(".001") else "tif"
            )

            if job_dict["job_id"] is None:
                job_dict["file_name"] = os.path.basename(job_dict["file_path"])
                # Update status: queued
                insert_query = """
                    INSERT INTO enlight_job_log (
                        tool_name,
                        file_name,
                        file_type,
                        job_type,
                        job_start_time,
                        job_status,
                        file_path,
                        cdt
                    ) VALUES (
                        '{tool_name}',
                        '{file_name}',
                        '{file_type}',
                        '{job_type}',
                        NOW(),
                        'created',
                        '{file_path}',
                        NOW()
                    )
                """
                insert_query = insert_query.format(**job_dict)
                await get_query_with_pool(insert_query)

                select_query = "Select id from enlight_job_log final where file_name = '{file_name}' and job_status = 'created'"
                select_query = select_query.format(**job_dict)
                job_id = await get_query_with_pool(select_query, '')
                self.job_id = job_id[0][0]

            elif job_dict["job_id"]:
                # Update status: picked/Success/Failed
                job_dict["job_end_time"] = (
                    "NOW()" if job_dict["job_status"] != "created" else "job_end_time"
                )

                job_dict["job_duration"] = (
                    "TIMESTAMPDIFF(SECOND, job_start_time, NOW())"
                    if job_dict["job_status"] != "created"
                    else "job_duration"
                )
                job_dict["err_message"] = kwargs.get("err_message", "").replace("'", '"')

                job_dict["re_try"] = (
                    "re_try + 1" if job_dict["job_status"] == "failed" else "re_try"
                )

                update_query = """
                    INSERT INTO enlight_job_log
                    SELECT
                        id,
                        tool_name,
                        file_name,
                        file_type,
                        job_type,
                        job_start_time,
                        {job_end_time} AS job_end_time,
                        {job_duration} AS job_duration,
                        '{job_status}' AS job_status,
                        '{err_message}' AS err_message,
                        '{file_path}' AS file_path,
                        cdt,
                        {re_try} AS re_try
                    FROM
                        enlight_job_log FINAL
                    WHERE
                        id = {job_id}
                """
                update_query = update_query.format(**job_dict)
                await get_query_with_pool(update_query)
            else:
                raise ValueError("Missing Job id.")
        except Exception as e:
            app_log.error("Failed to update job status.")
            app_log.exception(e)

    async def push_data(self):
        """
        to push header and main data into clickhouse
        """
        try:
            app_log.info("Loading data into header table")
            query = common_queries["radiality"]
            header_df = self.header_df
            header_df.drop(["mapid"], axis=1, inplace=True)
            cols = ",".join([item.replace("'", "") for item in header_df.columns])
            query_to_execute = f"INSERT INTO enlight.enlight_map_header ({cols}) VALUES "
            await insert_data(
                query_to_execute,
                [tuple(x) for x in header_df.to_records(index=False)]
            )
            app_log.info("Completed pushing data into header table")

            app_log.info("Processing main DF.")
            main_df = await self.process_main_df()
            main_df["resulttimestamp"] = header_df["resulttimestamp"].iloc[0]

            map_query = queries["mapid"].format(
                **{
                    "product": header_df["product"][0],
                    "layer": header_df["layer"][0],
                    "recipeid": header_df["recipeid"][0],
                    "is_master": header_df["is_master"][0],
                    "cndtn_query": f"AND resulttimestamp = '{header_df['resulttimestamp'][0]}'" if header_df["is_master"][0] == 0 else f"AND resulttimestamp = '{header_df['resulttimestamp'][0]}' and tool = '{header_df['tool'][0]}'",
                    "rfg": self.rfg
                }
            )
            mapid = await get_query_with_pool(map_query, '')
            mapid = mapid[0][0]
            self.mapid = mapid
            self.export_dict['mapid'] = mapid
            app_log.info(mapid)
            main_df["mapid"] = mapid
            main_df = self.main_df[columns_info["main_cols"].keys()]
            """ Processing to Inserting main_df into enlight_defect_main_wip(temp_table)"""
            """ We will delete the mapid after the data inserted into enlight_defect_main table """
            # Insert Data into enlight_defect_main_wip
            cols = ",".join([item.replace("'", "") for item in main_df.columns])
            query_to_execute = f"INSERT INTO enlight.enlight_defect_main_wip ({cols}) VALUES "
            splits = round(
                1
                if main_df.shape[0] < int(DEFAULT_BATCH_SIZE)
                else main_df.shape[0] / int(DEFAULT_BATCH_SIZE)
            )

            if splits > 1:
                app_log.info(f"Splitting the main df into {splits} batches")
                main_df_split = np.array_split(main_df, splits)
            else:
                main_df_split = [main_df]
            ## Create a coroutine list where insert data will have the data splits as input
            coros = [
                insert_data(
                    query_to_execute,
                    [tuple(x) for x in i.to_records(index=False)]
                )
                for i in main_df_split
            ]
            # run the tasks to execute inserts parallely
            await asyncio.gather(*coros)

            app_log.info(f"END push data into wip table.")

            # Merge class_df with main_df

            app_log.info("Loading data into main table")
            """ Get the data from the enlight_defect_main_wip and insert into enlight_defect_main """
            insert_query = query["insert_defect_main"].format(**{"mapid": mapid, "rfg": self.rfg})
            app_log.info(f"Insert query: {insert_query}")
            await get_query_with_pool(insert_query, '')
            # end radiality process

            # Checking the defectcount
            defect_count = await self.get_defect_count(mapid)
            app_log.info(f"DEFECT COUNT: {defect_count}, {mapid}")
            app_log.info(
                f"Defect count, main_df: {self.main_df.shape[0]}, header_df: {header_df['defectcnt']}"
            )
            app_log.info(f"shape of dataframes : {main_df.shape}, {header_df.shape}")

            """ The rotation data processed and delete the data from the enlight_defect_main_wip """
            # Delete map from enlight_defect_main_wip table
            app_log.info(f"Deleting {mapid} from enlight_defect_main_wip STARTED")
            trunc_query = (
                f"alter table enlight_defect_main_wip delete where mapid={mapid};"
            )
            app_log.info(f"enlight_defect_main_wip delete query: {trunc_query}")

            await get_query_with_pool(trunc_query)
            app_log.info("Deleting {mapid} from enlight_defect_main_wip END")
            app_log.info("Open connections has been closed.")

            #Update Master Map Tool column
            if self.is_master == 1:
                master_map_query = queries["update_mastermap_tool"].format(
                **{
                    "product": header_df["product"][0],
                    "layer": header_df["layer"][0],
                    "recipeid": header_df["recipeid"][0],
                    "master_tool": "'NA'" if self.tool == 'NA' else 'tool',
                }
                )
                await get_query_with_pool(master_map_query, '')
            export_df = pd.DataFrame.from_records([self.export_dict])
            export_cols = ",".join([item.replace("'", "") for item in export_df.columns])
            query_to_execute = f"INSERT INTO enlight.enlight_export_metadata ({export_cols}) VALUES "
            await insert_data(
                query_to_execute,
                [tuple(x) for x in export_df.to_records(index=False)]
            )
        except Exception as e:
            app_log.exception(f"File Upload Error: {traceback.format_exc()}")
            raise Exception("File Upload error in while pushing data in WIP table")

    async def save_klarf(self):
        with open(self.file_path, "w") as f:
            for line in self.file:
                line = line.rstrip('\x00')
                f.write(f"{line}")

    async def verify(self):
        """Function is used to validate PLR from header data against QC Recipe"""
        query_data = {}
        query_data["product"] = self.header_df["deviceid"].iloc[0]
        query_data["layer"] = self.header_df["stepid"].iloc[0]
        query_data["recipeid"] = (
            self.header_df["recipeid"].iloc[0]
            if "1.8" in self.file[0]
            else self.header_df["setupid"].iloc[0]
        )
        if self.recipeid is None:
            query_to_execute = queries["plr_check"].format(**query_data)
            app_log.info(f"PLR Check Query: {query_to_execute}")
            exists = await get_query_with_pool(query_to_execute, resp_type="list")
            if exists[0][0] == 0 and self.is_master == 1:
                raise Exception("Product, Layer, Recipeid Combination mismatch")

            elif exists[0][0] == 0 and self.is_master == 0:
                self.rfg = 2

        else:
            mismatch = []
            if self.product != query_data["product"]:
                mismatch.append('Product')
            if self.layer != query_data["layer"]:
                mismatch.append('Layer')
            if self.recipeid != query_data["recipeid"]:
                mismatch.append('Recipeid')

            if len(mismatch) >= 1:
                mismatch_str = ", ".join(mismatch)
                raise Exception(f"{mismatch_str} mismatch")
        if self.overwrite == 0 and self.is_master == 1:
            query_data["is_master"] = 1
            query_data["cndtn_query"] = f"and tool = '{self.tool}'"
            query_data["rfg"] = self.rfg
            query_to_execute = queries["mapid"].format(**query_data)
            app_log.info(f"Check if file exists: {query_to_execute}")
            exists = await get_query_with_pool(query_to_execute, resp_type="list")
            if len(exists):
                await self.save_klarf()
                raise Exception("The file already exists")
        elif self.overwrite == 1 and not(os.path.exists(self.file_path)):
            raise Exception("Please upload file first")

    async def overwrite_map(self):
        """
        This function is to overwrites if the map already exists in header
        """
        query_data = {
            "rfg": self.rfg,
            "product": self.header_df["product"][0],
            "layer": self.header_df["layer"][0],
            "recipeid": self.header_df["recipeid"][0],
            "is_master": self.header_df["is_master"][0],
            "cndtn_query": "",
        }

        if self.is_master == 0:
            query_data[
                "cndtn_query"
            ] = f"AND resulttimestamp = '{self.header_df['resulttimestamp'][0]}'"
            master_query = queries["check_mastermap_tool"].format(**query_data)
            self.master_tool_check = (await get_query_with_pool(master_query, resp_type="list"))[0]

        else:
            tool = ['NA']
            tool.append(self.tool) if self.tool != 'NA' else ''
            query_data["cndtn_query"] = f"AND tool in {tuple(tool)}" if self.tool != 'NA' else ''
        query = queries["mapid"].format(**query_data)
        app_log.info(f"Fetch duplicate mapid query: {query}")
        duplicate_mapid = await get_query_with_pool(query, resp_type="dict")
        duplicate_mapid = [i.get("mapid", "") for i in duplicate_mapid]

        if duplicate_mapid:
            rfg_query = queries["rfgquery"].format(
                **{"duplicate_mapid": duplicate_mapid, "rfg": self.rfg}
            )
            app_log.info(f"RFG Query: {rfg_query}")
            await get_query_with_pool(rfg_query)
            app_log.info(f'Successfully updated duplicate mapids: {duplicate_mapid}')

    async def dataload(self):
        """
        validates klarf with corresponding xml and inserts data into clickhouse
        """
        try:
            if self.overwrite == 1 and not(os.path.exists(self.file_path)):
                raise Exception("Please upload file first")

            if self.overwrite == 1:
                with open(self.file_path, "r") as file:
                    lines = file.readlines()
                    self.file = lines

            await self.parse_file()
            self.main_df = self.main_df.merge(self.class_df, on="classnumber", how="left")
            await self.verify()
            app_log.info("Creating header.")
            self.header_df["defectcnt"] = self.main_df.shape[0]
            self.header_df["filename"] = self.filename
            self.export_dict['filename'] = self.filename
            self.header_df["filesize"] = 0
            self.header_df["cby"] = "pvadmin"
            self.header_df["tool"] = self.tool
            self.header_df["is_master"] = self.is_master
            await self.process_header_df()
            await self.add_oriented_col()
            await self.overwrite_map()
            self.header_df["rfg"] = self.rfg
            self.header_df['master_tool'] = 'NA' if self.master_tool_check[0] == 0 and self.is_master == 0 else self.tool
            self.export_dict['product'] = self.header_df['product'][0]
            self.export_dict['layer'] = self.header_df['layer'][0]
            self.export_dict['recipeid'] = self.header_df['recipeid'][0]
            self.export_dict['resulttimestamp'] = self.header_df['resulttimestamp'][0]
            self.export_dict['tool'] = self.tool
            await self.push_data()
            await self.update_job_status(
                {"job_id": self.job_id, "job_status": "success", "file_path": self.file_path}
            )
            await self.calculate_limit()
            if self.is_master == 0 and self.rfg == 1:
                app_log.info("Alert Process Started")
                await self.alert_validation()

        except Exception as excep:
            app_log.exception(excep)
            await self.update_job_status(
                {
                    "job_id": self.job_id,
                    "job_status": "failed",
                    "file_path": self.file_path,
                    "err_message": str(excep),
                }
            )
            raise Exception(excep)

    async def alert_validation(self):
        try:
            start_time = time.time()
            query_data = {}
            query_data['product'] = '"{}"'.format(self.header_df["product"][0])
            query_data['layer'] = '"{}"'.format(self.header_df["layer"][0])
            query_data['recipeid'] = '"{}"'.format(self.header_df["recipeid"][0])

            queries = common_queries["alert"]
            get_alert = queries['get_alert'].format(**query_data)

            alert_list = await get_query_with_pool(get_alert, resp_type="dict")
            if alert_list:
                for alert in alert_list:
                    dashboard = []
                    dashboard_name = []
                    alert_filter = json.loads(alert['dataselectionfilters'])
                    for chart in alert_filter['dashboardfilters']:
                        dashboard.append(chart['type'])
                        dashboard_name.append(chart['name'])
                    data = alert
                    data['dashboard'] = dashboard
                    data['dashboard_name'] = ",".join(dashboard_name)
                    await self.limit_validate(self.mapid, data)
        except Exception as e:
            app_log.exception(e)

    async def limit_validate(self, mapid, data):
        try:
            start_time = time.time()
            query_data = {}
            query_data['product'] = self.header_df["product"][0]
            query_data['layer'] = self.header_df["layer"][0]
            query_data['recipeid'] = self.header_df["recipeid"][0]
            query_data['dashboard'] = tuple(data['dashboard'])
            query_data['mapid'] = mapid

            data['product'] = self.header_df["product"][0]
            data['layer'] = self.header_df["layer"][0]
            data['recipeid'] = self.header_df["recipeid"][0]
            data['resulttimestamp'] = self.header_df["resulttimestamp"][0]
            data['tool'] = self.header_df["tool"][0]
            data["lot"] = self.header_df["carrierid"][0]
            data['waferid'] = self.header_df["waferid"][0]
            data['filename'] = self.header_df["filename"][0]

            queries = common_queries["alert"]
            app_log.info("Limit Validate for Alerts")
            alert_limit = queries['alert_limit'].format(**query_data)
            alert_limit_df = await get_query_with_pool(alert_limit)

            merge_na = alert_limit_df[alert_limit_df['tool'] == 'NA']
            merge_tool = alert_limit_df[alert_limit_df['tool']!= 'NA']

            merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
            merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

            control_limit = merge_tool.combine_first(merge_na)
            control_limit.reset_index(inplace=True)

            control_limit= control_limit.replace({np.nan: "null"})
            query_data["control_limit"] = str(
                [
                    tuple(x)
                    for x in control_limit[
                        [
                            "product",
                            "layer",
                            "recipeid",
                            "dc_lcl",
                            "dc_ucl",
                            "gr_lcl",
                            "gr_ucl",
                            "vl_lcl",
                            "vl_ucl",
                            "sl_lcl",
                            "sl_ucl",
                            "tl_lcl",
                            "tl_ucl",
                            "cr_lcl",
                            "cr_ucl",
                            "test",
                            "tool",
                        ]
                    ].to_numpy()
                ]
            ).replace("'null'", "null")

            limit_validation = queries['limit_validation'].format(**query_data)
            app_log.info(limit_validation)
            validation_result = await get_query_with_pool(limit_validation)
            result = validation_result[data['dashboard']].max().max()
            if result > 0:
                for i in data['dashboard']:
                    data[i]= {
                        "outlier": validation_result[i][0],
                        "value": validation_result[f'{i}_value'][0],
                        "lcl": validation_result[f'{i}_lcl'][0],
                        "ucl":  validation_result[f'{i}_ucl'][0]
                    }

                data['link'] = f'http://{os.environ["APP_SERVER"]}/enlight/#/qc?product={data["product"]}&layer={data["layer"]}&recipeid={data["recipeid"]}'
                await trigger_email(data)
                execution_time = time.time() - start_time

                data['status'] = 'success'
                data['timetaken'] = f'{execution_time:.0f} sec'
                data['email'] = 'success'
                data['files'] = 1
                payload = {
                    "autoreportid": data.get("id"),
                    "reportname": data.get("reportname"),
                    "filename": data.get("filename"),
                    "username": data.get("username"),
                    "product" : data.get("product"),
                    "layer" :data.get("layer"),
                    "recipeid": data.get("recipeid"),
                    "tool": data.get("tool"),
                    "status": data['status'],
                    "timetaken": data['timetaken'],
                    "email": data['reportinvitees'],
                    "url": f'http://{os.environ["APP_SERVER"]}/enlight/#/qc?product={data["product"]}&layer={data["layer"]}&recipeid={data["recipeid"]}',
                    "numberoffiles": 1
                }
                history = queries['create_alert_hist'].format(**payload)
                await get_query_with_pool(history)
        except Exception as e:
            execution_time = time.time() - start_time
            data['status'] = 'failure'
            data['timetaken'] = f'{execution_time:.0f} sec'
            data['email'] = 'failure'
            data['files'] = 1
            # history = queries['add_history'].format(**data)
            # await get_query_with_pool(history)
            app_log.exception(e)

    async def extract_tif_file(self):
        start_time = datetime.now()
        n_frame = 0
        dest_path = await self.get_image_folder()
        file_title_name = str(self.filename.split('.')[0])
        im = Image.open(self.file)
        n_frame = im.n_frames
        index = 0
        for i in range(im.n_frames):
            index = i+1
            im.seek(i)
            if im.mode != 'L':
                im.mode = 'I'
                im.point(lambda i:i*(1./256)).convert('L').save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
            else:
                im.save(str(dest_path)+'/'+str(file_title_name)+'_%d.jpg' %index, 'JPEG', subsampling=0 , quality = 95)
        app_log.info(f'Extracted {index} JPEGs')
        app_log.info(f"Tiff file processing time: {datetime.now() - start_time}")
        return n_frame

    async def get_image_folder(self):
        tiff_file_name_split, ext = os.path.splitext(self.filename)
        app_log.info(f"image_folder_creation_unix: process start")
        base_path = env_config['watchdog_pick_location']['src']

        forward_path = os.path.join('images', tiff_file_name_split)
        complete_report_path = os.path.join(base_path, forward_path)
        try:
            if os.path.exists(complete_report_path):
                app_log.info('Deleting previously added folder : {0}'.format(
                    complete_report_path))
                os.popen(f' rm -rf {complete_report_path}').read()
                # shutil.rmtree(complete_report_path)

            os.makedirs(complete_report_path, mode=0o777)
            app_log.info('Image Path is created in the this location')
            return complete_report_path
        except Exception as e:
                app_log.exception(
                    "Command to create the tiff image folder Failed : {0}".format(repr(e)))

    async def process_tiff(self):
        """
        validate tiff file
        """
        try:
            app_log.info("Checking if Klarf exist for tiff")
            queries = common_queries["upload"]
            tiff_check = queries['check_tiff'].format(**{"filename": self.filename})
            app_log.info(f"Query: {tiff_check}")
            tiff_check = await get_query_with_pool(tiff_check, "")
            if len(tiff_check):
                n_frame = await self.extract_tif_file()
                if n_frame:
                    # Populate has_tif column
                    has_tiff = queries['update_has_tiff'].format(**{"filename": self.filename})
                    app_log.info(f"Update has_tif query: {has_tiff}")
                    await get_query_with_pool(has_tiff,"")
                    await self.update_job_status({"job_id": self.job_id, "job_status": "success", "file_path": self.file_path})
            else:
                raise Exception("Please upload Klarf First")
        except Exception as excep:
            await self.update_job_status(
                {
                    "job_id": self.job_id,
                    "job_status": "failed",
                    "file_path": self.file_path,
                    "err_message": str(excep),
                }
            )
            app_log.exception(excep)
            raise Exception(excep)

    async def calculate_limit(self):
        try:
            app_log.info("Finding limit config for the PLR")
            queries = common_queries["limit"]
            limit_config_data = {}
            limit_config_data['product_list'] = tuple(self.header_df['product'].tolist() + [''])
            limit_config_data['layer_list'] = tuple(self.header_df['layer'].tolist() + [''])
            limit_config_data['recipe_list'] = tuple(self.header_df['recipeid'].tolist() + [''])
            limit_config_query = queries["save_limit"]['limit_config'].format(**limit_config_data)
            limit_data = await get_query_with_pool(limit_config_query)
            limit_data = limit_data[limit_data['product'] != ''].to_dict(orient='records') if len(limit_data) >= 2 else limit_data.to_dict(orient='records')
            limit_dict = limit_data[0] if len(limit_data) else {}
            query_data = {}
            query_data["product"] = self.header_df["product"].iloc[0]
            query_data["layer"] = self.header_df["layer"].iloc[0]
            query_data["recipeid"] = self.header_df["recipeid"].iloc[0]
            query_data['tool'] = self.header_df["tool"].iloc[0]
            query_data['std'] = limit_dict.get('std', 3)
            if limit_dict.get('min_date', None) and limit_dict.get('max_date', None):
                query_data['date_cdtn'] = f"and resulttimestamp between '{limit_dict['min_date']}' and '{limit_dict['max_date']}' "
            else:
                query_data['date_cdtn'] = ''
            toolid = ["NA"]
            dashboard_list = ['dc', 'cr','vl', 'gr', 'sf', 'tf']

            if query_data['tool'] != "NA":
                toolid.append(query_data['tool'])
            query_data['toolid'] = tuple(toolid)
            overwrite = queries["save_limit"]["overwrite_limit"].format(**query_data)
            await get_query_with_pool(overwrite)
            auto_limit = queries["save_limit"]['auto_limits'].format(**query_data)
            auto_limit_df = (await get_query_with_pool(auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

            tool_auto_limit = queries["save_limit"]["tool_auto_limit"].format(**query_data)
            tool_auto_limit_df = (await get_query_with_pool(tool_auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

            auto_limit_df = auto_limit_df.fillna("NULL")
            tool_auto_limit_df = tool_auto_limit_df.fillna("NULL")
            auto_limit_list = [tuple(row) for row in auto_limit_df.values]
            tool_auto_limit_list = [tuple(row) for row in tool_auto_limit_df.values]
            auto_limit_list.extend(tool_auto_limit_list)

            if len(auto_limit_list):
                query_data['values'] = ','.join([str(item) for item in auto_limit_list])
                query_data['values'].replace("'NULL'", 'NULL')

                save_limit = queries["save_limit"]['insert_limit'].format(**query_data)
                await get_query_with_pool(save_limit)

                auto_limit_ss = queries["save_limit"]["auto_limit_ss"].format(**query_data)
                auto_limit_ss_df = (await get_query_with_pool(auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

                tool_auto_limit_ss = queries["save_limit"]["tool_auto_limit_ss"].format(**query_data)
                tool_auto_limit_ss_df = (await get_query_with_pool(tool_auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

                auto_limit_ss_df = auto_limit_ss_df.fillna("NULL")
                tool_auto_limit_ss_df = tool_auto_limit_ss_df.fillna("NULL")

                auto_limit_list_ss = [tuple(row) for row in auto_limit_ss_df.values]
                tool_auto_limit_ss = [tuple(row) for row in tool_auto_limit_ss_df.values]

                auto_limit_list_ss.extend(tool_auto_limit_ss)
                query_data['values'] = ','.join([str(item) for item in auto_limit_list_ss])
                query_data['values'].replace("'NULL'", 'NULL')
                save_limit_ss = queries["save_limit"]['insert_limit_ss'].format(**query_data)
                await get_query_with_pool(save_limit_ss)

            for test_cdtn in ['and test != -1', 'and test = -1']:
                query_data['tool_cdtn'] = f"and tool != 'NA'"
                query_data['test_cdtn'] = test_cdtn
                kpi_info = queries["save_limit"]['kpi_limit'].format(**query_data)
                kpi_list = await get_query_with_pool(kpi_info, "tuple")

                if len(kpi_list) and query_data['tool'] != 'NA':
                    query_data['tool_cdtn'] = f"and tool = '{query_data['tool']}'"
                    manual_info = queries["save_limit"]['kpi_limit'].format(**query_data)
                    manual_check =  await get_query_with_pool(manual_info, "tuple")
                    manual_check =  [t[0] for t in manual_check]
                    kpi_check = [t[0] for t in kpi_list]
                    limit_updation = [t for t in kpi_check if t not in manual_check]
                    temp_data = copy.deepcopy(query_data)
                    for limit in limit_updation:
                        temp_data['timetrend'] = limit
                        manual_insert = queries["save_limit"]['insert_defualt_manual'].format(**temp_data)
                        await get_query_with_pool(manual_insert)

                toolid  = []
                toolid.append(query_data['tool'])
                query_data['toolid'] = tuple(toolid)
                if not len(kpi_list):
                    query_data['tool_cdtn'] = "and tool = 'NA'"
                    kpi_info = queries["save_limit"]['kpi_limit'].format(**query_data)
                    kpi_list = await get_query_with_pool(kpi_info, "list")
                    query_data['toolid'] = ["NA"]

                kpi_list = [t[0] for t in kpi_list]
                kpi_list = kpi_list if len(kpi_list) else []
                kpi_list = [item for item in dashboard_list if item not in kpi_list]
                query_data['timetrend'] = tuple(kpi_list)
                if len(kpi_list):
                    limit_tool_info = queries['save_limit']['limit_tool_info'].format(**query_data)
                    limit_tool_result = await get_query_with_pool(limit_tool_info, "list")
                    app_log.info(limit_tool_result)
                    limit_tool_result = [t[0] for t in limit_tool_result]
                    limit_tool_result = limit_tool_result if len(limit_tool_result) else []
                    if query_data['tool'] == 'NA':
                        kpi_list = [item for item in kpi_list if item not in limit_tool_result]
                if len(kpi_list):
                    limit_list = ['slf' if item == 'sf' else 'tlf' if item == 'tf' else item for item in kpi_list]
                    overwrite_control_limit = queries["save_limit"]['overwrite_control_limit'].format(**query_data)
                    await get_query_with_pool(overwrite_control_limit)
                    limits = []
                    for timetrend, kpi in zip(kpi_list, limit_list):
                        query_data['toolid'] =  tuple(toolid) if timetrend in limit_tool_result else tuple(["NA"])
                        query_data['timetrend'] = timetrend
                        query_data['kpi'] = kpi
                        limits.append(queries["save_limit"]['insert_control_limit'].format(**query_data))
                    task = [get_query_with_pool(limit, "list") for limit in limits]
                    asyncio.gather(*task)

        except Exception as e:
            app_log.exception(e)
            raise Exception(e)

    async def process_file(self):
        try:
            if self.job_id is None:
                    job_log = {
                    "job_type": self.job_type,
                    "job_status": 'created',
                    "tool_name": self.tool,
                    "file_path": self.file_path
                    }
                    await self.update_job_status(job_log)

            if self.file_type == 'klarf' or self.file_type == '001':
                await self.dataload()
            else:
                await self.process_tiff()
        except Exception as excep:
            app_log.exception(excep)
            raise Exception(excep)
