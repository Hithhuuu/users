from api.utils.fastapi_app import app
from api.limit.limit_api import limit_handler

app.include_router(limit_handler.router)


