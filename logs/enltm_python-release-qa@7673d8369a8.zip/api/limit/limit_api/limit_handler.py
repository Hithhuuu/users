"""Global Limit API Handler"""
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends
from typing import Optional

from api.limit.limit_api.limit_model import Limit
from api.utils.fastapi_app import verify_jwt

router = APIRouter(tags=['Limit'], prefix='/limit', dependencies=[Depends(verify_jwt)])


@router.post('')
async def save_limit(body: dict):
    """POST Method for limit """
    limit_data = Limit()
    response = await limit_data.save(body)
    if 'error' in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)

@router.get('')
async def get_limit(product: Optional[str] = '', layer: Optional[str] = '', recipeid: Optional[str] = ''):
    """GET Method for limit """
    body = {
        "product": product,
        "layer": layer,
        "recipeid": recipeid
    }
    limit_data = Limit()
    response = await limit_data.get_limit(body)
    if 'error' in response:
        return JSONResponse(status_code=400, content=response)
    return response

@router.post('/calculate')
async def limit_calcuation(body: dict):
    """GET Method for limit """
    limit_data = Limit()
    response = await limit_data.limit_calculate(body)
    if 'error' in response:
        return JSONResponse(status_code=400, content=response)
    return response