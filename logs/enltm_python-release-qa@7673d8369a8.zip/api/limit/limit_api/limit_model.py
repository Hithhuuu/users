"""Gloabal Limit API Model File"""
import asyncio
import numpy as np
from api.utils.utils import queries, get_logger
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger('limit')

class Limit:
    """This class provides method to save or get Gloabl Control Limit Config"""

    def __init__(self):
        """Initializing Limit instance"""
        self.queries = queries['limit']

    async def save(self, data):
        """Save Global Control Limit Config"""
        try:
            app_log.info('Preparing to save global control limit config')
            data['min_date'] = data['date'].get('min_date', '')
            data['max_date'] = data['date'].get('max_date', '')
            data.pop('date')
            overwrite_query = self.queries['overwrite_limit_config'].format(**data)
            await get_query_with_pool(overwrite_query)

            #Saving Limit Config
            insert_query = self.queries['save_limit_config'].format(**data)
            await get_query_with_pool(insert_query)

            #Calculating Limit based on new config
            await self.save_calculated_limit(data) if data['product'] == '' else await self.save_plr_limit(data)

            return {'msg': 'Control Limit Config Saved Successfully'}
        except Exception as e:
            app_log.error(e)
            return {'error': 'Failed to save control limit config'}

    async def save_calculated_limit(self, data):
        try:
            app_log.info('Calcualte limit based on the given setting')
            query_data = {}
            if data.get('product') == '':
                limit_config = await get_query_with_pool(self.queries['limit_config'])
            for cdtn in ['product', 'layer', 'recipeid']:
                query_data[cdtn] = f"and {cdtn} not in {tuple(limit_config[cdtn].to_list())}" if len(limit_config) else ''

            query_data['std'] = data.get('std', 3)
            if data.get('min_date', None) and data.get('max_date', None):
                query_data['date_cdtn'] = f"and resulttimestamp between '{data['min_date']}' and '{data['max_date']}' "
            else:
                query_data['date_cdtn'] = ''

            auto_limit = self.queries['general_limit'].format(**query_data)
            auto_limit_df = (await get_query_with_pool(auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sf_lcl", "sf_ucl", "sf_base", "tf_lcl", "tf_ucl", "tf_base"]]

            tool_auto_limit = self.queries["general_tool_limit"].format(**query_data)
            tool_auto_limit_df = (await get_query_with_pool(tool_auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sf_lcl", "sf_ucl", "sf_base", "tf_lcl", "tf_ucl", "tf_base"]]
            auto_limit_df = auto_limit_df.fillna("NULL")
            tool_auto_limit_df = tool_auto_limit_df.fillna("NULL")

            if len(auto_limit_df):
                auto_limit_ss = self.queries["general_limit_ss"].format(**query_data)
                auto_limit_ss_df = (await get_query_with_pool(auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]
                tool_auto_limit_ss = self.queries["general_tool_limit_ss"].format(**query_data)
                tool_auto_limit_ss_df = (await get_query_with_pool(tool_auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

                auto_limit_ss_df = auto_limit_ss_df.fillna("NULL")
                tool_auto_limit_ss_df = tool_auto_limit_ss_df.fillna("NULL")

                unique_combinations = auto_limit_df[['product', 'layer', 'recipeid']].drop_duplicates()
                query_data = {}
                for index, row in unique_combinations.iterrows():

                    product = row['product']
                    layer = row['layer']
                    recipeid = row['recipeid']

                    query_data = {}
                    query_data['product_val'] = product
                    query_data['recipeid_val'] = recipeid
                    query_data['layer_val'] = layer

                    query_data['product'] = product
                    query_data['recipeid'] = recipeid
                    query_data['layer'] = layer


                    auto_limit_data = auto_limit_df[(auto_limit_df['product'] == product) & (auto_limit_df['layer'] == layer) & (auto_limit_df['recipeid'] == recipeid)]
                    tool_auto_limit_data = tool_auto_limit_df[(tool_auto_limit_df['product'] == product) & (tool_auto_limit_df['layer'] == layer) & (tool_auto_limit_df['recipeid'] == recipeid)]

                    auto_limit_data_ss = auto_limit_ss_df[(auto_limit_ss_df['product'] == product) & (auto_limit_ss_df['layer'] == layer) & (auto_limit_ss_df['recipeid'] == recipeid)]
                    tool_auto_limit_data_ss = tool_auto_limit_ss_df[(tool_auto_limit_ss_df['product'] == product) & (tool_auto_limit_ss_df['layer'] == layer) & (tool_auto_limit_ss_df['recipeid'] == recipeid)]

                    auto_limit_list = [tuple(row) for row in auto_limit_data.values]
                    tool_auto_limit_list = [tuple(row) for row in tool_auto_limit_data.values]
                    auto_limit_list.extend(tool_auto_limit_list)

                    auto_limit_list_ss = [tuple(row) for row in auto_limit_data_ss.values]
                    tool_auto_limit_list_ss = [tuple(row) for row in tool_auto_limit_data_ss.values]
                    auto_limit_list_ss.extend(tool_auto_limit_list_ss)
                    query_data['values'] = ','.join([str(item) for item in auto_limit_list])
                    query_data['values'].replace("'NULL'", 'NULL')

                    overwrite = self.queries["overwrite_limit"].format(**query_data)
                    await get_query_with_pool(overwrite)

                    save_limit = self.queries['insert_limit'].format(**query_data)
                    await get_query_with_pool(save_limit)

                    query_data['values'] = ','.join([str(item) for item in auto_limit_list_ss])
                    query_data['values'].replace("'NULL'", 'NULL')
                    save_limit_ss = self.queries['insert_limit_ss'].format(**query_data)
                    await get_query_with_pool(save_limit_ss)
                    #Calculation done

                    #Check tool wise limit:
                    dashboard_list = ['dc', 'cr','vl', 'gr', 'sf', 'tf']
                    for test_cdtn in ['and test = -1 ', 'and test != -1']:
                        query_data['test_cdtn'] = test_cdtn
                        tool_list_query = self.queries['tool_kpi_list'].format(**query_data)
                        tool_kpi_list = await get_query_with_pool(tool_list_query, "list")

                        tool_kpi_list = [t[0] for t in tool_kpi_list]
                        tool_kpi_list = tool_kpi_list if len(tool_kpi_list) else []

                        general_kpi_list = [item for item in dashboard_list if item not in tool_kpi_list]


                        if len(general_kpi_list):
                            query_data['tool_cdtn'] = "and tool = 'NA' "
                            manual_query = self.queries['dashboard_limit_check'].format(**query_data)
                            manual_list = await get_query_with_pool(manual_query, "list")
                            manual_list = [t[0] for t in tool_kpi_list]
                            manual_list = manual_list if len(manual_list) else []

                            general_kpi_list = [item for item in general_kpi_list if item not in manual_list]

                            if len(general_kpi_list):
                                limit_list = ['slf' if item == 'sf' else 'tlf' if item == 'tf' else item for item in general_kpi_list]
                                overwrite_control_limit = self.queries['overwrite_control_limit'].format(**query_data)
                                await get_query_with_pool(overwrite_control_limit)
                                limits = []
                                for timetrend, kpi in zip(general_kpi_list, limit_list):
                                    query_data['timetrend'] = timetrend
                                    query_data['kpi'] = kpi
                                    limits.append(self.queries['insert_control_limit'].format(**query_data))
                                task = [get_query_with_pool(limit, "list") for limit in limits]
                                asyncio.gather(*task)

                        if len(tool_kpi_list):
                            query_data['tool_cdtn'] = "and tool != 'NA' "
                            manual_query = self.queries['dashboard_limit_check'].format(**query_data)
                            manual_list = await get_query_with_pool(manual_query, "list")
                            manual_list = [t[0] for t in tool_kpi_list]
                            manual_list = manual_list if len(manual_list) else []

                            general_kpi_list = [item for item in general_kpi_list if item not in manual_list]

                            if len(general_kpi_list):
                                limit_list = ['slf' if item == 'sf' else 'tlf' if item == 'tf' else item for item in general_kpi_list]
                                overwrite_control_limit = self.queries['overwrite_control_limit'].format(**query_data)
                                await get_query_with_pool(overwrite_control_limit)
                                limits = []
                                for timetrend, kpi in zip(general_kpi_list, limit_list):
                                    query_data['timetrend'] = timetrend
                                    query_data['kpi'] = kpi
                                    limits.append(self.queries['insert_control_limit'].format(**query_data))
                                task = [get_query_with_pool(limit, "list") for limit in limits]
                                asyncio.gather(*task)

        except Exception as err:
            app_log.error(err)
            raise Exception('Failed to save calculated limit')

    async def get_limit(self, data):
        try:
            app_log.info('Getting saved limit config')
            result = await get_query_with_pool(self.queries['get_limit_config'].format(**data), 'df')
            if len(result):
                result = result[result['product'] != ''] if len(result[result['product'] != '']) else result[result['product'] == '']
                result_dict = result[['product', 'layer', 'recipeid', 'std']].to_dict(orient='records')
                result_dict[0]['date'] = result[['min_date', 'max_date']].to_dict(orient='records')[0]
                return result_dict[0]
            else:
                return {}
        except Exception as err:
            app_log.error(err)
            return {'error': 'Failed to get global control limit config'}

    async def limit_calculate(self, data):
        try:
            app_log.info('Calculate the limits')
            data['charttype'] = 'gr' if data.get("charttype") == 'mgt' else data.get("charttype")
            if data.get('date').get('min_date', None) and data.get('date').get('max_date', None):
                data['date_cdtn'] = f"and resulttimestamp between '{data.get('date')['min_date']}' and '{data.get('date')['max_date']}' "
            else:
                data['date_cdtn'] = ''

            if data.get('tool', '') != '':
                data['tool_cdtn'] = f"and tool in {tuple(data.get('tool'))}"
                queries = self.queries['tool_auto_limit'].format(**data)
                result = await get_query_with_pool(queries, 'df')
                if len(result):
                    result = result[['tool', f"{data.get('charttype')}_lcl",f"{data.get('charttype')}_ucl", f"{data.get('charttype')}_base"]]
                    result.columns = ['tool', 'lcl', 'ucl', 'base']
                    result = result.replace({np.NaN : None})
                    result = result.to_dict(orient='records')
                else:
                    return []
            else:
                queries = self.queries['auto_limits'].format(**data)
                result = await get_query_with_pool(queries, 'df')
                if len(result):
                    result = result[['tool', f"{data.get('charttype')}_lcl",f"{data.get('charttype')}_ucl", f"{data.get('charttype')}_base"]]
                    result.columns = ['tool', 'lcl', 'ucl', 'base']
                    result = result.replace({np.NaN : None})
                    result = result.to_dict(orient='records')
                else:
                    return []
            return result

        except Exception as err:
            app_log.exception(err)
            return {'error': 'Something went wrong'}

    async def save_plr_limit(self, data):
        try:
            app_log.info('Calcualte limit based on the given setting')
            query_data = {}
            for cdtn in ['product', 'layer', 'recipeid']:
                query_data[cdtn] = f"and {cdtn} = '{data.get(cdtn)}'"

            query_data['std'] = data.get('std', 3)
            if data.get('min_date', None) and data.get('max_date', None):
                query_data['date_cdtn'] = f"and resulttimestamp between '{data['min_date']}' and '{data['max_date']}' "
            else:
                query_data['date_cdtn'] = ''

            auto_limit = self.queries['general_limit'].format(**query_data)
            auto_limit_df = (await get_query_with_pool(auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sf_lcl", "sf_ucl", "sf_base", "tf_lcl", "tf_ucl", "tf_base"]]

            tool_auto_limit = self.queries["general_tool_limit"].format(**query_data)
            tool_auto_limit_df = (await get_query_with_pool(tool_auto_limit,"df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sf_lcl", "sf_ucl", "sf_base", "tf_lcl", "tf_ucl", "tf_base"]]

            auto_limit_df = auto_limit_df.fillna("NULL")
            tool_auto_limit_df = tool_auto_limit_df.fillna("NULL")
            auto_limit_list = [tuple(row) for row in auto_limit_df.values]
            tool_auto_limit_list = [tuple(row) for row in tool_auto_limit_df.values]
            auto_limit_list.extend(tool_auto_limit_list)

            if len(auto_limit_list):
                query_data['product_val'] = data.get('product')
                query_data['layer_val'] = data.get('layer')
                query_data['recipeid_val'] = data.get('recipeid')


                auto_limit_ss = self.queries["general_limit_ss"].format(**query_data)
                auto_limit_ss_df = (await get_query_with_pool(auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

                tool_auto_limit_ss = self.queries["general_tool_limit_ss"].format(**query_data)
                tool_auto_limit_ss_df = (await get_query_with_pool(tool_auto_limit_ss,"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]

                auto_limit_ss_df = auto_limit_ss_df.fillna("NULL")
                tool_auto_limit_ss_df = tool_auto_limit_ss_df.fillna("NULL")

                auto_limit_list_ss = [tuple(row) for row in auto_limit_ss_df.values]
                tool_auto_limit_ss = [tuple(row) for row in tool_auto_limit_ss_df.values]
                auto_limit_list_ss.extend(tool_auto_limit_ss)

                overwrite = self.queries["overwrite_limit"].format(**query_data)
                await get_query_with_pool(overwrite)


                query_data['values'] = ','.join([str(item) for item in auto_limit_list])
                query_data['values'].replace("'NULL'", 'NULL')
                save_limit = self.queries['insert_limit'].format(**query_data)
                await get_query_with_pool(save_limit)

                query_data['values'] = ','.join([str(item) for item in auto_limit_list_ss])
                query_data['values'].replace("'NULL'", 'NULL')
                save_limit_ss = self.queries['insert_limit_ss'].format(**query_data)
                await get_query_with_pool(save_limit_ss)

                dashboard_list = ['dc', 'cr','vl', 'gr', 'sf', 'tf']
                dashboard_list = [item  for item in dashboard_list if data.get('charttype') != item]
                query_data['product'] = query_data['product_val']
                query_data['recipeid'] = query_data['recipeid_val']
                query_data['layer'] = query_data['layer_val']
                for test_cdtn in ['and test = -1 ', 'and test != -1']:
                    query_data['test_cdtn'] = test_cdtn
                    tool_list_query = self.queries['tool_kpi_list'].format(**query_data)
                    tool_kpi_list = await get_query_with_pool(tool_list_query, "list")

                    tool_kpi_list = [t[0] for t in tool_kpi_list]
                    tool_kpi_list = tool_kpi_list if len(tool_kpi_list) else []

                    general_kpi_list = [item for item in dashboard_list if item not in tool_kpi_list]


                    if len(general_kpi_list):
                        query_data['tool_cdtn'] = "and tool = 'NA' "
                        manual_query = self.queries['dashboard_limit_check'].format(**query_data)
                        manual_list = await get_query_with_pool(manual_query, "list")
                        manual_list = [t[0] for t in tool_kpi_list]
                        manual_list = manual_list if len(manual_list) else []

                        general_kpi_list = [item for item in general_kpi_list if item not in manual_list]

                        if len(general_kpi_list):
                            limit_list = ['slf' if item == 'sf' else 'tlf' if item == 'tf' else item for item in general_kpi_list]
                            overwrite_control_limit = self.queries['overwrite_control_limit'].format(**query_data)
                            await get_query_with_pool(overwrite_control_limit)
                            limits = []
                            for timetrend, kpi in zip(general_kpi_list, limit_list):
                                query_data['timetrend'] = timetrend
                                query_data['kpi'] = kpi
                                limits.append(self.queries['insert_control_limit'].format(**query_data))
                            task = [get_query_with_pool(limit, "list") for limit in limits]
                            asyncio.gather(*task)

                    if len(tool_kpi_list):
                        query_data['tool_cdtn'] = "and tool != 'NA' "
                        manual_query = self.queries['dashboard_limit_check'].format(**query_data)
                        manual_list = await get_query_with_pool(manual_query, "list")
                        manual_list = [t[0] for t in tool_kpi_list]
                        manual_list = manual_list if len(manual_list) else []

                        general_kpi_list = [item for item in general_kpi_list if item not in manual_list]

                        if len(general_kpi_list):
                            limit_list = ['slf' if item == 'sf' else 'tlf' if item == 'tf' else item for item in general_kpi_list]
                            overwrite_control_limit = self.queries['overwrite_control_limit'].format(**query_data)
                            await get_query_with_pool(overwrite_control_limit)
                            limits = []
                            for timetrend, kpi in zip(general_kpi_list, limit_list):
                                query_data['timetrend'] = timetrend
                                query_data['kpi'] = kpi
                                limits.append(self.queries['insert_control_limit'].format(**query_data))
                            task = [get_query_with_pool(limit, "list") for limit in limits]
                            asyncio.gather(*task)


        except Exception as err:
            app_log.exception(err)
            raise err
