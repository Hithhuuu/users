"""Model to fetch fleet status for Last Run and For Extended period"""
import itertools
from datetime import datetime
import asyncio
import calendar
import numpy as np
import pandas as pd

from api.utils.utils import queries, get_logger
from api.utils.common import make_query
from api.utils.fastapi_app import get_query_with_pool


app_log = get_logger("fleetstatus")


class FleetStatus:
    """This class provides methods to fetch data for Fleet Status"""

    def __init__(self):
        """Initializing timetrend instance"""
        self.queries = queries["fleetstatus"]

    async def lastrun(self, data):
        """Function to fetch fleet status for last run."""
        try:
            app_log.info("Fetching Fleet Status data for last run")
            resp = {}
            query_data = make_query(data)
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)
            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]

            lastruntable = data["inputs"].get("lastruntable", {})

            columns_sort_query = []
            if lastruntable.get("sort", {}):
                sort = ["toolid", "layername", "recipename", "productname"]
                for sort_data in lastruntable.get("sort"):
                    columns_sort_query.append(
                        f"{sort_data['id']} {sort_data['order']}"
                        if sort_data["id"] not in sort
                        else f"lower({sort_data['id']}) {sort_data['order']}"
                    )

                columns_sort_query = ", ".join(columns_sort_query)
            query_data["sort_order"] = (
                f"ORDER BY {columns_sort_query}"
                if columns_sort_query
                else "ORDER BY lower(toolid), lower(layername), lower(recipename)"
            )
            query_data[
                "limit"
            ] = f'LIMIT {lastruntable.get("offset", 0)}, {lastruntable.get("limit", 10)}'

            query_data["offset"] = lastruntable.get("offset", 0)

            fleet_status_total = self.queries["fs_last_run"].format(**query_data)
            app_log.info(f"Fleet Status Last Run Query: {fleet_status_total}")
            fleet_status_total = await get_query_with_pool(fleet_status_total)
            fleet_status_total = fleet_status_total.replace({np.nan: "NA"})
            order = fleet_status_total['id'].to_list()
            query_data["product"] = tuple(fleet_status_total['productname'].unique().tolist()) if len(fleet_status_total) else "(null)"
            query_data["layer"]= tuple(fleet_status_total['layername'].unique().tolist()) if len(fleet_status_total) else "(null)"
            query_data["recipeid"] = tuple(fleet_status_total['recipename'].unique().tolist()) if len(fleet_status_total) else "(null)"
            limit_query = self.queries["limit_change"].format(**query_data)
            # limit_df = (await get_query_with_pool(limit_query, "df"))[
            #     ["productname", "layername", "recipename","dc_base","dc_lcl","dc_ucl","cr_base","cr_lcl","cr_ucl","vl_base","vl_lcl", "vl_ucl", "gr_base","gr_lcl", "gr_ucl", "sl_base","sl_lcl", "sl_ucl"]]
            query_data["dmaps"] = tuple(fleet_status_total["dmaps"].tolist())
            query_data["dmaps"] = (query_data["dmaps"] if len(query_data["dmaps"]) else "(null)")

            query_data["rmaps"] = tuple(
                set(itertools.chain.from_iterable(fleet_status_total["rmaps"].tolist()))
            )
            query_data["rmaps"] = (
                query_data["rmaps"] if len(query_data["rmaps"]) else "(null)"
            )
            query_data["smaps"] = tuple(fleet_status_total["smaps"].tolist())
            query_data["smaps"] = (query_data["smaps"] if len(query_data["smaps"]) else "(null)")
            total = fleet_status_total['total'].iloc[0] if len(fleet_status_total) else 0
            if total == 0:
                resp = {
                    "data": [],
                    "limit": 10,
                    "offset": 0,
                    "total": int(total)
                }
                return resp

            control_limit = self.queries["fs_lastrun_ss_limit"].format(**query_data)
            control_limit_df = await get_query_with_pool(control_limit)
            merge_na = control_limit_df[control_limit_df['tool'] == 'NA']
            merge_tool = control_limit_df[control_limit_df['tool']!= 'NA']

            merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
            merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

            control_limit = merge_tool.combine_first(merge_na)
            control_limit.reset_index(inplace=True)

            control_limit= control_limit.replace({np.nan: "null"})

            query_data["control_limit"] = str(
                [
                    tuple(x)
                    for x in control_limit[
                        [
                            "product",
                            "layer",
                            "recipeid",
                            "dc_lcl",
                            "dc_ucl",
                            "gr_lcl",
                            "gr_ucl",
                            "vl_lcl",
                            "vl_ucl",
                            "sl_lcl",
                            "sl_ucl",
                            "tl_lcl",
                            "tl_ucl",
                            "cr_lcl",
                            "cr_ucl",
                            "test",
                            "tool",
                            "dc_base"
                        ]
                    ].to_numpy()
                ]
            ).replace("'null'", "null")

            fleet_status_ss = self.queries["fs_last_run_ss"].format(**query_data)
            app_log.info(f"Fleet Status Last Run Query: {fleet_status_ss}")
            tasks = [get_query_with_pool(limit_query, "df"), get_query_with_pool(fleet_status_ss, "df")]
            limit_df, fleet_status_ss = await asyncio.gather(*tasks)
            limit_df = limit_df[["productname", "layername", "recipename","toolid","dc_base","dc_lcl","dc_ucl","cr_base","cr_lcl","cr_ucl","vl_base","vl_lcl", "vl_ucl", "gr_base","gr_lcl", "gr_ucl", "sl_base","sl_lcl", "sl_ucl"]]
            #fleet_status_ss = await get_query_with_pool(fleet_status_ss)
            fleet_status_ss = fleet_status_ss.replace({np.nan: None})
            last_run_data = []
            temp_dict = {
                    "data": "NA",
                    "lcl": None,
                    "ucl": None,
                    "outlier": False
                }
            # fleet_status_total = fleet_status_total.merge(limit_df, how='left')
            merge_tool = pd.merge(fleet_status_total, limit_df[limit_df['toolid'] != 'NA'], on=['productname', 'layername','recipename', 'toolid'], how='inner')

            # Then, merge rows where tool is 'NA' in dataframe b only on 'name' and 'place'
            merge_na = pd.merge(fleet_status_total, limit_df[limit_df['toolid'] == 'NA'], on=['productname', 'layername', 'recipename'], how='inner')
            merge_na = merge_na.rename(columns={'toolid_x': 'toolid'})

            merge_tool.set_index(['toolid', 'productname', 'layername', 'recipename'], inplace=True)
            merge_na.set_index(['toolid', 'productname', 'layername', 'recipename'], inplace=True)

            fleet_status_total = merge_tool.combine_first(merge_na)
            fleet_status_total.reset_index(inplace=True)

            fleet_status_total = fleet_status_total.drop_duplicates(subset=['toolid', 'productname', 'layername', 'recipename'])
            fleet_status_total = fleet_status_total.replace({np.nan: None})
            # Drop 'toolid' and 'toolid_y' columns
            fleet_status_total = fleet_status_total.drop(['toolid_y'], axis=1)
            order_dict = {value: i for i, value in enumerate(order)}
            fleet_status_total['rank'] = fleet_status_total['id'].map(order_dict)
            # Sort fleet_status_total by the 'rank' column
            fleet_status_total.sort_values(by='rank', inplace=True)
            # Drop the 'rank' column
            fleet_status_total.drop('rank', axis=1, inplace=True)
            # fleet_status_total = fleet_status_total.rename(columns={'toolid_x': 'toolid'})
            for row in fleet_status_total.iterrows():
                last_run_ss_df = fleet_status_ss[
                    (fleet_status_ss["toolid"] == row[1]["toolid"])
                    & (fleet_status_ss["productname"] == row[1]["productname"])
                    & (fleet_status_ss["layer"] == row[1]["layername"])
                    & (fleet_status_ss["recipename"] == row[1]["recipename"])
                ].drop(["layer"], axis=1)
                last_run_ss = []
                last_run_ss_df_req = last_run_ss_df[["toolid","productname","layername","recipename","dctarget","dclastrun","crvsmaster","volumeratio","graderatio","selfiscore"]]
                ss_data = last_run_ss_df.to_dict(orient = 'records')
                i = 0
                for ss_row in last_run_ss_df_req.iterrows():
                    row_dict = ss_row[1].to_dict()

                    if row_dict['dclastrun'] == 'NA':
                        row_dict['dclastrun'] = temp_dict
                    else:
                        if ss_data[i]['dc_lcl'] is not None and ss_data[i]['dc_ucl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] < ss_data[i]["dc_lcl"] or row_dict['dclastrun'] > ss_data[i]["dc_ucl"] else False
                            }
                        elif ss_data[i]['dc_lcl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] < ss_data[i]["dc_lcl"]  else False
                            }
                        elif ss_data[i]['dc_ucl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] > ss_data[i]["dc_ucl"] else False
                            }
                        else:
                            row_dict["dclastrun"] = {
                                "data": row_dict['dclastrun'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['crvsmaster'] is None:
                        row_dict['crvsmaster'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['cr_lcl'] is not None and ss_data[i]['cr_ucl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] < ss_data[i]["cr_lcl"] or row_dict['crvsmaster'] >ss_data[i]["cr_ucl"] else False
                            }
                        elif ss_data[i]['cr_lcl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] < ss_data[i]["cr_lcl"] else False
                            }
                        elif ss_data[i]['cr_ucl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] > ss_data[i]["cr_ucl"] else False
                            }
                        else:
                            row_dict["crvsmaster"] = {
                                "data": row_dict['crvsmaster'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['graderatio'] is None:
                        row_dict['graderatio'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['gr_lcl'] is not None and ss_data[i]['gr_ucl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio']< ss_data[i]["gr_lcl"] or row_dict['graderatio'] > ss_data[i]["gr_ucl"] else False
                            }
                        elif ss_data[i]['gr_lcl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio']< ss_data[i]["gr_lcl"] else False
                            }
                        elif ss_data[i]['gr_ucl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio'] > ss_data[i]["gr_ucl"] else False
                            }
                        else:
                            row_dict["graderatio"] = {
                                "data": row_dict['graderatio'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['volumeratio'] is None:
                        row_dict['volumeratio'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['vl_lcl'] is not None and ss_data[i]['vl_ucl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio']< ss_data[i]["vl_lcl"] or row_dict['volumeratio'] > ss_data[i]["vl_ucl"] else False
                            }
                        elif ss_data[i]['vl_lcl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio']< ss_data[i]["vl_lcl"] else False
                            }
                        elif ss_data[i]['vl_ucl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio'] > ss_data[i]["vl_ucl"] else False
                            }
                        else:
                            row_dict["volumeratio"] = {
                                "data": row_dict['volumeratio'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['selfiscore'] is None:
                        row_dict['selfiscore'] = temp_dict
                    else:
                        if ss_data[i]['sl_lcl'] is not None and ss_data[i]['sl_ucl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore']< ss_data[i]["sl_lcl"] or row_dict['selfiscore'] > ss_data[i]["sl_ucl"] else False
                        }
                        elif ss_data[i]['sl_lcl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore']< ss_data[i]["sl_lcl"] else False
                        }
                        elif ss_data[i]['sl_ucl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore'] > ss_data[i]["sl_ucl"] else False
                        }
                        else:
                            row_dict["selfiscore"] = {
                                "data": row_dict['selfiscore'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    last_run_ss.append(row_dict)
                    i+=1

                if row[1]["crvsmaster"] == 'NA':
                    cr_data = temp_dict
                else:
                    # breakpoint()
                    if row[1]["cr_lcl"] is not None and row[1]["cr_ucl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] < row[1]["cr_lcl"] or row[1]["crvsmaster"] >row[1]["cr_ucl"] else False
                        }
                    elif row[1]["cr_lcl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] < row[1]["cr_lcl"] else False
                        }
                    elif row[1]["cr_ucl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] >row[1]["cr_ucl"] else False
                        }
                    else:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["dclastrun"] == 'NA':
                    dc_data = temp_dict
                else:
                    if row[1]["dc_lcl"] is not None and row[1]["dc_ucl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] <row[1]["dc_lcl"] or row[1]["dclastrun"] >row[1]["dc_ucl"] else False
                        }
                    elif row[1]["dc_lcl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] <row[1]["dc_lcl"] else False
                        }
                    elif row[1]["dc_ucl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] > row[1]["dc_ucl"] else False
                        }
                    else:
                        dc_data = {
                            "data":row[1]["dclastrun"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["volumeratio"] == 'NA':
                    vl_data = temp_dict
                else:
                    # breakpoint()
                    if row[1]["vl_lcl"] is not None and row[1]["vl_ucl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"]< row[1]["vl_lcl"] or row[1]["volumeratio"] > row[1]["vl_ucl"] else False
                        }
                    elif row[1]["vl_lcl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"]< row[1]["vl_lcl"] else False
                        }
                    elif row[1]["vl_ucl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"] > row[1]["vl_ucl"] else False
                        }
                    else:
                        vl_data = {
                            "data": row[1]["volumeratio"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["graderatio"] == 'NA':
                    gr_data = temp_dict
                else:
                    if row[1]["gr_lcl"] is not None and row[1]["gr_ucl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"]< row[1]["gr_lcl"] or row[1]["graderatio"] > row[1]["gr_ucl"] else False
                        }
                    elif row[1]["gr_lcl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"]< row[1]["gr_lcl"] else False
                        }
                    elif row[1]["gr_ucl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"] > row[1]["gr_ucl"] else False
                        }
                    else:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["selfiscore"] == 'NA':
                    sl_data = temp_dict
                else:
                    if row[1]["sl_lcl"] is not None and row[1]["sl_ucl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] < row[1]["sl_lcl"] or row[1]["selfiscore"] > row[1]["sl_ucl"] else False
                        }
                    elif row[1]["sl_lcl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] < row[1]["sl_lcl"] else False
                        }
                    elif row[1]["sl_ucl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] > row[1]["sl_ucl"] else False
                        }
                    else:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                last_run_data.append(
                    {
                        "id": row[1]["id"],
                        "toolid": row[1]["toolid"],
                        "productname": row[1]["productname"],
                        "layername": row[1]["layername"],
                        "recipename": row[1]["recipename"],
                        "dctarget": row[1]["dctarget"],
                        "dclastrun": dc_data,
                        "crvsmaster": cr_data,
                        "graderatio": gr_data,
                        "volumeratio": vl_data,
                        "selfiscore": sl_data,
                        "subRows": last_run_ss,
                    }
                )

            resp = {
                "data": last_run_data,
                "limit": lastruntable.get("limit", 10),
                "offset": lastruntable.get("offset", 0),
                "total": int(total),
            }

        except Exception as err:
            app_log.exception(f"Error while fetching fleet status for last run:{err}")
            return {"error": str(err)}

        return resp

    async def extended_period(self, data, pareto=False):
        """Function to fetch fleet summary for extended period."""
        try:
            app_log.info("Fetching Fleet Summary data for extended period")
            resp = {}
            inputs = data.get("inputs", {})
            gfilter = {"filters": {"gfilter": {}}}
            query_data = make_query(data)

            # Loop to fetch PLR for control limit condition
            for key, val in data["filters"].get("gfilter", {}).items():
                if key in ["product", "layer", "recipeid"]:
                    gfilter["filters"]["gfilter"][key] = val
            query_data["control_limit_cdtn"] = make_query(gfilter)["header_cdtn"]

            # Section to handle runs
            periodfilter = data["filters"].pop("periodfilter", None)
            query_data['upper_run'] = 1
            if periodfilter.get("runs", None):
                query_data["run_limit"] = f'and runid <= {periodfilter.get("runs").get("data")}'
            else:
                query_data['run_limit'] = ''

            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)
            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]

            # Fetching control limits
            control_limit = self.queries["fs_control_limits"].format(**query_data)
            control_limit_df = await get_query_with_pool(control_limit)
            extended_limit = control_limit_df[control_limit_df['test']=='-1']
            merge_na = extended_limit[extended_limit['tool'] == 'NA']
            merge_tool = extended_limit[extended_limit['tool']!= 'NA']

            merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
            merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

            control_limit = merge_tool.combine_first(merge_na)
            control_limit.reset_index(inplace=True)

            control_limit= control_limit.replace({np.nan: "null"})

            query_data["control_limit"] = str(
                [
                    tuple(x)
                    for x in control_limit[
                        [
                            "product",
                            "layer",
                            "recipeid",
                            "dc_lcl",
                            "dc_ucl",
                            "gr_lcl",
                            "gr_ucl",
                            "vl_lcl",
                            "vl_ucl",
                            "sl_lcl",
                            "sl_ucl",
                            "tl_lcl",
                            "tl_ucl",
                            "cr_lcl",
                            "cr_ucl",
                            "test",
                            "tool",
                        ]
                    ].to_numpy()
                ]
            ).replace("'null'", "null")
            fleet_summary = self.queries["fs_extended_table"].format(**query_data)
            app_log.info(f"Fetching outliers for extended period: {fleet_summary}")
            outliers = await get_query_with_pool(fleet_summary)
            outliers = outliers.replace({np.nan: 0})
            outliers = outliers if len(outliers) else []

            if pareto:
                return outliers, query_data, control_limit_df

            extendedperiodtable = inputs.get("extendedperiodtable", {})
            total = len(outliers)
            limit = extendedperiodtable.get("limit", 10)
            offset = extendedperiodtable.get("offset", 0)

            if len(outliers):
                columns_sort = extendedperiodtable.get(
                    "sort", [{"id": "tool", "order": "desc"}]
                )
                sort_by = []
                sort_asc = []
                for sort_data in columns_sort:
                    sort_by.append(sort_data["id"])
                    sort_asc.append(False if sort_data["order"] == "desc" else True)

                outliers = outliers.sort_values(by=sort_by, ascending=sort_asc)
                outliers["outliers"] = outliers[["outliers", "percentage"]].apply(lambda x: f"{x['outliers']} ({x['percentage']}%)", axis=1)

                outliers = outliers.iloc[offset:].head(limit)
                outliers = outliers.drop("percentage", axis=1).to_dict("records")

            resp = {
                "data": outliers,
                "limit": limit,
                "offset": offset,
                "total": total,
            }
        except Exception as err:
            app_log.exception(
                f"Error while fetching fleet status for extended period:{err}"
            )
            return {"error": str(err)}

        return resp

    async def get_pareto(self, data):
        """Function to fetch pareto data for extended period."""
        try:
            app_log.info("Fetching Fleet Summary data for extended period")
            outliers, query_data, control_limit_df = await self.extended_period(data, pareto=True)

            if len(outliers) == 0:
                return []

            extended_ss_limit = control_limit_df[control_limit_df['test']!='-1']
            merge_na = extended_ss_limit[extended_ss_limit['tool'] == 'NA']
            merge_tool = extended_ss_limit[extended_ss_limit['tool']!= 'NA']

            merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
            merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

            control_limit = merge_tool.combine_first(merge_na)
            control_limit.reset_index(inplace=True)

            control_limit= control_limit.replace({np.nan: "null"})

            query_data["control_limit"] = str(
                [
                    tuple(x)
                    for x in control_limit[
                        [
                            "product",
                            "layer",
                            "recipeid",
                            "dc_lcl",
                            "dc_ucl",
                            "gr_lcl",
                            "gr_ucl",
                            "vl_lcl",
                            "vl_ucl",
                            "sl_lcl",
                            "sl_ucl",
                            "tl_lcl",
                            "tl_ucl",
                            "cr_lcl",
                            "cr_ucl",
                            "test",
                            "tool",
                        ]
                    ].to_numpy()
                ]
            ).replace("'null'", "null")

            outliers["pass"] = outliers.apply(
                lambda x: x["runs"] - x["outliers"], axis=1
            )
            outliers = outliers.rename({"outliers": "fail"}, axis=1).drop(
                ["runs", "percentage"], axis=1
            )
            fleet_summary_ss = self.queries["fs_extended_ss"].format(**query_data)
            app_log.info(
                f"Fleet Summary Extended period scanset Query: {fleet_summary_ss}"
            )
            fleet_summary_ss = await get_query_with_pool(fleet_summary_ss)
            fleet_summary_ss["details"] = fleet_summary_ss[
                [
                    "dc_outliers",
                    "cr_outliers",
                    "vl_outliers",
                    "gr_outliers",
                    "sl_outliers",
                    "tl_outliers",
                ]
            ].apply(self.get_outlier_details, axis=1)

            fleet_summary_ss = fleet_summary_ss.drop(
                [
                    "dc_outliers",
                    "cr_outliers",
                    "vl_outliers",
                    "gr_outliers",
                    "sl_outliers",
                    "tl_outliers",
                ],
                axis=1,
            )

            fleet_summary_ss = fleet_summary_ss.rename({"outliers": "fail"}, axis=1)

            ss_outliers = {
                tool: group.to_dict(orient="records")
                for tool, group in fleet_summary_ss.groupby("tool")
            }

            outliers = outliers.to_dict(orient="records")
            for outlier in outliers:
                tool = outlier["tool"]
                if tool in ss_outliers:
                    outlier["recipeWise"] = ss_outliers[tool]

        except Exception as err:
            app_log.exception(
                f"Error while fetching fleet status for extended period:{err}"
            )
            return {"error": str(err)}

        return outliers

    def get_outlier_details(self, row):
        """ Function to get outlier details for pareto data."""
        details = []

        if row["dc_outliers"] > 0:
            details.append(f"{row['dc_outliers']} DC")

        if row["cr_outliers"] > 0:
            details.append(f"{row['cr_outliers']} CR")

        if row["vl_outliers"] > 0:
            details.append(f"{row['vl_outliers']} VR")

        if row["gr_outliers"] > 0:
            details.append(f"{row['gr_outliers']} GR")

        if row["sl_outliers"] > 0:
            details.append(f"{row['sl_outliers']} SF")

        if row["tl_outliers"] > 0:
            details.append(f"{row['tl_outliers']} TF")

        return ", ".join(details)

    async def run_data(self, data):
        """
            Runs the data for fleet status.

            Args:
                data (dict): The input data for fleet status.

            Returns:
                resp (dict): The response data
        """
        try:
            query_data = make_query(data)
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)

            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]
            lastruntable = data["inputs"].get("runtable", {})

            columns_sort_query = []
            if lastruntable.get("sort", {}):
                sort = ["toolid", "layername", "recipename", "productname"]
                for sort_data in lastruntable.get("sort"):
                    columns_sort_query.append(
                        f"{sort_data['id']} {sort_data['order']}"
                        if sort_data["id"] not in sort
                        else f"lower({sort_data['id']}) {sort_data['order']}"
                    )

                columns_sort_query = ", ".join(columns_sort_query)

            query_data["sort_order"] = (
                f"ORDER BY {columns_sort_query}"
                if columns_sort_query
                else "ORDER BY lower(toolid), lower(layername), lower(recipename)"
            )
            query_data[
                "limit"
            ] = f'LIMIT {lastruntable.get("offset", 0)}, {lastruntable.get("limit", 10)}'
            query_data["offset"] = lastruntable.get("offset", 0)
            fleet_status_total = self.queries["run_data"].format(**query_data)
            app_log.info(f"Fleet Status Last Run Query: {fleet_status_total}")
            fleet_status_total = await get_query_with_pool(fleet_status_total)
            fleet_status_total = fleet_status_total.replace({np.nan: "NA"})
            order = fleet_status_total['id'].to_list()
            query_data["product"] = tuple(fleet_status_total['productname'].unique().tolist()) if len(fleet_status_total) else "(null)"
            query_data["layer"]= tuple(fleet_status_total['layername'].unique().tolist()) if len(fleet_status_total) else "(null)"
            query_data["recipeid"] = tuple(fleet_status_total['recipename'].unique().tolist()) if len(fleet_status_total) else "(null)"
            limit_query = self.queries["limit_change"].format(**query_data)
            query_data["offset"] = lastruntable.get("offset", 0)

            query_data["dmaps"] = tuple(fleet_status_total["dmaps"].tolist())
            query_data["dmaps"] = (query_data["dmaps"] if len(query_data["dmaps"]) else "(null)")

            query_data["rmaps"] = tuple(
                set(itertools.chain.from_iterable(fleet_status_total["rmaps"].tolist()))
            )
            query_data["rmaps"] = (
                query_data["rmaps"] if len(query_data["rmaps"]) else "(null)"
            )
            query_data["smaps"] = tuple(fleet_status_total["smaps"].tolist())
            query_data["smaps"] = (query_data["smaps"] if len(query_data["smaps"]) else "(null)")

            total = fleet_status_total['total'].iloc[0] if len(fleet_status_total) else 0
            if total == 0:
                resp = {
                    "data": [],
                    "max_scanset": 0,
                    "scanset_val": [],
                    "limit": 10,
                    "offset": 0,
                    "total": int(total),
                }
                return resp

            control_limit = self.queries["fs_lastrun_ss_limit"].format(**query_data)
            control_limit_df = await get_query_with_pool(control_limit)
            merge_na = control_limit_df[control_limit_df['tool'] == 'NA']
            merge_tool = control_limit_df[control_limit_df['tool']!= 'NA']

            merge_tool.set_index([ 'test','product', 'layer', 'recipeid'], inplace=True)
            merge_na.set_index(['test','product', 'layer', 'recipeid'], inplace=True)

            control_limit = merge_tool.combine_first(merge_na)
            control_limit.reset_index(inplace=True)

            control_limit= control_limit.replace({np.nan: "null"})

            query_data["control_limit"] = str(
                [
                    tuple(x)
                    for x in control_limit[
                        [
                            "product",
                            "layer",
                            "recipeid",
                            "dc_lcl",
                            "dc_ucl",
                            "gr_lcl",
                            "gr_ucl",
                            "vl_lcl",
                            "vl_ucl",
                            "sl_lcl",
                            "sl_ucl",
                            "tl_lcl",
                            "tl_ucl",
                            "cr_lcl",
                            "cr_ucl",
                            "test",
                            "tool",
                            "dc_base"
                        ]
                    ].to_numpy()
                ]
            ).replace("'null'", "null")
            fleet_status_ss = self.queries["run_data_ss"].format(**query_data)
            app_log.info(f"Fleet Status Last Run Query: {fleet_status_ss}")
            tasks = [get_query_with_pool(limit_query, "df"), get_query_with_pool(fleet_status_ss, "df")]
            limit_df, fleet_status_ss = await asyncio.gather(*tasks)
            limit_df = limit_df[["productname", "layername", "recipename","toolid","dc_base","dc_lcl","dc_ucl","cr_base","cr_lcl","cr_ucl","vl_base","vl_lcl", "vl_ucl", "gr_base","gr_lcl", "gr_ucl", "sl_base","sl_lcl", "sl_ucl", "tl_lcl", "tl_ucl"]]
            fleet_status_ss = fleet_status_ss.replace({np.nan: None})
            scanset_val = [int(i) for i in fleet_status_ss['scanset'].unique().tolist()]
            scanset_val.sort()
            max_scanset = len(scanset_val)
            last_run_data = []
            temp_dict = {
                    "data": "NA",
                    "lcl": None,
                    "ucl": None,
                    "outlier": False
                }

            merge_tool = pd.merge(fleet_status_total, limit_df[limit_df['toolid'] != 'NA'], on=['productname', 'layername','recipename', 'toolid'], how='inner')

            # Then, merge rows where tool is 'NA' in dataframe b only on 'name' and 'place'
            merge_na = pd.merge(fleet_status_total, limit_df[limit_df['toolid'] == 'NA'], on=['productname', 'layername', 'recipename'], how='inner')
            merge_na = merge_na.rename(columns={'toolid_x': 'toolid'})
             # fleet_status_total = pd.concat([merge_tool, merge_na])
            merge_tool.set_index(['toolid', 'timestamp', 'productname', 'layername', 'recipename'], inplace=True)
            merge_na.set_index(['toolid', 'timestamp', 'productname', 'layername', 'recipename'], inplace=True)

            fleet_status_total = merge_tool.combine_first(merge_na)
            fleet_status_total.reset_index(inplace=True)

            fleet_status_total = fleet_status_total.drop_duplicates(subset=['toolid', 'productname', 'layername', 'recipename', 'timestamp'])
            fleet_status_total = fleet_status_total.replace({np.nan: None})
            app_log.info(fleet_status_total)
            fleet_status_total = fleet_status_total.drop(['toolid_y'], axis=1)
            order_dict = {value: i for i, value in enumerate(order)}
            fleet_status_total['rank'] = fleet_status_total['id'].map(order_dict)
            # Sort fleet_status_total by the 'rank' column
            fleet_status_total.sort_values(by='rank', inplace=True)
            # Drop the 'rank' column
            fleet_status_total.drop('rank', axis=1, inplace=True)
            for row in fleet_status_total.iterrows():
                last_run_ss_df = fleet_status_ss[

                    (fleet_status_ss["toolid"] == row[1]["toolid"])
                    & (fleet_status_ss["timestamp"] == row[1]["timestamp"])
                    & (fleet_status_ss["productname"] == row[1]["productname"])
                    & (fleet_status_ss["layer"] == row[1]["layername"]  )
                    & (fleet_status_ss["recipename"] == row[1]["recipename"])
                ].drop(["layer"], axis=1)
                last_run_ss = []
                last_run_ss_df_req = last_run_ss_df[["toolid","productname","layername","recipename","scanset","dctarget","dclastrun","crvsmaster","volumeratio","graderatio","selfiscore", "tlfscore"]]
                ss_data = last_run_ss_df.to_dict(orient = 'records')
                i = 0
                for ss_row in last_run_ss_df_req.iterrows():
                    row_dict = ss_row[1].to_dict()

                    if row_dict['dclastrun'] == 'NA':
                        row_dict['dclastrun'] = temp_dict
                    else:
                        if ss_data[i]['dc_lcl'] is not None and ss_data[i]['dc_ucl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] < ss_data[i]["dc_lcl"] or row_dict['dclastrun'] > ss_data[i]["dc_ucl"] else False
                            }
                        elif ss_data[i]['dc_lcl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] < ss_data[i]["dc_lcl"]  else False
                            }
                        elif ss_data[i]['dc_ucl'] is not None:
                            row_dict['dclastrun'] = {
                                "data": row_dict['dclastrun'],
                                "lcl": ss_data[i]["dc_lcl"],
                                "ucl": ss_data[i]["dc_ucl"],
                                "outlier": True if row_dict['dclastrun'] > ss_data[i]["dc_ucl"] else False
                            }
                        else:
                            row_dict["dclastrun"] = {
                                "data": row_dict['dclastrun'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['crvsmaster'] is None:
                        row_dict['crvsmaster'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['cr_lcl'] is not None and ss_data[i]['cr_ucl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] < ss_data[i]["cr_lcl"] or row_dict['crvsmaster'] >ss_data[i]["cr_ucl"] else False
                            }
                        elif ss_data[i]['cr_lcl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] < ss_data[i]["cr_lcl"] else False
                            }
                        elif ss_data[i]['cr_ucl'] is not None:
                            row_dict['crvsmaster'] = {
                                "data": row_dict['crvsmaster'],
                                "lcl":  ss_data[i]["cr_lcl"],
                                "ucl":  ss_data[i]["cr_ucl"],
                                "outlier": True if row_dict['crvsmaster'] > ss_data[i]["cr_ucl"] else False
                            }
                        else:
                            row_dict["crvsmaster"] = {
                                "data": row_dict['crvsmaster'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['graderatio'] is None:
                        row_dict['graderatio'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['gr_lcl'] is not None and ss_data[i]['gr_ucl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio']< ss_data[i]["gr_lcl"] or row_dict['graderatio'] > ss_data[i]["gr_ucl"] else False
                            }
                        elif ss_data[i]['gr_lcl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio']< ss_data[i]["gr_lcl"] else False
                            }
                        elif ss_data[i]['gr_ucl'] is not None:
                            row_dict['graderatio'] = {
                            "data": row_dict['graderatio'],
                            "lcl": ss_data[i]["gr_lcl"],
                            "ucl": ss_data[i]["gr_ucl"],
                            "outlier": True if row_dict['graderatio'] > ss_data[i]["gr_ucl"] else False
                            }
                        else:
                            row_dict["graderatio"] = {
                                "data": row_dict['graderatio'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['volumeratio'] is None:
                        row_dict['volumeratio'] = temp_dict
                    else:
                        # breakpoint()
                        if ss_data[i]['vl_lcl'] is not None and ss_data[i]['vl_ucl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio']< ss_data[i]["vl_lcl"] or row_dict['volumeratio'] > ss_data[i]["vl_ucl"] else False
                            }
                        elif ss_data[i]['vl_lcl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio']< ss_data[i]["vl_lcl"] else False
                            }
                        elif ss_data[i]['vl_ucl'] is not None:
                            row_dict['volumeratio'] = {
                                "data": row_dict['volumeratio'],
                                "lcl": ss_data[i]["vl_lcl"],
                                "ucl": ss_data[i]["vl_ucl"],
                                "outlier": True if row_dict['volumeratio'] > ss_data[i]["vl_ucl"] else False
                            }
                        else:
                            row_dict["volumeratio"] = {
                                "data": row_dict['volumeratio'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    if row_dict['selfiscore'] is None:
                        row_dict['selfiscore'] = temp_dict
                    else:
                        if ss_data[i]['sl_lcl'] is not None and ss_data[i]['sl_ucl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore']<ss_data[i]["sl_lcl"] or row_dict['selfiscore'] > ss_data[i]["sl_ucl"] else False
                        }
                        elif ss_data[i]['sl_lcl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore']<ss_data[i]["sl_lcl"] else False
                        }
                        elif ss_data[i]['sl_ucl'] is not None:
                            row_dict['selfiscore'] = {
                            "data": row_dict['selfiscore'],
                            "lcl": ss_data[i]["sl_lcl"],
                            "ucl": ss_data[i]["sl_ucl"],
                            "outlier": True if row_dict['selfiscore']>ss_data[i]["sl_ucl"] else False
                        }
                        else:
                            row_dict["selfiscore"] = {
                                "data": row_dict['selfiscore'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }
                    if row_dict['tlfscore'] is None:
                        row_dict['tlfscore'] = temp_dict
                    else:
                        if ss_data[i]['tl_lcl'] is not None and ss_data[i]['tl_ucl'] is not None:
                            row_dict['tlfscore'] = {
                            "data": row_dict['tlfscore'],
                            "lcl": ss_data[i]["tl_lcl"],
                            "ucl": ss_data[i]["tl_ucl"],
                            "outlier": True if row_dict['tlfscore']< ss_data[i]["tl_lcl"] or row_dict['tlfscore'] > ss_data[i]["tl_ucl"] else False
                        }
                        elif ss_data[i]['tl_lcl'] is not None:
                            row_dict['tlfscore'] = {
                            "data": row_dict['tlfscore'],
                            "lcl": ss_data[i]["tl_lcl"],
                            "ucl": ss_data[i]["tl_ucl"],
                            "outlier": True if row_dict['tlfscore']< ss_data[i]["tl_lcl"] else False
                        }
                        elif ss_data[i]['tl_ucl'] is not None:
                            row_dict['tlfscore'] = {
                            "data": row_dict['tlfscore'],
                            "lcl": ss_data[i]["tl_lcl"],
                            "ucl": ss_data[i]["tl_ucl"],
                            "outlier": True if row_dict['tlfscore'] > ss_data[i]["tl_ucl"] else False
                        }
                        else:
                            row_dict["tlfscore"] = {
                                "data": row_dict['tlfscore'],
                                "lcl": None,
                                "ucl": None,
                                "outlier": False
                            }

                    last_run_ss.append(row_dict)
                    i+=1

                if row[1]["crvsmaster"] == 'NA':
                    cr_data = temp_dict
                else:
                    # breakpoint()
                    if row[1]["cr_lcl"] is not None and row[1]["cr_ucl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] < row[1]["cr_lcl"] or row[1]["crvsmaster"] >row[1]["cr_ucl"] else False
                        }
                    elif row[1]["cr_lcl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] < row[1]["cr_lcl"] else False
                        }
                    elif row[1]["cr_ucl"] is not None:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": row[1]["cr_lcl"],
                            "ucl":  row[1]["cr_ucl"],
                            "outlier": True if row[1]["crvsmaster"] >row[1]["cr_ucl"] else False
                        }
                    else:
                        cr_data = {
                            "data": row[1]["crvsmaster"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["dclastrun"] == 'NA':
                    dc_data = temp_dict
                else:
                    if row[1]["dc_lcl"] is not None and row[1]["dc_ucl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] <row[1]["dc_lcl"] or row[1]["dclastrun"] >row[1]["dc_ucl"] else False
                        }
                    elif row[1]["dc_lcl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] <row[1]["dc_lcl"] else False
                        }
                    elif row[1]["dc_ucl"] is not None:
                        dc_data = {
                            "data": row[1]["dclastrun"],
                            "lcl":  row[1]["dc_lcl"],
                            "ucl":  row[1]["dc_ucl"],
                            "outlier": True if row[1]["dclastrun"] > row[1]["dc_ucl"] else False
                        }
                    else:
                        dc_data = {
                            "data":row[1]["dclastrun"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["volumeratio"] == 'NA':
                    vl_data = temp_dict
                else:
                    # breakpoint()
                    if row[1]["vl_lcl"] is not None and row[1]["vl_ucl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"]< row[1]["vl_lcl"] or row[1]["volumeratio"] > row[1]["vl_ucl"] else False
                        }
                    elif row[1]["vl_lcl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"]< row[1]["vl_lcl"] else False
                        }
                    elif row[1]["vl_ucl"] is not None:
                        vl_data = {
                        "data": row[1]["volumeratio"],
                        "lcl": row[1]["vl_lcl"],
                        "ucl": row[1]["vl_ucl"],
                        "outlier": True if row[1]["volumeratio"] > row[1]["vl_ucl"] else False
                        }
                    else:
                        vl_data = {
                            "data": row[1]["volumeratio"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["graderatio"] == 'NA':
                    gr_data = temp_dict
                else:
                    if row[1]["gr_lcl"] is not None and row[1]["gr_ucl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"]< row[1]["gr_lcl"] or row[1]["graderatio"] > row[1]["gr_ucl"] else False
                        }
                    elif row[1]["gr_lcl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"]< row[1]["gr_lcl"] else False
                        }
                    elif row[1]["gr_ucl"] is not None:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": row[1]["gr_lcl"],
                            "ucl": row[1]["gr_ucl"],
                            "outlier": True if row[1]["graderatio"] > row[1]["gr_ucl"] else False
                        }
                    else:
                        gr_data = {
                            "data": row[1]["graderatio"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["selfiscore"] == 'NA':
                    sl_data = temp_dict
                else:
                    if row[1]["sl_lcl"] is not None and row[1]["sl_ucl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] < row[1]["sl_lcl"] or row[1]["selfiscore"] > row[1]["sl_ucl"] else False
                        }
                    elif row[1]["sl_lcl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] < row[1]["sl_lcl"] else False
                        }
                    elif row[1]["sl_ucl"] is not None:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": row[1]["sl_lcl"],
                            "ucl": row[1]["sl_ucl"],
                            "outlier": True if row[1]["selfiscore"] > row[1]["sl_ucl"] else False
                        }
                    else:
                        sl_data = {
                            "data": row[1]["selfiscore"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                if row[1]["tlfscore"] == 'NA':
                    tl_data = temp_dict
                else:
                    if row[1]["tl_lcl"] is not None and row[1]["tl_ucl"] is not None:
                        tl_data = {
                            "data": row[1]["tlfscore"],
                            "lcl": row[1]["tl_lcl"],
                            "ucl": row[1]["tl_ucl"],
                            "outlier": True if row[1]["tlfscore"] < row[1]["tl_lcl"] or row[1]["tlfscore"] > row[1]["tl_ucl"] else False
                        }
                    elif row[1]["tl_lcl"] is not None:
                        tl_data = {
                            "data": row[1]["tlfscore"],
                            "lcl": row[1]["tl_lcl"],
                            "ucl": row[1]["tl_ucl"],
                            "outlier": True if row[1]["tlfscore"] < row[1]["tl_lcl"] else False
                        }
                    elif row[1]["tl_ucl"] is not None:
                        tl_data = {
                            "data": row[1]["tlfscore"],
                            "lcl": row[1]["tl_lcl"],
                            "ucl": row[1]["tl_ucl"],
                            "outlier": True if row[1]["tlfscore"] > row[1]["tl_ucl"] else False
                        }
                    else:
                        tl_data = {
                            "data": row[1]["tlfscore"],
                            "lcl": None,
                            "ucl": None,
                            "outlier": False
                        }

                last_run_data.append(
                    {
                        "id": row[1]["id"],
                        "timestamp": str(row[1]["timestamp"]),
                        "toolid": row[1]["toolid"],
                        "productname": row[1]["productname"],
                        "layername": row[1]["layername"],
                        "recipename": row[1]["recipename"],
                        "dclastrun": dc_data,
                        "crvsmaster": cr_data,
                        "graderatio": gr_data,
                        "volumeratio": vl_data,
                        "selfiscore": sl_data,
                        "tlfscore": tl_data,
                        "subRows": last_run_ss,
                    }
                )

            resp = {
                "data": last_run_data,
                "max_scanset": max_scanset,
                "scanset_val": scanset_val,
                "limit": lastruntable.get("limit", 10),
                "offset": lastruntable.get("offset", 0),
                "total": int(total),
            }

        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def export_model(self, data):
        """
        Export the run data to a CSV file.

        Returns:
            dict: A dictionary containing the filename of the exported file.

        Raises:
            Exception: If an error occurs during the export process.
        """
        try:
            query_data = make_query(data)
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            master_cdtn = make_query(data)

            query_data["master_header_cdtn"] = master_cdtn["header_cdtn"]
            query_data["master_defect_cdtn"] = master_cdtn["defect_cdtn"]
            app_log.info("Exporting Run Data Started")
            current_time = datetime.now()
            file_time = calendar.timegm(current_time.timetuple())
            filename = f"RunTable_{file_time}.csv"
            app_log.info("Export Run Limit Table Data")

            query_data['sort_order'] = ''
            query_data['limit'] = ''
            query_data['offset'] = 0

            run_data = self.queries['run_data'].format(**query_data)
            app_log.info(f"Run Data Query: {run_data}")
            run_data = await get_query_with_pool(run_data)
            if not len(run_data):
                return {}
            run_data = run_data.replace({np.nan: "NA"})
            query_data['product'] = tuple(run_data['productname'].unique().tolist())
            query_data['layer'] = tuple(run_data['layername'].unique().tolist())
            query_data['recipeid'] = tuple(run_data['recipename'].unique().tolist())

            query_data["dmaps"] = tuple(run_data["dmaps"].tolist())
            query_data["dmaps"] = (query_data["dmaps"] if len(query_data["dmaps"]) else "(null)")

            query_data["rmaps"] = tuple(
                set(itertools.chain.from_iterable(run_data["rmaps"].tolist()))
            )
            query_data["rmaps"] = (
                query_data["rmaps"] if len(query_data["rmaps"]) else "(null)"
            )
            query_data["smaps"] = tuple(run_data["smaps"].tolist())
            query_data["smaps"] = (query_data["smaps"] if len(query_data["smaps"]) else "(null)")
            run_data_ss = self.queries['run_data_export'].format(**query_data)
            app_log.info(f"Run Data Query: {run_data_ss}")
            run_data_ss = await get_query_with_pool(run_data_ss)
            run_data_ss = run_data_ss.replace({np.nan: "NA"})

            run_data = run_data[['timestamp','toolid','productname','layername','recipename','dclastrun', 'crvsmaster', 'graderatio', 'volumeratio', 'selfiscore','tlfscore']]
            run_data.insert(5, 'scanset', '-')
            run_data['timestamp'] = run_data['timestamp'].astype(str)
            run_data_ss = run_data_ss[['timestamp','toolid','productname','layername','recipename','scanset','dclastrun', 'crvsmaster', 'graderatio', 'volumeratio', 'selfiscore','tlfscore']]

            run_data = run_data.astype(str)
            run_data_ss = run_data_ss.astype(str)
            
            run_data = run_data.merge(run_data_ss, how='outer')
            run_data = run_data.sort_values(by=['timestamp', 'toolid', 'productname', 'layername', 'recipename', 'scanset'])

            new_column_names = {
            "timestamp": "Time Stamp",
            "toolid": "Tool ID",
            "productname": "Product Name",
            "layername": "Layer Name",
            "recipename": "Recipe Name",
            "scanset": "Scanset",
            "dclastrun": "DC",
            "crvsmaster": "CR vs Master",
            "graderatio": "Grade Ratio",
            "volumeratio": "Volume Ratio",
            "selfiscore": "SELFI Score Avg",
            "tlfscore": "TLF Score Avg"
            }
            run_data = run_data.rename(columns=new_column_names)
            run_data.to_csv(f"export/{filename}", header=True, index=False)
            resp = {'filename': filename}
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp
