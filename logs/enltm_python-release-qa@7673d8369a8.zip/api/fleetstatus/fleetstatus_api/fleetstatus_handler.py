"""Fleet Status Handler"""
import os
import sys
import io

from fastapi.responses import JSONResponse, Response
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.fleetstatus.fleetstatus_api.fleetstatus_model import FleetStatus


router = APIRouter(tags=['Fleetstatus'],prefix="/fleetstatus",dependencies=[Depends(verify_jwt)])
fleetstatus = FleetStatus()


@router.post("/lastrun")
async def post(request: Request, body: dict):
    """On post request return the fleet status for last run"""
    resp = await fleetstatus.lastrun(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Failed to fetch data."},
        )

    return JSONResponse(content=resp)

@router.post("/runtable")
async def post(request: Request, body: dict):
    """On post request return the fleet status for last run"""
    resp = await fleetstatus.run_data(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Failed to fetch data."},
        )

    return JSONResponse(content=resp)

@router.post("/extendedperiod")
async def post(request: Request, body: dict):
    """On post request return the fleet status for extended period"""
    resp = await fleetstatus.extended_period(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Failed to fetch data."},
        )

    return JSONResponse(content=resp)


@router.post("/pareto")
async def post(request: Request, body: dict):
    """On post request return the fleet status for extended period"""
    resp = await fleetstatus.get_pareto(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Failed to fetch data."},
        )

    return JSONResponse(content=resp)

@router.post("/export")
async def post(request: Request, body: dict):
    """On get request return the export for Run data """
    resp = await fleetstatus.export_model(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Failed to fetch data."},
        )
    if len(resp.keys()) == 0:
        return Response(status_code=204)
    
    filename = f"export/{resp['filename']}"
    with open(filename, "rb") as fi:
        contents = fi.read()

    blob_data = io.BytesIO(contents)
    if os.path.exists(f"{filename}"):
        os.remove(f"{filename}")
    response = Response(content=blob_data.getvalue())
    response.headers['Content-Type'] = 'application/octet-stream'
    return response



