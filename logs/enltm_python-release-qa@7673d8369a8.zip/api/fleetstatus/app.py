"""FAST API Router file for fleetstatus"""
from api.utils.fastapi_app import app
from api.fleetstatus.fleetstatus_api import fleetstatus_handler


app.include_router(fleetstatus_handler.router)
