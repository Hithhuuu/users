from api.utils.fastapi_app import app
from api.user.user_api import userhandler


app.include_router(userhandler.router)
