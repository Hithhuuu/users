import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from user_api.usermodel import Users


router = APIRouter(tags=["User"],prefix="/auth")
user = Users()

@router.post("")
async def auth(request: Request, body: dict):
    """On get request return the user\'s list as JSON"""
    response = await user.auth(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )


@router.post("/refresh",dependencies=[Depends(verify_jwt)])
async def authrefresh(request: Request, body: dict):
    """Refresh call for session"""
    response = await user.refresh(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )


@router.get("/user",dependencies=[Depends(verify_jwt)])
async def get(request: Request):
    """On get request return the user\'s list as JSON"""
    body = {}
    body['authorization'] = request.headers.get("Authorization")
    response = await user.get(body)
    return response


@router.post("/user",dependencies=[Depends(verify_jwt)])
async def post(request: Request, body: dict):
    """On post request create the user if doesn't exist"""
    return JSONResponse(content=await user.create(body))


@router.put("/user",dependencies=[Depends(verify_jwt)])
async def put(request: Request, body: dict):
    """On get request return the user\'s list as JSON"""
    response = await user.update(body)
    if response.get("status_code", 200) == 400:
        return JSONResponse(
            status_code=response.get("status_code"),
            content={"message": response.get("msg")},
        )
    return JSONResponse(content=response)


@router.delete("/user",dependencies=[Depends(verify_jwt)])
async def delete(request: Request, body: dict):
    """On get request return the user\'s list as JSON"""
    await user.delete(body)
    body = {}
    body['authorization'] = request.headers.get("Authorization")
    response = await user.get(body)
    return response


@router.get("/feature",dependencies=[Depends(verify_jwt)])
async def get(request: Request):
    body = {}
    body['authorization'] = request.headers.get("Authorization")
    response = await user.get_user_feature(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)
  

@router.put("/feature",dependencies=[Depends(verify_jwt)])
async def update(request: Request, body: dict):
    body['authorization'] = request.headers.get("Authorization")
    response = await user.update_user_feature(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)