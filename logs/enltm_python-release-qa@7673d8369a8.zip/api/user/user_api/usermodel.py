import re
import os
import time
import sys
import json
from datetime import datetime, timedelta
import bcrypt
from jwt import encode, decode

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from api.utils.auth import AuthUtil
from utils.utils import (
    queries,
    get_logger,
    env_config,
    decrypt,
    encrypt,
)

app_log = get_logger("user")


class Users:
    """This class provides methods to get/add/update/delete user account"""

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["users"]

    def get_password(self, password):
        """Decode the Users password"""
        salt = bcrypt.gensalt()
        password = bcrypt.hashpw(password.encode(), salt)
        return password.decode()

    def check_password(self, user_password, requested_password):
        """Check User password"""
        return bcrypt.checkpw(requested_password.encode(), user_password.encode())

    def check_userid(self, userid):
        """Check for correct user id"""
        return bool(re.findall("[\!~@#$%^&()*=|]", userid))

    async def auth(self, data):
        """Authentication Users with username and password"""
        try:

            user_data = await self.data(data)
            if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
                return {
                    "status": "error",
                    "status_code": 401,
                    "content": "UserID not valid",
                }


            user_data = user_data[0]
            pass_word = decrypt(
                data["password"], bytes(env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")

            if self.check_password(user_data["password"], pass_word):
                to_encode = {
                    "some": "payload",
                    "userid": data["userid"],
                    "usertype": user_data['usertype'],
                    "isadmin": "Y" if user_data["assignedrole"] == "admin" else 'A' if user_data['assignedrole'] == 'advance' else 'N',
                    "a": {2: True},
                    "exp": datetime.utcnow() + timedelta(minutes=480),
                }
                encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
                jwt_key = (
                    encoded.decode("utf-8") if (isinstance(encoded, bytes)) else encoded
                )
                feature_df = await get_query_with_pool(self.queries['get_user_feature'])
                response_data = {
                    "jwt": jwt_key,
                    "userid": user_data["userid"],
                    "username": user_data["email"],
                    "firstname": user_data["firstname"],
                    "usertype": user_data['usertype'],
                    "isadmin": "Y" if user_data["assignedrole"] == "admin" else 'A'  if user_data['assignedrole'] == 'advance' else 'N',
                    "displayName": user_data["firstname"] + " " + user_data["lastname"],
                    "featureList":feature_df.to_dict(orient='records'),
                    "expiredAt": str(to_encode["exp"]),
                }

                response = {
                    "encryptedData": encrypt(
                        f"{json.dumps(response_data)}".replace("'", '"'),
                        bytes(env_config["password_secret_key"], "utf-8"),
                    ).decode("ascii")
                }
                app_log.info("Successfully authenticated")

                return response

            return {
                "status": "error",
                "status_code": 401,
                "content": "Authentication failed",
            }
        except Exception as e:
            app_log.exception(e)
            return {
                "status": "error",
                "status_code": 500,
                "content": "Something went wrong",
            }

    async def refresh(self, data):
        try:
            user_data = await self.data(data)
            if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
                return {
                    "status": "error",
                    "status_code": 401,
                    "content": "UserID not valid",
                }
            user_data = user_data[0]
            to_encode = {
                "some": "payload",
                "userid": data["userid"],
                "usertye": user_data['usertype'],
                "isadmin": "Y" if user_data["assignedrole"] == "admin" else 'A' if user_data['assignedrole'] == 'advance' else 'N',
                "a": {2: True},
                "exp": datetime.utcnow() + timedelta(minutes=480),
            }
            encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
            feature_df = await get_query_with_pool(self.queries['get_user_feature'])

            response = {
                "jwt": encoded.decode("utf-8"),
                "userid": user_data["userid"],
                "username": user_data["email"],
                "firstname": user_data["firstname"],
                "usertype": user_data['usertype'],
                "isadmin": "Y" if user_data["assignedrole"] == "admin" else 'A' if user_data['assignedrole'] == 'advance' else 'N',
                "displayName": f"{user_data['firstname']} {user_data['lastname']}",
                "featureList": feature_df.to_dict(orient='records'),
                "expiredAt": to_encode["exp"],
            }
            response = {
                "encryptedData": encrypt(
                    f"{response}".replace("'", '"'),
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("ascii")
            }
            return response
        except Exception as e:
            app_log.exception(e)
            return {
                "status": "error",
                "status_code": 500,
                "content": "Something went wrong",
            }

    async def get(self, data):
        """Get list of users"""
        try:
            userid, usertype = await AuthUtil.get_current_user(data.get("authorization"))
            user = {}
            app_log.info("Get list of users")
            app_log.info(self.queries["read"])
            user['userid'] = userid
            user['usertype'] = ('internal', 'external')  if not usertype == 'external' else ('external',)
            data = await get_query_with_pool(
                self.queries["read"].format(**user), "dict"
            )
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}
        return data

    async def create(self, data):
        """creates new user"""
        try:
            app_log.info("Create user")
            data = json.loads(
                decrypt(
                    data["encryptedData"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
            )
            if self.check_userid(data["userid"]):
                raise TypeError("No Special Character Allowed")

            if data['userid'] == 'report':
                return {'msg': 'User already exists', 'status_code': 400}

            user_exists_query = self.queries["user_exists"].format(**data)
            app_log.info(f"USER EXISTS QUERY: {user_exists_query}")

            users = await get_query_with_pool(
                 user_exists_query, "dict"
            )

            if len(users):
                return {"msg": "user exists"}

            # Encrypt user password
            pass_word = decrypt(
                data["password"], bytes(env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")
            data["password"] = self.get_password(pass_word)

            # Create new user
            assignedrole = "admin" if data.get("isadmin") == "Y" else "normal user"
            rfg = 1 if data.get("isactive") == "Y" else 2
            data.update({"assignedrole": assignedrole, "rfg": rfg})
            user_create_query = self.queries["create"].format(**data)
            app_log.info(f"USER CREATE QUERY: {user_create_query}")
            await get_query_with_pool( user_create_query)
        except Exception as e:
            app_log.exception(f"error in user creation: {e}")
            return {"error": str(e)}
        return {"msg": "user created"}

    def prepare_query(self, data):
        query_data = []

        for key, value in data.items():
            if key == "isactive":
                rfg = 1 if data.get("isactive") == "Y" else 2
                query_data.append(f"rfg = '{rfg}'")
            elif key == "isadmin":
                assignedrole = "admin" if data.get("isadmin") == "Y"  else 'normal user' if data.get("isadmin") == "N" else "advance"
                query_data.append(f"assignedrole = '{assignedrole}'")
            elif key in ("active", "customeradvance", "customernormal"):
                query_data.append(f"{key} = {1 if value else 0}")

            # NOTE - Always Keep below condtion at last so it won't affect the in old conditions.
            elif key not in ("userid", "udt", "cdt", "currentPassword"):
                query_data.append(f"{key} = '{value}'")
        return " , ".join(query_data)

    async def update(self, data):
        """Update user record"""
        try:
            app_log.info("Update User Record")
            data = json.loads(
                decrypt(
                    data["encryptedData"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
            )

            app_log.info("Authenticating users")
            user_auth_query = self.queries["authenticate_update"].format(**data)
            app_log.info(f"USER AUTH QUERY: {user_auth_query}")
            user_data = await get_query_with_pool(
                 user_auth_query, "dict"
            )
            if len(user_data) <= 0 or user_data[0]["rfg"] == 0:
                return {"msg": "UserID not valid"}
            user_data = user_data[0]
            if data.get("currentPassword", "") != "":
                pass_word = decrypt(
                    data["currentPassword"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                # Verify user input password and user data password are equal or not
                if not bcrypt.checkpw(
                    pass_word.encode(), user_data["password"].encode()
                ):
                    return {
                        "status_code": 400,
                        "msg": f"Current password is incorrect for user {data['userid']}.",
                    }

            if data.get("password"):
                pass_word = decrypt(
                    data["password"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                data["password"] = self.get_password(pass_word)

            query_data = self.prepare_query(data)

            data["select_param"] = query_data
            user_update_query = self.queries["update"].format(**data)
            app_log.info(f"USER UPDATE QUERY: {user_update_query}")
            await get_query_with_pool( user_update_query, "dict")
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return {"msg": f"user {data['userid']} updated successfully"}

    async def data(self, data):
        """Get the User details for Authentication"""
        try:
            app_log.info("Authenticating users")
            user_auth_query = self.queries["authenticate"].format(**data)
            app_log.info(f"USER AUTH QUERY: {user_auth_query}")
            user_data = await get_query_with_pool(
                 user_auth_query, "dict"
            )
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}
        return user_data

    async def delete(self, data):
        """Delete User"""
        try:
            app_log.info("Delete users")
            data["userid"] = "', '".join(data["userid"])
            user_delete_query = self.queries["delete"].format(**data)
            app_log.info(f"USER DELETE QUERY: {user_delete_query}")
            await get_query_with_pool( user_delete_query)
            for i in range(30):
                count_query = self.queries["user_count"].format(**data)
                app_log.info(f" count query : {count_query}")
                count = await get_query_with_pool( count_query)
                app_log.info(f" count is {count['count'].iloc[0]}")
                if count["count"].iloc[0] != 0:
                    break
                time.sleep(0.2)
            app_log.info("Deleted successful")
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}

    async def get_user_feature(self, data):
        try:
            _, user_token = data.get('authorization').split()
            jwt_key = (
                        decode(user_token, env_config['secret_key'], algorithms="HS256")
                    )
            is_admin = jwt_key.get('isadmin')
            if is_admin == 'Y':
                result = await get_query_with_pool(self.queries['get_user_feature'])
                return result.to_dict(orient='records')
            else:
                return {"error": "LoggedIn user is not an Admin."}
        except Exception as err:
            app_log.exception(err)
            return {"error": 'Something went wrong.'}


    async def update_user_feature(self, data):
        try:
            _, user_token = data.pop('authorization').split()
            jwt_key = (
                        decode(user_token, env_config['secret_key'], algorithms="HS256")
                    )
            is_admin = jwt_key.get('isadmin')
            if is_admin == 'Y':
                query_data = {}
                query_data['featurename'] = data.pop('featurename')
                query_data['select_param'] = self.prepare_query(data) + ', udt = now()'
                await get_query_with_pool(self.queries['update_user_feature'].format(**query_data))
                return {"msg": "Feature updated successfully."}
            else:
                return {"error": "LoggedIn user is not an Admin."}
        except Exception as err:
            app_log.exception(err)