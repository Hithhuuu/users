from api.utils.fastapi_app import app
from api.qcrecipe.qcrecipe_api import qcrecipe_handler


app.include_router(qcrecipe_handler.router)
