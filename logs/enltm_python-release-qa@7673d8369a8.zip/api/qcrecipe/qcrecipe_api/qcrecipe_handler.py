"""Handler to define and fetch QC recipe"""
import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from qcrecipe_api.qcrecipe_model import QcRecipe


router = APIRouter(tags=['QCRecipe'],prefix="/qcrecipe",dependencies=[Depends(verify_jwt)])
qcrecipe = QcRecipe()


@router.post("")
async def post(request: Request, body: dict):
    """On get request return the QC Recipe List as JSON"""
    return JSONResponse(content=await qcrecipe.get(body))


@router.put("")
async def put(request: Request, body: dict):
    """On post request Create the new Qc recipe"""
    response = await qcrecipe.create(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=await qcrecipe.get(body))


@router.delete("")
async def delete(request: Request, body: dict):
    """On delete request Delete the user"""
    response = await qcrecipe.delete(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=await qcrecipe.get(body))
