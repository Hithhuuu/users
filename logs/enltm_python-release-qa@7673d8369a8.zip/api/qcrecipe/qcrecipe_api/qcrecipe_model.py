import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from utils.utils import (
    queries,
    get_logger,
    env_config
)

app_log = get_logger("qcrecipe")


class QcRecipe:
    """This class provides methods to get/add/delete qc recipe"""

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["qcrecipe"]

    async def get(self, data):
        """Function to get list of QC Recipe"""
        try:
            tool_list = len(env_config["tools"])
            app_log.info("Get list of recipe")
            query_data = {}
            column_sort_query = ""
            columns_sort_query = []
            if data.get("sort", {}):
                for sort_data in data.get("sort"):
                    columns_sort_query.append(
                        f"lower({sort_data['id']}) {sort_data['order']}"
                    )

                column_sort_query = ", ".join(columns_sort_query)
            query_data["sort_order"] = (
                f"ORDER BY {column_sort_query}"
                if column_sort_query
                else "ORDER BY lower(recipeid) DESC"
            )
            query_data[
                "limit"
            ] = f'LIMIT {data.get("offset", 0)},{data.get("limit", 10)}'
            query_data['tool_list'] = tool_list
            qc_read_query = self.queries["read"].format(**query_data)
            app_log.info(qc_read_query)
            data_out = await get_query_with_pool(qc_read_query)
            count = await get_query_with_pool(self.queries["count"], "list")
            data_output = {
                "data": data_out.to_dict("records"),
                "total": count[0][0],
                "limit": data.get("limit"),
                "offset": data.get("offset"),
            }

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return data_output

    async def create(self, data):
        """Function to define new QC Recipe"""
        try:
            app_log.info("Check if same combination exist or not")
            qc_exist_query = self.queries["check"].format(**data)
            check_exist = await get_query_with_pool(qc_exist_query, "list")
            if check_exist[0][0] != 0:
                return {"error": "Recipe Already exist"}

            if data.get('id', None):
                app_log.info('Updating QC Recipe')
                qc_update_query = self.queries["update"].format(**data)
                app_log.info(f"QC Update Query: {qc_update_query}")
                await get_query_with_pool(qc_update_query)

                app_log.info("Adding Updated QC Recipe")
                qc_create_query = self.queries["create"].format(**data)
                app_log.info(f"QC Create Query: {qc_create_query}")
                await get_query_with_pool(qc_create_query)

            else:
                app_log.info("Create QC Recipe")
                qc_create_query = self.queries["create"].format(**data)
                app_log.info(f"QC Create Recipe: {qc_create_query}")
                await get_query_with_pool(qc_create_query)

                data["rfg"] = 1
                data["cur_rfg"] = 2
                rfg_update_query = self.queries["update_rfg"].format(**data)
                app_log.info(f"Updating rfg query: {rfg_update_query}")
                await get_query_with_pool(rfg_update_query)

        except Exception as e:
            app_log.exception(f"Error in recipe creation:{e}")
            return {"error": str(e)}

        return {"msg": "QC recipe created"}

    async def delete(self, data):
        """Function to delete QC Recipe"""
        try:
            app_log.info("Delete QC Recipe")
            qc_delete_query = self.queries["delete"].format(**data)
            app_log.info(f"QC Delete Recipe: {qc_delete_query}")
            await get_query_with_pool(qc_delete_query)
            app_log.info("Deleted Successfully")

            data["rfg"] = 2
            data["cur_rfg"] = 1
            rfg_update_query = self.queries["update_rfg"].format(**data)
            app_log.info(f"Updating rfg query: {rfg_update_query}")
            await get_query_with_pool(rfg_update_query)

        except Exception as e:
            app_log.exception(e)
            return {"error": "Something went wrong"}

        return {"msg": "QC Recipe Deleted"}
