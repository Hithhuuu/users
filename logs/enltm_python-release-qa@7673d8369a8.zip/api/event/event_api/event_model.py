import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import (
    queries,
    get_logger,
)

app_log = get_logger("eventlogging")


class EventLogging:
    """This class provides methods to get/add events in timetrend"""

    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["event"]

    async def create(self, data):
        """To create the events for a particular tool"""
        try:
            query_data = {}
            if not (
                data.get("inspectiontoolid")
                and data.get("activitytype")
                and data.get("eventdate")
            ):
                raise Exception("Values are missing")

            query_data["inspectiontoolid"] = data.get("inspectiontoolid")
            query_data["activitytype"] = data.get("activitytype")
            query_data["eventdt"] = data.get("eventdate")
            query_data["comment"] = data.get("comment", "")
            query_data["id"] = data.get("id", "")

            app_log.info("Check if event exist for that timestamp")
            check_query = self.queries["check_event"].format(**query_data)
            check_exist = await get_query_with_pool(check_query, "list")

            if check_exist[0][0] != 0 and query_data["id"] == "":
                return {
                    "error": "Activity already exist at the given time for the Tool"
                }

            if query_data["id"]:
                app_log.info(f"Deleting event {query_data['id']}")
                delete_query = self.queries["delete_event"].format(**query_data)
                await get_query_with_pool(delete_query)

            app_log.info("Creating event now")
            create_query = self.queries["add_event"].format(**query_data)
            await get_query_with_pool(create_query)

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return await self.get(data)

    async def delete(self, data):
        """Delete an event"""
        try:
            event_id = data.get("id", "")

            if event_id == "":
                raise Exception("Event id is missing")

            app_log.info(f"Deleting event {event_id}")
            delete_query = self.queries["delete_event"].format(**{"id": event_id})
            await get_query_with_pool(delete_query)
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return await self.get(data)

    async def get(self, data):
        """To fetch all the events"""
        try:
            query_data = {}
            data_output = {
                "data": [],
                "total": 0,
                "limit": data.get("limit", 10),
                "offset": data.get("offset", 0),
            }

            query_data["tools_cdtn"] = ""
            query_data["sort_order"] = "ORDER BY lower(inspectiontoolid) ASC"

            # Change inspectiontoolid to tool
            if data.get("tools", []):
                query_data[
                    "tools_cdtn"
                ] = f"AND inspectiontoolid IN {data.get('tools')}"

            if data.get("sort", {}):
                sort_query = []
                for sort_data in data.get("sort"):
                    sort_query.append(f"lower({sort_data['id']}) {sort_data['order']}")
                query_data["sort_order"] = f"ORDER BY {', '.join(sort_query)}"

            query_data[
                "limit"
            ] = f'LIMIT {data.get("offset", 0)},{data.get("limit", 10)}'

            app_log.info("Fetching events")
            get_events = self.queries["get_events"].format(**query_data)
            event_data = await get_query_with_pool(get_events)

            if len(event_data):
                data_output["total"] = int(event_data["total"].iloc[0])
                data_output["data"] = event_data.drop("total", axis=1).to_dict(
                    "records"
                )

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return data_output
