"""Handler to define and fetch QC recipe"""
import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from event_api.event_model import EventLogging
from api.utils.fastapi_app import app


router = APIRouter(tags=['Event'],dependencies=[Depends(verify_jwt)])


@router.post("/getevents")
async def get_events(body: dict):
    """On post request Create the new Event"""
    event = EventLogging()
    response = await event.get(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)


@router.post("/event")
async def post(request: Request, body: dict):
    """On post request Create the new Event"""
    event = EventLogging()
    response = await event.create(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)


@router.delete("/event")
async def delete(body: dict):
    """On post request Create the new Event"""
    event = EventLogging()
    response = await event.delete(body)
    if "error" in response:
        return JSONResponse(status_code=400, content=response)
    return JSONResponse(content=response)