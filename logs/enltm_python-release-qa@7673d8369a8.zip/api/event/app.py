from api.utils.fastapi_app import app
from api.event.event_api import event_handler


app.include_router(event_handler.router)
