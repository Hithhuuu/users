import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from api.utils.fastapi_app import get_query_with_pool
from utils.utils import (
    queries,
    get_logger,
)
from api.utils.common import make_query

app_log = get_logger("stacking")


class Stacking:
    def __init__(self):
        """Initializing User instance"""
        self.queries = queries["stacking"]
        self.pixel = 120
        self.stacking_limit = 20000

    async def get_offset(self, type, data, stacking_inputs, condition):
        if type == "diestacking":
            if (
                data["inputs"].get("waferView", "stack")
                and data["inputs"].get("waferView", "stack") != "multi1"
            ):
                stacking_inputs["offset_columns"] = self.queries[
                    "offset_columns_die"
                ].format(
                    **{
                        "xsite": f"xsite_{stacking_inputs['orientation']}",
                        "ysite": f"ysite_{stacking_inputs['orientation']}",
                        "orientation": stacking_inputs["orientation"],
                    }
                )
                stacking_inputs["offset"] = self.queries["offset_join"].format(
                    **{
                        "mapid": tuple(data["inputs"]["selectedruns"]),
                        "orientation": stacking_inputs["orientation"],
                        "header_cdtn": condition["header_cdtn"],
                        "defect_cdtn": condition["defect_cdtn"],
                    }
                )
            else:
                stacking_inputs["offset_columns"] = self.queries[
                    "no_offset_columns_die"
                ].format(
                    **{
                        "xsite": f"xsite_{stacking_inputs['orientation']}",
                        "ysite": f"ysite_{stacking_inputs['orientation']}",
                        "orientation": stacking_inputs["orientation"],
                    }
                )
                stacking_inputs["offset"] = ""
        elif type == "fieldstacking":
            if (
                data["inputs"].get("waferView", "stack")
                and data["inputs"].get("waferView", "stack") != "multi1"
            ):
                stacking_inputs["offset_columns"] = self.queries[
                    "offset_columns_field"
                ].format(
                    **{
                        "xsite": f"xsite_{stacking_inputs['orientation']}",
                        "ysite": f"ysite_{stacking_inputs['orientation']}",
                        "orientation": stacking_inputs["orientation"],
                        "fieldx": stacking_inputs["fieldx"],
                        "fieldy": stacking_inputs["fieldy"],
                        "diepitch_x": stacking_inputs["diepitch_x"],
                        "diepitch_y": stacking_inputs["diepitch_y"],
                    }
                )
                stacking_inputs["offset"] = self.queries["offset_join"].format(
                    **{
                        "mapid": tuple(data["inputs"]["selectedruns"]),
                        "orientation": stacking_inputs["orientation"],
                        "header_cdtn": condition["header_cdtn"],
                        "defect_cdtn": condition["defect_cdtn"],
                    }
                )
            else:
                stacking_inputs["offset_columns"] = self.queries[
                    "no_offset_columns_field"
                ].format(
                    **{
                        "xsite": f"xsite_{stacking_inputs['orientation']}",
                        "ysite": f"ysite_{stacking_inputs['orientation']}",
                        "orientation": stacking_inputs["orientation"],
                        "fieldx": stacking_inputs["fieldx"],
                        "fieldy": stacking_inputs["fieldy"],
                        "diepitch_x": stacking_inputs["diepitch_x"],
                        "diepitch_y": stacking_inputs["diepitch_y"],
                    }
                )
                stacking_inputs["offset"] = ""

    async def prepare_query_inputs(self, condition, data, func_name=None):
        """
        Preparing stacking inputs for fetching stacking data,
        Updating query string with orientation.
        """
        inputs = data["inputs"]
        orientation = inputs.get("orientationmarklocation", "down").lower()
        mapid = inputs.get("selectedruns", [])

        """ Check if mapid is set or not. """
        if len(mapid) == 0:
            raise Exception("Please select at least one run.")

        """Fetching Master Map"""
        if inputs.get('tool'):
            tool = ['NA']
            tool.append(inputs.get('tool'))
            condition["tool"] = tool
            fetch_master_map = self.queries["fetch_master_map"].format(**condition)
            mmap = await get_query_with_pool(fetch_master_map, resp_type="list")

        else:
            mmap =[]

        mapid.append(mmap[0][0]) if len(mmap) else ""
        stacking_inputs = {
            "orientation": orientation,
            "shape_by": inputs["shape_by"],
            "volume_by": inputs["volume_by"],
            "mapid": tuple(mapid),
            "waferView": inputs.get("waferView", "stack"),
            "mmap": mmap[0][0] if len(mmap) else 0,
        }

        stacking_inputs.update(condition)

        """ Updating Input Data only for diestacking """
        if func_name == "diestacking":
            if inputs.get("xrel", None) and inputs.get("yrel", None):
                zoom_cdtn = (
                    f" AND (defect.xrel_{orientation} BETWEEN "
                    f"{inputs.get('xrel')['min']} AND {inputs.get('xrel')['max']})"
                    f" AND (defect.yrel_{orientation} BETWEEN "
                    f"{inputs.get('yrel')['min']} AND {inputs.get('yrel')['max']})"
                )
                stacking_inputs["defect_cdtn"] += zoom_cdtn
            stacking_inputs.update({"pixel": self.pixel})
            await self.get_offset("diestacking", data, stacking_inputs, condition)

        """ Updating Input Data only for fieldstacking """
        if func_name == "fieldstacking":
            stacking_inputs["zoom_cdtn"] = ""
            if inputs.get("fieldrelx", None) and inputs.get("fieldrely", None):
                zoom_cdtn = (
                    f" AND (fieldrelx BETWEEN "
                    f"{inputs.get('fieldrelx')['min']} AND {inputs.get('fieldrelx')['max']})"
                    f" AND (fieldrely BETWEEN "
                    f"{inputs.get('fieldrely')['min']} AND {inputs.get('fieldrely')['max']})"
                )
                stacking_inputs["zoom_cdtn"] = zoom_cdtn

            field_inputs = inputs.get("fieldstacking", {})
            stacking_inputs.update(field_inputs)
            stacking_inputs["diepitch_x"] = inputs["diepitch_x"]
            stacking_inputs["diepitch_y"] = inputs["diepitch_y"]
            await self.get_offset("fieldstacking", data, stacking_inputs, condition)

        return stacking_inputs

    async def get_fieldstacking(self, data):
        """Get the fieldstacking data based on the given inputs data"""
        try:
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            condition = make_query(data)

            """ Generating query inputs for making query """
            query_data = await self.prepare_query_inputs(
                condition, data, func_name="fieldstacking"
            )

            """ Fetching fieldstacking data start """
            query = self.queries["read_fieldstacking_level0"].format(**query_data)

            app_log.info(f"FIELD STACKING QUERY: {query}")
            response = await get_query_with_pool(query, resp_type="dict")

            """ Selecting query based on the data count """
            if len(response) > self.stacking_limit:
                query = self.queries["read_fieldstacking"].format(**query_data)
                response = await get_query_with_pool(query, resp_type="dict")
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return response

    async def get_diestacking(self, data):
        """Get the diestacking data based on the given inputs data"""
        try:
            data["filters"].pop("periodfilter", None)
            data["filters"]["gfilter"].pop("tool", None)
            """Generating query string with input data"""
            condition = make_query(data)

            """ Generating query inputs for making query """
            query_data = await self.prepare_query_inputs(
                condition, data, func_name="diestacking"
            )

            """ Calculating data count for diestacking """
            query = self.queries["read_diestacking_level0"].format(**query_data)

            response = await get_query_with_pool(query, resp_type="dict")
            """ Selecting query based on the data count """

            if len(response) > self.stacking_limit:
                query = self.queries["read_diestacking"].format(**query_data)
                response = await get_query_with_pool(query, resp_type="dict")

            app_log.info(f"DIE STACKING QUERY: {query}")

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return response

    async def update_field_values(self, data):
        """
        This function will update the fieldx, fieldy, fieldoriginx, fieldoriginy values for particular recipe
        """
        try:
            app_log.info(
                "Processing Update fieldx, fieldy, fieldoriginx and fieldoriginy"
            )
            query_data = data.get("inputs").get("fieldstacking")
            query_data["recipeid"] = tuple(
                data.get("filters").get("gfilter").get("recipeid").get("data")
            )
            query_data["product"] = tuple(
                data.get("filters").get("gfilter").get("product").get("data")
            )
            query_data["layer"] = tuple(
                data.get("filters").get("gfilter").get("layer").get("data")
            )
            app_log.info("Deleting the field values if exist ")
            field_query = self.queries["delete_fieldvalues"].format(**query_data)
            app_log.info(f"FIELD STACKING VALUES Delete QUERY: {field_query}")
            await get_query_with_pool(field_query, "")

            query_data["recipeid"] = query_data["recipeid"][0]
            query_data["product"] = query_data["product"][0]
            query_data["layer"] = query_data["layer"][0]
            field_query = self.queries["add_fieldvalues"].format(**query_data)
            app_log.info(f"FIELD STACKING VALUES Update QUERY: {field_query}")
            await get_query_with_pool(field_query, "")

            app_log.info(
                f"Fieldstacking values got updated for the recipe {query_data['recipeid']}"
            )
            data.get("inputs").get("fieldstacking").pop("recipeid")
            data.get("inputs").get("fieldstacking").pop("product")
            data.get("inputs").get("fieldstacking").pop("layer")
        except Exception as e:
            app_log.info(f"ERROR:{str(e)}")
            return {"error": str(e)}
        return {"fieldconfig": data.get("inputs").get("fieldstacking", {})}
