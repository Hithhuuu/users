"""Handler for stacking api"""
import os
import sys

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.utils.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from stacking_api.stacking_model import Stacking


router = APIRouter(tags=['Stacking'],dependencies=[Depends(verify_jwt)])
stacking = Stacking()


@router.post("/stacking")
async def fieldstacking(request: Request, body: dict):
    """Get fieldstacking data based on user inputs"""
    resp = await stacking.get_fieldstacking(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/diestacking")
async def diestacking(request: Request, body: dict):
    """Get fieldstacking data based on user inputs"""
    resp = await stacking.get_diestacking(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.put("/stacking")
async def fieldconfig(request: Request, body: dict):
    """Update field config data based on user inputs"""
    resp = await stacking.update_field_values(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)
