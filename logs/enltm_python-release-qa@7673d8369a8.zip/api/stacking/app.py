from api.utils.fastapi_app import app
from api.stacking.stacking_api import stacking_handler


app.include_router(stacking_handler.router)
