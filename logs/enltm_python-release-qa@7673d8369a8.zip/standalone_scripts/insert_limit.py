import os
import sys
import yaml
import pandas as pd
import itertools
import asyncio



sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.utils import get_async_connection_pool


async def insert_control_limit():
    limit_dict = {
        "dc": "dc",
        "cr": "cr",
        "gr": "gr",
        "vl": "vl",
        "slf": "sf",
        "tlf": "tf"
    }
    path = os.path.abspath(os.getcwd())
    query_file = path + "/standalone_scripts/limit.yaml"
    with open(query_file) as file:
        queries = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()

    for key in limit_dict.keys():
        query_data = {}
        query_data['kpi'] = key
        query_data['timetrend'] = limit_dict[key]
        insert_limit_query = queries['insert_control_limit'].format(**query_data)
        await execute_query(insert_limit_query)
        print(f"Inserted {key} control limits")

async def execute_query(query, resp_type="df"):
    try:
        get_pool = await get_async_connection_pool()
        conn =  await get_pool.acquire()
        memory_executor_settings = ["4G", "10G"]
        async with conn.cursor() as cur:
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")

            if resp_type != "None":
                data = await cur.fetchall()
                col = cur._columns
                if resp_type == "df":
                    data = pd.DataFrame(data, columns=col)
                elif resp_type == "dict":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(col), row)),
                            data,
                        )
                    )
                    if len(data) != 0:
                        data = [
                            {
                                k: " ".join(val.split("\x00")).strip()
                                if isinstance(val, str)
                                else val
                                for k, val in d.items()
                            }
                            for d in data
                        ]
                await get_pool.release(conn)
                return data
            await get_pool.release(conn)
    except Exception as err:
        await get_pool.release(conn)
        raise err

if __name__ == "__main__":
    asyncio.run(insert_control_limit())
