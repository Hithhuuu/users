import os
import sys
import yaml
import pandas as pd
import itertools
import asyncio



sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from api.utils.utils import execute_query

async def limit_calculate():
    query_data = {}
    path = os.path.abspath(os.getcwd())
    query_file = path + "/standalone_scripts/limit.yaml"
    with open(query_file) as file:
        queries = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()

    limit_query = queries['auto_limit']
    limit_df = (await execute_query(query=limit_query, resp_type="df"))[["product", "layer", "recipeid","tool" ,"dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]
    limit_df = limit_df.fillna("NULL")
    limit_list = [tuple(row) for row in limit_df.values]
    if len(limit_list):
        query_data['values'] = ','.join([str(item) for item in limit_list])
        query_data['values'].replace("'NULL'", 'NULL')
        save_limit = queries['insert_limit'].format(**query_data)
        await execute_query(save_limit)

        auto_limit_ss_df = (await execute_query(queries['auto_limit_ss'],"df"))[["product", "layer", "recipeid", "tool","scanset","dc_lcl", "dc_ucl","dc_base", "cr_lcl", "cr_ucl","cr_base","vl_lcl", "vl_ucl", "vl_base", "gr_lcl", "gr_ucl", "gr_base", "sl_lcl", "sl_ucl", "sl_base", "tl_lcl", "tl_ucl", "tl_base"]]
        auto_limit_ss_df = auto_limit_ss_df.fillna("NULL")
        auto_limit_list_ss = [tuple(row) for row in auto_limit_ss_df.values]
        query_data['values'] = ','.join([str(item) for item in auto_limit_list_ss])
        query_data['values'].replace("'NULL'", 'NULL')
        save_limit_ss = queries['insert_limit_ss'].format(**query_data)
        await execute_query(save_limit_ss)
        print("Inserting done")
        return True
    else:
        print("No value to insert")




if __name__ == "__main__":
    asyncio.run(limit_calculate())
