from datetime import datetime, timedelta
from fastapi import Depends, HTTPException
from passlib.context import CryptContext
from jose import JWTError, jwt



def hash_password(password):
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    hashed_str = pwd_context.hash(password)
    return hashed_str


def get_token(userid):
    token = jwt.encode({"sub": userid, "exp": datetime.utcnow() + timedelta(minutes