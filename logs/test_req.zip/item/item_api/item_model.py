from utils import get_logger, get_db_connection
from item_api.item_schema import Item


class ItemModel():
    def __init__(self):
        self.app_log = get_logger("item")
        self.conn = get_db_connection()

    def create_item(self, item):
        try:
            self.app_log.info("Adding new items to db")
            cursor = self.conn.cursor()
            breakpoint()
            cursor.execute("Insert into item_book (item_name, item_price) values (?, ?)", (item.item_name, item.item_price))
            self.conn.commit()
            cursor.close()
            return {"Status": "Item Added Successfully"}
        except Exception as err:
            self.app_log.error(f"Error while creating item: {err}")
            return {"error": "Error while creating item"}

    def get_item(self):
        try:
            self.app_log.info("Getting Items from the db")
            cursor = self.conn.cursor()
            cursor.execute("Select * from item_book")
            columns = [desc[0] for desc in cursor.description]
            items = [dict(zip(columns, row)) for row in cursor.fetchall()]
            cursor.close()
            return items
        except Exception as err:
            self.app_log.error(f"Error while getting item: {err}")
            return {"error": "Error while getting item"}

    def get_summray(self):
        try:
            self.app_log.info("Getting Items from the db")
            cursor = self.conn.cursor()
            cursor.execute("Select sum(item_price) from item_book")
            item_total = cursor.fetchone()
            cursor.close()
            if item_total:
                return {'item_total': item_total[0]}
            else:
                return {'item_total': 0}
        except Exception as err:
            self.app_log.error(f"Error while getting item summary: {err}")
            return {"error":"Error while getting item"}

    def auth(self,login):
        try:
            self.app_log.info("Authenticating user")
            cursor = self.conn.cursor()
            hash_password =
            cursor.execute("Select * from user where userid = ?", (login.userid))
            user = cursor.fetchone()

            cursor.close()
            if user:
                return {"Status": "User Authenticated"}
            else:
                return {"error": "Invalid Credentials"}
        except Exception as err:
            self.app_log.error(f"Error while authenticating user: {err}")
            return {"error":"Error while authenticating user"}




