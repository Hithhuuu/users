from fastapi import APIRouter
from fastapi.responses import JSONResponse
from typing import List

#Importing the pydantic schema and the Item model class
from item_api.item_schema import Item, Login
from item_api.item_model import ItemModel

router = APIRouter(prefix="/item")

item_model = ItemModel()

@router.post("/auth")
async def auth(login: Login):
    resp = item_model.auth(login)
    if "error" in resp:
        return JSONResponse(resp, status_code=400)
    return JSONResponse(resp)

@router.post("/create_item")
async def create_item(item: Item):
    resp = item_model.create_item(item)
    if "error" in resp:
        return JSONResponse(resp, status_code=400)
    return JSONResponse(resp)

@router.get("")
async def get_item():
    resp = item_model.get_item()
    if "error" in resp:
        return JSONResponse(resp, status_code=400)
    return JSONResponse(resp)

@router.get('/summary')
async def get_summary():
    resp = item_model.get_summray()
    if "error" in resp:
        return JSONResponse(resp, status_code=400)
    return JSONResponse(resp)