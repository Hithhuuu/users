import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from item_api.item_handler import router

app = FastAPI()
app.include_router(router)

template = Jinja2Templates(directory="item/templates")

app.mount("/static", StaticFiles(directory="item/static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

@app.get('/', response_class=HTMLResponse)
async def read_root(request: Request):
    return template.TemplateResponse("index.html", {"request": request})

@app.get('/summary', response_class=HTMLResponse)
async def read_summary(request: Request):
    return template.TemplateResponse("summary.html", {"request": request})

if __name__ == '__main__':
    uvicorn.run(app, host='localhost', port=9020)