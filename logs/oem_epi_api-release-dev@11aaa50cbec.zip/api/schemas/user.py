from pydantic import BaseModel

class CreateUser(BaseModel):
    user_fullname:str
    user_email:str
    role:str
    