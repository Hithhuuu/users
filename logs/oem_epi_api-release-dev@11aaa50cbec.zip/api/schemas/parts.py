from pydantic import BaseModel
from datetime import datetime


class CreateRequestset(BaseModel):
    partnumber: str
    mfgname_partnumber: str | None
    demand: str | None
    demandBU: str | None
    quantity: int | None | str
    isactive: int | str


class RequestSubmitted(BaseModel):
    msg: str
    requestid: int


class RequestSet(CreateRequestset):
    requestid: int
    created_datetime: datetime
    created_by: str | None
    lastupddatetsmp: datetime
    alternatepartnumber : str | None
    matchcatgtype: str | None
    alternatepartnumstr : str | None
    rejectreason: str | None

class RequestForm(BaseModel):
    requestid: int
    requested_by: str
    status: str
    created_datetime: datetime
    created_by: str
    lastupddatetsmp: datetime
    totalset: int
    assigned_to_name: str | None
    assigned_by_name: str | None
    dea_name: str | None
    rejectreason:str | None

class SetAlternate(BaseModel):
    partnumber: str
    alternatepartnumber: dict

class Evalute(BaseModel):
    partnumber: str
    acceptedpartnum: list | None
    rejectedpartnum: list | None
    rejectreason: str | None

class RequestAssign(BaseModel):
    assigned_to_name: str | None
    assigned_to_email: str | None
    dea_name: str | None
    dea_email: str | None

class Closepart(BaseModel):
    reason: str| None