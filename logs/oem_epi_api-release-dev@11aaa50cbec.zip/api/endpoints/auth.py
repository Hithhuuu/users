from fastapi import APIRouter, Request, HTTPException, Depends
from ldap3 import Server, Connection, SAFE_SYNC,ALL
from api.schemas import user
from api.utility.dependency import has_only_admin_access
from api.utility.splunk import logger
from api.utility.utils import config

router = APIRouter()
@router.get('/check_access')
async def check_teamcenter_access(request:Request):
    try:
        data = request.state.security_context
        return data
    except Exception as e:
        logger.error('Error in check teamcenter access')
        raise HTTPException(status_code=400, detail=str(e))

@router.get('/list')
async def list_user(type:str = None):
    try:
        server = Server('ldaps://austad-prd.amat.com', port=636)
        #server = Server('ldaps://amat.com')
        username = config['USERLDAP']
        passwordldap = config['PASSWORDLDAP']
        conn = Connection(
            server, user=username, password=passwordldap, client_strategy=SAFE_SYNC, check_names = False,
            raise_exceptions = False, authentication='SIMPLE'
        )
        conn.open()
        conn.start_tls()
        conn.bind()
        print(conn)
        logger.info(f'ldap result {conn.result=}')

        searchbase= 'DC=amat,DC=com'

        groupname = type
        searchfilter = f'(&(objectClass=user)(memberOf=CN={groupname},OU=Groups,OU=Managed Objects,DC=amat,DC=com))'


        status, _, result, _ = conn.search(search_base=searchbase, search_filter=searchfilter, attributes=["mail", "displayName"])
        users = []
        print(status)
        if status == True:
            for user in result:
                if user and user.get('attributes'):
                    attributes = user.get('attributes')
                    users.append({'user_fullname':attributes['displayName'][0], 'user_email':attributes['mail'][0]})
        return users
    except Exception as e:
        logger.error(f'Error in user listing gettind data from ldap{e=}')
        raise HTTPException(status_code=400, detail=f'Error in user listing {username=}{passwordldap=}{e=}{conn.result=}')
