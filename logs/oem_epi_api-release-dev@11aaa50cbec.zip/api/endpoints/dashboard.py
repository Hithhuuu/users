from copy import copy
import calendar
from itertools import zip_longest
from fastapi import APIRouter, HTTPException, Depends
from api.models.dashboard import Dashboard
from api.utility.splunk import logger
from api.config.settings import setting
from api.utility.utils import get_start_enddate
from api.utility.dependency import has_only_admin_access

router = APIRouter()

@router.get('', dependencies=[Depends(has_only_admin_access)])
async def dashboard_numbers(requestid: int = None, fromdate:str=None, todate:str=None):
    dashboard = Dashboard()
    try:
        results = dashboard.count_auto_vs_man_parts(requestid, fromdate, todate)
        output = {}
        for item in results:
            output[item['part_type']] = item['count']
        results2 = dashboard.dashboard_counts(requestid, fromdate, todate)
        results2 = results2 if results2 else {}
        output.update(results2)
        return output
    except Exception as e:
        print(e)
        logger.error(f'Error in dashboard counts {e=}')
        raise HTTPException(status_code=400, detail='Some error occured')


@router.get('/countbuwise', dependencies=[Depends(has_only_admin_access)])
async def count_buwise(requestid:int = None, fromdate:str = None, todate:str = None):
    try:
        dashboard = Dashboard()
        results = dashboard.count_buwise(requestid, fromdate, todate)
        output = []
        demand_bu_present_in_db = set()
        for item in results:
            if item['demandBU'] not in setting.DEMAND_BU:
                item['demandBU'] = 'Other'
            demand_bu_present_in_db.add(item['demandBU'])
            data = next((obj for obj in output if obj['y'] == item['demandBU']), {})
            if not data:
                data = {'y':item['demandBU'], 'x':0, 'z':0}
                output.append(data)
            data['x'] += item['totalpartreq']
            data['z'] += item['totalpartapprove']
        notpresentkey = setting.DEMAND_BU.difference(demand_bu_present_in_db)
        for key in notpresentkey:
            output.append({'y':key, 'x':0, 'z':0})
        return output
    except Exception as e:
        logger.error(f'Error in dashboard count approved buwise parts bu wise {e=}')
        raise HTTPException(status_code=400, detail='Some error occured')

@router.get('/reqlifecycle', dependencies=[Depends(has_only_admin_access)])
async def avg_req_lifecycle(requestid:int = None, fromdate:str = None, todate:str = None):
    try:
        dashboard = Dashboard()
        allkeys = {"Assignment", "Configured", "Evalution", "Completion"}
        results = dashboard.avg_req_lifecycle(requestid, fromdate, todate)
        notpresents = allkeys.difference(results.keys())
        for key in notpresents:
            results[key] = 0
        data = []
        totalhours = sum(value for value in results.values() if value)
        colors = ['#fe9b35', '#df3d6e', '#b34afc', '#5793f3']
        for index, key in enumerate(results):
            value = 0 if not results.get(key) or not totalhours else int(results[key]/totalhours * 100)
            data.append({
                "name":key+ ' % ',
                "value":value,
                "sliceColor": colors[index]
            })
        return data
    except Exception as e:
        logger.error(f'Error in dashboard count approved vs rejected  parts bu wise {e=}')
        raise HTTPException(status_code=400, detail=f'Some error occured')

@router.get('/groupbar', dependencies=[Depends(has_only_admin_access)])
async def group_bar(requestid:int = None, fromdate:str = None, todate:str = None):
    try:
        dashboard = Dashboard()
        notconfigured, configured, approved, rejected, completed = dashboard.count_buwisegroup(requestid, fromdate, todate)
        output = []
        all_bu = copy(setting.DEMAND_BU)
        all_bu.remove('Other')
        for bu in all_bu:
            output.append({'x':bu, 'y':[0, 0 , 0, 0, 0]})
        final = {'x':'Other', 'y':[0,0,0,0,0]}
        for item in zip_longest(notconfigured, configured, approved, rejected, completed):
            item = list(item)
            for i in range(5):
                if item[i]:
                    if item[i]['demandBU'] not in all_bu:
                        final['y'][i]+=item[i]['countparts']
                    data = next((obj for obj in output if obj['x'] == item[i]['demandBU']), {})
                    if not data:
                        continue
                    data['y'][i]+=item[i]['countparts']
        output.append(final)
        return output
    except Exception as e:
        logger.error(f'Error in dashboard count approved buwise parts bu wise {e=}')
        raise HTTPException(status_code=400, detail=f'Some error occured {e=}')

@router.get('/reqlifecycletable', dependencies=[Depends(has_only_admin_access)])
async def reqlifecycletable(year:int, quarter:int=None, month:int=None, bu:str=None):
    try:
        start_date, end_date = get_start_enddate(year, quarter, month)
        dashboard = Dashboard()
        print(start_date, end_date)
        logger.info(f'Req lifecycltable {start_date} {end_date}')
        results = dashboard.req_lifecycle_table(start_date, end_date, bu, year, quarter, month)
        output = []
        for result in results:
            update = True
            data = {}
            result = { key:( 0 if value is None else value) for key,value in result.items()}
            result['overall'] = sum([result['Admin'], result['Engineer'], result['Approver'], result['Requestor']])
            if result.get('date'):
                data['fiscal_period'] = f"{result['date']}"
                del result['date']
            elif quarter is not None and result.get('month'):
                data['fiscal_period'] = calendar.month_name[result['month']]
                del result['month']
            elif year:
                result_month = result['month']
                fquarter = ''
                if result_month in {11,12,1}:
                    fquarter = 'Q1'
                elif result_month in {2,3,4}:
                    fquarter = 'Q2'
                elif result_month in {5,6,7}:
                    fquarter = 'Q3'
                elif result_month in {8, 9, 10}:
                    fquarter = 'Q4'
                data['fiscal_period'] = f'FY{year}-{fquarter}'
                del result['month']
                for tdata in output:
                    if tdata['fiscal_period'] == data['fiscal_period']:
                        update = False
                        tdata['totalrequest']+= result['totalrequest']
                        tdata['Admin'] = (tdata['Admin']+result['Admin'])
                        tdata['Engineer'] = (tdata['Engineer']+result['Engineer'])
                        tdata['Approver'] = (tdata['Approver'] + result['Approver'])
                        tdata['Requestor'] = (tdata['Requestor'] + result['Requestor'])
                        tdata['overall'] = (tdata['overall']) + result['overall']
            if update:
                data.update(result)
                output.append(data)
        return output
    except Exception as e:
        logger.error(f'Error in dashboard count approved buwise parts bu wise {e=}')
        raise HTTPException(status_code=400, detail=f'Some error occured {e=}')
