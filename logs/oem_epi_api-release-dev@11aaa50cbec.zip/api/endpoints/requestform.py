from typing import Any
import time
from fastapi import APIRouter, HTTPException, Request, Depends
from api.schemas import parts
from api.utility.dependency import has_admin_access, has_only_admin_access, has_only_requestor_access
from api.models.requestdetail import Requestdetail
from api.models.requestform import Requestform
from api.models.partcompare import Partcompare
from api.utility.splunk import logger

router = APIRouter()

@router.get("/validate")
async def validate_part(partno: str) -> Any:
    requestform = Requestform()
    logger.info(f'Validating and getting mfg name {partno=}')
    result = requestform.get_mfg_name(partno)
    if not result:
        logger.warn(f'Not a valid part {partno=}')
        raise HTTPException(status_code=400, detail="Part number not valid")
    return result

@router.post("/getmfg")
async def getmfg(partno: list) -> Any:
    try:
        if not partno:
            raise HTTPException(status_code=400, detail='No Parts Provided')
        requestform = Requestform()
        result = requestform.get_mfg_list(partno)
        successparts = set(partobj['amatpartnum'] for partobj in result)
        for part in partno:
            if part not in successparts:
                result.append({'amatpartno':part,'error':'Invalid part no'})
        return result
    except Exception as e:
        logger.error(f'get mfg post error {e=}')
        raise HTTPException(status_code = 400, detail=f"get mfg error {e=}")

@router.get("", response_model=list[parts.RequestForm])
async def get_listing(request : Request, status: str | None = None) -> Any:
    requestform = Requestform()
    loggeduser = request.state.security_context
    try:
        return requestform.get_listing(loggeduser, status)
    except Exception as e:
        logger.error(f'request listing error {e=}')
        raise HTTPException(status_code=400, detail='Request listing issue')


@router.get("/count")
async def get_count(request:Request) -> Any:
    user = request.state.security_context
    requestform = Requestform()
    try:
        counts = requestform.count(user)
        allkeys = {'unassigned','inprogress', 'completed', 'all', 'approved', 'rejected'}
        output = {}
        for item in counts:
           output[item['status']] = item['count']
           output['all'] = item['count'] + output.get('all', 0)
        notpresetkeys = allkeys.difference(output)
        for notpresetkey in notpresetkeys:
            output[notpresetkey] = 0
        return output
    except Exception as e:
        logger.error(f'Error in count api {e=}')
        raise HTTPException(status_code=400, detail='Some error occured')


@router.get("/{requestid}/detail", response_model=list[parts.RequestSet])
async def get_detail(requestid: int) -> Any:
    from api.models.setalternate import Setalternate
    requestdetail = Requestdetail()
    setalternate = Setalternate()
    try:
        logger.info(f'getting detail of {requestid=}')
        details = requestdetail.getrequestdetails(requestid)
        for reqdetail in details:
            reqdetail['alternatepartnumstr'] = ''
            allpartnums = setalternate.get_evaluated_parts(requestid, reqdetail['partnumber'])
            partnumbers = map(lambda obj: obj['alternatepartnumber'], allpartnums)
            reqdetail['alternatepartnumstr'] = ','.join(partnumbers)
        return details
    except Exception as e:
        logger.error(f'error occured in getting detail of {requestid=}')
        raise HTTPException(status_code=400, detail='Error occured')


@router.put("/{requestid}/assign", dependencies=[Depends(has_admin_access)])
async def assign_request(request:Request, requestid: int, assigndata:parts.RequestAssign) -> Any:
    requestform = Requestform()
    user = request.state.security_context
    try:
        return requestform.assign(requestid, dict(
            assigndata, assigned_by_name= user['firstname']+' '+user['lastname'],
            assigned_by_email = user['email']
         ))
    except Exception as e:
        logger.error(f'Error occured in assign request {requestid=} {assigndata=} {e=}')
        raise HTTPException(status_code=400, detail=f'Error occured in assign {e=}')

@router.put("/{requestid}/acknowledge", dependencies=[Depends(has_only_requestor_access)])
async def acknowledge_request(request:Request, requestid: int) -> Any:
    requestform = Requestform()
    user = request.state.security_context
    try:
        requestform.acknowledge(requestid, user['email'])
        return {'detail':'Succcess'}
    except Exception as e:
        logger.error(f'Error occured in acknowledge request {requestid=} ')
        raise HTTPException(status_code=400, detail=f'Error occured in acknowledge request {e=}')


@router.post("", response_model=parts.RequestSubmitted)
async def create_request(request:Request, items: list[parts.CreateRequestset]) -> Any:
    requestdetail = Requestdetail()
    user = request.state.security_context
    data = {
        "created_by": f"{user.get('firstname')} {user.get('lastname', '')}",
        "status": "unassigned",
        "requested_by": f"{user.get('firstname')} {user.get('lastname', '')}",
        "requestor_email":user['email']
    }
    try:
        requestid = requestdetail.create(items, data)
        return {"msg": "Request Submitted", "requestid": requestid}
    except Exception as e:
        logger.error(f'Error occured in creating request {e=}')
        raise HTTPException(status_code=400, detail='Some Error occured')


@router.get("/{partno}/matches", dependencies=[Depends(has_admin_access)])
async def find_matches(partno: str) -> Any:
    partcompare = Partcompare()
    try:
        logger.info(f'finding alternatepart of {partno=}')
        print(f'finding part detail for self start time = {time.time()}')
        partdetail = partcompare.get_part_detail(partno)
        print(f'fetched part detail end time = {time.time()}')
        partdetaildict = {
            'partnumber':partno,
            'matchcatgtype':'',
            'status':'',
            'Item Description': '',
            'Mfg-PartNo @ Mfg-Name':'',
            'STANDARDIZATION':'',
            'ORGANIZATION':'',
        }
        for item in partdetail:
            partdetaildict[item['rqstdparmname']] = item['comparedparmval']
        print(f'trying to get match part numbers {time.time()}')
        matches = partcompare.get_matches(partno)
        print(f'found match part numbers end time {time.time()}')
        output = []
        output.append(partdetaildict)
        fullobj = set()
        if matches:
            for match in matches:
                tdata = next((item for item in output if item.get('partnumber')==match['comparedpartnum']), {})
                if not tdata:
                    tdata = {'partnumber':match["comparedpartnum"]}
                    output.append(tdata)
                fullobj.add(match['rqstdparmname'])
                tdata[match['rqstdparmname']] = match['comparedparmval']
                tdata['matchcatgtype'] = match['matchcatgtype']
                tdata['status'] = match['comparedpartnumstatus']
        for data in output:
            notpresetkeys = fullobj.difference(data.keys())
            for key in notpresetkeys:
                data[key] = None
        return output
    except Exception as e:
        logger.error(f'Error occured while finding alternate of {partno=} {e=}')
        raise HTTPException(status_code=400, detail='Some Error Occured')


@router.post('/{requestid}/{partno}/close', dependencies=[Depends(has_admin_access)])
async def close_part(requestid:int, partno:str, data:parts.Closepart) -> Any:
    try:
        requestdetail = Requestdetail()
        requestdetail.update_status(requestid, partno, 5, data.reason)
        return {'detail':'Success'}
    except Exception as e:
        logger.error(f'Error occured while closing parts {partno=} {e=}')
        raise HTTPException(status_code=400, detail=f'Some Error Occured {e=}')