import json
from fastapi import APIRouter, Request, Depends, HTTPException
from api.utility.dependency import has_admin_access, has_only_dea_access
from api.schemas import parts
from api.models.setalternate import Setalternate
from api.models.partcompare import Partcompare
from api.utility.splunk import logger
from typing import Any

router = APIRouter()

@router.post('/{requestid}', dependencies=[Depends(has_admin_access)])
async def set_alternate(request:Request, requestid:int, alternate: parts.SetAlternate) -> Any:
    setalternate = Setalternate()
    partcompare = Partcompare()
    user = request.state.security_context
    try:
        partdetail = partcompare.get_part_detail(alternate.partnumber)
        partdetaildict = {
            'partnumber':alternate.partnumber,
            'matchcatgtype':'',
            'Item Description': '',
            'Mfg-PartNo @ Mfg-Name':'',
            'STANDARDIZATION':'',
            'ORGANIZATION':'',
        }
        for item in partdetail:
            partdetaildict[item['rqstdparmname']] = item['comparedparmval']
        setalternate.removealternatepart(requestid, dict(alternate))
        setalternate.setalternate(requestid, dict(alternate), user, json.dumps(partdetaildict))
        return {'detail':'Success'}
    except Exception as e:
        logger.warn(f'Error occured in setting alternatepart {requestid=} {e=}')
        raise HTTPException(status_code=400, detail=f'Error occured {e=}')

@router.get('/{requestid}/{partnumber}')
async def get_alternate(requestid:int, partnumber:str) -> Any:

    setalternate = Setalternate()
    try:
        logger.info(f'getting alternatepartno of {requestid=} {partnumber=}')
        results = setalternate.get_selected_parts(requestid, partnumber)
        output = []
        fullobj = set()
        if results:
            for part in results:
                result = json.loads(part['part_attributes'])
                if result['partnumber'] == partnumber:
                    output.insert(0, result)
                else:
                    output.append(result)
                fullobj = fullobj.union(result.keys())
        for data in output:
            notpresetkeys = fullobj.difference(data.keys())
            for key in notpresetkeys:
                data[key] = None
        return output
    except Exception as e:
        logger.error(f'Error occured while getting alt part no {requestid=} {e=}')
        raise HTTPException(status_code = 400, detail='Error occured')


@router.post('/{requestid}/evaluate', dependencies=[Depends(has_only_dea_access)])
async def evalute_parts(request:Request, requestid:int, data: parts.Evalute) -> Any:
    setalternate = Setalternate()
    try:
        setalternate.evalute(dict(data), requestid)
        return {'detail':'Success'}
    except Exception as e:
        logger.warn(f'Error occured in evalute alternatepart {requestid=} {e=}')
        raise HTTPException(status_code=400, detail=f'Error occured {e=}')

@router.get('/{requestid}/{partnumber}/evaluated', dependencies=[Depends(has_only_dea_access)])
async def evalute_parts(request:Request, requestid:int, partnumber:str) -> Any:
    setalternate = Setalternate()
    try:
        logger.info(f'getting alternatepartno of {requestid=} {partnumber=}')
        results = setalternate.get_evaluated_parts(requestid, partnumber)
        return results
    except Exception as e:
        logger.error(f'Error occured while getting evalutated part part no {requestid=} {e=}')
        raise HTTPException(status_code = 400, detail='Error occured in fetching evaluated parts')
