from api.utility.utils import connection_pool
from api.utility.queries import dashboardquery
from api.utility.splunk import logger

class Dashboard:
    def __init__(self):
        self.connection = connection_pool.connect()
        self.queries = dashboardquery

    def count_auto_vs_man_parts(self, requestid:int=None, fromdate:str=None, todate:str=None):
        cursor = self.connection.cursor(as_dict=True)
        query = self.queries['autovsmanpartscount']
        filtercond = ''
        if requestid:
            filtercond = f" and requestid = {requestid}"
        elif fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        query = query.replace('{filtercond}', filtercond)
        logger.info(f'dashboard auto vs man parts {query=}')
        cursor.execute(query)
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))

    def count_buwise(self, requestid:int = None, fromdate:str=None, todate:str=None):
        cursor = self.connection.cursor(as_dict=True)
        query = self.queries['countbuwise']
        filtercond = ''
        if requestid:
            filtercond = f" and requestid = {requestid}"
        elif fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        query = query.replace('{filtercond}', filtercond)
        logger.info(f'count bu wise {query=}')
        cursor.execute(query)
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))


    def count_buwisegroup(self, requestid:int = None, fromdate:str=None, todate:str=None):
        cursor = self.connection.cursor(as_dict=True)
        filtercond = ''
        if requestid:
            filtercond = f" and requestid = {requestid}"
        elif fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        query = self.queries['buwiseunconfigured']
        logger.info(f'count bu wise {query=}')
        cursor.execute(query.format(filtercond=filtercond))
        notconfigured = cursor.fetchall()

        query = self.queries['buwiseconfigured']
        logger.info(f'count bu wise {query=}')
        cursor.execute(query.format(filtercond=filtercond))
        configured = cursor.fetchall()

        query = self.queries['buwiseappr']
        logger.info(f'count bu wise {query=}')
        cursor.execute(query.format(filtercond=filtercond))
        approved = cursor.fetchall()

        query = self.queries['buwiserej']
        logger.info(f'count bu wise {query=}')
        cursor.execute(query.format(filtercond=filtercond))
        rejected = cursor.fetchall()

        query = self.queries['buwisecompl']
        logger.info(f'count bu wise {query=}')
        cursor.execute(query.format(filtercond=filtercond))
        completed = cursor.fetchall()
        return [notconfigured, configured, approved, rejected, completed]

    def avg_req_lifecycle(self, requestid:int=None, fromdate:str=None, todate:str=None):
        cursor = self.connection.cursor(as_dict=True)
        query = self.queries['reqlifecycleavg']
        filtercond = ''
        if requestid:
            filtercond = f" and requestid = {requestid}"
        elif fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        query = query.replace('{filtercond}', filtercond)
        logger.info(f'request life cycle {query=}')
        cursor.execute(query)
        results = cursor.fetchone()
        return results

    def dashboard_counts(self, requestid:int = None, fromdate:str=None, todate:str=None):
        cursor = self.connection.cursor(as_dict=True)
        query = self.queries['counts']
        filtercond = ''
        if requestid:
            filtercond = f" and requestid = {requestid}"
        elif fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        query = query.replace('{filtercond}', filtercond)
        logger.info(f'dashboard counts {query=}')
        cursor.execute(query)
        results = cursor.fetchone()
        return results

    def req_lifecycle_table(self, fromdate, todate, bu, year, quarter, month):
        cursor = self.connection.cursor(as_dict=True)
        query = self.queries['reqlifecycletable']
        filtercond = ''
        if fromdate and todate:
            filtercond = f" and created_datetime >= '{fromdate}' and created_datetime < '{todate}'"
        if year or quarter:
            selectcond = 'DATEPART(month, created_datetime) as month'
            groupbycond = 'DATEPART(month, created_datetime)'
        if month:
            selectcond = 'TRY_CONVERT(DATE, created_datetime) as date'
            groupbycond = 'TRY_CONVERT(DATE, created_datetime)'
        if bu:
            bus = bu.split(',')
            bustr = ','.join(map(lambda bu:f"'{bu}'", bus))
            filtercond += f" and requestid in (select requestid from oem_requestdetail or2 where demandBU in ({bustr}) and requestid = oem_request.requestid)"
        query = query.replace('{filtercond}', filtercond)
        query = query.replace('{selectcond}', selectcond)
        query = query.replace('{groupbycond}', groupbycond)
        logger.info(f'request life cycle {query=}')
        print(query)
        cursor.execute(query)
        results = cursor.fetchall()
        return results

    def __del__(self):
        self.connection.close()
