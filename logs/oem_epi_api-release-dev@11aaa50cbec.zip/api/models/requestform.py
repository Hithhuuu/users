from api.utility.utils import connection_pool
from api.utility.mail import Mail
from api.utility.queries import requestformqueries
from api.utility.role import Role
from api.utility.splunk import logger

class Requestform:
    def __init__(self) -> None:
        self.connection = connection_pool.connect()
        self.query = requestformqueries

    def get_mfg_name(self, partnumber):
        logger.info(f'Getting mfg name of {partnumber=}')
        cursor = self.connection.cursor()
        query = self.query["get_mfg_name"]
        logger.info(f'getting mfgname {query=} {partnumber=}')
        cursor.execute(query, {"amatpartnum":partnumber})
        result = cursor.fetchall()
        output = []
        for mfg in result:
            output.append(mfg[0])
        return output

    def get_mfg_list(self, partnumbers):
        logger.info(f'Getting mfg name of {partnumbers=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query["get_mfg_list"]
        partnumberstr = ','.join(map(lambda obj: f"'{obj}'", partnumbers))
        query = query.format(amatpartnum=partnumberstr)
        cursor.execute(query)
        results = cursor.fetchall()
        return list(map(lambda obj:dict(obj), results))

    def create_request(self, data:dict) -> int:
        cursor = self.connection.cursor()
        logger.info(f'creating a new request {data=}')
        query = self.query["create"]
        logger.info(f'creqte request {query=} {data=}')
        cursor.execute(query, data)
        self.connection.commit()
        requestid = cursor.lastrowid
        logger.info(f'request created {requestid=}')
        return int(requestid)

    def get_listing(self, userdata:dict,  status: str | None = None) -> int:
        cursor = self.connection.cursor(as_dict=True)
        logger.info(f'request getlistng {userdata=} {status=}')
        query = self.query["read"]
        rolecond = ''
        if userdata['role'] == Role.ADMIN:
            rolecond = ""
        elif userdata['role'] == Role.REQUESTOR:
            rolecond = f" where requestor_email = '{userdata['email']}' "
        elif userdata['role'] == Role.ENGINEER:
            rolecond =  f" where ( requestor_email = '{userdata['email']}' or assigned_to_email = '{userdata['email']}' )"
        elif userdata['role'] == Role.DEA:
            rolecond =  f" where ( requestor_email = '{userdata['email']}' or dea_email = '{userdata['email']}' )"
        joincond = '' if not rolecond else rolecond
        cond = joincond
        if status:
            cond =  joincond+f" and status = '{status}'"  if joincond else " where status = '{status}'"
        query = query.replace('{cond}', cond)
        logger.info(f'request listing {query=}')
        cursor.execute(query)
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))

    def update_status(self, requestid :int, status:str, reason:str = None, partno:str=None) -> bool:
        cursor = self.connection.cursor(as_dict=True)
        cursor.execute(self.query['update_status'], {"requestid":requestid, "status":status})
        rolecond = ' where requestid = %(requestid)s '
        query = self.query['read'].replace('{cond}', rolecond)
        cursor.execute(query, {"requestid":requestid})
        requestdetail = cursor.fetchone()
        cursor.execute(self.query['requestedparts'], {'requestid':requestid})
        partnumbers = cursor.fetchall()
        if status in {'approved', 'rejected'}:
            cursor.execute(self.query['updateevaldate'], {"requestid":requestid})
            mailengine = Mail()
            if status == 'approved':
                mailengine.send_mail_requestor_to_approved(
                    requestdetail['requestor_email'],
                    requestdetail['requested_by'],
                    requestid,
                    partnumbers
                )
            if status == 'rejected' and requestdetail['assigned_to_name']:
                mailengine.send_mail_engineer_for_rejected(
                    requestdetail['assigned_to_email'],
                    requestdetail['assigned_to_name'],
                    requestid,
                    partnumbers,
                    reason,
                    partno
                )
        if status == 'completed':
            mailengine.send_mail_requestor_for_completed(
                requestdetail['requestor_email'],
                requestdetail['requested_by'],
                requestid,
                partnumbers
            )
        self.connection.commit()
        return True

    def count(self, user:dict) -> list:
        cursor = self.connection.cursor(as_dict=True)
        logger.info(f'Counting requestlisting {user=}')
        query = self.query['count']
        rolecond = ''
        if user['role'] == Role.REQUESTOR :
            rolecond = f"where requestor_email = '{user['email']}'"
        elif user['role'] == Role.ENGINEER:
            rolecond = f" where ( requestor_email = '{user['email']}' or assigned_to_email = '{user['email']}' )"
        elif user['role'] == Role.DEA:
            rolecond =  f" where ( requestor_email = '{user['email']}' or dea_email = '{user['email']}' )"
        query = query.replace('{rolecond}', rolecond)
        logger.info(f'Count requestlisting {query=}')
        cursor.execute(query)
        results = cursor.fetchall()
        self.connection.commit()
        return list(map(lambda obj:dict(obj), results))

    def assign(self, requestid:int, assigndata:dict) -> list:
        cursor = self.connection.cursor(as_dict=True)
        logger.info(f'assiging {requestid=} {assigndata=}')
        data = dict(assigndata, requestid=requestid)
        mailengine = Mail()
        if assigndata.get('assigned_to_name') and assigndata.get('assigned_to_email'):
            query = self.query['assign_to']
            cursor.execute(query, data)
            cursor.execute(self.query['requestedparts'], {'requestid':requestid})
            partnumbers = cursor.fetchall()
            mailengine.send_mail_to_engineer(
                assigndata.get('assigned_to_email'),
                assigndata.get('assigned_to_name'),
                requestid,
                partnumbers
            )
        if assigndata.get('dea_name') and assigndata.get('dea_email'):
            query = self.query['assign_dea']
            cursor.execute(query, data)
            cursor.execute(self.query['requestedparts'], {'requestid':requestid})
            partnumbers = cursor.fetchall()
            mailengine.send_mail_to_dea(
                assigndata.get('dea_email'),
                assigndata.get('dea_name'),
                requestid,
                partnumbers
            )
        self.update_status(requestid, "inprogress")
        self.connection.commit()
        return True

    def acknowledge(self, requestid:int, requestor_email:str) -> bool:
        cursor = self.connection.cursor(as_dict=True)
        logger.info(f'ackknowledging  {requestid=} {requestor_email=}')
        query = self.query['acknowledge']
        cursor.execute(query, {"requestid":requestid, "email":requestor_email})
        self.connection.commit()
        return True

    def check_in_configured(self, requestid:int) -> bool:
        cursor = self.connection.cursor(as_dict=True)
        cursor.execute(self.query['configured'], {'requestid':requestid})
        resp = cursor.fetchone()
        cursor.execute(self.query['requestedpartsconfigured'], {'requestid':requestid})
        partnumbers = cursor.fetchall()
        if resp:
            cursor.execute(self.query['updateconfdate'], {'requestid':requestid})
            if resp['dea_name'] and resp['dea_email']:
                mailengine = Mail()
                resp['partno'] = partnumbers
                mailengine.send_mail_to_dea_on_req_configured(**resp)
            self.connection.commit()
        return True

    def __del__(self):
        self.connection.close()
