from typing import Any
from api.utility.utils  import connection_pool
from api.models.requestform import Requestform
from api.utility.queries import requestdetailqueries
from api.utility.splunk import logger


class Requestdetail():

    def __init__(self) -> None:
        self.connection = connection_pool.connect()
        self.query = requestdetailqueries


    def create(self, items:list, data:dict) -> int:
        logger.info(f'creating requestdetail {items=} {data=}')
        requestform = Requestform()
        requestid = requestform.create_request(data)
        cursor = self.connection.cursor()
        query = self.query['create']
        for item in items:
            logger.info(f'{query=} {requestid=}')
            cursor.execute(query, dict(
                    item.__dict__,
                    requestid=requestid,
                    created_by=data['created_by'],
                )
            )
        self.connection.commit()
        return requestid


    def getrequestdetails(self, requestid:int) -> list:
        logger.info(f'Getting requestdetail {requestid=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['readbyrequestid']
        cursor.execute(query, {"requestid":requestid})
        logger.info(f'request detail {query=} {requestid=}')
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))


    def update_status(self, requestid :int, partnumber:str, isactive:int, reason:str=None) -> bool:
        cursor = self.connection.cursor()
        logger.info(f'update status {requestid=} {partnumber=} {isactive=}')
        query = self.query['update_status']
        logger.info(f'status {query=} {requestid=} {isactive=}')
        data = {
            "requestid":requestid,
            "partnumber":partnumber,
            "isactive":isactive,
            "closereason":None
        }
        if isactive == 5:
            data['closereason'] = reason
        cursor.execute(query, data)
        self.connection.commit()
        requestform = Requestform()
        if isactive == 4:
            requestform.update_status(requestid, 'rejected', reason, partnumber)
        elif isactive in {3, 5}:
            cursor.execute(self.query['countunapprove'], {'requestid':requestid})
            result = cursor.fetchone()
            if result[0] <=0 :
                requestform.update_status(requestid, 'approved')
        return True


    def __del__(self) -> None:
        self.connection.close()