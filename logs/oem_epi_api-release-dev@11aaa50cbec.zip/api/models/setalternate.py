import json
from api.utility.utils import connection_pool
from api.models.requestdetail import Requestdetail
from api.models.requestform import Requestform
from api.utility.queries import alternatepartnumberqueries
from api.utility.splunk import logger
from api.utility.mail import Mail

class Setalternate:
    def __init__(self) -> None:
        self.connection = connection_pool.connect()
        self.query = alternatepartnumberqueries

    def setalternate(self, requestid:int, alternatedetail:dict, user:dict, part_attr:str) -> bool:
        logger.info(f'seeting alternatepart {requestid=}')
        cursor = self.connection.cursor()
        query = self.query['create']
        partnumber = alternatedetail['partnumber']
        alternatepartnumbers = alternatedetail['alternatepartnumber']
        valuestoinsert = []
        for alternatenumber, part_attributes in alternatepartnumbers.items():
            part_attrobj = json.loads(part_attributes)
            part_type = 'auto' if part_attrobj.get('matchcatgtype').lower() in {
                'type_b', 'type_a', 'type_c'
            } else 'manual'
            valuestoinsert.append({
                "requestid":requestid,
                "partnumber": partnumber,
                "alternatepartnumber":alternatenumber,
                "updatedbyemail":user['email'],
                "part_attributes":part_attributes,
                'part_type':part_type
            })
        valuestoinsert.append({
            "requestid":requestid,
            "partnumber": partnumber,
            "alternatepartnumber":None,
            "updatedbyemail":user['email'],
            "part_attributes":part_attr,
            'part_type':None
        })
        logger.info(f'setting alternate {query=}')
        cursor.executemany(query, valuestoinsert)
        self.connection.commit()
        requestform = Requestform()
        logger.info(f'request form updating status {requestid=}')
        requestform.update_status(requestid, "inprogress")
        requestdetail = Requestdetail()
        logger.info(f'request detail updating status {requestid=}')
        requestdetail.update_status(requestid, partnumber, 2)
        requestform.check_in_configured(requestid)
        return True

    def removealternatepart(self, requestid:int, alternatedetail:dict) -> bool:
        cursor = self.connection.cursor()
        logger.info(f'Removing alternate part {requestid=} {alternatedetail=}')
        query = self.query['remove']
        partnumber = alternatedetail['partnumber']
        logger.info(f'alternate remove {query=} {partnumber=} {requestid=}')
        cursor.execute(query, {'partnumber':partnumber, 'requestid':requestid})
        self.connection.commit()
        return True

    def get_selected_parts(self, requestid:int, partnumber:str) -> list:
        logger.info(f'getting selected part {requestid=} {partnumber=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['read']
        logger.info(f'selected part {query=} {requestid=} {partnumber=}')
        cursor.execute(query, {'requestid':requestid, 'partnumber':partnumber})
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))

    def evalute(self, data: dict, requestid:int):
        logger.info(f'Evaluating parts {requestid=}')
        cursor = self.connection.cursor()
        query = self.query['evalute']
        requestdetail = Requestdetail()
        cursor.execute(self.query['unevalute'], {
            'requestid':requestid,
            'partnumber':data.get('partnumber')
        })
        self.connection.commit()
        isactive = 2
        if data.get('acceptedpartnum'):
            alternatepartnumber = ', '.join(map(lambda obj: f"'{obj}'", data.get('acceptedpartnum')))
            datatoupdate = {
                'requestid':requestid,
                'status':'approved',
                'alternatepartnumber':alternatepartnumber,
                'rejectreason':None,
                'partnumber':data.get('partnumber')
            }
            isactive = 3
        elif (data.get('rejectedpartnum')):
            alternatepartnumber = ', '.join(map(lambda obj: f"'{obj}'", data.get('rejectedpartnum')))
            datatoupdate = {
                'requestid':requestid,
                'status':'rejected',
                'alternatepartnumber':alternatepartnumber,
                'rejectreason':data.get('rejectreason'),
                'partnumber':data.get('partnumber')
            }
            isactive = 4
        query = query.format(alternatepartnumber=datatoupdate.get('alternatepartnumber', ''))
        cursor.execute(query, datatoupdate)
        self.connection.commit()
        requestdetail.update_status(
            requestid,
            data.get('partnumber'),
            isactive,
            data.get('rejectreason')
        )
        return True


    def get_evaluated_parts(self, requestid:int, partnumber:str) -> list:
        logger.info(f'getting selected part {requestid=} {partnumber=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['evaluted_read']
        logger.info(f'evaluated part {query=} {requestid=} {partnumber=}')
        cursor.execute(query, {'requestid':requestid, 'partnumber':partnumber})
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))


    def __del__(self):
        self.connection.close()