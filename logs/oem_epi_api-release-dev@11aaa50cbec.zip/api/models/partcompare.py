from api.utility.utils  import connection_pool 
from api.utility.queries import partcomparequeries
from api.utility.splunk import logger


class Partcompare():
    
    def __init__(self) -> None:
        self.connection = connection_pool.connect()
        self.query = partcomparequeries


    def get_matches(self, partno:str):
        logger.info(f'find matches of {partno=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['match']
        logger.info(f'matches {query=} {partno=}')
        cursor.execute(query, {'partnumber':partno})
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))

    def get_part_detail(self, partno:str):
        logger.info(f'Getting part detail {partno=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['detail']
        cursor.execute(query, {"partnumber":partno})
        logger.info(f'detail {query=} {partno=}')
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))


    def get_selected_part_detail(self, requestid:int, partno:str):
        logger.info(f'getting selected part {requestid=} {partno=}')
        cursor = self.connection.cursor(as_dict=True)
        query = self.query['selecteddetail']
        logger.info(f'{query=} {partno=} {requestid=}')
        cursor.execute(query, {"partnumber":partno, "requestid":requestid})
        results = cursor.fetchall()
        return list(map(lambda obj: dict(obj), results))


    def __del__(self) -> None:
        self.connection.close()