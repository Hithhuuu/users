from pydantic import BaseSettings
from api.utility.utils import config

class Settings(BaseSettings):
    APP_NAME: str = 'OEM'
    OPENAPI_URL: str | None = config.get('OPENAPI_URI', None) 
    CORS_DISABLE: bool = True
    EMAIL_TEMPLATES :str = 'api/email_templates/'
    DEMAND_BU : set = {
        'AGS', 'AKT', 'ALD', 'CTO', 'CMP', 'CSG', 'DDP', 'ETCH', 'FEP', 'FSS',
        'MDP', 'Semitool', 'SRP', 'EPI', 'PVD', 'OLED', 'CVD', 'DLG', 'Other'
    }


setting = Settings()
