from fastapi import APIRouter
from api.endpoints import requestform, welcome, auth, setalternate, dashboard

api_router = APIRouter()

api_router.include_router(welcome.router, prefix='', tags=['Welcome'])
api_router.include_router(auth.router, prefix='/auth', tags=['Auth'])
api_router.include_router(requestform.router, prefix='/request', tags=['Request'])
api_router.include_router(setalternate.router, prefix='/alternate', tags=['Alternate'])
api_router.include_router(dashboard.router, prefix='/dashboard', tags=['Dashboard'])