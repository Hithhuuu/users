import os
from pathlib import Path
import sqlalchemy.pool as pool
from dotenv import dotenv_values, load_dotenv
import datetime
import pymssql
import calendar


def get_config():
    env_path = os.path.join(Path(__file__).parent.parent.parent, ".env/.{env}".format(
        env=os.environ.get("PYENV") or "local"
    ))


    load_dotenv(env_path)
    return os.environ


def get_dbconnection():
    """ Create db connection for clickhouse """
    config = get_config()
    cnn = pymssql.connect(
        config['DBSERVER'],
        config['DBUSERNAME'],
        config['DBPASSWORD'],
        config['DBNAME']
    )
    return cnn


def create_connection_pool():
    """Creates and returns a Connection Pool"""
    connection_pool = pool.QueuePool(get_dbconnection, max_overflow=50, pool_size=10)
    return connection_pool

def get_start_enddate(year:int, quarter:int=None, month:int=None):
    start_year = end_year = year
    start_date = datetime.datetime(year-1, 11, 1, 00, 00, 00)
    end_date = datetime.datetime(year, 10, 31, 23, 59, 59)
    if quarter == 1:
        start_year = year-1
        start_date = datetime.datetime(start_year, 11, 1, 00,00, 00)
        end_date = datetime.datetime(year, 1, 31, 23, 59, 59)
    elif quarter == 2:
        start_date = datetime.datetime(year, 2, 1, 00,00, 00)
        end_date = datetime.datetime(year, 4, 30, 23, 59, 59)
    elif quarter == 3:
        start_date = datetime.datetime(year, 5, 1, 00,00, 00)
        end_date = datetime.datetime(year, 7, 31, 23, 59, 59)
    elif quarter == 4:
        start_date = datetime.datetime(year, 8, 1, 00, 0, 00)
        end_date = datetime.datetime(year, 10, 31, 23, 59, 59)
    if month:
        year = start_year if quarter == 1 and month in {11, 12} else end_year
        month_range = calendar.monthrange(year, month)
        start_date = datetime.datetime(year, month, 1, 00,00,00)
        end_date = datetime.datetime(year, month, month_range[1], 23, 59, 59)
    return (start_date, end_date)


connection_pool = create_connection_pool()
config = get_config()
