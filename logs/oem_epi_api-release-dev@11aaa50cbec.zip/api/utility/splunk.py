import urllib3
import logging
import os
from pathlib import Path
from splunk_hec_handler import SplunkHecHandler

from api.utility.utils import config
urllib3.disable_warnings()

class Splunk:
    FORMATTER = logging.Formatter(
        "%(asctime)s — %(name)s — %(filename)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s"
    )
    _logger = None
    def __init__(self):
        self.SPLUNK_TOKEN = config.get('SPLUNK_TOKEN')
        self.SPLUNK_URL = config.get('SPLUNK_URL')
        self.SPLUNK_INDEX = config.get('SPLUNK_INDEX')
        self.SPLUNK_PORT = config.get('SPLUNK_PORT')
        self.SPLUNK_PROTO = config.get('SPLUNK_PROTO')
        self.SPLUNK_SOURCETYPE = config.get('SPLUNK_SOURCETYPE')
        self.SPLUNK_SOURCE = config.get('SPLUNK_SOURCE')


    def splunk_logging(self):
        if Splunk._logger is not None:
            return Splunk._logger
        if config.get('SPLUNK_LOGGING_ENABLE') in {'true', 'True'}:
            self.logger = logging.getLogger('SplunkHecHandlerExample')
            self.logger.setLevel(logging.INFO)
            splunk_handler = SplunkHecHandler(self.SPLUNK_URL,
                                            self.SPLUNK_TOKEN, index=self.SPLUNK_INDEX,
                                            port=self.SPLUNK_PORT, proto=self.SPLUNK_PROTO, ssl_verify=False,
                                            sourcetype=self.SPLUNK_SOURCETYPE, source=self.SPLUNK_SOURCE)
            splunk_handler.setFormatter(self.FORMATTER)
            self.logger.addHandler(splunk_handler)
            self.logger.propagate = False
            Splunk._logger = self.logger
            return self.logger

        self.logger = logging.getLogger('OEM')
        self.logger.setLevel(logging.INFO)
        logpath = os.path.join(
            Path(__file__).parent.parent.parent,
            'logs'
        )
        os.makedirs(logpath, mode=0o666, exist_ok = True)
        file_handler = logging.handlers.TimedRotatingFileHandler(
            os.path.join(logpath,'oem.log'),
            when='midnight'
        )
        file_handler.setFormatter(self.FORMATTER)
        self.logger.propagate = False
        self.logger.addHandler(file_handler)
        Splunk._logger = self.logger
        return self.logger

logger = Splunk().splunk_logging()