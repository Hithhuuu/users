import emails
import threading
from api.utility.utils import config
from emails.template import JinjaTemplate
from api.config.settings import setting
from pathlib import Path
from api.utility.splunk import logger

class Mail:

    def __init__(self):
        self.SMTP_HOST = config['SMTP_HOST']
        self.SMTP_PORT = config['SMTP_PORT']
        self.USE_TLS = False
        self.MAIL_FROM = ('OEM Notification', 'oem_noreply@amat.com')

    def sendmail(self, subject:str, message:str, to: str,  render_dict={}):
        message = emails.Message(subject=subject, html=JinjaTemplate(message), mail_from=self.MAIL_FROM)
        smtp_options = {}
        smtp_options['host'] = self.SMTP_HOST
        smtp_options['port'] = self.SMTP_PORT
        smtp_options['tls'] = self.USE_TLS
        to = [to]
        response = message.send(to=to, render=render_dict, smtp=smtp_options)
        if response.error:
            logger.error(f'sending email error {response.error}')
        return response

    def send_mail_to_engineer(self, engineer_email:str, engineer_name:str, requestid:str, partno:list):
        subject = 'Request Assigned | OEM'
        with open(Path(setting.EMAIL_TEMPLATES) / 'engineer.html', 'r') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, engineer_email),
            kwargs={'render_dict':{'name':engineer_name, 'requestid':requestid, 'partnumbers':partno}}
        ).start()
        return True


    def send_mail_to_dea(self, dea_email:str, dea_name:str, requestid:str, partno:list):
        subject = 'Request Assigned | OEM'
        with open(Path(setting.EMAIL_TEMPLATES) / 'dea.html', 'r') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, dea_email),
            kwargs={'render_dict':{'name':dea_name, 'requestid':requestid, 'partnumbers':partno}}
        ).start()
        return True

    def send_mail_to_dea_on_req_configured(self, dea_email:str, dea_name:str, requestid:str, partno:list):
        subject = 'Request Configured | OEM'
        with open(Path(setting.EMAIL_TEMPLATES) / 'dea_req_configured.html', 'r') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, dea_email),
            kwargs={'render_dict':{'name':dea_name, 'requestid':requestid, 'partnumbers':partno}}
        ).start()
        return True

    def send_mail_requestor_to_approved(self, req_email:str, req_name:str, requestid:str, partno:list):
        subject = 'Request Approved | OEM'
        message = ''
        with open(Path(setting.EMAIL_TEMPLATES) / 'request_approved.html') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, req_email),
            kwargs={'render_dict':{'name':req_name, 'requestid':requestid, 'partnumbers':partno}}
        ).start()
        return True

    def send_mail_engineer_for_rejected(self, eng_email:str, eng_name:str, requestid:str, partnos:list, reason:str, part:str):
        subject = 'Request Rejected | OEM'
        message = ''
        with open(Path(setting.EMAIL_TEMPLATES) / 'request_rejected.html') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, eng_email),
            kwargs={'render_dict':{
                'name':eng_name,
                'requestid':requestid,
                'partnumbers':partnos,
                'reason':reason,
                'rejectedpartnumber':part
            }}
        ).start()
        return True


    def send_mail_requestor_for_completed(self, req_email:str, req_name:str, requestid:str, partno:list):
        subject = 'Request completed | OEM'
        message = ''
        with open(Path(setting.EMAIL_TEMPLATES) / 'request_completed.html') as f:
            message = f.read()
        threading.Thread(
            target=self.sendmail,
            args =(subject, message, req_email),
            kwargs={'render_dict':{'name':req_name, 'requestid':requestid, 'partnumbers':partno}}
        ).start()
        return True