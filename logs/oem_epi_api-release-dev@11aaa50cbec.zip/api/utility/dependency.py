import jwt
from jwt import PyJWKClient
from fastapi import HTTPException, Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from .utils import config
from .role import Role
from api.utility.utils import connection_pool
from api.utility.queries import checkuser
from api.utility.splunk import logger

security = HTTPBearer()


async def has_access(request:Request, credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        #jwks_client = PyJWKClient(config['PING_JWKS_URI'])
        #signing_key = jwks_client.get_signing_key_from_jwt(token)
        data = jwt.decode(
            token,
            #signing_key.key,
            algorithms=["RS256"],
            options={
                "verify_signature": False,
                "verify_exp": True,
                "verify_iat": True,
            },
        )
        role = ''
        if data.get('role') == config['ADMIN_GROUP'] or config['ADMIN_GROUP'] in data.get('role', []):
            role = Role.ADMIN
        elif data.get('role') == config['ENGINEER_GROUP'] or config['ENGINEER_GROUP'] in data.get('role', []):
            role = Role.ENGINEER
        elif data.get('role') == config['APPROVER_GROUP'] or config['APPROVER_GROUP'] in data.get('role', []):
            role = Role.DEA
        elif data.get('role') == config['REQUESTOR_GROUP'] or config['REQUESTOR_GROUP'] in data.get('role', []):
            role = Role.REQUESTOR
        else:
            raise HTTPException(status_code=401, detail='Not authorized')
        data['role'] = role

        connection = connection_pool.connect()
        cursor = connection.cursor(as_dict=True)
        cursor.execute(checkuser['read'], {'email':data.get('email', '')})
        results = cursor.fetchall()
        if len(list(map(lambda obj: dict(obj), results)))>0:
            data['has_teamcenter_access'] = True
        else:
            raise HTTPException(status_code=401, detail='User do not have teamcenter access')
        request.state.security_context = data
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

async def has_admin_access(request:Request):
    try:
        user = request.state.security_context
        if user['role'] in {Role.ADMIN, Role.ENGINEER, Role.DEA}:
            return True
        raise HTTPException(status_code = 401, detail ='Role should be admin')
    except Exception as e:
        raise HTTPException(status_code=401, detail='Role should be admin')

async def has_only_admin_access(request:Request):
    try:
        user = request.state.security_context
        if user['role'] == Role.ADMIN:
            return True
        raise HTTPException(status_code = 401, detail ='Role should be admin')
    except Exception as e:
        raise HTTPException(status_code=401, detail='Role should be admin')

async def has_only_dea_access(request:Request):
    try:
        user = request.state.security_context
        if user['role'] == Role.DEA:
            return True
        raise HTTPException(status_code = 401, detail ='Role should be dea')
    except Exception as e:
        raise HTTPException(status_code=401, detail='Role should be DEA')

async def has_only_requestor_access(request:Request):
    try:
        user = request.state.security_context
        if user['role'] == Role.REQUESTOR:
            return True
        raise HTTPException(status_code = 401, detail ='Role should be Requestor')
    except Exception as e:
        raise HTTPException(status_code=401, detail='Role should be Requestor')
