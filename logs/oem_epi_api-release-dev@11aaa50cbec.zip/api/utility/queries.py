requestformqueries = {
    "get_mfg_name": """SELECT  mfgpartnumname FROM OEMPARTSDB.dbo.dimoempartnumdtls
        where amatpartnum = %(amatpartnum)s and rflg=1;
    """,
    "get_mfg_list": """SELECT  amatpartnum, mfgpartnumname FROM OEMPARTSDB.dbo.dimoempartnumdtls
        where amatpartnum in ({amatpartnum}) and rflg=1;
    """,
    "create": """
        INSERT INTO oem_request ( requested_by, status, created_datetime,
        requestor_email, created_by, lastupddatetsmp ) VALUES ( %(requested_by)s, %(status)s, GETDATE(), %(requestor_email)s, %(created_by)s, GETDATE())
    """,
    "read": """select requestid, requested_by, status, created_datetime, created_by,
        lastupddatetsmp, (
            select count(*) from oem_requestdetail dt where
            dt.requestid = oem_request.requestid
        ) as totalset,  (
            select top 1 rejectreason from oem_requestsalternatepart as alt where rejectreason is not null
            and alt.requestid = oem_request.requestid and status = 'rejected'
        ) as rejectreason, assigned_to_name, assigned_to_email, assigned_by_name,
        requestor_email, dea_name from oem_request {cond}""",
    'update_status':'update oem_request set status = %(status)s, lastupddatetsmp = GETDATE() where requestid = %(requestid)s',
    'count':'select status, count(requestid) as count from oem_request {rolecond} group by status',
    'assign_to':'''
        update oem_request set assigned_to_name = %(assigned_to_name)s, assigned_to_email = %(assigned_to_email)s,
        assigned_by_name = %(assigned_by_name)s, assigned_by_email = %(assigned_by_email)s, assigned_date = GETDATE(), lastupddatetsmp = GETDATE() where requestid = %(requestid)s
    ''',
    'assign_dea':'''
        update oem_request set dea_name = %(dea_name)s, dea_email = %(dea_email)s,
        assigned_by_name = %(assigned_by_name)s, assigned_by_email = %(assigned_by_email)s,
        dea_assign_date = GETDATE(), lastupddatetsmp = GETDATE() where requestid = %(requestid)s
    ''',
    'acknowledge':'''
        update oem_request set status = 'completed', lastupddatetsmp = GETDATE(), completion_date=GETDATE()
        where requestid = %(requestid)s and requestor_email = %(email)s
    ''',
    'configured':'''
        select requestid, dea_name, dea_email from oem_request where requestid not in
        ( select requestid from dbo.oem_requestdetail where isactive<2 )
        and requestid = %(requestid)s
    ''',
    'updateconfdate':'update oem_request set configured_date=GETDATE(), evaluation_date=null where requestid = %(requestid)s ',
    'updateevaldate':'update oem_request set evaluation_date=GETDATE() where requestid = %(requestid)s ',
    'requestedparts':'select partnumber from oem_requestdetail where requestid = %(requestid)s',
    'requestedpartsconfigured':'select partnumber from oem_requestdetail where requestid = %(requestid)s and isactive = 2'
}


requestdetailqueries = {
    "create": """
        INSERT INTO oem_requestdetail ( requestid, partnumber, mfgname_partnumber,
        demand, demandBU, quantity, isactive, created_datetime, created_by,
        lastupddatetsmp ) VALUES ( %(requestid)s, %(partnumber)s, %(mfgname_partnumber)s,
          %(demand)s, %(demandBU)s, %(quantity)s, %(isactive)s,
          GETDATE(), %(created_by)s, GETDATE()
        )
    """,
    "readbyrequestid": """
        select rdt.*,(
	        select DISTINCT rejectreason from dbo.oem_requestsalternatepart alt where rdt.requestid = alt.requestid
	        and alt.partnumber = rdt.partnumber and alternatepartnumber is not null and rejectreason is not null
        ) as rejectreason  from oem_requestdetail rdt where rdt.requestid = %(requestid)s
    """,
    'update_status':'''
        update oem_requestdetail set isactive = %(isactive)s, closereason = %(closereason)s,
        lastupddatetsmp = GETDATE()
        where requestid = %(requestid)s and partnumber = %(partnumber)s
    ''',
    'countunapprove':'''
        select count(*) as count from oem_requestdetail where requestid = %(requestid)s
        and isactive != 3
    '''
}

partcomparequeries = {
    'match':'''
        select rqstdpartnum,comparedpartnum,rqstdparmname,rqstdparmval,comparedparmval,matchcatgtype, comparedpartnumstatus
        from [OEMPARTSDB].[dbo].[factoempartnumcmprsn] where rqstdpartnum = %(partnumber)s order by matchcatgtype
    ''',
    'detail':'''
        select  partnum as  comparedpartnum, CONVERT(VARCHAR(MAX), parmval) as comparedparmval, parmname as  rqstdparmname
        from [OEMPARTSDB].[dbo].[factoempartnumparmdtls] where partnum = %(partnumber)s
    '''
}


alternatepartnumberqueries = {
    'create': '''
        INSERT INTO OEMPARTSDB.dbo.oem_requestsalternatepart (
            requestid, partnumber, alternatepartnumber, updatedbyemail,
            part_attributes, part_type
        ) VALUES (
            %(requestid)s, %(partnumber)s, %(alternatepartnumber)s,
            %(updatedbyemail)s, %(part_attributes)s, %(part_type)s
        )
    ''',
    'read':'''
        select part_attributes, status from OEMPARTSDB.dbo.oem_requestsalternatepart
        where partnumber = %(partnumber)s and requestid = %(requestid)s
    ''',
    'remove':'''
        delete from OEMPARTSDB.dbo.oem_requestsalternatepart
        where requestid = %(requestid)s and partnumber = %(partnumber)s
    ''',
    'unevalute':'''
        update OEMPARTSDB.dbo.oem_requestsalternatepart  set status = null,
        rejectreason = null where partnumber = %(partnumber)s and requestid = %(requestid)s
    ''',
    'evalute':'''
        update OEMPARTSDB.dbo.oem_requestsalternatepart set status = %(status)s,
        rejectreason = %(rejectreason)s where alternatepartnumber in ({alternatepartnumber})
        and partnumber = %(partnumber)s and requestid = %(requestid)s
    ''',
    'evaluted_read':'''
        select alternatepartnumber, status from OEMPARTSDB.dbo.oem_requestsalternatepart
        where partnumber = %(partnumber)s and requestid = %(requestid)s and (
            status = 'approved'
        ) and alternatepartnumber is not null
    ''',
}

checkuser = {
    'read': '''select user_id from OEMPARTSDB.dbo.dimamatoemtcusers where emailid = %(email)s'''
}

dashboardquery = {
    'autovsmanpartscount':'''
        select count(part_type) as count, part_type  from oem_requestsalternatepart
        where requestid in (
            select requestid from oem_request or2  where status = 'completed' {filtercond}
        ) and part_type is not null and status = 'approved' group by part_type
    ''',
    'countbuwise':'''
        select demandBU, count(distinct dt.partnumber) as totalpartreq,
        count(alt.alternatepartnumber) as totalpartapprove from oem_requestdetail dt
        left join oem_requestsalternatepart alt on alt.requestid = dt.requestid and dt.partnumber = alt.partnumber
	    and alt.alternatepartnumber is not null and alt.status = 'approved'
	    where dt.requestid in (
            select requestid from oem_request or2 where status in ('completed')
            {filtercond}
        )
	    group by demandBU
    ''',
    'reqlifecycleavg':'''
        select avg(DATEDIFF(hour,  created_datetime, assigned_date )) as 'Assignment',
        avg(datediff(hour, assigned_date, configured_date)) as 'Configured',
        avg(DATEDIFF(hour, configured_date, evaluation_date)) as 'Evalution',
        avg(DATEDIFF(hour, evaluation_date , completion_date)) as 'Completion'
        from dbo.oem_request where status = 'completed' {filtercond}
    ''',
    'counts':'''
        select (select count(requestid) from oem_request where 1 = 1 {filtercond}) req_count,
		(select count(requestid) from oem_request where status = 'completed' {filtercond}) as completed_count,
		(select count(requestid) from oem_request where status != 'completed' {filtercond}) as backlog_count,
		(select count(requestid) from dbo.oem_requestdetail  where requestid in (
            select requestid from oem_request where 1 = 1 {filtercond})
        ) as total_part_requested
    ''',
    'buwiseunconfigured':'''
        select count(partnumber) as countparts, demandBU from dbo.oem_requestdetail  where requestid in (
            select requestid from oem_request where (
                status in ('unassigned', 'inprogress')
            ) {filtercond}
        ) and isactive = '1' group by demandBU
    ''',
    'buwiseconfigured':'''
        select count(partnumber) as countparts, demandBU from
        dbo.oem_requestdetail or2 where requestid in (
            select requestid from oem_request where (
                status = 'inprogress'
            ) {filtercond}
        ) and isactive = '2' group by demandBU
    ''',
    'buwiseappr':'''
        select count(partnumber) as countparts, demandBU from dbo.oem_requestdetail or2 where requestid in (
            select requestid from oem_request where (
                status in ('inprogress', 'approved')
            ) {filtercond}
        ) and isactive = '3' group by demandBU
    ''',
    'buwiserej':'''
        select count(partnumber) as countparts, demandBU from dbo.oem_requestdetail or2 where requestid in (
            select requestid from oem_request where (
                status in ('rejected', 'inprogress') and assigned_to_name is not null
                and dea_name is not NULL
            ) {filtercond}
        ) and isactive = '4' group by demandBU
    ''',
    'buwisecompl':'''
        select count(partnumber) as countparts, demandBU from dbo.oem_requestdetail or2 where requestid in (
            select requestid from oem_request where status in ('completed') {filtercond}
        ) and isactive = '3' group by demandBU
    ''',
    'reqlifecycletable':'''
        select {selectcond},
        count(requestid) as totalrequest,
        sum(DATEDIFF(day,  created_datetime, Coalesce(assigned_date, configured_date) )) as 'Admin',
        sum(datediff(day, assigned_date, configured_date)) as 'Engineer',
        sum(DATEDIFF(day, configured_date, evaluation_date)) as 'Approver',
        sum(DATEDIFF(day, evaluation_date , completion_date)) as 'Requestor'
        from oem_request where 1= 1
        {filtercond}
        group by {groupbycond}
    '''
}