from enum import Enum
class Role(Enum):
    ADMIN = 'admin'
    ENGINEER = 'engineer'
    DEA = 'dea'
    REQUESTOR = 'requestor'

    @staticmethod
    def has_value(role:str):
        return role in [item.value for item in Role.__members__.values()]