#!groovy
def call(String serviceName) {
    pipeline {
         agent {
            node {
                label "A2V-OCP-BUILDHOST"
            }
        }
        stages {
            stage("Initialize") {
                steps {
                    script {
                        def envfile = ""
                        env.SERVICE_NAME = "${serviceName}"

                        switch(GIT_BRANCH) {
                            case "origin/release/dev":
                                envfile = "dev-env.yml"
                                break
                            case "origin/release/qa":
                                envfile = "qa-env.yml"
                                break
                            case "origin/release/prod":
                                envfile = "prod-env.yml"
                                break
                            case "origin/master":
                                envfile = "prod-env.yml"
                                break
                            default:
                                envfile = ""
                                break
                        }
                        def props = readYaml file: "./pipeline/variables/${envfile}"
                    for (elem in props)
                            env."${elem.key}" = elem.value                    
                    }
                    sh "sh ./pipeline/download-scripts.sh"
                }
                
            }
            stage("OCP HELM Release") {
                steps {
                    withCredentials([file(credentialsId: 'oem-secrets', variable: 'SECRETS_FILE')]){
                        sh "sh ./pipeline/scripts/create-namespace.sh"
                        sh "sh ./pipeline/scripts/helm-release.sh ./pipeline/helm/${serviceName}"
                    }
                }
            }
        
            stage("Build") {
                steps {
                    parallel(
                        BuildNode: {
                            sh "sh ./pipeline/scripts/oc-build.sh ${serviceName}-api-build"
                        }
                    )
                }
                post {
                    aborted {
                        sh "sh ./pipeline/scripts/cancel-build.sh ${serviceName}-api-build"
                    }
                }
            }

            stage("Deploy") {
                steps {
                    sh "sh ./pipeline/scripts/oc-deploy.sh ${serviceName}-api-deploy"
                }
                post {
                    aborted {
                        sh "sh ./pipeline/scripts/cancel-deploy.sh ${serviceName}-api-deploy"
                    }
                }
            }

            stage("Git Tag") {
                when {
                    expression {
                        return GIT_BRANCH == 'origin/release/qa' || GIT_BRANCH == 'origin/release/prod'
                    }
                }
                steps {
                    sh "sh ./pipeline/scripts/git-tag.sh"
                }
            }
        }
    }
}

return this
