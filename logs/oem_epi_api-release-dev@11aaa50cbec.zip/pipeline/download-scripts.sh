#!/bin/sh
set -e

if [ -z "${SCRIPTS_REPO}" ] || [ -z "${SCRIPTS_REPO_REF}" ] || [ -z "${SCRIPTS_REPO_NAME}" ]
    then
    echo "Cannot find scripts repo location."
    exit 1
fi
rm -rf "${SCRIPTS_REPO_NAME}"
git clone "${SCRIPTS_REPO}" -b "${SCRIPTS_REPO_REF}"
rm -rf ./pipeline/scripts
cp -R "./${SCRIPTS_REPO_NAME}/scripts" ./pipeline
rm -rf "${SCRIPTS_REPO_NAME}"

