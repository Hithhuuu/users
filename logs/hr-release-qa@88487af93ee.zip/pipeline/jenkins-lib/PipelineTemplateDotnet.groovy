#!groovy
def call(Map pipelineParams) {

    pipeline {
         agent {
            node {
                label "A2V-OCP-BUILDHOST"
            }
        }
        stages {
            stage("Initialize") {
                steps {
                    script {
                        def envfile = ""
                        env.SERVICE_NAME = "${pipelineParams.serviceName}"
                        env.SERVICE_CONTEXT_DIR = "${pipelineParams.serviceContextDir}"
                        env.DOCKERFILE = "${pipelineParams.dockerFile}"
                        env.TECHNOLOGY = "${pipelineParams.technology}"
                        switch(GIT_BRANCH) {                              
                            case 'origin/release/gis-dev':
                            case "origin/release/dev": 
                                envfile = "dev-env.yml"
                                break                           
                            case "origin/release/qa-west3":
                            case "origin/feature/qa_pdf":
                            case "origin/release/qa":                            
                                envfile = "qa-env.yml"
                                break
                            case "origin/release/prod":
                            case "origin/release/prod-beta":
                                envfile = "prod-env.yml"
                                break
                            default:
                                envfile = ""
                                break
                        }
                        def props = readYaml file: "./pipeline/variables/${envfile}"
                    for (elem in props)
                            env."${elem.key}" = elem.value                    
                    }
                    sh "sh ./pipeline/download-scripts.sh"
                }
            }
            stage("BUILD DOCKER IMAGE AND PUSH TO JFROG") {
                steps {
                      sh "sh ./pipeline/scripts/docker-build.sh"
                }
            }
            stage("OCP HELM Release") {
                steps {
                    sh "sh ./pipeline/scripts/create-namespace.sh"
                    sh "sh ./pipeline/scripts/helm-release.sh ./pipeline/helm/${SERVICE_NAME}"
                }
            }
            stage("Deploy") {
                steps {
                    sh "sh ./pipeline/scripts/oc-deployment.sh ${SERVICE_NAME}-api-deploy"
                }
                post {
                    aborted {
                        sh "sh ./pipeline/scripts/cancel-deployment.sh ${SERVICE_NAME}-api-deploy"
                    }
                }
            }

            stage("Git Tag") {
                when {
                    expression {
                        return GIT_BRANCH == 'origin/release/qa' || GIT_BRANCH == 'origin/release/prod'
                    }
                }
                steps {
                    sh "sh ./pipeline/scripts/git-tag.sh"
                }
            }
        }
    }
}

return this
