#!groovy
def call(Map pipelineParams) {
    def IS_WEBHOOK_TRIGGER = env.IS_WEBHOOK_TRIGGER
 
    pipeline {
        agent {
            node {
                label 'A2V-OCP-BUILDHOST'
            }
        }
        stages {
            stage('Initialize') {
                steps {
                    script {
                        def envfile = ''
                        env.SERVICE_NAME = "${pipelineParams.serviceName}"
                        env.SERVICE_CONTEXT_DIR = "${pipelineParams.serviceContextDir}"
                        env.DOCKERFILE = "${pipelineParams.dockerFile}"
                        env.TECHNOLOGY = "${pipelineParams.technology}"
                        env.SONAR_PROJECT_KEY = "${pipelineParams.sonarProjectKey}"
                        switch (GIT_BRANCH) {
                            case 'origin/release/dev':
                            case 'origin/release/gis-dev':
                            case 'origin/feature/aro_cron':
                            case 'origin/release/indiaglobal-gis-dev':
                            case 'origin/release/indiaglobal-dev':
                                envfile = 'dev-env.yml'
                                break
                            case 'origin/feature/qa_cron':
                            case 'origin/release/qa':                            
                                envfile = 'qa-env.yml'
                                break
                            case 'origin/release/prod':
                                envfile = 'prod-env.yml'
                                break
                            default:
                                if (!GIT_BRANCH.contains('release/')) {
                                    envfile = "dev-env.yml"
                                } else {
                                    envfile = ""
                                }
                                break
                        }
                        if ("${IS_WEBHOOK_TRIGGER}" == "true") {
                            envfile = "dev-env.yml"
                            withCredentials([string(credentialsId: 'GENS-BITBUCKET-TOKEN', variable: 'BITBUCKET_ACCESS_TOKEN')]) {
                                env.BITBUCKET_ACCESS_TOKEN = env.BITBUCKET_ACCESS_TOKEN
                            }
                        }
                        def props = readYaml file: "./pipeline/variables/${envfile}"
                        for (elem in props)
                                env."${elem.key}" = elem.value                    
                        sh "sh ./pipeline/download-scripts.sh"
                        if ("${IS_WEBHOOK_TRIGGER}" == "true" && "${PRDESTINATION}".contains('release/') && !"${GIT_BRANCH}".contains('release/')) {
                            // Add execute permissions to the script
                            sh "chmod +x ./pipeline/scripts/success-pr.sh"
 
                            // Initial comment on PR stating the pipeline has started and not to merge the PR
                            sh "./pipeline/scripts/success-pr.sh ${PRURL} pre-comment"
                        }    
                    }
                }            
            }
            // stage("Lint") {
            //     when {
            //         expression {
            //             return !GIT_BRANCH.startsWith('origin/release/') && "${IS_WEBHOOK_TRIGGER}" == "true"
            //         }
            //     }
            //     steps {
            //         sh "sh ./pipeline/scripts/quality-check.sh '${LINT}'"
            //     }
            // }
            stage("Audit") {
                when {
                    expression {
                        return !GIT_BRANCH.startsWith('origin/release/') && "${IS_WEBHOOK_TRIGGER}" == "true"
                    }
                }
                steps {
                    script {
                        def exitCode = sh(script: "sh ./pipeline/scripts/quality-check.sh '${AUDIT}'", returnStatus: true)
                        if (exitCode == 0 && "${AUDIT_EXCEPTION}" == "true") {
                            catchError(buildResult: 'SUCCESS', stageResult: 'UNSTABLE') {
                            error("The audit stage as added as exception")
                            }
                        }
                        else if (exitCode == 1 && "${AUDIT_EXCEPTION}" == "false") {
                            error("The audit stage failed")
                        } else {
                            echo "The audit stage passed"
                        }
                    }
                    // sh "sh ./pipeline/scripts/quality-check.sh '${AUDIT}'"
                }
            }
            stage("Security Scans - SonarQube") {
                when {
                    expression {
                        return !GIT_BRANCH.startsWith('origin/release/') && "${IS_WEBHOOK_TRIGGER}" == "true"
                    }
                }
                steps {
                    script {
                        def exitCode = sh(script: "sh ./pipeline/scripts/quality-check.sh '${SONARQUBE_SCAN}'", returnStatus: true)
                        if (exitCode == 0 && "${SONAR_EXCEPTION}" == "true") {
                            catchError(buildResult: 'SUCCESS', stageResult: 'UNSTABLE') {
                            error("The sonar stage as added as exception")
                            }
                        }
                        else if (exitCode == 1 && "${SONAR_EXCEPTION}" == "false") {
                            error("The Sonar stage failed")
                        } else {
                            echo "The sonar stage passed"
                        }
                    }
                    // sh "sh ./pipeline/scripts/quality-check.sh '${SONARQUBE_SCAN}'"
                }
            }
            stage("Code review") {
                when {
                    expression {
                        return !GIT_BRANCH.startsWith('origin/release/') && "${IS_WEBHOOK_TRIGGER}" == "true"
                    }
                }
                steps {
                    sh "sh ./pipeline/scripts/quality-check.sh '${GENAI_CODE_REVIEW}'"
                }
            }
            stage('BUILD DOCKER IMAGE AND PUSH TO JFROG') {
                when {
                    expression {
                        return "${IS_WEBHOOK_TRIGGER}" != "true"
                        }
                   }
                steps {
                    sh 'sh ./pipeline/scripts/docker-build.sh'
                }
            }
            stage('OCP HELM Release') {
                when {
                    expression {
                        return "${IS_WEBHOOK_TRIGGER}" != "true"
                        }
                   }
                steps {
                    withCredentials([file(credentialsId: 'hr-assist-cron-secrets', variable: 'SECRETS_FILE')]) {
                        sh 'sh ./pipeline/scripts/create-namespace.sh'
                        sh "sh ./pipeline/scripts/helm-release.sh ./pipeline/helm/${SERVICE_NAME}"
                    }
                }
            }
            // stage("Deploy") {
            //     steps {
            //         sh "sh ./pipeline/scripts/oc-deploy.sh ${SERVICE_NAME}-api-deploy"
            //     }
            //     post {
            //         aborted {
            //             sh "sh ./pipeline/scripts/cancel-deploy.sh ${SERVICE_NAME}-api-deploy"
            //         }
            //     }
            // }
 
            stage('Git Tag') {
                when {
                    expression {
                        return (GIT_BRANCH == 'origin/release/qa' || GIT_BRANCH == 'origin/release/prod') && "${IS_WEBHOOK_TRIGGER}" != "true"
                    }
                }
                steps {
                    sh 'sh ./pipeline/scripts/git-tag.sh'
                }
            }
        }
        post {
            success {
                script {
                    echo "Pipeline completed successfully"
                    if ("${IS_WEBHOOK_TRIGGER}" == "true" && "${PRDESTINATION}".contains('release/') && !"${GIT_BRANCH}".contains('release/')) {
                        // Steps to run on success
                        sh "sh ./pipeline/scripts/success-pr.sh ${PRURL}"
                    }
                }
            }
   
            failure {
                script {
                    echo "Pipeline failed"
                    if ("${IS_WEBHOOK_TRIGGER}" == "true" && "${PRDESTINATION}".contains('release/') && !"${GIT_BRANCH}".contains('release/')) {
                        // Add execute permissions to the script
                        sh "chmod +x ./pipeline/scripts/decline-pr.sh"
                        // Steps to run on failure
                        sh "sh ./pipeline/scripts/decline-pr.sh ${PRURL}"
                    }  
                }
            }
        }
    }
}
 
return this