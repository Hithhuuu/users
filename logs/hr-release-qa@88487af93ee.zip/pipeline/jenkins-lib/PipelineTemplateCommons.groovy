#!groovy
def call(Map pipelineParams) {
    pipeline {
        agent {
            node {
                label 'A2V-OCP-BUILDHOST'
            }
        }

        stages {
            stage('Initialize') {
                steps {
                    script {
                        def envfile = ''
                        env.SERVICE_NAME = "${pipelineParams.serviceName}"

                        switch (GIT_BRANCH) {
                            case 'origin/release/dev':
                            case 'origin/release/gis-dev':
                                envfile = 'dev-env.yml'
                                break
                            case 'origin/release/qa':
                                envfile = 'qa-env.yml'
                                break
                            case 'origin/release/prod':
                                envfile = 'prod-env.yml'
                                break
                            default:
                                envfile = ''
                                break
                        }
                        def props = readYaml file: "./pipeline/variables/${envfile}"
                        for (elem in props)
                            env."${elem.key}" = elem.value
                    }
                    sh 'sh ./pipeline/download-scripts.sh'
                }
            }
            stage('OCP HELM Release') {
                steps {
                    //withCredentials([file(credentialsId: 'hr-assist-secrets', variable: 'SECRETS_FILE')]){
                    sh 'sh ./pipeline/scripts/create-namespace.sh'
                    sh "sh ./pipeline/scripts/helm-release.sh ./pipeline/helm/${pipelineParams.serviceName}"
                //}
                }
            }
        }
    }
}

return this
