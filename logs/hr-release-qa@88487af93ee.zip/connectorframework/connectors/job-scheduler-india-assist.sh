#!/bin/bash
python3 script_hr_assist_india.py --file_path "config_hr_india_assist.yaml"