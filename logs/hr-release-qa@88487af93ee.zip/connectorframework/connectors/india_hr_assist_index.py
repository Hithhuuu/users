NAS_PATH = ""
JSON_PATH = ""
USERNAME = ""
PASSWORD = ""
list_url = ""
attach_url = ""
endpoint = ""
index_name = ""
api_key = ""

import os
import json
import csv
import requests
import re
import datetime
import shutil
import yaml
import pandas as pd
from requests.auth import HTTPBasicAuth
from fastapi import APIRouter, Request
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from bs4 import BeautifulSoup
from chunk_main_6 import main_chunk
from connectors.main_connector import ConnectorRun
from markdownify import markdownify as md
from utils import logger
from contextvars import ContextVar
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())


main_folder_paths = [
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\hr-assist\\",
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\hr-assist\\hr-json",
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\csv\\",
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\india-hr-shared\\",
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\stats-path\\",
    r"C:\\HRAssist\\hr-index\\hr-indiaglobal\\logs\\"
]


for folder_path in main_folder_paths:
    os.makedirs(folder_path, exist_ok=True)

def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)

def read_yaml(file_path):
    with open(file_path, "r") as file:
        config_data = yaml.safe_load(file)
    return config_data


def hr_assist(filePath):
    global NAS_PATH, JSON_PATH, USERNAME, PASSWORD, list_url, attach_url, endpoint, index_name, api_key
    dir_path = os.path.dirname(os.path.abspath(__file__))
    CONFIG_PATH = os.path.join(dir_path, filePath)
    config = read_yaml(CONFIG_PATH)

    SHARED_PATH = config.get('connector')['shared_path']
    STATS_PATH = config.get('connector')['stats_path']
    NAS_PATH = config.get('india_hr_assist')['NAS_PATH']
    JSON_PATH = config.get('india_hr_assist')['JSON_PATH']
    USERNAME = config.get('india_hr_assist')['USERNAME']
    PASSWORD = config.get('secret').get('PASSWORD')
    list_url = config.get('india_hr_assist')['list_url']
    attach_url = config.get('india_hr_assist')['attach_url']


    try:
        
        list_params = {
            "sysparm_query":"sys_class_name!=kb_knowledge_block^kb_knowledge_base.titleINHR India,HR Global^workflow_stateINpublished",
            "sysparm_limit":"250"
        }
        list_json_data = extract_json_data(list_url, list_params, USERNAME, PASSWORD)
        article_fields = [
            "number",
            "short_description",
            "article_id",
            "sys_id",
            "sys_updated_on",
            "sys_created_on",
            "sys_updated_by",
            "sys_created_by",
            "meta",
        ]

        metadata_csv = []
        if len(list_json_data["result"]) > 0:
            for article in list_json_data["result"]:
                attach_params = {
                    "sysparm_query": "content_type=application/pdf^table_sys_id="
                    + article["sys_id"]
                }
                attach_json_data = extract_json_data(
                    attach_url, attach_params, USERNAME, PASSWORD
                )
              
                folder_path = os.path.join(NAS_PATH, article["sys_id"])
                # Check if the folder exists before creating it
                # if not os.path.exists(folder_path):
                #     os.mkdir(folder_path)
                file_name = article["sys_id"] + "_article.json"
                with open(os.path.join(NAS_PATH, file_name), "w") as file:
                    json.dump(article, file)
                if article["text"] != "":
                    file_name = article["sys_id"] + "_summary.txt"
                    with open(os.path.join(NAS_PATH, file_name), "w", encoding="utf-8") as file:
                        file.write(article["text"])
                    row = {key: article.get(key, "") for key in article_fields}
                    if article['kb_category']['value'] != '':
                        row.update(
                            {
                                "file_name": article["sys_id"] + "_summary.txt",
                                "article_link": f"https://amat.service-now.com/esc?id=kb_article&kb_id={article['kb_knowledge_base']['value']}&sys_id={article['sys_id']}&kb_category={article['kb_category']['value']}",
                                
                            }
                        )
                    else:
                        row.update(
                            {
                                "file_name": article["sys_id"] + "_summary.txt",
                                "article_link": f"https://amat.service-now.com/esc?id=kb_article&kb_id={article['kb_knowledge_base']['value']}&sys_id={article['sys_id']}&kb_category=",
                            }
                        )
                    metadata_csv.append(row)
                pdf_count = 0
                for item in attach_json_data["result"]:
                    row = {key: article.get(key, "") for key in article_fields}
                    file_name = article["sys_id"] + "_" + item["file_name"]
                    if article['kb_category']['value'] != '':
                        row.update(
                            {
                                "file_name": file_name,
                                "article_link": f"https://amat.service-now.com/esc?id=kb_article&kb_id={article['kb_knowledge_base']['value']}&sys_id={article['sys_id']}&kb_category={article['kb_category']['value']}",
                            }
                        )
                    else:
                        row.update(
                            {
                                "file_name": file_name,
                                "article_link": f"https://amat.service-now.com/esc?id=kb_article&kb_id={article['kb_knowledge_base']['value']}&sys_id={article['sys_id']}&kb_category=",
                            }
                        )
                    metadata_csv.append(row)
                    if item["file_name"].lower().endswith(".pdf") and pdf_count < 5:
                        pdf_count+=1
                        download_content(
                            item["download_link"],
                            os.path.join(NAS_PATH, file_name),
                            username=USERNAME,
                            password=PASSWORD,
                        )

            htmlanchortag(NAS_PATH)
            pdf_files = find_pdf(NAS_PATH)
            main_chunk(pdf_files)
            move_files(NAS_PATH, JSON_PATH)

            csv_file = os.path.join('C:\\HRAssist\\hr-index\\hr-indiaglobal\\csv\\', "data.csv")
            with open(csv_file, mode="w", newline="", encoding="utf-8") as csvfile:
                article_fields.extend(["file_name", "article_link"])
                writer = csv.DictWriter(csvfile, fieldnames=article_fields)
                writer.writeheader()
                writer.writerows(metadata_csv)
            
            df = pd.read_csv(csv_file)
            df.rename(columns={'short_description': 'title'}, inplace=True)
            df.to_csv(csv_file, index=False)
            
            delete_all_files_and_folders(SHARED_PATH)
            delete_all_files_and_folders(STATS_PATH)
            Connector = ConnectorRun(config.get("connector"))
            print("Connector triggered")
            Connector.filesystem_run()
            
            #delete_all_files_and_folders(NAS_PATH)
        else:
            print("No data found")
    except Exception as e:
        print("Error:", e)


def extract_json_data(url, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
    if response.status_code == 200:
        try:
            json_data = response.json()
            return json_data
        except ValueError as e:
            print("Error parsing JSON:", e)
    else:
        print("Error:", response.status_code)
 
 
def download_content(url, save_path, params=None, username=None, password=None):
    response = requests.get(url, params=params, auth=HTTPBasicAuth(username, password))
    if response.status_code == 200:
        with open(save_path, "wb") as file:
            file.write(response.content)
        print("Content downloaded successfully.")
    else:
        print(f"Failed to download content. Status Code: {response.status_code}")
 
 
def find_pdf(directory):
    pdf_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(".pdf"):
                pdf_files.append(os.path.join(root, file))
    return pdf_files


def move_files(NAS_PATH, JSON_PATH):
    parent_folder_path = NAS_PATH
    json_folder_path = JSON_PATH
    pdf_folder_path = parent_folder_path
    
    # Move files to the respective folders
    for root, _, files in os.walk(parent_folder_path):
        for file_name in files:
            if file_name.endswith('.json'):
                file_path = os.path.join(root, file_name)
                new_file_path = os.path.join(json_folder_path, file_name)
                shutil.move(file_path, new_file_path)
 

def delete_all_files_and_folders(folder_path):
    try:
        for root, dirs, files in os.walk(folder_path, topdown=False):
            for file_name in files:
                file_path = os.path.join(root, file_name)
                os.remove(file_path)
                print(f"File '{file_path}' deleted successfully.")
            for dir_name in dirs:
                dir_path = os.path.join(root, dir_name)
                os.rmdir(dir_path)
                print(f"Folder '{dir_path}' deleted successfully.")
        print(f"All files and folders in '{folder_path}' deleted successfully.")
    except FileNotFoundError:
        print(f"Folder '{folder_path}' not found.")
    except PermissionError:
        print(f"Permission denied. Unable to delete files and folders in '{folder_path}'.")


def htmlanchortag(folder_path):
    for file_name in os.listdir(folder_path):
        item_path = os.path.join(folder_path, file_name)
        if os.path.isfile(item_path) and file_name.endswith("article.json"):
            with open(item_path, 'r', encoding='utf-8') as file:
                json_data = json.load(file)
            html_content = json_data.get('text', '')
            soup = BeautifulSoup(html_content, 'html.parser')
            for img_tag in soup.find_all('img'):
                img_tag.decompose()  # Remove the image tag completely
            json_data['text'] = md(str(soup))
            json_data['text'] = re.sub(r'\n{2,}', '\n', json_data['text'])
            with open(item_path, 'w', encoding='utf-8') as file:
                json.dump(json_data, file, indent=4, ensure_ascii=False)
            print(f"article.json file updated successfully with anchor tags")
        elif os.path.isfile(item_path) and file_name.endswith("summary.txt"):
            with open(item_path, "r", encoding='utf-8') as file:
                data = file.read()
            soup = BeautifulSoup(data, "lxml")
            for img_tag in soup.find_all('img'):
                img_tag.decompose()  # Remove the image tag completely
            result = md(str(soup))
            result = re.sub(r'\n{2,}', '\n', result)
            # Update the file
            with open(item_path, "w", encoding="utf-8") as file:
                file.write(str(result))
                print("text file updated successfully with anchor tags")
        elif os.path.isdir(item_path):
            htmlanchortag(item_path)

