from connectors.base import AbstractClass
from connectors.sharepoint_connector.main import SharepointConnector
from connectors.filesystem_connector.main import FilesystemConnector
from connectors.sharepoint_connector_online.main import SharepointOnlineConnector

class ConnectorRun():
    def __init__(self, config) -> None:
        self.config = config

    def run(self):
        return self.method_call(SharepointConnector(self.config))
    def run_online(self):
        return self.method_call(SharepointOnlineConnector(self.config))
    def filesystem_run(self):
        return self.method_call(FilesystemConnector(self.config))
    
    def method_call(self, abstract_class: AbstractClass):
        return abstract_class.template_method()
