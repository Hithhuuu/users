from datetime import datetime

from .base_command import BaseCommand
from connectors.sharepoint_connector_online.utils.connector_queue import ConnectorQueue
from connectors.sharepoint_connector_online.utils.sharepoint_helpers import SyncSharepoint
from connectors.sharepoint_connector_online.utils.utils import split_date_range_into_chunks

from metrics.main_metrics import MetricsRun
from metrics.doc_metrics import Metrics
from indexing.cognitive_search import AzureSearchVectorStore
import argparse
import yaml
import os


def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)
parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
         "--file_path", default="config.yaml", help="Path to the config.yaml file"
                )
args = parser.parse_args()
sharepoint_config = args.file_path

with open(sharepoint_config, 'r') as file:
    config_data = yaml.safe_load(file)

class FullSync(BaseCommand):
    """This class start execution of fullsync feature."""

    def fetch_sharepoint_documents(self):
        """This method starts async calls for the producer which is responsible for fetching documents from
        the SharePoint and pushing them in the shared queue
        :param queue: Shared queue to fetch the stored documents
        """
        self.logger.debug("Starting the full indexing..")
        self.sync_type = "full"
        current_time = (datetime.utcnow()).strftime("%Y-%m-%dT%H:%M:%SZ")
        time1 = datetime.now()
        thread_count = self.config.get("sharepoint_sync_thread_count")
        start_time, end_time = self.config.get("start_time"), current_time
        # print(start_time)
        try:
            sync_sharepoint = SyncSharepoint(
                self.config,
                self.logger,
                self.sharepoint_client,
                self.sync_type,
                start_time,
                end_time,
            )
            for collection in self.config.get("sharepoint.site_collections"):
                storage_with_collection = (
                    self.local_storage.get_storage_with_collection(collection)
                )
                self.logger.info(
                    "Starting to index all the objects configured in the object field: %s"
                    % (str(self.config.get("objects")))
                )
                ids = storage_with_collection["global_keys"][collection]
                # print("ids",ids)
                files = sync_sharepoint.fetch_records_from_sharepoint(
                    thread_count, ids, collection
                )
                indexing_status = 'Success'
            self.logger.info(
                f"Done fetching data from sharepoint {thread_count}")
            return files
        except Exception as exception:
            indexing_status = 'Failed'
            self.logger.exception(
                f"Error while fetching the objects . Error {exception}"
            )
            raise exception
        finally:
            collection_name = config_data['vector_db']['azure_cognitive_search_index_name']
            project_id = sync_sharepoint.projectid if sync_sharepoint.projectid else "N/A"
            job_id = sync_sharepoint.job_id if  sync_sharepoint.job_id else "N/A"
            documentCount = 0
            indexsize = 0
            # no_of_batches = AzureSearchVectorStore.no_of_batches if AzureSearchVectorStore.no_of_batches else "N/A"
            time2 = datetime.now()
            processing_time = (time2 - time1).total_seconds() * 10**3
            time2 = time2.strftime('%Y-%m-%d %H:%M:%S')
            appname = config_data['common']['appname']
            file_metrics = [project_id, job_id, indexing_status, documentCount,processing_time ,indexsize, collection_name, appname, time2]
            MetricsRun().run_index_metrics(file_metrics)
        # self.local_storage.update_storage(storage_with_collection)

    def execute(self):
        """This function execute the start function."""
        return self.fetch_sharepoint_documents()
