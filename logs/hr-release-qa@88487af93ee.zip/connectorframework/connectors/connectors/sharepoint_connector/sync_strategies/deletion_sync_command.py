from utils import logger
from contextvars import ContextVar
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())


class DeletionSync:
    def __init__(self) -> None:
        app_log.info('Deletion Sync')
        pass
    pass