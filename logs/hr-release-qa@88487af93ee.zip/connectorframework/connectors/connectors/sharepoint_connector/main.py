from connectors.base import AbstractClass
from connectors.sharepoint_connector.sync_strategies.full_sync_command import FullSync
from connectors.sharepoint_connector.sync_strategies.incremental_sync_command import (
    IncrementalSync,
)
from connectors.sharepoint_connector.sync_strategies.deletion_sync_command import (
    DeletionSync,
)

CMD_FULL_SYNC = "full-sync"
CMD_INCREMENTAL_SYNC = "incremental-sync"
CMD_DELETION_SYNC = "deletion-sync"
CMD_PERMISSION_SYNC = "permission-sync"

commands = {
    CMD_FULL_SYNC: FullSync,
    CMD_INCREMENTAL_SYNC: IncrementalSync,
    CMD_DELETION_SYNC: DeletionSync,
}


class SharepointConnector(AbstractClass):
    def __init__(self, config) -> None:
        super().__init__()
        self.config = config

    def main(self):
        """Entry point for the connector."""

        sync_type = self.config.get("sync_type")
        return commands[sync_type](self.config).execute()
