import os
import threading
import time
from urllib.parse import urljoin
import requests
import uuid
import warnings
import datetime
import calendar
from dateutil.parser import parse
from multiprocessing import Pool
from chain_template import main_call
from connectors.sharepoint_connector.utils.usergroup_permissions import Permissions
from requests_ntlm import HttpNtlmAuth
from connectors.sharepoint_connector.utils.sharepoint_client import SharePoint
from connectors.sharepoint_connector.utils.utils import (
    encode,
    split_documents_into_equal_chunks,
    split_list_into_buckets,
    write_to_file,
    write_json,
)
import yaml
import argparse
import json
from contextvars import ContextVar

context_vars = ContextVar('context', default={})
#app_log = logger.getLogger(context_vars.get())
context = {}
context['component'] = "Connector"

IDS_PATH = os.path.join(os.path.dirname(__file__), "doc_id.json")

SITE = "site"
LIST = "list"
ITEM = "item"
SITES = "sites"
LISTS = "lists"
LIST_ITEMS = "list_items"
DRIVE_ITEMS = "drive_items"

warnings.filterwarnings("ignore")

def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)
parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
         "--file_path", default="config.yaml", help="Path to the config.yaml file"
                )
args = parser.parse_args()
filesystem_config = args.file_path
with open(filesystem_config, 'r') as file:
    common_data = yaml.safe_load(file)


def get_results(logger, response, entity_name):
    """Attempts to fetch results from a Sharepoint Server response
    :param response: response from the sharepoint client
    :param entity_name: entity name whether it is SITES, LISTS, LIST_ITEMS OR DRIVE_ITEMS
    Returns:
        Parsed response
    """
    if not response:
        #app_log.error(f"Empty response when fetching {entity_name}")
        return None

    if entity_name == "attachment" and not response.get("d", {}).get("results"):
        #app_log.info("Failed to fetch attachment")
        return None
    return response.get("d", {}).get("results")


class SyncSharepoint:
    """This class allows syncing objects from the SharePoint Server."""

    def __init__(
        self,
        config,
        logger,
        sharepoint_client,
        sync_type,
        start_time,
        end_time,
    ):
        self.config = config
        self.logger = logger
        self.sharepoint_client = sharepoint_client

        self.objects = config.get("objects")
        self.site_collections = config.get("sharepoint.site_collections")
        self.enable_permission = config.get("enable_document_permission")
        self.sync_type = sync_type
        self.start_time = start_time
        self.end_time = end_time
        self.sharepoint_thread_count = config.get("sharepoint_sync_thread_count")
        self.sharepoint_host = config.get("sharepoint.host_url")
        self.file_extensions = config.get("file_extensions")
        self.seclore_api_url = config.get("seclore.seclore_api_url")
        self.shared_path = config.get("shared_path")
        self.custom_urls = config.get("custom_url")
        self.site_to_include = self.get_site_to_include()
        self.secure_connection = config.get("sharepoint.secure_connection")
        self.certificate_path = config.get("sharepoint.certificate_path")
        self.lists_to_include = self.get_list_to_include()
        self.lists = config.get('lists', {})
        self.permissions = Permissions(self.sharepoint_client, logger)
        self.batch_size = config.get("batch_size")
        self.processor = config.get("num_of_processes")
        self.file_batch_size = config.get("file_batch_size")
        self.ADI_nas_path = common_data['parser']['nas_path']
        if not (config.get("isSecloreEnabled") is None):
                self.isSecloreEnabled = config.get("isSecloreEnabled")
        else:
            self.isSecloreEnabled = 'No'
        if not (config.get("filenames") is None):
             self.filenames = config.get("filenames")
        else:
            self.filenames = 'NA'
        current_time = datetime.datetime.now()
        self.job_id = calendar.timegm(current_time.timetuple())
        if not (config.get("projectid") is None):
            self.projectid = config.get("projectid")
        else:
            self.projectid =common_data['common']['appname'] + "_" + common_data['vector_db']['destination_name'] + "_" + config.get("type").replace('_','') + "_" + str(calendar.timegm(time.gmtime()))
        print("projectid",self.projectid)
    def get_site_to_include(self):
        sites_config = self.objects.get(SITES)
        sites_to_include = []
        for key in sites_config:
            sites_to_include.append(key)
        return sites_to_include

    def get_list_to_include(self):
        lists_config = self.objects.get(LISTS)
        lists_to_include = []
        for key in lists_config:
            lists_to_include.append(key)
        return lists_to_include

    def get_config(self, document_name):
        sites_to_include = self.objects.get(document_name)
        return sites_to_include

    def fetch_sites(self, parent_site_url, sites, ids):
        """This method fetches sites from a collection and invokes the
        index permission method to get the document level permissions.
        If the fetching is not successful, it logs proper message.
        :param parent_site_url: parent site relative path
        :param sites: dictionary of site paths
        :param ids: structure containing id's of all objects
        Returns:
            sites: list of site paths
            documents: response of sharepoint GET call with fields specified in the schema
        """
        rel_url = f"{parent_site_url}/_api/web/webs"
        #self.logger.info("Fetching the sites detail from url: %s" % (rel_url), extra=context)
        query = self.sharepoint_client.get_query(
            param_name=SITES,
            sync_type=self.sync_type,
        )

        response = self.sharepoint_client.get_data_batch(rel_url, query, SITES)
        # #print(response)
        sites_to_include = self.get_config(SITES)

        response_data = get_results(self.logger, response, SITES)

        if not response_data:
            '''self.logger.info(
                "No sites were created in %s"
                % (parent_site_url), extra=context
            )'''
            return sites
        '''self.logger.info(
            "Successfully fetched and parsed %s sites response from SharePoint"
            % len(response_data), extra=context
        )'''

        for i, _ in enumerate(response_data):
            id = response_data[i].get("Id")
            ids["sites"].update({id: response_data[i]["ServerRelativeUrl"]})
        for result in response_data:
            site_server_url = result.get("ServerRelativeUrl")
            sites.update({site_server_url: None})
            _ = self.fetch_sites(site_server_url, sites, ids)
        return sites

    def fetch_lists(self, sites, ids):
        """This method fetches lists from all sites in a collection and invokes the
        index permission method to get the document level permissions.
        If the fetching is not successful, it logs proper message.
        :param sites: dictionary of site path and it's last updated time
        :param ids: structure containing id's of all objects
        Returns:
            document: response of sharepoint GET call, with fields specified in the schema
        """
        #self.logger.info("Fetching lists for all the sites", extra=context)
        responses = []
        if not sites:
            '''self.logger.info(
                "No list was created in this interval: start time: %s and end time: %s"
                % (self.start_time, self.end_time), extra=context
            )'''
            return [], []

        for site in sites:
            rel_url = f"{site}/_api/web/lists"
            '''self.logger.info(
                "Fetching the lists for site: %s from url: %s" % (
                    site, rel_url), extra=context
            )'''

            query = self.sharepoint_client.get_query(
                param_name=LISTS,
                sync_type=self.sync_type
            )
            response = self.sharepoint_client.get_data_batch(
                rel_url, query, LISTS)

            response_data = get_results(self.logger, response, LISTS)
            if not response_data:
                '''self.logger.info(
                    "No list was created for the site : %s in this interval: start time: %s and end time: %s"
                    % (site, self.start_time, self.end_time), extra=context
                )'''
                continue
            '''self.logger.info(
                "Successfully fetched and parsed %s list response for site: %s from SharePoint"
                % (len(response_data), site), extra=context
            )'''

            if not ids["lists"].get(site):
                ids["lists"].update({site: {}})
            for i, _ in enumerate(response_data):
                relative_url = response_data[i]["RootFolder"].get(
                    "ServerRelativeUrl"
                )
                url = urljoin(
                    self.sharepoint_host,
                    relative_url,
                )
                list_id = response_data[i].get("Id")
                relative_url = response_data[i]["RootFolder"].get(
                    "ServerRelativeUrl"
                )

                ids["lists"][site].update(
                    {list_id: response_data[i]["Title"]})

            responses.append(response_data)
            lists = {}
            libraries = {}
            for response in responses:
                for result in response:
                    if result.get("BaseType") == 1:
                        libName = f"{result.get('ParentWebUrl')}/{result.get('Title')}"
                        if (
                            self.lists_to_include == None
                            or libName in self.lists_to_include
                        ):
                            libraries[result.get("Id")] = [
                                result.get("ParentWebUrl"),
                                result.get("Title"),
                                result.get("LastItemModifiedDate"),
                            ]
                    else:
                        lists[result.get("Id")] = [
                            result.get("ParentWebUrl"),
                            result.get("Title"),
                            result.get("LastItemModifiedDate"),
                        ]
        return lists, libraries

    def fetch_items(self, lists, ids):
        """This method fetches items from all the lists in a collection and
        invokes theindex permission method to get the document level permissions.
        If the fetching is not successful, it logs proper message.
        :param lists: document lists
        :param ids: structure containing id's of all objects
        Returns:
            document: response of sharepoint GET call, with fields specified in the schema
        """
        responses = []
        #self.logger.info("Fetching all the items for the lists", extra=context)
        if not lists:
            '''self.logger.info(
                "No item was created in this interval: start time: %s and end time: %s"
                % (self.start_time, self.end_time), extra=context
            )'''
        else:
            for value in lists.values():
                if not ids["list_items"].get(value[0]):
                    ids["list_items"].update({value[0]: {}})
            for list_content, value in lists.items():
                if parse(self.start_time) > parse(value[2]):
                    continue
                rel_url = f"{value[0]}/_api/web/lists(guid'{list_content}')/items?$select=*,FileRef"
                '''self.logger.info(
                    "Fetching the items for list: %s from url: %s" % (
                        value[1], rel_url), extra=context
                )'''

                query = self.sharepoint_client.get_query(
                    param_name=LIST_ITEMS
                )
                response = self.sharepoint_client.get_data_batch(
                    rel_url, query, LIST_ITEMS)

                response_data = get_results(self.logger, response, LIST_ITEMS)
                if not response_data:
                    '''self.logger.info(
                        "No item was created for the list %s in this interval: start time: %s and end time: %s"
                        % (value[1], self.start_time, self.end_time), extra=context
                    )'''
                    continue
                '''self.logger.info(
                    "Successfully fetched and parsed %s listitem response for list: %s from SharePoint"
                    % (len(response_data), value[1]),extra=context
                )'''

                document = []
                if not ids["list_items"][value[0]].get(list_content):
                    ids["list_items"][value[0]].update({list_content: []})
                rel_url = f"{value[0]}/_api/web/lists(guid'{list_content}')/items?$select=Attachments,AttachmentFiles,Title&$expand=AttachmentFiles"

                file_response_data = self.sharepoint_client.get_data_batch(
                    rel_url, query=query, param_name="attachment"
                )
                if file_response_data:
                    file_response_data = get_results(
                        self.logger, file_response_data.json(), "attachment"
                    )

                for i, _ in enumerate(response_data):
                    doc = {"type": ITEM}
                    url = urljoin(self.sharepoint_host, relative_url)
                    item_id = response_data[i].get("GUID")
                    if response_data[i].get("Attachments") and file_response_data:
                        for data in file_response_data:
                            if response_data[i].get("Title") == data["Title"]:
                                file_relative_url = data["AttachmentFiles"]["results"][
                                    0
                                ]["ServerRelativeUrl"]
                                url_s = f"{value[0]}/_api/web/GetFileByServerRelativeUrl('{encode(file_relative_url)}')/$value"
                                response = self.sharepoint_client.get_data_batch(
                                    url_s, query="", param_name="attachment"
                                )
                                doc["body"] = {}
                                if response and response.ok:
                                    try:
                                        doc["body"] = response.content
                                    except Exception as exception:
                                        self.logger.error(
                                            "Error while fetching the contents from the attachment, Error %s"
                                            % (exception), extra=context
                                        )

                                break
                    if self.enable_permission is True:
                        item_permission = self.fetch_permissions(
                            key=LIST_ITEMS,
                            list_id=list_content,
                            list_url=value[0],
                            itemid=str(response_data[i]["Id"]),
                        )
                    relative_url = response_data[i].get("FileRef")

                    doc["url"] = urljoin(self.sharepoint_host, relative_url)

                    document.append(doc)
                    if item_id not in ids["list_items"][value[0]][list_content]:
                        ids["list_items"][value[0]
                                          ][list_content].append(item_id)
                responses.extend(document)
        documents = {"type": LIST_ITEMS, "data": responses}
        return documents

    def fetch_drive_items(self, libraries, ids):
        """This method fetches items from all the lists in a collection and
        invokes the index permission method to get the document level permissions.
        If the fetching is not successful, it logs proper message.
        :param libraries: document lists
        :param ids: structure containing id's of all objects
        """
        try:
            #print("libraries", libraries)
            responses = []
            #self.logger.info("Fetching all the files for the library", extra=context)
            if not libraries:
                '''self.logger.info(
                    "No file was created in this interval: start time: %s and end time: %s"
                    % (self.start_time, self.end_time), extra=context
                )'''
            else:
                lists_config = self.get_config(LISTS)
                filter = ""
                metadata_fields = ""
                for lib_content, value in libraries.items():
                    if lists_config is not None:
                        list_config = lists_config[value[1]]
                        metadata_fields = list_config["metadata_fields"]
                        filter = list_config["filter"]
                        ##print("metadata", metadata_fields)

                    if not ids["drive_items"].get(value[0]):
                        ids["drive_items"].update({value[0]: {}})

                    rel_url = f"{value[0]}/_api/web/lists(guid'{lib_content}')/items?$select=Modified,Id,GUID,File,Folder,{metadata_fields}&$expand=File,Folder"
                    '''self.logger.info(
                        "Fetching the items for libraries: %s from url: %s"
                        % (value[1], rel_url), extra=context
                    )'''
                    query = self.sharepoint_client.get_query(
                        param_name=DRIVE_ITEMS,
                        sync_type=self.sync_type,
                        filter=filter
                    )
                    response = self.sharepoint_client.get_data_batch(
                        rel_url, query, DRIVE_ITEMS)
                    response_data = get_results(
                        self.logger, response, DRIVE_ITEMS)
                    if not response_data:
                        '''self.logger.info(
                            "No item was created for the library %s in this interval: start time: %s and end time: %s"
                            % (value[1], self.start_time, self.end_time), extra=context
                        )'''
                        continue
                    '''self.logger.info(
                        "Successfully fetched and parsed %s drive item response for library: %s from SharePoint"
                        % (len(response_data), value[1]), extra=context
                    )'''

                    if not ids["drive_items"][value[0]].get(lib_content):
                        ids["drive_items"][value[0]].update({lib_content: []})
                    for i, _ in enumerate(response_data):
                        document = {}
                        if response_data[i]["File"].get("TimeLastModified"):
                            document["job_id"] = self.job_id
                            document["file_name"] = f"{response_data[i]['File']['Name']}"
                            document["list_rel_url"] = f"{value[0]}"
                            document["file_id"] = f"{response_data[i].get('GUID')}"
                            document["list_id"] = f"{lib_content}"
                            document["id"] = f"{response_data[i].get('ID')}"
                            obj_type = "File"
                            file_url = urljoin(self.sharepoint_host,
                                               response_data[i][obj_type]['ServerRelativeUrl'])
                            document["file_url"] = f"{file_url}"
                            file_relative_url = response_data[i]["File"][
                                "ServerRelativeUrl"
                            ]
                            document[
                                "file_content_url"
                            ] = f"{value[0]}/_api/web/GetFileByServerRelativeUrl('{encode(file_relative_url)}')/$value"

                            metadata = {}
                            for field in metadata_fields.split(","):
                                if response_data[i][field] is not None:
                                    metadata[field] = response_data[i][field]
                            document["metadata"] = metadata

                        responses.append(document)
            return responses
        except Exception as ex:
            self.logger.exception(
                f"\Error fetching data {lib_content}: {ex}\n", extra=context)

    def fetch_drive_items_library(self, ids, libraryGuid, libraryName, siteUrl, pageUrl=None):
        """This method fetches items from specific library.
        If the fetching is not successful, it logs proper message.
        :param library: document list
        :param ids: structure containing id's of all objects
        """
        try:
            responses = []
            #self.logger.info("Fetching all the files for the library", extra=context)
            lists_config = self.get_config(LISTS)
            filter = ""
            metadata_fields = ""
            libName = f"{siteUrl}/{libraryName}"
            if lists_config is not None:
                list_config = lists_config[libName]
                metadata_fields = list_config["metadata_fields"]
                filter = list_config["filter"]
                #print("metadata", metadata_fields)

            if not ids["drive_items"].get(siteUrl):
                ids["drive_items"].update({siteUrl: {}})

            rel_url = f"{siteUrl}/_api/web/lists(guid'{libraryGuid}')/items?$select=Modified,Id,GUID,File,Folder,{metadata_fields}&$expand=File,Folder"
            '''self.logger.info(
                "Fetching the items for libraries: %s from url: %s"
                % (libraryName, rel_url), extra=context
            )'''
            query = self.sharepoint_client.get_query(
                param_name=DRIVE_ITEMS,
                sync_type=self.sync_type,
                filter=filter
            )
            response, nextUrl = self.sharepoint_client.get_items_batch(
                rel_url, query, DRIVE_ITEMS, pageUrl)
            response_data = get_results(
                self.logger, response, DRIVE_ITEMS)
            if not response_data:
                '''self.logger.info(
                    "No item was created for the library %s " % (libraryName), extra=context
                )'''

            self.logger.info(
                "Successfully fetched and parsed %s drive item response for library: %s from SharePoint"
                % (len(response_data), libraryName), extra=context
            )

            if not ids["drive_items"][siteUrl].get(libraryGuid):
                ids["drive_items"][siteUrl].update({libraryGuid: []})
            for i, _ in enumerate(response_data):
                document = {}
                if response_data[i]["File"].get("TimeLastModified"):
                    #self.logger.info(response_data[i], extra=context)
                    document["job_id"] = self.job_id
                    document["file_name"] = f"{response_data[i]['File']['Name']}"
                    document["list_rel_url"] = f"{siteUrl}"
                    document["file_id"] = f"{response_data[i].get('GUID')}"
                    document["file_size"] = f"{response_data[i]['File']['Length']}"
                    document["list_id"] = f"{libraryGuid}"
                    document["id"] = f"{response_data[i].get('ID')}"
                    document["is_seclore"] = list_config.get('IsSecloreEnabled', 'No')
                    document["file_path_url"] = response_data[i]["File"]["ServerRelativeUrl"].replace(siteUrl,'')
                    document["projectid"] = self.projectid
                    obj_type = "File"
                    file_url = urljoin(self.sharepoint_host,
                                       response_data[i][obj_type]['ServerRelativeUrl'])
                    document["file_url"] = f"{file_url}"
                    file_relative_url = response_data[i]["File"][
                        "ServerRelativeUrl"
                    ]
                    document[
                        "file_content_url"
                    ] = f"{siteUrl}/_api/web/GetFileByServerRelativeUrl('{encode(file_relative_url)}')/$value"

                metadata = {}
                for field in metadata_fields.split(","):
                    if response_data[i][field] is not None:
                        metadata[field] = response_data[i][field]
                document["metadata"] = metadata

                responses.append(document)

            return responses, nextUrl

        except Exception as ex:
            self.logger.exception(
                f"\Error fetching data {libraryGuid}: {ex}\n", extra=context)

    def process_files(self, files):
        try:
            list_config = self.get_config(LISTS)
            # #print("Thread id", str(threading.get_ident()))
            unique_string = str(uuid.uuid4())
            shared_path = self.shared_path
            json_path = os.path.join(
                shared_path,
                unique_string,
                "file_info.json",
            )
            json_response = []
            index = 0
            if not self.custom_urls:
                for i, _ in enumerate(files):
                    index = i
                    json_data = {}
                    json_data["job_id"] = files[i].get("job_id",self.job_id)
                    json_data["projectid"] = files[i].get("projectid",self.projectid)
                    json_data["file_id"] = files[i]["file_id"]
                    json_data["list_id"] = files[i]["list_id"]
                    json_data["item_id"] = files[i]["id"]
                    json_data["file_url"] = files[i]["file_url"]
                    json_data["file_name"] = files[i]["file_name"]
                    json_data["sourcelink"] = files[i]["file_url"]
                    json_data["source"] = files[i]["file_name"].rpartition('.')[0]
                    json_data['file_extn'] = files[i]["file_name"].rpartition('.')[2]
                    json_data["site_url"] = files[i]["list_rel_url"]
                    json_data["file_size"] = files[i]["file_size"]
                    json_data["metadata"] = files[i]["metadata"]
                    json_data["security"] = {}
                    # response = self.sharepoint_client.get(
                    #     files[i].get("file_content_url"), query="", param_name="attachment"
                    # )
                    url = f'{files[i]["list_rel_url"]}/_layouts/download.aspx?SourceUrl={files[i]["file_path_url"][1:]}'
                    response = self.sharepoint_client.get(
                        url, query="", param_name="attachment"
                    )
                    '''self.logger.info(
                        "file_relative_url %s %s"
                        % (files[i].get("file_content_url"), response.ok), extra=context
                    )'''
                    context.update({'file_name': files[i]["file_name"], 'actual_filesize': files[i]["file_size"]})
                    #self.logger.info("file details", extra=context)
                    if (any(x in json_data["file_url"] for x in self.filenames) or self.filenames =='NA') and (response and response.ok):
                    #if response and response.ok:
                        content = response.content
                        # Write to file
                        if content is not None and isinstance(content, bytes):
                            if self.enable_permission is True:
                                # users, groups = self.fetch_permissions(
                                users = self.fetch_permissions(
                                    key=DRIVE_ITEMS,
                                    list_id=files[i].get("list_id"),
                                    list_url=files[i].get("list_rel_url"),
                                    itemid=str(files[i].get("id")),
                                )
                                json_data["security"].update({"users": users})
                        file_path = os.path.join(
                            shared_path,
                            unique_string,
                            files[i].get("file_name"),
                        )
                        json_data['shared_file_path'] = file_path
                        file_metrics = [json_data["projectid"], json_data["job_id"], "Sharepoint", json_data["file_name"], json_data["file_url"], json_data["file_size"],
                                        common_data['common']['appname'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                        write_to_file(file_path, content, file_metrics)
                        # with open(file_path) as file:
                        #     ss = file.read()
                        if files[i].get('is_seclore') == 'Yes':
                            response = self.unprotect_document(file_path)
                        #print("writing file data : " + file_path)
                        # json_data["file_url"] = json_path
                        json_response.append(json_data)
            else:
                for i, _ in enumerate(files):
                    index = i
                    # json_data = {}
                    # json_data["job_id"] = files[i].get("job_id",self.job_id)
                    # json_data["file_id"] = files[i]["fileid"]
                    # # json_data["list_id"] = files[i]["list_id"]
                    # json_data["item_id"] = files[i]["itemid"]
                    # json_data["projectid"] = files[i].get("projectid",self.projectid)
                    # json_data["file_url"] = files[i]["fileurl"]
                    # json_data["file_name"] = files[i]["filename"]
                    # json_data["site_url"] = files[i]["siteurl"]
                    # json_data["file_size"] = files[i]["filesize"]
                    # json_data["metadata"] = files[i]["metadata"]
                    # json_data["security"] = {}
                    # json_path = os.path.join(self.ADI_nas_path, files[i].get("filename").replace('.pdf', '.json'))
                    if os.path.exists(os.path.join(self.ADI_nas_path, files[i].get("filename").replace('.pdf', '.json'))):
                        json_data = {}
                        json_data["job_id"] = files[i].get("job_id",self.job_id)
                        json_data["projectid"] = files[i].get("projectid",self.projectid)
                        json_data["file_id"] = files[i]["fileid"]
                        # json_data["list_id"] = files[i]["list_id"]
                        json_data["siteurl"] = files[i]["siteurl"]
                        # json_data["page"] = files[i]["page"]
                        json_data["item_id"] =  files[i].get("itemid", files[i].get("item_id",''))
                        json_data["file_url"] = files[i].get("fileurl", files[i].get("file_url",''))
                        json_data["file_name"] = files[i].get("filename", files[i].get("file_name",''))
                        json_data["sourcelink"] =  files[i].get("fileurl", files[i].get("file_url",''))
                        json_data["source"] = json_data["file_name"].rpartition('.')[0]
                        json_data["file_extn"] = json_data["file_name"].rpartition('.')[2]
                        json_data["site_url"] = files[i]["siteurl"]
                        json_data["file_size"] = files[i]["filesize"]
                        json_data["seclorefileurl"] = files[i].get("seclorefileurl",'')
                        json_data["metadata"] = files[i]["metadata"]
                        json_data["sharepoint_metadata"] = json.dumps(files[i]["metadata"]) if isinstance(files[i]["metadata"], dict) else files[i]["metadata"]
                        # json_data["metadata"] = files[i]["metadata"]
                        json_data["security"] = files[i].get("security",{})

                        # response = self.sharepoint_client.get(
                        #     files[i].get("file_content_url"), query="", param_name="attachment"
                        # )
                        # code added for ark
                        if any(x in json_data["file_name"] for x in self.filenames) or self.filenames =='NA':
                            replace_dict= {"!": "%21" ,"\"": "%22" ,"#": "%23" ,"%": "%25" ,"&": "%26" ,"'": "%27" ,"(": "%28" ,")": "%29" ,"*": "%2A" ,"+": "%2B" ,",": "%2C" ,"-": "%2D"}
                            for old, new in replace_dict.items():
                                if "metadata" in files[i] and "nonseclorefilepath" in files[i]["metadata"]:
                                    url = f'{files[i]["siteurl"]}/_layouts/download.aspx?SourceUrl={files[i]["metadata"]["nonseclorefilepath"]}'
                                else:
                                    url = f'{files[i]["siteurl"]}/_layouts/download.aspx?SourceUrl={files[i]["fileurl"][6:]}'
                            response = self.sharepoint_client.download_file(
                                url
                            )
                        '''self.logger.info(
                            "file_relative_url %s %s"
                            % (files[i].get("file_content_url"), response.ok)
                        )'''
                        context.update({'file_name': files[i]["filename"], 'actual_filesize': files[i]["filesize"]})
                        #self.logger.info("file details", extra=context)
                        #updated code to run specific file names
                        #filenames = ["ET2015 Poster_0189_Ryuichi Miura_Rev3.pdf"]
                        if (any(x in json_data["file_url"] for x in self.filenames) and (response and response.ok)) or (self.filenames =='NA' and (response and response.ok)):
                        #if response and response.ok:
                            content = response.content
                            # Write to file
                            if content is not None and isinstance(content, bytes):
                                if self.enable_permission is True:
                                    users = {}
                                    # users, groups = self.fetch_permissions(
                                    # users = self.fetch_permissions(
                                    #     key=DRIVE_ITEMS,
                                    #     list_id=files[i].get("list_id"),
                                    #     list_url=files[i].get("list_rel_url"),
                                    #     itemid=str(files[i].get("itemid")),
                                    # )
                                    json_data["security"].update({"users": users})
                            file_path = os.path.join(
                                shared_path,
                                unique_string,
                                files[i].get("filename"),
                            )
                            json_data['shared_file_path'] = file_path
                            file_metrics = [json_data["projectid"], json_data["job_id"], "Sharepoint", json_data["file_name"], json_data["file_url"], json_data["file_size"],
                                            common_data['common']['appname'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                            write_to_file(file_path, content, file_metrics)
                            if self.isSecloreEnabled == 'Yes' or list_config.get('IsSecloreEnabled', 'No') == 'Yes':
                                response = self.unprotect_document(file_path)
                            #print("writing file data : " + file_path)
                            # json_data["file_url"] = json_path
                            json_response.append(json_data)
            if(len(json_response) > 0):
                write_json(json_path, json_response)
                main_call(json_path)
            # write_json(json_path, json_response)
            # main_call(json_path)
            return json_path

        except Exception as exception:
            self.logger.error(
                "Error while processing: %s", exception
            )

    def unprotect_document(self, file_path):
        try:
            ActivityComments = "Protected by Search Crawler"
            SecloreURLUnProtection = self.seclore_api_url
            path = file_path.replace("\\","/")
            client = requests.Session()
            valueProtect = (
                "strFilePath=" + path + "&strActivityComments=" + ActivityComments
            )
            urlForProtection = SecloreURLUnProtection + valueProtect
            responseProtect = client.get(urlForProtection)
            statusCode = str(responseProtect.status_code)
            message = responseProtect.text
            '''self.logger.info(
                f"Unprotection for file {file_path}: {message} {statusCode}"
            )'''
            return True if statusCode == "200" else False
        except Exception as ex:
            self.logger.exception(
                f"\nError unprotecting file in path {file_path}: {ex}\n"
            )
            return False

    def fetch_drive_items_api(self, libraries, total_processed):
        """This method fetches items from all the lists in a collection and
        invokes the index permission method to get the document level permissions.
        If the fetching is not successful, it logs proper message.
        :param libraries: document lists
        :param ids: structure containing id's of all objects
        """
        try:
            responses = []
            report = {}
            #  here value is a list of url and title of the library
            self.logger.info("Fetching all the files for the library")
            if not libraries:
                '''self.logger.info(
                    "No file was created in this interval: start time: %s and end time: %s"
                    % (self.start_time, self.end_time)
                )'''
            else:
                documents = []
                file_name = libraries["FileName"]
                file_url = libraries["FileUrl"]
                sp_security = libraries["SP_Security"]
                sp_metadata = libraries["SP_Metadata"]
                sp_et_year = sp_metadata["ETYear"]
                sp_file_size = sp_metadata["FileSize"]
                if file_name.split(".")[-1] in self.file_extensions:
                    report["Source_File_Url"] = file_url
                    report["Source_File_Size"] = sp_file_size

                    content = ""
                    # url = f"http://ppesp13spcapps/Test2023/_layouts/15/download.aspx?SourceUrl={file_url}"
                    url = f"https://spintapps.amat.com/{sp_et_year}/_layouts/download.aspx?SourceUrl={file_url}"

                    file_path = self.nas_path + file_name
                    download_start_time = time.time()
                    self.download_file(file_path, url)
                    download_end_time = time.time()
                    report["Download_Time"] = download_end_time - \
                        download_start_time
                    seclore_result = self.unprotect_document(file_path)
                    report["Secure_Unprotection_Success"] = seclore_result
                    documents.append({"file_name": file_name})
            responses.extend(documents)
            documents = {"type": DRIVE_ITEMS, "data": responses}
            '''print(
                f"\nThread Id: {threading.get_ident()}\nCurrently processing: {file_name}\nProcessed: {total_processed} files\n"
            )
            self.logger.info(
                f"Thread Id: {threading.get_ident()}\nCurrently processing: {file_name}\nProcessed: {total_processed} files"
            )'''

            #self.logger.info(f"Report for file {file_url} {str(report)}")
            return documents, report
        except Exception as ex:
            self.logger.exception(f"\nError fetching file: {ex}\n")

    def get_roles(self, key, site, list_url, list_id, itemid):
        """Checks the permissions and returns the user roles.
        :param key: key, a string value
        :param site: site name to check the permission
        :param list_url: list url to access the list
        :param list_id: list id to check the permission
        :param itemid: item id to check the permission
        Returns:
            roles: user roles
        """
        if key == SITES:
            rel_url = site
            roles = self.permissions.fetch_users(key, rel_url)

        elif key == LISTS:
            rel_url = list_url
            roles = self.permissions.fetch_users(key, rel_url, list_id=list_id)

        else:
            rel_url = list_url
            roles = self.permissions.fetch_users(
                key, rel_url, list_id=list_id, item_id=itemid
            )

        return roles

    def fetch_permissions(
        self,
        key,
        site=None,
        list_id=None,
        list_url=None,
        itemid=None,
    ):
        """This method when invoked, checks the permission inheritance of each object.
        If the object has unique permissions, the list of users having access to it
        is fetched using sharepoint api else the permission levels of the that object
        is taken same as the permission level of the site collection.
        :param key: key, a string value
        :param site: site name to index the permission for the site
        :param list_id: list id to index the permission for the list
        :param list_url: url of the list
        :param itemid: item id to index the permission for the item
        Returns:
            groups: list of users having access to the given object
        """
        roles = self.get_roles(key, site, list_url, list_id, itemid)

        users = []
        groups = []

        if not roles:
            return []
        roles = get_results(self.logger, roles.json(), "roles")
        for role in roles:
            if role["Member"]["__metadata"]["type"] == "SP.User":
                email = role["Member"]["Email"]
                title = role["Member"]["Title"]
                add = email if email else title
                if add in users:
                    continue
                users.append(add)
            else:
                group_users = role['Member']['Users']['results']
                for user in group_users:
                    email = user['Email']
                    if email in users:
                        continue
                    users.append(email)
        return users

    def fetch_and_append_sites(self, ids, collection):
        """Fetches and appends site details
        :param ids: id collection of the all the objects
        :param collection: collection name
        """
        try:
            if None in self.site_collections:
                parent_site_url = f"/"
            else:
                parent_site_url = f"/sites/{collection}"

            #print(parent_site_url)
            sites_path = []
            sites = self.fetch_sites(
                parent_site_url,
                {},
                ids
            )
            if sites is not None:
                sites_path.append(sites)
            return sites_path
        except Exception as ex:
            print(ex)

    def fetch_and_append_lists(self, ids, sites_path):
        """Fetches and appends list details
        :param ids: id collection of the all the objects
        :param sites_path: dictionary of site path and it's last updated time
        """
        try:
            lists_details, libraries_details = self.fetch_lists(
                sites_path, ids)
            return [lists_details, libraries_details]
        except Exception as ex:
            print(ex)

    def fetch_and_append_list_items(self, ids, lists_details):
        """Fetches and appends list_items
        :param ids: id collection of the all the objects
        :param lists_details: dictionary containing list name, list path and id
        """
        try:
            items = self.fetch_items(lists_details, ids)
            return items
        except Exception as ex:
            print(ex)

    def fetch_and_append_drive_items(self, ids, libraries_details):
        """Fetches and appends the drive items
        :param ids: id collection of the all the objects
        :param libraries_details: dictionary containing library name, library path and id
        """
        try:
            documents = self.fetch_drive_items(libraries_details, ids)
            return documents
        except Exception as ex:
            print(ex)

    def fetch_and_append_drive_api(self, libraries_details, total_processed):
        try:
            documents, report = self.fetch_drive_items_api(
                libraries_details, total_processed
            )
            return report
        except Exception as ex:
            self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")

    def fetch_records_from_api(self):
        try:
            document_urls = []
            if self.secure_connection and self.certificate_path:
                verify = self.certificate_path
            else:
                verify = self.secure_connection
            request_headers = {
                "accept": "application/json",
                "content-type": "application/json",
            }
            for url in self.custom_urls:
                # payload = f'\"{url["body"]}\"'
                if url["body"] != None:
                    payload = f'\"{url["body"]}\"'
                    response = requests.post(
                        url['url'], data= payload ,headers=request_headers, verify=False)
                    data = response.json()
                    document_urls.append(data)
                else:
                    response = requests.get(
                        url['url'], headers=request_headers, verify=False)
                    data = response.json()
                    document_urls.append(data)
            return document_urls
        except Exception as ex:
            self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")

    def fetch_records_from_sharepoint(self, thread_count, ids, collection):
        """Fetches Sites, Lists, List Items and Drive Items from sharepoint.
        :param producer: Producer function
        :param date_ranges: Partition of time range
        :param thread_count: Thread count
        :param ids: Content of the local storage
        :param collection: SharePoint server Collection name
        """
        # Fetch sites
        try:
            if not self.custom_urls:
                warnings.filterwarnings("ignore")
                st = time.time()
                sites = self.fetch_and_append_sites(ids, collection)
                if None in self.site_collections:
                    all_sites = [f"/"]
                else:
                    all_sites = [f"/sites/{collection}"]

                for site in sites:
                    all_sites.extend(site)

                #print("All sites", all_sites)
                # Fetch lists
                lists = self.fetch_and_append_lists(ids, all_sites)

                # Fetch list items
                lists_details, libraries_details = {}, {}
                # for result in lists:
                if len(lists) > 0:
                    lists_details.update(lists[0])
                    libraries_details.update(lists[1])

                #self.logger.info("Lists: %s" % (lists_details))
                #self.logger.info("Libraries: %s" % (libraries_details))

                # if LIST_ITEMS in self.objects:
                #     #print("Found lists", lists_details)
                #     listItems = self.fetch_and_append_list_items(ids, lists_details)

                # Fetch library details
                if DRIVE_ITEMS in self.objects:
                    #self.logger.info("Found libraries %s" % (libraries_details))
                    for libGuid, value in libraries_details.items():
                        documents = None
                        nextUrl = None
                        new_lists = []
                        while True:
                            if nextUrl is None:
                                documents, nextUrl = self.fetch_drive_items_library(
                                    ids, libGuid, value[1], value[0])
                            else:
                                documents, nextUrl = self.fetch_drive_items_library(
                                    ids, libGuid, value[1], value[0], nextUrl)

                            '''self.logger.info(
                                "Total documents to be indexed %s" % (len(documents)))
                            self.logger.info("Next Page %s" % (nextUrl))
                            #print("Total documents to be indexed", len(documents))'''

                            # for i in range(0, len(documents), 2):
                            #     new_lists.append(documents[i:i+2])

                            # # multi processing
                            json_path = []
                            batch_size = int(self.file_batch_size)
                            pool_object = Pool(self.processor)
                            file_batches = [documents[i:i + batch_size] for i in range(0,len(documents), batch_size)]

                            try:
                                # Spawn threads
                                json_path = pool_object.map(self.process_files, file_batches)
                                pool_object.close()
                                pool_object.join()
                            except Exception as err:
                                # Terminate the thread if failed
                                pool_object.close()
                                pool_object.join()

                            # self.logger.info(new_lists)
                            # file_lists = new_lists
                            # for files in file_lists:
                            #     json_path = self.process_files(files)
                            #     self.logger.info(json_path)

                            # new_lists = []
                            # nextUrl=None
                            if nextUrl is False or nextUrl is None:
                                break

                et = time.time()
                #print("time of execution", et - st)
                #print("path of the json file", json_path)
                return self.job_id  # files
            else:
                documents = self.fetch_records_from_api()
                for document in documents:
                    new_lists = []
                    while True:
                        document, nextUrl = document['results'], document['nextbatch']
                        # for i in range(0, len(document), 2):
                        #     new_lists.append(document[i:i+2])

                        # multi processing
                        json_path = []
                        batch_size = int(self.file_batch_size)
                        pool_object = Pool(self.processor)
                        file_batches = [document[i:i + batch_size] for i in range(0,len(document), batch_size)]
                        try:
                            # Spawn threads
                            json_path = pool_object.map(self.process_files, file_batches)
                            pool_object.close()
                            pool_object.join()
                        except Exception as err:
                            # Terminate the thread if failed
                            pool_object.close()
                            pool_object.join()
                        #if nextUrl=="":
                         #   break

                        if nextUrl is False or nextUrl is None:
                            break                        # self.logger.info(new_lists)
                        # file_lists = new_lists
                        # for files in file_lists:
                        #     json_path = self.process_files(files)
                        #     self.logger.info(json_path)

        except Exception as ex:
            self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")