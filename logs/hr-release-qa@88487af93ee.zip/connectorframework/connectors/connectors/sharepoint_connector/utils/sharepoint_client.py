import time
import requests
import base64

from requests.exceptions import RequestException
from requests_ntlm import HttpNtlmAuth

from utils import logger
from contextvars import ContextVar
context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
context = {}

class SharePoint:
    def __init__(self, config, logger):
        self.logger = logger
        self.retry_count = int(config.get("retry_count"))
        self.host = config.get("sharepoint.host_url")
        self.domain = config.get("sharepoint.domain")
        self.username = config.get("sharepoint.username")
        self.password = base64.b64decode(config.get("sharepoint.password")).decode()
        self.secure_connection = config.get("sharepoint.secure_connection")
        self.certificate_path = config.get("sharepoint.certificate_path")
        self.batch_size = config.get("batch_size")

    def get(self, rel_url, query, param_name):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is sites, lists, list_items, drive_items, permissions or deindex
        Returns:
            Response of the GET call"""

        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        response_list = {"d": {"results": []}}
        paginate_query = True
        skip, top = 0, 500
        next_url = None
        next = True
        while next:
            if param_name in ["sites", "lists"]:
                if query is None or query == "":
                    paginate_query = f"?$top={top}"
                else:
                    paginate_query = query + f"&$top=5000"
            elif skip == 0 and param_name in ["list_items", "drive_items"]:
                paginate_query = query + f"&$top={top}"
            elif param_name in [
                "permission_users",
                "permission_groups",
                "deindex",
                "attachment",
            ]:
                paginate_query = query
            next_url = (
                next_url
                if next_url is not None
                else f"{self.host}/{rel_url}{paginate_query}"
            )
            print("URL", next_url)
            skip += 500
            retry = 0
            if self.secure_connection and self.certificate_path:
                verify = self.certificate_path
            else:
                verify = self.secure_connection
            while retry <= self.retry_count:
                try:
                    response = requests.get(
                        next_url,
                        auth=HttpNtlmAuth(
                            self.domain + "\\" + self.username, self.password
                        ),
                        headers=request_headers,
                        verify=verify,
                    )
                    if response.ok:
                        if param_name in ["sites", "lists"] and response:
                            response_data = response.json()
                            response_result = response_data.get(
                                "d", {}).get("results")
                            response_list["d"]["results"].extend(
                                response_result)
                            next = None
                            break
                        if param_name in ["list_items", "drive_items"] and response:
                            response_data = response.json()
                            response_list["d"]["results"].extend(
                                response_data.get("d", {}).get("results")
                            )
                            '''print(
                                "\nresponse_list\n",
                                response_data.get("d", {}).get(
                                    "__next", False),
                                len(response_list["d"]["results"]),
                            )'''
                            next_url = response_data.get(
                                "d", {}).get("__next", False)
                            if not next_url:
                                next = False
                            #print("\nurl\n", next_url)
                            break

                        return response

                    if response.status_code >= 400 and response.status_code < 500:
                        if not (
                            param_name == "deindex" and response.status_code == 404
                        ):
                            app_log.exception(
                                f"Error: {response.reason}. Error while fetching from the sharepoint, url: {next_url}."
                            )
                        return response
                    app_log.error(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {response.reason}"
                    )
                    # This condition is to avoid sleeping for the last time
                    if retry < self.retry_count:
                        time.sleep(2**retry)
                    retry += 1
                    paginate_query = None
                    continue
                except RequestException as exception:
                    app_log.exception(
                        f"Error while fetching from the sharepoint, url: {next_url}. Retry Count: {retry}. Error: {exception}"
                    )
                    # This condition is to avoid sleeping for the last time
                    if retry < self.retry_count:
                        time.sleep(2**retry)
                    else:
                        return False
                    retry += 1
        if retry > self.retry_count:
            return response
        return response_list

    def download_file(self, file_url):
        try:
            request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            }
            app_log.info(f"Attempting to download {file_url}")
            if self.secure_connection and self.certificate_path:
                verify = self.certificate_path
            else:
                verify = self.secure_connection
            response = requests.get(
                file_url,
                auth=HttpNtlmAuth(
                    f"{self.domain}\\{self.username}", self.password), headers=request_headers , verify=False
            )
            return response
        except Exception as ex:
            app_log.exception(f"\nError downloading file: {ex}\n", extra=context)

    def get_data_batch(self, rel_url, query, param_name):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is sites, lists, list_items, drive_items, permissions or deindex
        Returns:
            Response of the GET call"""
        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        paginate_query = True
        top = 500
        if param_name in ["sites", "lists"]:
            if query is None or query == "":
                paginate_query = f"?$top={top}"
            else:
                paginate_query = query
        elif param_name in ["list_items", "drive_items"]:
            if query is None or query == "":
                paginate_query = f"?$top={top}"
            else:
                paginate_query = query
        elif param_name in [
            "permission_users",
            "permission_groups",
            "deindex",
            "attachment",
        ]:
            paginate_query = query

        url = f"{self.host}/{rel_url}{paginate_query}"
        print("URL", url)

        retry = 0
        if self.secure_connection and self.certificate_path:
            verify = self.certificate_path
        else:
            verify = self.secure_connection

        response = requests.get(url, auth=HttpNtlmAuth(
            self.domain + "\\" + self.username, self.password), headers=request_headers, verify=verify)

        if response.status_code < 400:
            if param_name in ["sites", "lists"]:
                response_data = response.json()
                response_result = response_data.get("d", {}).get("results")
                response_list = {"d": {"results": response_result}}
                return response_list
            elif param_name in ["list_items", "drive_items"]:
                response_data = response.json()
                response_list = {
                    "d": {"results": response_data.get("d", {}).get("results")}}
                next_url = response_data.get("d", {}).get("__next", False)
                return response_list
            else:
                return response
        elif response.status_code >= 400 and response.status_code < 500:
            if not (param_name == "deindex" and response.status_code == 404):
                app_log.exception(
                    f"Error: {response.reason}. Error while fetching from the sharepoint, url: {url}.")
            return response
        else:
            app_log.error(
                f"Error while fetching from the sharepoint, url: {url}. Retry Count: {retry}. Error: {response.reason}")
            return None

    def get_items_batch(self, rel_url, query, param_name, pageUrl=None):
        """Invokes a GET call to the Sharepoint server
        :param rel_url: relative url to the sharepoint farm
        :param query: query for passing arguments to the url
        :param param_name: parameter name whether it is list_items, drive_items
        Returns:
            Response of the GET call"""
        request_headers = {
            "accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
        }

        paginate_query = True
        top = self.batch_size
        if param_name in ["list_items", "drive_items"]:
            if query is None or query == "":
                paginate_query = f"&$top={top}"
            else:
                paginate_query = query
        elif param_name in ["attachment"]:
            paginate_query = query

        if pageUrl is None:
            url = f"{self.host}/{rel_url}{paginate_query}"
        else:
            url = pageUrl
        print("URL-2", url)

        retry = 0
        if self.secure_connection and self.certificate_path:
            verify = self.certificate_path
        else:
            verify = self.secure_connection

        response = requests.get(url, auth=HttpNtlmAuth(
            self.domain + "\\" + self.username, self.password), headers=request_headers, verify=verify)

        if response.status_code < 400:
            if param_name in ["list_items", "drive_items"]:
                response_data = response.json()
                response_list = {
                    "d": {"results": response_data.get("d", {}).get("results")}}
                next_url = response_data.get("d", {}).get("__next", False)
                return response_list, next_url
            else:
                return response, None
        elif response.status_code >= 400 and response.status_code < 500:
            if not (param_name == "deindex" and response.status_code == 404):
                app_log.exception(
                    f"Error: {response.reason}. Error while fetching from the sharepoint, url: {url}.")
            return response, None
        else:
            app_log.error(
                f"Error while fetching from the sharepoint, url: {url}. Retry Count: {retry}. Error: {response.reason}")
            return None, None

    @staticmethod
    def get_query(
        param_name, sync_type=None, filter=None, start_time=None, end_time=None
    ):
        """returns the query for each objects
        :param start_time: start time of the interval for fetching the documents
        :param end_time: end time of the interval for fetching the documents
        Returns:
            query: query for each object"""
        query = ""
        time_filter = f"(LastItemModifiedDate ge datetime'{start_time}') and (LastItemModifiedDate le datetime'{end_time}')"
        drive_time_filter = f"(Modified ge datetime'{start_time}') and (Modified le datetime'{end_time}')"
        if param_name == "sites":
            if sync_type == "full":
                query = f"?$filter=({filter})" if filter else ""
            else:
                query = (
                    f"?$filter={time_filter} and ({filter})"
                    if filter
                    else f"?$filter={time_filter}"
                )
        elif param_name == "lists":
            expand_str = "?$expand=RootFolder"
            if sync_type == "full":
                query = (
                    f"{expand_str}&$filter=({filter}) and (Hidden eq false)"
                    if filter
                    else f"{expand_str}&$filter=(Hidden eq false)"
                )
            else:
                query = (
                    f"{expand_str}&$filter={time_filter} and (Hidden eq false) and ({filter})"
                    if filter
                    else f"{expand_str}&$filter={time_filter} and (Hidden eq false)"
                )
        else:
            if sync_type == "full":
                query = f"&$filter=({filter})" if filter else ""
            else:
                query = (
                    f"&$filter={drive_time_filter} and ({filter})"
                    if filter
                    else f"&$filter={drive_time_filter}"
                )
        return query
