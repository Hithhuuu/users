SITES = "sites"
LISTS = "lists"
LIST_ITEMS = "list_items"
DRIVE_ITEMS = "drive_items"


class Permissions:
    def __init__(self, sharepoint_client, logger):
        self.sharepoint_client = sharepoint_client
        self.logger = logger

    def fetch_users(self, key, rel_url, list_id="", item_id=""):
        """Invokes GET calls to fetch unique permissions assigned to an object
        :param key: object key
        :param rel_url: relative url to the sharepoint farm
        :param list_id: list guid
        :param item_id: item id
        Returns:
            Response of the GET call
        """
        self.logger.info("Fetching the user roles for key: %s" % (key))
        maps = {
            SITES: "_api/web/roleassignments?$expand=Member/users,RoleDefinitionBindings",
            LISTS: f"_api/web/lists(guid'{list_id}')/roleassignments?$expand=Member/users,RoleDefinitionBindings",
            LIST_ITEMS: f"_api/web/lists(guid'{list_id}')/items({item_id})/roleassignments?$expand=Member/users,RoleDefinitionBindings",
            DRIVE_ITEMS: f"_api/web/lists(guid'{list_id}')/items({item_id})/roleassignments?$expand=Member/users,RoleDefinitionBindings",
        }
        if not rel_url.endswith("/"):
            rel_url = rel_url + "/"
        return self.sharepoint_client.get(rel_url, maps[key], "permission_users")

    def fetch_groups(self, rel_url, userid):
        """Invokes GET calls to fetch the group roles for a user
        :param rel_url: relative url to the sharepoint farm
        :param userid: user id for fetching the roles
        """
        self.logger.info("Fetching the group roles for userid: %s" % (userid))
        return self.sharepoint_client.get(
            rel_url, f"_api/web/GetUserById({userid})/groups", "permission_groups"
        )
