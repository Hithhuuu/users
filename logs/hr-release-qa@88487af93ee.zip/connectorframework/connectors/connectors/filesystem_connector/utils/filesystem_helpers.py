import os
import threading
import time
import json
from urllib.parse import urljoin
import requests
import uuid
import warnings
from dateutil.parser import parse
from multiprocessing import Pool
from chain_template import main_call
from connectors.filesystem_connector.utils.utils import (
    encode,
    split_documents_into_equal_chunks,
    split_list_into_buckets,
    write_to_file,
    write_json,
)
from datetime import datetime
import calendar
import argparse
import yaml

IDS_PATH = os.path.join(os.path.dirname(__file__), "doc_id.json")

SITE = "site"
LIST = "list"
ITEM = "item"
SITES = "sites"
LISTS = "lists"
LIST_ITEMS = "list_items"
DRIVE_ITEMS = "drive_items"

warnings.filterwarnings("ignore")

def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)


# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)
parser = argparse.ArgumentParser(description="Data Ingestion Flow")
parser.add_argument(
         "--file_path", default="filesystem.yaml", help="Path to the config.yaml file"
                )
args = parser.parse_args()
filesystem_config = args.file_path
with open(filesystem_config, 'r') as file:
    common_data = yaml.safe_load(file)
    

def get_results(logger, response, entity_name):
    """Attempts to fetch results from a Sharepoint Server response
    :param response: response from the sharepoint client
    :param entity_name: entity name whether it is SITES, LISTS, LIST_ITEMS OR DRIVE_ITEMS
    Returns:
        Parsed response
    """
    if not response:
        logger.error(f"Empty response when fetching {entity_name}")
        return None

    if entity_name == "attachment" and not response.get("d", {}).get("results"):
        logger.info("Failed to fetch attachment")
        return None
    return response.get("d", {}).get("results")


class SyncFileSystem:
    """This class allows syncing objects from the filesystem Server."""

    def __init__(
        self,
        config,
        logger,
        sync_type,
        start_time,
        end_time,
    ):
        self.config = config
        self.logger = logger

        self.objects = config.get("objects")
        self.sync_type = sync_type
        self.start_time = start_time
        self.end_time = end_time
        self.filesystem_thread_count = config.get("filesystem_sync_thread_count")
        self.file_extensions = config.get("file_extensions")
        self.seclore_api_url = config.get("seclore.seclore_api_url")
        self.shared_path = config.get("shared_path")
        self.batch_size = config.get("batch_size")
        self.processor = config.get("num_of_processes")
        self.file_batch_size = config.get("file_batch_size")
        if not (config.get("projectid") is None):
            self.projectid = config.get("projectid")
        else:
            self.projectid =common_data['common']['appname'] + "_" + common_data['vector_db']['destination_name'] + "_" + config.get("type").replace('_','') + "_" + str(calendar.timegm(time.gmtime()))

        self.type = config.get("type")
        current_time = datetime.now()
        self.job_id = calendar.timegm(current_time.timetuple())

    def fetch_filessytem_prop(self, url, input_type):
        responses = []
        if(input_type == 'local'):
            if os.path.isdir(url):
                folder_properties = []
                for file_name in os.listdir(url):
                    file_path = os.path.join(url, file_name)
                    if os.path.isfile(file_path):
                        document = {}
                        file_stat = os.stat(file_path)
                        document["file_name"] = file_name
                        document["file_size"] = str(file_stat.st_size)
                        document["file_crt_date"] = datetime.fromtimestamp(os.path.getctime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                        document["file_mod_date"] = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                        document["file_acc_time"] = datetime.fromtimestamp(os.path.getatime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                        document["file_path"] = file_path
                        document["job_id"] = self.job_id
                        document["projectid"] = self.projectid
                        document["type"] = self.type
                        responses.append(document)
        return responses

    def process_files(self, files):
        try:
            unique_string = str(uuid.uuid4())
            shared_path = self.shared_path
            json_path = os.path.join(
                shared_path,
                unique_string,
                "file_info.json",
            )
            json_response = []
            index = 0
            for i, _ in enumerate(files):
                index = i
                json_data = {}
                json_data["file_size"] = files[i]["file_size"]
                json_data["file_crt_date"] = files[i]["file_crt_date"]
                json_data["file_mod_date"] = files[i]["file_mod_date"]
                json_data["file_acc_time"] = files[i]["file_acc_time"]
                json_data["file_name"] = files[i]["file_name"]
                json_data["file_path"] = files[i]["file_path"]
                json_data["file_url"] = files[i]["file_path"]
                json_data["job_id"] = files[i]["job_id"]
                if not (files[i].get("projectid") is None):
                    json_data["projectid"] = files[i]["projectid"]
                else:
                    json_data["projectid"] = files[i]["type"] + "_" + str(calendar.timegm(time.gmtime()))
                json_data["file_id"] = files[i]["file_path"]
                file_path = files[i]["file_path"]
                with open(file_path, 'rb') as file:
                    content = file.read()
                    file_path_update = os.path.join(
                        shared_path,
                        unique_string,
                        files[i].get("file_name"),
                    )
                    #add source, filename, path, security, size
                    file_metrics = [json_data["projectid"], json_data["job_id"], "FileSystem", json_data["file_name"], json_data["file_path"], json_data["file_size"],
                                    common_data['common']['appname'], datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
                    write_to_file(file_path_update, content,file_metrics)
                    json_data['shared_file_path'] = file_path_update
                    json_data["last_updated"]=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    json_response.append(json_data)
            write_json(json_path, json_response)
            main_call(json_path)
            return json_path

        except Exception as exception:
            print(exception)
            self.logger.error(
                "Error while downloading the contents from the file at %s, Error %s"
                % (files[index].get("Url"), exception)
            )

    def count_files(directory):
        count = 0
        for root, dirs, files in os.walk(directory):
            count += len(files)
        return count
    
    num_files = 0
    def fetch_records_from_filesystem(self, thread_count, ids, url, input_type):
        global num_files
        st = time.time()
        try:
            documents = None
            """Fetch document properties from filesystem"""
            documents = self.fetch_filessytem_prop(url, input_type)
            try:
                if(input_type == "local"):
                    files = os.listdir(url)
                    num_files = len(files)
                    print(f"Number of files in {url}: {num_files}")

                elif (input_type == "nas"):
                    request_headers = {
                "accept": "application/json;odata=verbose",
                "content-type": "application/json;odata=verbose",
                "Authorization" : 'Bearer ' +""
                }
                    response = requests.get(
                    url, headers=request_headers, verify=False)
                    data = response.json()
                    url.extend(data)
            except Exception as ex:
                self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")

            print(
                f"Total documents to be indexed {num_files}")
            self.logger.info(
                f"Total documents to be indexed {num_files}")
            new_lists = []
            for i in range(0, len(documents), 2):
                new_lists.append(documents[i:i+2])

             # multi processing
            json_path = []
            batch_size = int(self.file_batch_size)
            pool_object = Pool(self.processor)
            file_batches = [documents[i:i + batch_size] for i in range(0,len(documents), batch_size)]

            try:
            # Spawn threads
                json_path = pool_object.map(self.process_files, file_batches)
                pool_object.close()
                pool_object.join()
            except Exception as err:
                # Terminate the thread if failed
                pool_object.close()
                pool_object.join()

            et = time.time()
            print("time of execution", et - st)
            print("path of the json file", json_path)
            return json_path  # files
        except Exception as ex:
            print(
                f"\nError fetching the documents {str(ex)}\n")
            self.logger.exception(
                f"\nError fetching the documents {str(ex)}\n")
