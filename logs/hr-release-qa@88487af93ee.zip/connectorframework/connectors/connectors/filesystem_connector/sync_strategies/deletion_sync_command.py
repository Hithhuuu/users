class DeletionSync:
    def __init__(self) -> None:
        print("Deletion Sync")
        pass
    pass