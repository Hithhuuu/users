import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


async def send_mail(message):
    EMAIL_SIGNATURE  =  "<div> Hello </div><br/> <div>"+f"{message}"+"</div>"
    +"<table style='width:80%;border-collapse: collapse;'><div><br/><br/><br/>Thanks<br/> Data Platform Alerts</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
    email_content  = EMAIL_SIGNATURE
    your_smtp_port = 25
    host  =  "mailserver.amat.com"
    msg = MIMEMultipart()
    msg["From"] = "genaiframeworkalerts@amat.com"
    msg["To"] = "anmol_ahuja@contractor.amat.com, dhruvendra_singh@amat.com"
    msg["Subject"] = "Job Details Alert"
    msg.attach(MIMEText(email_content, "html"))
    with smtplib.SMTP(host, your_smtp_port) as server:
        server.starttls() 
        server.send_message(msg)