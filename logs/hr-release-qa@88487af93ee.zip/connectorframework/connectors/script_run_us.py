from us_hr_incremental import hr_incremental
import argparse


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    
    # Add the file_path argument
    parser.add_argument("--file_path", help="Path to the file")

    # Parse the command-line arguments
    args = parser.parse_args()

    # Access the value of file_path
    file_path = args.file_path

    print("Running US HR Incremental script with file path:", file_path)
    hr_incremental(file_path)
