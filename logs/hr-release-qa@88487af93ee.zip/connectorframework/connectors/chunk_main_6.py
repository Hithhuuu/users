import PyPDF2
# from chunking_core import SmartChunking
from azure_document_analysis import AzureDocumentAnalysis



# NAS_PATH = r'\\dca-qa-365\\ARK\\Production1'
#Pipeline for processing docs through Azure document intelligence
def main_chunk(pdf_files):
    azure_doc_analysis = AzureDocumentAnalysis()
    azure_doc_analysis.process_docs(pdf_files)

# Pipeline for SmartChunking
# initialize_chunks = SmartChunking("ETCH01342_01_EN_PCN-2023-1204_PCN-TMP-Controller-5k-Pumps.pdf")
# chunk_paragraph = initialize_chunks.getchunks()
# print(len(chunk_paragraph)) 


