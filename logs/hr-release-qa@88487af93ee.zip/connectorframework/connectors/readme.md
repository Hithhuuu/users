# DATA Ingestion Framework
This project aims to provide support to load or indexed your files to Vector DB.

## Components
The project consists of the following components:

- Connectors
- Parser
- Chunking
- Indexing


### Connectors
The Connectors component is responsibele fetching files from the given source and write it in the shared path. Currently we are supporting Sharepoint Connectors and Filesystem Connectors with Multiprocessing Support configured through confi.yaml file

### Parser
The Parser component handles the parsing of the fetched file and returns the output. We are supporting PDF, PPT, DOCS, TXT and Excel File Parser. For PDF we are also supporting page wise parser and that information will be available in vector DB also as a metadata

### Chunking
The Chunking component performs Chunking of the Parsed file based on the method defined in the Config.yaml file. Currently we are supporting all the mains langchain chunking method. User needs to mention the particular chunking method, chunk size and overlap.
These are the methods name supported for langchain method
##### `'character_splitter'` = CharacterTextSplitter
##### `'character_tiktoken_splitter'` = CharacterTextSplitter.from_tiktoken_encoder
##### `'recursive_splitter'` = RecursiveCharacterTextSplitter
##### `'spacy_splitter'` = SpacyTextSplitter
##### `'tiktoken_splitter'` = TokenTextSplitter

These all are the predefined chunking methods frameworks support so if user wants a custom chunking method. They can create their own custom chunking python file and placed it inside `chunking/chunking_method`. After that user will mention the method name in config,yaml file in order to use their own chunking method
##### Note: Make sure to keep the custom chunking file name same as method name inside the file.


### Indexing
The Indexing component takes care of inserting our Chunked docs in Vector DB. We are supporting cognitive search for Indexing. User will be able to define the index name, service name, indexing batch and the dynamic fields to be add in the index. If the specified index name is not available. The framework will automatically creates the index with 4 default fields and the dynamic fields mentioned in the config.yaml file


## HOW TO RUN ?
First, We need to setup JFrog Requirements in your local. Please follow the given mentioned steps for it.
   1. Create `pip.ini` file at the given mention directory in your local<br>
      `C:\Users\{your user id}\pip`
   2. Place this text inside this file<br>
      ```bash
      [global]
      index-url = https://x0143489:AKCp8ohJyYorUcNX99HKDYsbr9CuoKUMmqm669UAPZFEAhnTAef19VkN9uhj69FkYwQgyUdxK@amat-jfrog.amat.com/artifactory/api/pypi/A2V-python-virtual-repo/simple
      ```

Now, Open the Terminal and go to the `requirements.txt` directory in your framework code and Run this mentioned command in the terminal to install all the dependecy of the framework<br>
```bash
pip install -r requirements.txt
```

Now go the `connectorsframework/connectors` directory and Run this command to start the framework<br>
 ```bash
 python main.py
 ```






