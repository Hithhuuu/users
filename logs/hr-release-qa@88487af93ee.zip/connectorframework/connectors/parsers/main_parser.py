from parsers.base import AbstractClass
from parsers.parsers import Parser

class ParserRun():

    def run(self, chunked_docs):
        try:
            output = self.method_call(Parser(),chunked_docs)
            return output
        except Exception as e:
            raise Exception (e)

    def method_call(self, abstract_class: AbstractClass, chunked_docs):
        try:
            output = abstract_class.template_method(chunked_docs)
            return output
        except Exception as e:
            raise Exception (e)

