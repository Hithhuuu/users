import os
import sys
from abc import ABC, abstractmethod


class AbstractClass(ABC):

    def template_method(self, chunked_data):
        """
        The template method defines the skeleton of an algorithm.
        """
        try:
            output = self.method_first(chunked_data)
            return output
        except Exception as e:
            raise Exception (e)
        # self.method_second()

    @abstractmethod
    def method_first(self, chunked_data) -> None:
        pass

    # @abstractmethod
    # def method_second(self) -> None:
    #     pass