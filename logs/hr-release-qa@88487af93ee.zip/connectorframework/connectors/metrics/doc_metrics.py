import csv
import datetime
import os
import sys
import time
import psycopg2
import asyncio
import yaml
import argparse
import requests
from math import ceil
from metrics.base import AbstractClass
from utils import logger
from contextvars import ContextVar

context_vars = ContextVar('context', default={})
app_log = logger.getLogger(context_vars.get())
def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)

class Metrics(AbstractClass):
    def __init__(self):
        parser = argparse.ArgumentParser(description="Data Reconcilation")
        parser.add_argument(
            "--file_path", default="config.yaml", help="Path to the config.yaml file"
        )

        args = parser.parse_args()
        file_path = args.file_path
        print("doc_metrics-file path:", file_path)
        with open(file_path, 'r') as file:
            config_data = yaml.safe_load(file)
            
            self.config_data = config_data
            self.metrics_data = config_data['metrics']
            self.collection_name = config_data['vector_db']['azure_cognitive_search_index_name']
            self.service_name = config_data['vector_db']['azure_cognitive_search_service_name']
            self.api_count_version = config_data['vector_db']['openai_api_version']
            self.api_key = config_data.get('secret').get('azure_cognitive_search_api_key')
            self.vector_store = config_data['vector_db']['vector_store_address']

            self.pgsql_host = config_data['pgsql_db']['host']
            self.pgsql_db = config_data['pgsql_db']['database']
            self.pgsql_user = config_data['pgsql_db']['user']
            self.pgsql_password = config_data.get('secret').get('password')
            self.pgsql_port = config_data['pgsql_db']['port']

    def db_connection(self):
        try:
            conn = psycopg2.connect(host=self.pgsql_host,
                                    database=self.pgsql_db,
                                    user=self.pgsql_user,
                                    password=self.pgsql_password,
                                    port=self.pgsql_port
                                    )
            return conn
        except Exception as error:
            print("doc_metrics db_connection Error: ", error)
            return error
    
    def method_first(self, file_metrics):
        pass

    def source_metrics(self, file_metrics):
        print("source_metrics method")
        conn = self.db_connection()
        print("Connection:", conn)
        cur = conn.cursor()
        try:
            app_log.info("Source metrics method")
            source_cols = self.metrics_data['source']
            print("source_cols:", source_cols)
            file_metrics = [(sub,) for sub in file_metrics]
            placeholders = ", ".join(['%s'] * len(file_metrics))
            query = f"INSERT INTO source_metrics ({', '.join(source_cols)}) VALUES ({placeholders})"
            cur.execute(query, file_metrics)
            conn.commit()
        except Exception as error:
            print("source_metrics Error: ", error)
            cur.close()
            conn.close()
            return {"error":error}
        cur.close()
        conn.close()
        return {"success":"source metrics pushed successfully into db"}


    def filestats_metrics(self, file_metrics):
        print("filestats_metrics method")
        conn = self.db_connection()
        print("Connection:", conn)
        cur = conn.cursor()
        try:
            app_log.info("File stats metrics method")
            file_metrics = list(tuple(sub) for sub in file_metrics)
            filestats_embeddingstats_cols = self.metrics_data['file_stats']
            placeholders = ", ".join([f"%s" for _ in range(1, len(filestats_embeddingstats_cols) +1)])
            query = f"INSERT INTO filestats_metrics ({', '.join(filestats_embeddingstats_cols)}) VALUES ({placeholders})"
            cur.executemany(query, file_metrics)
            conn.commit()
        except Exception as error:
            print("filestats_metrics Error: ", error)
            cur.close()
            conn.close()
            return {"error":error}
        cur.close()
        conn.close()
        return {"success":"file stats metrics pushed successfully into db"}


    def indexing_metrics(self, file_metrics):
        print("indexing_metrics method")
        conn = self.db_connection()
        print("Connection:", conn)
        cur = conn.cursor()
        try:
            projectid = file_metrics[0]
            jobid = file_metrics[1]
            query = (f"select sum(CAST(no_of_chunks as INTEGER)),sum(CAST(file_size as INTEGER)) from filestats_metrics where jobid = '{jobid}' "
                     f"and projectid = '{projectid}' and indexing_status = 'Success' "
                     f"group by jobid, projectid")
            cur.execute(query)
            abc = cur.fetchone()
            if abc is not None:
                no_chunks = abc[0]
                sourcefilesize = abc[1]
                no_of_batches = ceil(no_chunks/self.config_data['vector_db']['batch_limit'])
            else:
                no_chunks = 0
                sourcefilesize = 0
                no_of_batches = 0
            file_metrics.insert(2, no_of_batches)
            if file_metrics[3] == 'Success':
                query = (f"SELECT distinct indexing_status FROM filestats_metrics where jobid = '{jobid}' "
                     f"and projectid = '{projectid}' and indexing_status <> 'Success'")
                cur.execute(query)
                res = cur.fetchall()
                if len(res) >= 1:
                    file_metrics[3]  = 'Failure'
                else:
                    query = (f"	SELECT  ( SELECT COUNT(*) FROM filestats_metrics where projectid= '{projectid}' and jobid='{jobid}') AS count1,"
                        f"(SELECT COUNT(*) FROM source_metrics where projectid= '{projectid}' and jobid='{jobid}' ) AS count2 ")
                    cur.execute(query)
                    res = cur.fetchone()
                    if res[0] != res[1]:
                        file_metrics[3]  = ('Failure')
            if no_chunks >= 0:
                counter = 0
                while True:
                    documentCount_statsapi, indexsize = Metrics().calculate_doc_and_index_count_statsapi()
                    documentCount_docsapi = Metrics().calculate_doc_count_docapi()
                    print("*********************documentCount_statsapi******************", documentCount_statsapi)
                    print("*********************documentCount_docsapi******************", documentCount_docsapi)
                    if documentCount_statsapi >= documentCount_docsapi or counter == 5:
                        file_metrics[4] = documentCount_statsapi
                        file_metrics[6] = indexsize
                        counter += 1
                        break
                    else:
                        time.sleep(30)
            if sourcefilesize != 0:
                xfactor = file_metrics[6]/sourcefilesize
            else:
                xfactor = 0
            file_metrics.insert(8, xfactor)
            
            app_log.info("Indexing metrics method")
            indexing_stats_cols = self.metrics_data['indexer_stats']
            placeholders = ", ".join([f"%s" for _ in range(1, len(indexing_stats_cols) +1)])
            query = f"INSERT INTO indexerstats_metrics ({', '.join(indexing_stats_cols)}) VALUES ({placeholders})"
            cur.execute(query, file_metrics)
            conn.commit()
            status = file_metrics[3]
            appname = file_metrics[9]
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            file_metrics = list(file_metrics[0:2])
            file_metrics.append(status)
            file_metrics.append(appname)
            file_metrics.append(timestamp)
            self.overall_stats_metrics(file_metrics)
        except Exception as error:
            print("indexing_metrics Error: ", error)
            cur.close()
            conn.close()
            return {"error":error}
        cur.close()
        conn.close()
        return {"success":"indexer stats metrics pushed successfully into db"}


    def overall_stats_metrics(self, file_metrics):
        print("overall_stats_metrics method")
        conn = self.db_connection()
        print("Connection:", conn)
        cur = conn.cursor()
        try:
            app_log.info("Overall Stats metrics method")
            overall_cols = self.metrics_data['Overall_status']
            overal_query = (f"select sum(no_of_chunks::numeric) as total_chunks, sum(no_of_tokens::numeric) as total_tokens, "
                            f"sum(embedding_cost::numeric) as total_cost, sum(adi_cost::numeric) as total_adi_cost from filestats_metrics "
                            f"where jobid  = '{file_metrics[1]}' and projectid = '{file_metrics[0]}' group by jobid, projectid")
            cur.execute(overal_query)
            overall_stats = cur.fetchone()
            if overall_stats != None:
                file_metrics.append(int(overall_stats[0]))
                file_metrics.append(float(overall_stats[1]))
                file_metrics.append(float(overall_stats[2]))
                file_metrics.append((float(overall_stats[3])))
            else:
                file_metrics.append(0).append(0).append(0).append(0)
            
            file_metrics = tuple(file_metrics)
            query = f""" INSERT INTO overall_status ({', '.join(overall_cols)}) VALUES {file_metrics}
            ON CONFLICT (projectid) DO UPDATE SET
                jobid = excluded.jobid,
                total_chunks = excluded.total_chunks,
                total_tokens = excluded.total_tokens,
                total_cost = excluded.total_cost,
                total_adi_cost = excluded.total_adi_cost
            """
            cur.execute(query)
            conn.commit()
            
        except Exception as error:
            print("overall_stats_metrics Error: ", error)
            cur.close()
            conn.close()
            return {"error":error}
        cur.close()
        conn.close()
        return {"success":"Overall stats pushed successfully into db"}

    def calculate_doc_and_index_count_statsapi(self):
        print("calculate_doc_and_index_count_statsapi method")
        url = str(self.vector_store)+"/indexes/"+str(self.collection_name)+"/stats?api-version="+str(self.api_count_version)+"&search=*"
        print("url: ",url)
        payload = ""
        headers = {
        'api-key': self.api_key
        }
        try:
            response = requests.request("GET", url, headers=headers, data=payload)
            data = response.json()
        except:
            print("Unable to get the response, status code is:", response.status_code)
        try:
            documentCount = data['documentCount']
            indexsize = int(data['storageSize'])/1048576    #index size in bytes
        except Exception as e:
            print(e)
            # key or index is missing, handle an unexpected response
            print('Unexpected response, got %r',
                    data)
        return documentCount, indexsize
    
    def calculate_doc_count_docapi(self):
        print("calculate_doc_count_docapi method")
        url = str(self.vector_store)+"/indexes/"+str(self.collection_name)+"/docs?api-version="+str(self.api_count_version)+"&search=*"+"&$count=true"
        print("url: ",url)
        payload = ""
        headers = {
        'api-key': self.api_key
        }
        try:
            response = requests.request("GET", url, headers=headers, data=payload)
            data = response.json()
        except:
            print("Unable to get the response, status code is:", response.status_code)
        try:
            documentCount = data['@odata.count']
        except Exception as e:
            print(e)
            # key or index is missing, handle an unexpected response
            print('Unexpected response, got %r',
                    data)
        return documentCount
