#!/bin/bash
python3 script_run_india.py --file_path "config_hr_india_incremental_dev.yaml"