#!/bin/bash
python3 script_hr_assist_us.py --file_path "config_hr_us_assist.yaml"