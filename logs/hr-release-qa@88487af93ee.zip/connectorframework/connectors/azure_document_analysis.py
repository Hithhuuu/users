from concurrent.futures import ThreadPoolExecutor
import csv
import json
import os
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from colorama import Back, Fore
import requests
from requests_ntlm import HttpNtlmAuth
from pathlib import Path
import PyPDF2
import yaml
from docx2pdf import convert
import argparse


def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)
parser = argparse.ArgumentParser()   
parser.add_argument("--file_path", help="Path to the file")
args = parser.parse_args()
file_path = args.file_path


def read_yaml(file_path):
    with open(file_path, "r") as file:
        config_data = yaml.safe_load(file)
    return config_data

dir_path = os.path.dirname(os.path.abspath(__file__))
print(dir_path, file_path)
CONFIG_PATH = os.path.join(dir_path, file_path)
config = read_yaml(CONFIG_PATH)


ENDPOINT = config.get("ADI")['ENDPOINT']
KEY = config.get("secret").get('Azur_ADI_KEY')
SITE_URL = config.get("ADI")['SITE_URL']
SHAREPOINT_DOMAIN = config.get("ADI")['SHAREPOINT_DOMAIN']
SHAREPOINT_USERNAME = config.get("ADI")['SHAREPOINT_USERNAME']
SHAREPOINT_PASSWORD = config.get("ADI")['SHAREPOINT_PASSWORD']
DATAFEED_API = config.get("ADI")['DATAFEED_API']


class AzureDocumentAnalysis:

    def __init__(self):
        # self.adi_nas_path = nas_path     
        self.site_url = SITE_URL
        self.domain = SHAREPOINT_DOMAIN
        self.username = SHAREPOINT_USERNAME
        self.password = SHAREPOINT_PASSWORD
        self.datfeed_api=DATAFEED_API

    def convert_docx_to_pdf(file_path):
        try:
            convert(file_path, file_path)
            # doc = word.Documents.Open(file_path)
            # doc.SaveAs(file_path, FileFormat=17)
            # doc.Close()
            # word.Quit() 
            print("Conversion successful!")
        except Exception as e:
            print(f"Conversion failed: {str(e)}")

    def process_docs(self, pdf_files):
        with ThreadPoolExecutor(1) as executor:
            futures = []

            futures.append(executor.submit(self.startgeneration(pdf_files)))

    def startgeneration(self, pdf_files):

        # take file paths as argument

        
        # file_list=["C:\\Users\\aojhax0104260\\OneDrive - Applied Materials\\Desktop\\formatted_docs\\Ergo, Commute & Broadband allowance guideline.docx"]
        # file_list=["C:\\Users\\x0151254\\Downloads\\testdata\\24676c2c1b7c75d03c5e99fa234bcba8_Guiding principles (knowledge receiver).pdf", "C:\\Users\\x0151254\\Downloads\\testdata\\24676c2c1b7c75d03c5e99fa234bcba8_Tips and Tricks.pdf"]
        file_list = pdf_files
        print(file_list)
        #iterate each file
        # pythoncom.CoInitialize()
        
        for file_path in file_list:
            
            # pdf_path=file_path.replace("'", "\"").replace('.docx','.pdf')

            # if(file_path.endswith('.docx')):
            #     pdf_path=file_path.replace("'", "\"").replace('.docx','.pdf')
            #     try:
            #         print(pdf_path)
            #         convert(file_path, pdf_path)
            #     except Exception as e:
            #         print(f"Conversion failed: {str(e)}")


            # elif(file_path.endswith('.doc')):
            #     pdf_path=file_path.replace("'", "\"").replace('.doc','.pdf')
            #     try:
            #         print("Conversion started!")
            #         word = win32.gencache.EnsureDispatch('Word.Application')
            #         word.Visible = False
            #         doc = word.Documents.Open(file_path)
            #         doc.SaveAs(pdf_path, FileFormat=17)
            #         doc.Close()
            #         word.Quit()
            #         print("Conversion successful!")
            #     except Exception as e:
            #         print(f"Conversion failed: {str(e)}")   

            try:
                raw_file_path = file_path
                adi_file_path = raw_file_path
                print(f"Doc parsing started:  {adi_file_path}")
                self.perform_doc_analysis(raw_file_path,adi_file_path,os.path.getsize(raw_file_path))
                print(f"Doc parsing Completed:  {adi_file_path}")
            except Exception as ex:
                print(f"error: {ex}")
        
    def generatepagecount(self,file_path,fileid,filename):
        pdfFileObj = open(file_path, 'rb')
        pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
        self.writetocsv(file_path,filename,fileid,pdfReader.numPages,self.get_file_size(file_path))

    def get_file_size(self, file_path):
        return os.path.getsize(file_path)

    def writetocsv(self,file_path,filename,fileid,pagecount,filesize):
        with open(r'logs\statpagecount.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([file_path,filename,fileid,pagecount,filesize])

    def writefailedtocsv(self,file_path,filename,fileid):
        with open(r'logs\failed.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([file_path,filename,fileid])
    def download_file(self, file_path, file_url):
        if not Path(file_path).exists():
            try:
                response = requests.get(file_url, auth=HttpNtlmAuth(f'{self.domain}\\{self.username}', self.password))
                if response.status_code == 200:
                    with open(file_path, 'wb') as f:
                        f.write(response.content)
                else:
                    self.writefailedtocsv(file_path,file_path.split('\\')[-1],file_path.split('\\')[-1].split('.')[0])
                    print(Fore.RED+ f"Error downloading file: {file_url} and response code: {response.status_code}")
            except Exception as ex:
                print(f"error: {ex}")
        else:
            print(f"File already exists: {file_path}")
    def prepare_json(self, raw_response, json_file_path):

        with open(json_file_path, 'w') as f:
            json.dump(raw_response.to_dict(), f)

    def perform_doc_analysis(self,raw_file_path,adi_file_path,filesize):
        try:
            # if not Path(adi_file_path.replace('.pdf','.json')).exists():  
            with open(raw_file_path, "rb") as file:
                pdf_bytes = file.read()
            document_analysis_client = DocumentAnalysisClient(endpoint=ENDPOINT, credential=AzureKeyCredential(KEY)) 
            poller = document_analysis_client.begin_analyze_document("prebuilt-document", pdf_bytes)
            raw_response = poller.result()
            self.prepare_json(raw_response, adi_file_path.replace('.pdf','.json'))
            # print(f"updating stat for :  {fileid}")
            # self.writestat(fileid,len(raw_response.pages),filename,filesize,adi_file_path.replace('.pdf','.json'))
        except Exception as ex:
            print(f"error: {ex}")
    def writestat(self,fileid,pagecount,filename,filesize,jsonpath):
        with open(r'logs\stat.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([filename,fileid,pagecount,filesize,os.path.getsize(jsonpath)])
