import os
import sys
from abc import ABC, abstractmethod


class AbstractClass(ABC):

    def template_method(self, data) -> None:
        """
        The template method defines the skeleton of an algorithm.
        """
        output = self.method_first(data)
        return output
        # self.method_second()

    @abstractmethod
    def method_first(self, data) -> None:
        pass

    # @abstractmethod
    # def method_second(self) -> None:
    #     pass
