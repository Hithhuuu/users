import yaml
import asyncio
from chunking_method.base import AbstractClass
from chunkingembedding.embedding_method.embedding import embedding
from chunking_method.custom_chunking.smart_chunking import smart_chunking
# from chunkingembedding import smart_chunking_v1
# from chunkingembedding.chunking_method import smart_chunking_ark_v1
# from chunking_method.custom_chunking.smart_chunking_v1 import smart_chunking_v1
from chunking_method.custom_chunking.text_chunking import text_chunking
from chunking_method.custom_chunking.smart_chunking_ark_v1 import smart_chunking_ark_v1
import argparse
import os
import re
import json
import csv
from langchain.docstore.document import Document


def env_constructor(loader, node):
    value = loader.construct_scalar(node)
    return os.environ.get(value)
 
# Register the custom constructor with the SafeLoader
yaml.SafeLoader.add_constructor('!ENV', env_constructor)

class Chunking(AbstractClass):

    def __init__(self, config=None):
#        self.config = config if config else 'config.yaml'
        parser = argparse.ArgumentParser(description="Data Ingestion Flow")
        parser.add_argument(
         "--file_path", default="config.yaml", help="Path to the config.yaml file"
                )
        args = parser.parse_args()
        self.config = args.file_path


    def extract_data_file(self,file_name):
        unique_identifier_match = re.search(r'^(\w+)_', file_name)
        file_extension_match = re.search(r'_(.+)\.(\w+)$', file_name)
        if unique_identifier_match and file_extension_match:
            unique_identifier = unique_identifier_match.group(1)
            file_name1 = file_extension_match.group(1)
            file_extension1 = file_extension_match.group(2)
            return unique_identifier, file_name1, file_extension1
        else:
            return None, None, None
    def extract_file_info(self, file_name):
        file_extension_match = re.search(r'(\.\w+)$', file_name)
        
        if file_extension_match:
            file_extension = file_extension_match.group(1)
            file_name1 = re.sub(r'(\.\w+)$', '', file_name)
            
            return file_extension, file_name1
        
        else:
            return None, None


    def method_first(self, raw_data):
        try:
            with open(self.config, 'r') as file:
                config_data = yaml.safe_load(file)
            chunk_fun = config_data['chunks']['type']
            page_parser = raw_data['page_parser']
            config_data['chunks']['page_parser'] = page_parser
            data =  raw_data['data']
            embeddings = embedding(config_data=config_data['embeddings'])

            # print(same_file)
            # if same_file == "summary":
            #     file = open(raw_data['file_name'], "r")
            #     row_data = file.read()
            #     print(row_data)
            #     doctitle = ''
            #     csv_path = config_data['connector']['csv_path']
            #     with open(csv_path) as csv_file:
            #         csv_reader = csv.reader(csv_file, delimiter=',')
            #         line_count = 0
            #         for row in csv_reader:
            #             if line_count == 0:
            #                 line_count += 1
            #             else:
            #                 title = row[1]
            #                 file_data = row[9].split('_')[1]
            #                 file = file_data.split(".")[0]
            #                 row_name = raw_data['file_name']
            #                 row_filename = row_name.split("_")[1]
            #                 row_file = row_filename.split(".")[0]
            #                 if file == row_file:
            #                     doctitle = title
            #                 line_count += 1
            #     obj = text_chunking(row_data,doctitle)
            #     chunked_docs_text = obj.getchunks()
                # imp = f'from chunkchunkingembeddingingembedding.chunking_method.{chunk_fun} import {chunk_fun}'
                # func_call = f"response = asyncio.run({chunk_fun}(data, config_data['chunks']))"
                # exec(imp)
                # exec(func_call)
                # result = {
                # "chunked_docs": locals()['response'],
                # "embeddings": embeddings,
                # "meta_data": {
                #     "filename": raw_data['file_name'],
                #     "filepath": raw_data['file_url']
                #     }
                # }

            if config_data['chunks']['type']=='smart_chunking_ark_v1':
                # summary_file = raw_data['file_name'].split("_")[1]
                # same_file = summary_file.split(".")[0]
                # end_path = summary_file.split(".")[1]
                file_ext = raw_data['file_name'].split('.')[-1]
                doctitle = ''
                csv_path = config_data['connector']['csv_path']
                with open(csv_path, newline='', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file, delimiter=',')
                    line_count = 0
                    for row in csv_reader:
                        if line_count == 0:
                            line_count += 1
                        else:
                            title = row[1]
                            unique_identifier1 = raw_data['file_name'].split('_')[0]
                            file_name1 = raw_data['file_name'].replace(unique_identifier1 + '_', '')
                            unique_identifier2 = row[9].split('_')[0]
                            file_name2 = row[9].replace(unique_identifier2 + '_', '')
                            # unique_identifier1, file_name1, file_txt_ext1 = self.extract_data_file(raw_data['file_name'])
                            # unique_identifier2, file_name2, file_txt_ext2 = self.extract_data_file(row[9])
                            if unique_identifier1 == unique_identifier2 and file_name1 == file_name2:
                                doctitle = title
                            
                            line_count += 1
                if file_ext == "txt":
                    obj = text_chunking(data, config_data, doctitle)
                    chunked_docs_text = obj.getchunks()
                elif file_ext == "pdf":
                    obj = smart_chunking_ark_v1(data, config_data,doctitle)
                    chunked_docs_text = obj.getchunks()
                
                # chunked_docs_text = smart_chunking_ark_v1(data, config_data)
                # chunked_docs_text = obj.getchunks()


                # chunked_docs_text = []
                # for i, _ in enumerate(func_call):
                #     #chunked_docs_text.append(Document(page_content=func_call[i][0]))
                #     pages = ', '.join(map(str, func_call[i][1])) if isinstance(func_call[i][1], list) else func_call[i][1]
                #     chunked_docs_text.append(Document(page_content=func_call[i][0], metadata={"page": pages,"chunk_header_info":func_call[i][2],"chunk_id":i}))
                # chunked_docs_text.append(func_call)
                pages = str(max([doc.metadata.get('page_no') for doc in chunked_docs_text]))
                result = {
                    "chunked_docs": chunked_docs_text,
                    "pages": pages,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }

            else:
                obj = smart_chunking(data, config_data)
                func_call = obj.getchunks()
                chunked_docs_text = []
                for i, _ in enumerate(func_call):
                    #chunked_docs_text.append(Document(page_content=func_call[i][0]))
                    pages = ', '.join(map(str, func_call[i][1])) if isinstance(func_call[i][1], list) else func_call[i][1]
                    chunked_docs_text.append(Document(page_content=func_call[i][0], metadata={"page": pages,"chunk_header_info":func_call[i][2],"chunk_id":i}))

                result = {
                    "chunked_docs": chunked_docs_text,
                    "pages": pages,
                    "embeddings": embeddings,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url']
                    }
                }
            try:
                '''addding chunking data to json file'''
                data_chunks ={}
                pos=0

                if config_data['parser'].get('ADI_parser', False):
                    for i in result['chunked_docs']:
                        data_chunks[pos] = i.page_content
                        pos+=1
                else:
                    for i in result['chunked_docs']:
                        data_chunks[pos] = i.page_content
                        pos+=1
                result_print = {
                    "chunked_docs": data_chunks,
                    "meta_data": {
                        "filename": raw_data['file_name'],
                        "filepath": raw_data['file_url'],
                        "chunk_type" :chunk_fun,
                        "chunk_size" : config_data['chunks']['chunksize']
                    }
                }
                shared_path = config_data['connector']['stats_path']
                print(shared_path, "Status Path")
                file_name =raw_data['file_name'].split(".")[0]+".json"
                complete_path = shared_path + "\\"+str(raw_data.get('job_id'))+'\\Chunking'
                print(complete_path, "Chunking file")
                if not os.path.isdir(complete_path):
                    os.makedirs(complete_path)
                completeName = os.path.join(complete_path, file_name)
                with open(completeName, 'w') as f:
                    json.dump(result_print, f)
            except Exception as e:
                print(e)
                raise Exception(e)
        except Exception as e:
            print(e)
            raise Exception(e)
        return result