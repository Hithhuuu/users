import json
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
from collections import defaultdict
import html
import torch
import torchvision.ops.boxes as bops
import pandas as pd
from langchain.docstore.document import Document
from fuzzywuzzy import fuzz
import numpy as np
import os
CONSTANT_SEGREGATOR = ' > '

stopwords_file = os.path.join(os.getcwd(),'stopwords.txt')

class text_chunking:

    def __init__(self, data, config_data,doctitle):
        self.page_title_section_heading = ''
        self.page_title = ''
        self.skip_ids = []
        self.first_run = True
        self.previous_table_status = False
        self.previous_table_id = -1
        self.section_header = []
        self.config = config_data
        self.title=doctitle
        # json_file_path = os.path.join(config_data['parser']['nas_path'], filename.replace('.pdf', '.json'))

        # with open(json_file_path) as user_file:
        #     file_contents = user_file.read()
        self.result = data
        # self.result=parsed_json['analyzeResult']

        # get the length of paragraphs and tables and set initial id's to -1
        self.paragraph_len = len(self.result)
        # self.table_len = len(self.result['tables'])
        # self.table_id = -1
        self.paragraph_id = -1
        self.remove_section_headings = ['pageFooter','pageHeader','pageNumber']

        self.stopwords = []
        relative_path = os.path.join('connectorframework', 'connectors', 'stopwords.txt')
        current_dir = os.getcwd()
        print(current_dir)
        # stopwords_file = os.path.join(current_dir, relative_path)

        with open(stopwords_file, "r", encoding='utf-8') as file:
            stopwords = file.read().splitlines()
            self.stopwords = [stopword.lower() for stopword in stopwords]
            
    def getchunks(self):
        chunk_paragraph=[]
        azure_res=  self.result
        filename=self.title
        # all_table,all_cell_content,all_table_cord = get_map_table(azure_res)
        # df_res, table_df_res = get_paragrah_res(azure_res,all_table,all_table_cord)
        # print("len of df_res",len(df_res))
        # df_fill = filter_dataframe(df_res)
        # df_with_header = get_header(df_res)
        all_para_lang_doc = get_paragraph_lang_doc(azure_res,filename,self)
        # all_table_lang_doc,all_not_match_index = get_table_lang_doc(df_with_header,all_cell_content,all_table,filename,self)
        # no_head_table = get_table_for_unmatched(all_table,all_not_match_index,df_with_header,filename,self)
        all_para_chunk = form_chunk(all_para_lang_doc, doc_type='Paragraph')
        # all_table_chunk = form_chunk(all_table_lang_doc, doc_type='Table')
        # all_table_chunk_second = form_chunk(no_head_table, doc_type='Table')
        for i in range(0, len(all_para_chunk)):
            chunk_paragraph.append(all_para_chunk[i])
        # for i in range(0, len(all_table_chunk)):
        #     chunk_paragraph.append(all_table_chunk[i])
        # for i in range(0, len(all_table_chunk_second)):
        #     chunk_paragraph.append(all_table_chunk_second[i])
        return chunk_paragraph


def form_chunk(lang_doc_list, doc_type):
    all_chunk = []
    for ech in lang_doc_list:
        Paragraph_Text = ech.page_content
        title = ech.metadata['src']
        page_no = ech.metadata['page_no']
        page_header = ech.metadata['page_header']
        para_no = ech.metadata['paragraph_no']
        sec_heading = ech.metadata['section_heading']
        chunk_1  = f"\nTitle:\n {title} \nPage_Header:\n {page_header} \n\nSection_Heading:\n {sec_heading} \n\n{doc_type}Text:\n {Paragraph_Text} \n\n{doc_type}Number: {para_no}"
        all_chunk.append(Document(page_content=chunk_1, metadata = ech.metadata))
    return all_chunk

def get_paragraph_lang_doc(mod_df,filename,self):
    para_data = []

    only_para_df = mod_df
    
    # for i,j in only_para_df.groupby(['page_no','section_heading']):
    #     j = j.drop_duplicates(subset='page_content', keep='first')
    #     page_no = j['page_no'].values[0]
    #     page_header = j['page_header'].values[0]
    #     section_heading = j['section_heading'].values[0]
    #     page_content = '\n'.join(j['page_content'].tolist())
    #     para_no_list = j['para_no'].tolist()
        
        # print(i[0], len(page_content))
    if len(mod_df)>self.config['chunks']['min_chunk']:
        if len(mod_df)>self.config['chunks']['chunksize']:
            child_splitter = RecursiveCharacterTextSplitter(chunk_size=self.config['chunks']['chunksize'], chunk_overlap=self.config['chunks']['overlap'])
            all_child = child_splitter.split_text(mod_df)
            for para_no, ech in enumerate(all_child):
                tmp_metadata = {}
                tmp_metadata['role']='paragraph'
                tmp_metadata['page_no']=1
                tmp_metadata['page_header']=""
                tmp_metadata['section_heading']=" "
                tmp_metadata['src']=filename
                tmp_metadata['paragraph_no'] = para_no+1
                para_data.append(Document(page_content = ech, metadata = tmp_metadata)) 
        else:
            tmp_metadata = {}
            tmp_metadata['role']='paragraph'
            tmp_metadata['page_no']=1
            tmp_metadata['page_header']=""
            tmp_metadata['section_heading']=""
            tmp_metadata['src']=filename
            tmp_metadata['paragraph_no'] = 1
            para_data.append(Document(page_content = mod_df, metadata = tmp_metadata))
    else:
        tmp_metadata = {}
        tmp_metadata['role']='paragraph'
        tmp_metadata['page_no']=1
        tmp_metadata['page_header']=""
        tmp_metadata['section_heading']=""
        tmp_metadata['src']=filename
        tmp_metadata['paragraph_no'] = 1
        para_data.append(Document(page_content = mod_df, metadata = tmp_metadata))
    print(para_data)
    return para_data

def filter_dataframe(main_df):
    page_list_to_remove = main_df[main_df['skip_page']==True]['page_no'].unique()
    main_df = main_df[~main_df.page_no.isin(page_list_to_remove)]
    main_df = main_df.reset_index().drop('index',axis=1)
    return main_df


# def remove_duplicates(lst):
#     return list(dict.fromkeys(lst))

# def get_table_for_unmatched(all_table,all_not_match_index,df_with_header,filename,self):
#     all_not_match_index = remove_duplicates(all_not_match_index)
#     all_table_chunk = []
#     for ech in all_not_match_index:
#         page_no = int(ech.split('_')[0].strip())
#         chunk_no = int(ech.split('_')[1].strip())
#         # print("page_no",page_no)
#         # print("chunk_no",chunk_no)
#         tmp_metadata = {}
#         tmp_metadata['role']='table'
#         tmp_metadata['page_no']=page_no
#         tmp_metadata['page_header']=df_with_header[df_with_header['page_no']==page_no]['page_header'].unique()[0]
#         tmp_metadata['section_heading']=df_with_header[df_with_header['page_no']==page_no]['section_heading'].unique()[0]
#         tmp_metadata['src']=filename
#         html_table = all_table[page_no][chunk_no]
#         tbl_lst = process_html_table(html_table,tmp_metadata,self)
#         all_table_chunk.extend(tbl_lst)
#     return all_table_chunk

# def process_html_table(html_table,tmp_metadata,self):
#     try:
#         data_frame = pd.read_html(html_table)[0]
#         csv_df = data_frame.fillna('').to_csv(index=False)
#         split_mark = []
#         if len(csv_df)>=self.config['chunks']['min_chunk']:
#             if len(csv_df)>=self.config['chunks']['chunksize']:
#                 split_no = int(len(csv_df)/self.config['chunks']['chunksize'])
#                 if split_no ==0:
#                     split_no = split_no+1
#                 splitted_df = np.array_split(data_frame, split_no)
#                 for i,j in enumerate(splitted_df):
#                     tabl_con = j.fillna('').to_csv(index=False)
#                     tmp_metadata['paragraph_no'] = i+1
#                     split_mark.append(Document(page_content = tabl_con, metadata = tmp_metadata))
#             else:
#                 tmp_metadata['paragraph_no'] = 1
#                 tabl_con = csv_df
#                 split_mark.append(Document(page_content = tabl_con, metadata = tmp_metadata))
#     except Exception as e:
#         print("error parsing html table", html_table)
#         split_mark = []
        
#     return split_mark

# def get_table_lang_doc(mod_df, all_cell_content,all_table,filename,self):
#     table_data = []
#     all_matched_index = []
#     all_not_match_index = []
#     only_tab_df = mod_df[mod_df['table_data']==True]
#     for i,j in only_tab_df.groupby(['page_no']):
#         j = j.drop_duplicates(subset='page_content', keep='first')
#         for k,v in j.groupby(['section_heading']):
#             page_no = v['page_no'].values[0]
#             page_header = v['page_header'].values[0]
#             section_heading = v['section_heading'].values[0]
#             page_content = v['page_content'].tolist()
#             para_no_list = v['para_no'].tolist()
#             tmp_metadata = {}
#             tmp_metadata['role']='table'
#             tmp_metadata['page_no']=page_no
#             tmp_metadata['page_header']=page_header
#             tmp_metadata['section_heading']=section_heading
#             tmp_metadata['src']=filename
#             cell_con_list = all_cell_content[page_no]
#             status  = False
#             for tab_no, con in enumerate(cell_con_list):
#                 tmp = list(con.values())
#                 tmp = list(filter(None,tmp))
#                 tmp = remove_duplicates(tmp)
#                 page_content = list(filter(None,page_content))
#                 page_content = remove_duplicates(page_content)
#                 if tmp == page_content:
#                     # print("tab_no------",tab_no,page_no)
#                     html_tab = all_table[page_no][tab_no]
#                     tab_list = process_html_table(html_tab,tmp_metadata,self)
#                     if len(tab_list)>0:
#                         table_data.extend(tab_list)    
#                     # if len(tab_list) ==0:
#                     #     print("warning table coming as 0")
                       
#                     all_matched_index.append(f'{page_no}_{tab_no}')
#                     status = True
#                     break
#                 elif fuzz.ratio('\n'.join(tmp),'\n'.join(page_content))>95:
#                     # print("tab_no fuzzy------",tab_no,page_no)
#                     html_tab = all_table[page_no][tab_no]
#                     all_matched_index.append(f'{page_no}_{tab_no}')
#                     tab_list = process_html_table(html_tab,tmp_metadata,self)
#                     if len(tab_list)>0:
#                         table_data.extend(tab_list)   
#                     status = True
#                     break
#             if not status:
#                 all_not_match_index.append(f'{page_no}_{tab_no}')
#                 # print(tmp,page_content)
#     # assert len(all_matched_index) + len(all_not_match_index) == len(all_table)
#     return table_data,all_not_match_index



# def get_header(df_fill):
#     all_paragraph = []
#     para_no = 0
#     pre_pg_header = ''
#     prev_sec_header = ''
#     df_fill = df_fill.fillna('')
#     para_no = 0
#     for i,j in df_fill.groupby(['page_no']):

#         curr_page_head = ''
#         curr_page_sec_head = ''

#         for k,v in j.iterrows():
#             # print(v['role'])
#             if v['role'] == 'pageHeader':
#                 curr_page_head =  curr_page_head +  ', ' + v['paragraph']

#             elif v['role'] == 'sectionHeading':
#                 curr_page_sec_head = curr_page_sec_head + ', ' +  v['paragraph']

#             elif  v['role'] == 'NA':
#                 if curr_page_head == '':
#                     page_head = pre_pg_header
#                 else:
#                     pre_pg_header = curr_page_head
#                     page_head = pre_pg_header
#                     curr_page_head = ''

#                 if curr_page_sec_head == '':
#                     page_sec_head = prev_sec_header
#                     para_no = para_no+1
#                 else:
#                     prev_sec_header = curr_page_sec_head
#                     page_sec_head = prev_sec_header
#                     curr_page_sec_head = ''
#                     para_no = 0

#                 tmp = {'page_no':v['page_no'],
#                       'page_header':page_head.strip(',').strip(),
#                       'section_heading':page_sec_head.strip(',').strip(),
#                       'page_content':v['paragraph'],
#                       'page_content_len':len(v['paragraph']),
#                       'para_no':para_no,
#                       'table_data':v['table_data']}

#                 all_paragraph.append(tmp)
#     return pd.DataFrame(all_paragraph)


# def get_paragrah_res(azure_res,all_table, all_table_cord):
#     all_data = []
#     # all_table_Data = []
#     extensionsToCheck = ['Table of Contents','List of Tables','List of Figures']
#     for i in range(len(azure_res.get('paragraphs'))):
#         data_tmp = {}
#         table_data_tmp= {}
#         tmp = azure_res.get('paragraphs')[i]
#         pg_no = ''
#         bb_regn = tmp.get('bounding_regions')

#         for j in bb_regn:
#             pg_no = j.get('page_number')
#             data_tmp['page_no'] = int(pg_no)
#             table_data_tmp['page_no'] = int(pg_no)
#             content = tmp.get('content')
#             poly = j.get('polygon')

#             curr_bbox = [poly[0].get('x'),poly[0].get('y'),poly[2].get('x'),poly[2].get('y')]
#             box2 = torch.tensor([curr_bbox], dtype=torch.float)
#             if not any(ext in content.replace('\n',' ') for ext in extensionsToCheck):
#                 data_tmp['skip_page'] = False
#                 table_data_tmp['skip_page'] = False
#             else:
#                 data_tmp['skip_page'] = True
#                 table_data_tmp['skip_page'] = False

#             if all_table.get(data_tmp['page_no'],[])!=[]:
#                 data_tmp['table_found'] = True
#                 table_data_tmp['table_found'] = True
#             else:
#                 data_tmp['table_found'] = False
#                 table_data_tmp['table_found'] = False

           
#             if data_tmp['table_found'] == True:
#                 all_cord = all_table_cord.get(data_tmp['page_no'],[])
#                 bbox_tensor = torch.tensor([i for i in all_cord], dtype=torch.float)
#                 iou = bops.box_iou(box2,bbox_tensor).cpu().detach().numpy()[0]
#                 if max(iou)==0:
#                     table_data = False
#                 else:
#                     table_data = True
#                     if tmp.get('role')!= None:

#                         table_data_tmp['role'] = tmp.get('role')
#                         table_data_tmp['paragraph'] = content
#                     else:
#                         table_data_tmp['role'] = 'NA'
#                         table_data_tmp['paragraph'] = content
#                     table_data_tmp['iou'] = iou
#                     table_data_tmp['bbox'] = bbox_tensor
#                     prev_sec_head = ''

#                 if tmp.get('role')!= None:
#                     data_tmp['role'] = tmp.get('role')
#                     data_tmp['paragraph'] = content
#                 else:
#                     data_tmp['role'] = 'NA'
#                     data_tmp['paragraph'] = content

#                 data_tmp['iou'] = iou
#                 data_tmp['bbox'] = poly
#                 data_tmp['table_data']=table_data


#             else:
#                 if tmp.get('role')!= None:
#             #         print(tmp['role'], tmp['content'])
#                     data_tmp['role'] = tmp.get('role')
#                     data_tmp['paragraph'] = content
#                 else:
#                     data_tmp['role'] = 'NA'
#                     data_tmp['paragraph'] = content

#                 data_tmp['iou'] = 'NA'
#                 data_tmp['bbox'] = 'NA'
#                 data_tmp['table_data']=False

#             all_data.append(data_tmp)
#             all_table_Data.append(table_data_tmp)

#     df_res = pd.DataFrame(all_data)
#     table_df_res = pd.DataFrame(all_table_Data)
#     return df_res,table_df_res


# def get_map_table(azure_res,get_annotated = False):
#     all_html_table = []
#     all_table = defaultdict(list)
#     all_cell_content = defaultdict(list)
#     all_table_cord = defaultdict(list)
#     for table in (azure_res.get('tables')):
#         all_xbox = []
#         all_ybox = []
#         page_wise_cell_content = {}
#         table_html = "<table>"
#         rows = [
#             sorted([cell for cell in table.get('cells') if cell.get('row_index') == i], key=lambda cell: cell.get('column_index'))
#             for i in range(table.get('row_count'))
#         ]
#         for row_cells in rows:
#             table_html += "<tr>"
#             for cell in row_cells:
#                 bboxs = cell.get('bounding_regions')
#                 for bb in bboxs:
#                     poly = bb.get('polygon')
#                     all_xbox.append(poly[0].get('x'))
#                     all_xbox.append(poly[2].get('x'))
#                     all_ybox.append(poly[0].get('y'))
#                     all_ybox.append(poly[2].get('y'))
#                 tag = "th" if (cell.get('kind') == "columnHeader" or cell.get('kind') == "rowHeader") else "td"
#                 cell_spans = ""
#                 if cell.get('column_span') is not None and cell.get('column_span') > 1:
#                     cell_spans += f" colSpan={cell.get('column_span')}"
#                 if cell.get('row_span') is not None and cell.get('row_span') > 1:
#                     cell_spans += f" rowSpan={cell.get('row_span')}"
#                 cell_id = f"{cell.get('row_index')}-{cell.get('column_index')}"
#                 cell_index = f"{cell.get('content')} (Cell-Id - {cell_id})"
#                 page_wise_cell_content[cell_id]=cell.get('content')
#                 if not get_annotated:
#                     table_html += f"<{tag}{cell_spans}>{html.escape(cell.get('content'))}</{tag}>"
#                 else:
#                     table_html += f"<{tag}{cell_spans}>{html.escape(cell_index)}</{tag}>"
#             table_html += "</tr>"
#         table_html += "</table>"
#         box = [sorted(all_xbox,reverse=False)[0],sorted(all_ybox,reverse=False)[0],
#                    sorted(all_xbox,reverse=True)[0],sorted(all_ybox,reverse=True)[0]]
#         all_table[table.get('bounding_regions')[0].get('page_number')].append(table_html)
#         all_cell_content[table.get('bounding_regions')[0].get('page_number')].append(page_wise_cell_content)
#         all_table_cord[table.get('bounding_regions')[0].get('page_number')].append(box)
# #         all_html_table.append((table_html,table.get('bounding_regions')[0].get('page_number')))
        
#     return all_table,all_cell_content,all_table_cord