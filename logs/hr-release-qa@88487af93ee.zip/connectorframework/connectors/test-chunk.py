import os
from chunk_main_6 import main_chunk

NAS_PATH = "C:\\Users\\x0151254\\Downloads\workspace\\nohtml-us"

def find_pdf(directory):
    pdf_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.lower().endswith('.pdf'):
                pdf_files.append(os.path.join(root, file))
    return pdf_files
pdf_files = find_pdf(NAS_PATH)
main_chunk(pdf_files)
for pdf in pdf_files:
    print(pdf)