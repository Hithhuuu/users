from us_hr_assist_index import hr_assist
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    
    # Add the file_path argument
    parser.add_argument("--file_path", help="Path to the file")

    # Parse the command-line arguments
    args = parser.parse_args()

    # Access the value of file_path
    file_path = args.file_path

    print("Running India HR Incremental script with file path:", file_path)
    hr_assist(file_path)
