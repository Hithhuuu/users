#!/bin/bash
python3 script_run_us.py --file_path "config_hr_us_incremental_prod.yaml"