﻿// See https://aka.ms/new-console-template for more information
using System.Configuration;
using WordsLicense = Aspose.Words.License;
using SlidesLicense = Aspose.Slides.License;
using EmailLicense = Aspose.Email.License;
using Aspose.Email;
using Aspose.Words;

Console.WriteLine("Conversion Started");
WordsLicense wordsLic = new();
wordsLic.SetLicense(ConfigurationManager.AppSettings["Aspose_Lic_Path"]);
SlidesLicense slidesLic = new();
slidesLic.SetLicense(ConfigurationManager.AppSettings["Aspose_Lic_Path"]);
EmailLicense emailLic = new();
emailLic.SetLicense(ConfigurationManager.AppSettings["Aspose_Lic_Path"]);

string path_list = ConfigurationManager.AppSettings["Files_List"]!;

try
{
    var files = Directory.GetFiles(path_list!, "*.*", SearchOption.AllDirectories);
    int docsCount = 0, pptCount = 0, msgCount = 0;
    string pdfFile = string.Empty;
    foreach (var file in files)
    {
        Console.WriteLine(file);
        try
        {
            string extension = Path.GetExtension(file);
            switch (extension.ToLower())
            {
                case ".doc":
                case ".docx":
                    Document document = new(file);
                    pdfFile = Path.ChangeExtension(file, ".pdf");
                    document.Save(pdfFile);

                    docsCount++;
                    break;
                case ".ppt":
                case ".pptx":
                    using (Aspose.Slides.Presentation presentation = new(file))
                    {
                        pdfFile = Path.ChangeExtension(file, ".pdf");
                        presentation.Save(pdfFile, Aspose.Slides.Export.SaveFormat.Pdf);
                    }
                    pptCount++;
                    break;
                case ".msg":
                case ".eml":
                    using (var message = MailMessage.Load(file))
                    {
                        string htmFile = Path.ChangeExtension(file, ".html");
                        message.Save(htmFile, SaveOptions.DefaultHtml);
                        // load HTML with an instance of Document
                        Document htmlDocument = new(htmFile);
                        // call save method while passing SaveFormat.Pdf
                        pdfFile = Path.ChangeExtension(htmFile, ".pdf");
                        htmlDocument.Save(pdfFile, SaveFormat.Pdf);
                    }
                    msgCount++;
                    break;
            }
        }
        catch (Exception iex)
        {
            Console.WriteLine("{0} conversion error - {1}", file, iex.Message);
        }
    }
    Console.WriteLine("Total Documents Converted: {0}", docsCount.ToString());
    Console.WriteLine("Total Presentations Converted: {0}", pptCount.ToString());
    Console.WriteLine("Total Messages Converted: {0}", msgCount.ToString());
    Console.WriteLine("Completed.");
}
catch (Exception e)
{
    Console.WriteLine("An error occurred: " + e.Message);
}
Console.Read();
