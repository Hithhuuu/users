PDFConversionApp and PDFConversionService are .NET based applications.

It is developed using .NET8 SDK.

It is using Aspose library to convert word document, powerpoint slides and email messages to PDF.

Pre-requisites for Deployment:

It requires .NET8 docker image with libgdiplus package to run on Non-windows environment (OCP/ARO).

ConnectorFramework is Python bases application.

It is developed using Python , Azur SDK.
