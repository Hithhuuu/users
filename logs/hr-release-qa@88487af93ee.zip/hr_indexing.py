"""vectorstores"""
from pathlib import Path
from typing import Any

import yaml
from langchain.docstore.document import Document
from langchain.vectorstores.azuresearch import AzureSearch
from tqdm import tqdm

from config.settings import ML_CONFIG_PATH
from .embedding_model import EmbeddingModels
from .vectorstore_model import VectorStoreModels

APP_CONFIG = Path(ML_CONFIG_PATH)


class VectorStoreService:
    """
    A service class for managing the vector store.

    Attributes:
        vector_models (VectorStoreModels): An instance of the VectorStoreModels class.

    Methods:
        initialise_vector_store(): Initializes the vector store and 
        returns an instance of the AzureSearch class.
        index_documents(): Indexes the documents in the vector store.
    """

    def __init__(self) -> None:
        self.vector_models = VectorStoreModels()
        self.config = self.initialise_config()
        self.vector_store, self.azure_search_client = self.initialise_vector_store()

    def initialise_config(self) -> Any:
        """
        Reads the configuration parameters from a YAML file and 
        returns them as a dictionary.

        Returns
        -------
        Any
            a dictionary containing configuration parameters for the chatbot models
        """
        with open(APP_CONFIG, "r") as file:
            config = yaml.safe_load(file)
            return config

    def initialise_vector_store(self) -> AzureSearch:
        """
        Initializes the vector store and returns an instance of the AzureSearch class.

        Returns:
            AzureSearch: An instance of the AzureSearch class.
        """
        # Get the name of the vector store index
        index_name = self.config["vectorstore"]["index_name"]

        # Get the embeddings for the vector store
        embeddings = EmbeddingModels().embeddings()
        # Create a new instance of the vector store using the index name and embeddings
        vector_store, azure_search_client = self.vector_models.vector_store(
            index_name, embeddings
        )
        # Return the new vector store instance
        return vector_store, azure_search_client

    def index_documents(self, user_id="") -> None:
        """
        Indexes the documents in the vector store.
        """
        kb_number = os.path.basename(file).split('.')[0]
        loader = TextLoader(file,encoding="utf-8")
        documents = loader.load()
        chunked_docs = char_text_splitter.split_text(documents[0].page_content)
        # chunksize=1000 & Overlap=10
        metadatas = [
            { "source": kb_data[kb_data['Number']==kb_number]['Short description'].values[0] , "link": kb_data[kb_data['Number']==kb_number]['link'].values[0]} for i, _ in enumerate(chunked_docs)
           
            ]
        _ = vector_store.add_texts(texts=chunked_docs, metadatas=metadatas)

    def check_user_exist_index(self, user_id: str):
        """Check if user exists in Azure index

        Args:
            user_id (str): user id
        """

        ids = self.azure_search_client.search(
            search_text=None, filter=f"user_id eq '{user_id}'", select=["id"]
        )
        has_ids = any(True for _ in ids)
        return has_ids

    def clean_user_from_index(self, user_id: str):
        """Delete user from Azure index

        Args:
            user_id (str): user id
        """
        ids = self.azure_search_client.search(
            search_text=None, filter=f"user_id eq '{user_id}'", select=["id"]
        )
        all_id = [id for id in ids]

        if len(all_id) > 0:
            self.azure_search_client.delete_documents(all_id)
