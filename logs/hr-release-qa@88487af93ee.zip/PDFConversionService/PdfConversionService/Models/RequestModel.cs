﻿namespace PdfConversionService.Models
{
    public class RequestModel
    {
        public string FilePath { get; set; } = string.Empty;
    }
}
