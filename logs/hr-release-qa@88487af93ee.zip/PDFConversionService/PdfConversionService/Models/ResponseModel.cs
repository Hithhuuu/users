﻿namespace PdfConversionService.Models
{
    public class ResponseModel
    {
        public int DocsCount {  get; set; }
        public int PptCount {  get; set; }
        public int MsgCount {  get; set; }
    }
}
