﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PdfConversionService.Models;
using System.IO;
using WordsLicense = Aspose.Words.License;
using SlidesLicense = Aspose.Slides.License;
using EmailLicense = Aspose.Email.License;
using Aspose.Email;
using Aspose.Words;

namespace PdfConversionService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PdfConversionController : ControllerBase
    {
        private readonly ILogger<PdfConversionController> _logger;

        public PdfConversionController(ILogger<PdfConversionController> logger, IConfiguration configuration)
        {
            _logger = logger;
            WordsLicense wordsLic = new();
            wordsLic.SetLicense(configuration.GetValue<string>("Aspose_Lic_Path"));
            SlidesLicense slidesLic = new();
            slidesLic.SetLicense(configuration.GetValue<string>("Aspose_Lic_Path"));
            EmailLicense emailLic = new();
            emailLic.SetLicense(configuration.GetValue<string>("Aspose_Lic_Path"));
        }

        [HttpPost]
        public IActionResult Post(RequestModel requestModel)
        {
            try
            {
                var files = Directory.GetFiles(requestModel.FilePath, "*.*", SearchOption.AllDirectories);
                int docsCount = 0, pptCount = 0, msgCount = 0;
                foreach (var file in files)
                {
                    _logger.LogInformation("{message}: ", file);
                    try
                    {
                        string extension = Path.GetExtension(file);
                        string pdfFile;
                        switch (extension.ToLower())
                        {
                            case ".doc":
                            case ".docx":
                                Document document = new(file);
                                pdfFile = Path.ChangeExtension(file, ".pdf");
                                document.Save(pdfFile);

                                docsCount++;
                                break;
                            case ".ppt":
                            case ".pptx":
                                using (Aspose.Slides.Presentation presentation = new(file))
                                {
                                    pdfFile = Path.ChangeExtension(file, ".pdf");
                                    presentation.Save(pdfFile, Aspose.Slides.Export.SaveFormat.Pdf);
                                }
                                pptCount++;
                                break;
                            case ".msg":
                            case ".eml":
                                using (var message = MailMessage.Load(file))
                                {
                                    string htmFile = Path.ChangeExtension(file, ".html");
                                    message.Save(htmFile, SaveOptions.DefaultHtml);
                                    // load HTML with an instance of Document
                                    Document htmlDocument = new(htmFile);
                                    // call save method while passing SaveFormat.Pdf
                                    pdfFile = Path.ChangeExtension(htmFile, ".pdf");
                                    htmlDocument.Save(pdfFile, SaveFormat.Pdf);
                                }
                                msgCount++;
                                break;
                        }
                    }
                    catch (Exception iex)
                    {
                        _logger.LogError("{FilePath} conversion error - {Message}", file, iex.Message);
                    }
                }
                return Ok(new ResponseModel { DocsCount = docsCount, PptCount = pptCount, MsgCount = msgCount });
            }
            catch(Exception ex)
            {
                _logger.LogError("Conversion Error: {Message}", ex.Message);
                _logger.LogError("{StackTrace}", ex.StackTrace);
                return StatusCode(500, ex.Message);
            }
        }
    }
}
