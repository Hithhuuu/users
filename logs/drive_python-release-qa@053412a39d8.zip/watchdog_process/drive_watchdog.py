import os
import re
import sys
import time
import datetime
import shutil
from glob import glob
import calendar
import asyncio

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_config, get_env_config, get_logger, config
from api.common.data_processing import dataload_tool
from api.common.common import update_job_status, move_file_rejected
from api.common.fastapi_app import get_query_with_pool


"""Config file to get the all the variable defined in the file"""
config = get_config()
env_config = get_env_config()

""" Calling the logger object to get all the logs """
env = os.getenv("env")
app_log = get_logger('drive_watchdog')
watch_path = env_config[env]['watchdog_pick_location']['src']
# watch_path = r'C:\Users\x0143654\OneDrive - Applied Materials\files'

async def upload_files_drive():
    """  """
    try:
        # connection = get_dbconnection()
        fetch_files = "SELECT id, xml_file_path, klarf_file_path, klarf_file_name FROM drive_job_log FINAL WHERE (job_status = 'queued') ORDER BY cdt DESC LIMIT 20 UNION ALL SELECT id, xml_file_path, klarf_file_path, klarf_file_name FROM drive_job_log FINAL WHERE (job_status = 'failed') AND re_try < 3 ORDER BY cdt DESC LIMIT 5"
        app_log.info(f'Fetched files: {fetch_files}')
        files_to_load=await get_query_with_pool(query=fetch_files,resp_type="dict")
        # files_to_load = execute_query(connection, fetch_files, fetch='all')
        loop  = asyncio.get_running_loop()

        for file in files_to_load:
            try:
                app_log.info(file)
                current_time = datetime.datetime.now()
                task_id_time = calendar.timegm(current_time.timetuple())
                task_id = file['klarf_file_name']+'_'+str(task_id_time)
                # dataload_tool(file['xml_file_path'], file['klarf_file_path'], file['id'])
                loop.create_task(dataload_tool(file['xml_file_path'], file['klarf_file_path'], file['id']))
                # dataload_tool.apply_async((file['xml_file_path'], file['klarf_file_path'], file['id']), task_id=task_id, queue=queue, routing_key=routing_key)
            except Exception as err:
                app_log.exception(err)

    except Exception as e:
        app_log.error(f"Something went wrong in uploading file.. {repr(e)}")
        app_log.exception(e)


async def file_watcher():
    """ Watches for klarf and xml file pairs and moves it to archive"""
    try:
        app_log.info('Looking for new log files now.')
        landing_zone = os.path.join(watch_path, 'lz/today/reports/')
        if os.path.exists(landing_zone):
            klarf_files = glob(f"{landing_zone}/*.*", recursive=True)
            xml_files = glob(f"{landing_zone}/*_Recipe_data.xml", recursive=True)
            klarf_files = list(set(klarf_files)-set(xml_files))
            app_log.info(f"Klarf files: {len(klarf_files)}")
            app_log.info(f"XML files: {len(xml_files)}")
            for klarf_file_path in klarf_files:
                # Ignoring .001 in the filename
                filename = klarf_file_path.rsplit('.',1)
                if filename[1].lower() not in ['tiff', 'tif', 'png', 'bmp', 'gif', 'jpeg', 'xml', 'log', 'xls', 'xlsx', 'doc', 'docx', 'jpg', 'pdf', 'ppt','pptx', 'emsa', 'bcf', 'txt', 'csv', 'png', 'mp3', 'wav', 'zip', 'rar', 'htm', 'html', 'css', 'js', 'exe', 'bat', 'py']:
                    xml_file_path = f"{filename[0]}_Recipe_data.xml"
                    if xml_file_path in xml_files:
                        klarf_file_path, xml_file_path = move_file_rejected(klarf_file_path, xml_file_path, 'archive')
                        # update job status to queued
                        await update_job_status({
                            'job_status': 'queued',
                            'xml_file_path': xml_file_path,
                            'klarf_file_path': klarf_file_path
                        })
        else:
            app_log.warning(f"{landing_zone}, Does not exist!")
        await upload_files_drive()
    except Exception as e:
        app_log.error(f"Something went wrong in copying file.. {repr(e)}")
        app_log.exception(e)
