"""XML parse for DRive """
import os
import sys
import xmltodict
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_logger,get_column_details
app_log = get_logger('parser_xml')

def extract_xml_df(file_path):
    """
    this function accepts file path and reads, parse XML files to dataframes 
    """
    try:
        with open(file_path) as xml_file:
            data_dict = xmltodict.parse(xml_file.read(), dict_constructor=dict)
        xml_df =  pd.DataFrame.from_dict(data = data_dict.get('JobFile'),orient='index').T
        df_cols =  get_column_details('columns').get('xml_cols')

        xml_df.rename(df_cols,axis=1,inplace=True)
        xml_df['doassistenabled'].iloc[0]='Yes' if xml_df['doassistenabled'].iloc[0]=='true' else 'No'
        xml_df_col=list(xml_df.columns)
        df_cols=list(df_cols.values())
        if xml_df_col.sort()==df_cols.sort():
            app_log.info(xml_df.T)
            return xml_df
        else:
            raise Exception("Missing column in xml file")

    except Exception as e:
        app_log.error(f"Error while loadind data. {e}")
        return {"error":e}


if __name__ == "__main__":
    abc=extract_xml_df(
        f'C:/Users/e176387/Downloads/Drive_samplefiles/Drive_SampleFiles1/125_Recipe_data.xml')
