"""1.8v Klarf parser """

import os
import re
import sys
import json
import pandas as pd
import numpy as np

sys.path.append(os.path.abspath(
    os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_logger, get_column_details, get_columns_info
app_log = get_logger('parserv8')


def clean_list_data(data):
    """
    This function is used to clean each row of the data frame.
    param: raw row level input
    return: cleaned row
    """
    # Image list load===>
    img_index = data.lower().find('images')
    if img_index >= 0:
        data = data.replace(';', "").replace('""', "NA")
        img_list = data[img_index:]
        img_list = img_list.split("{")[1].replace(
            "}", "").replace(" ", "-").replace('"', '')
        data = data[0:img_index] + img_list
    # <=== end of change
    data = data.replace(';', "").replace('""', "NA").split(" ")
    out = []
    flag = None
    for i in data:
        if '"' in i:
            if '"' == i[-1] and '"' == i[0]:
                out.append(i.replace('"', ''))
            elif flag:
                out.append(flag + ' ' + i.replace('"', ''))
                flag = None
            else:
                flag = i.replace('"', '')
        elif flag:
            flag = flag + ' ' + i
        else:
            out.append(i)
    return out


def parse_field(data):
    """
    This function is used to parse the field type rows.
    """
    data = data.split(' ', 3)
    name = data[1]
    pattern = re.compile(r"[^_@.:\-,\w]")
    actual_data = re.sub(pattern, '', data[3]).split(',')
    return name, actual_data


def parse_record(data):
    """
    This function is used to parse the record type rows.
    """
    data = data.split(' ', 2)
    le = len(data)
    l = []
    if (3-le) != 0:
        l = ['NaN'] * (3 - le)
    data += l
    data[-1] = data[-1].replace('"', '')
    return data[1:]


def process_header_meta_v8(data_record, data_file):
    """
    This function is used to create the header meta data from record and field.
    param: data_record, data_file
    return: final header meta data
    """
    meta_dict_rec = {i[0]: i[1] for i in data_record if i[0]
                     in ['FileRecord', 'LotRecord', 'WaferRecord']}
    meta_dict_file = {}
    for i, j in data_file:
        if i in ['ResultTimeStamp', 'FileTimeStamp']:
            meta_dict_file[i] = ' '.join([str(elem) for elem in j])
        if i == 'InspectionStationID':
            meta_dict_file[i] = j[2]
            meta_dict_file['InspectionStationModel'] = j[1]
        if i == 'DiePitch':
            meta_dict_file['XDIEPITCH'] = j[0]
            meta_dict_file['YDIEPITCH'] = j[1]
        if i == 'RecipeID':
            meta_dict_file['RecipeID'] = j[0]
            meta_dict_file['RecipeTimeStamp'] = f'{j[1]} {j[2]}'
        if i in ['SampleCenterLocation', 'DieOrigin', 'DieStreetCenter']:
            meta_dict_file[i] = ','.join([str(elem) for elem in j])
        if i in ['DeviceID', 'StepID', 'SlotNumber', 'SampleSize', 'SampleOrientationMarkType', 'OrientationMarkLocation', 'SampleType']:
            meta_dict_file[i] = j[0]
    meta_dict_file.update(meta_dict_rec)
    meta_df = pd.DataFrame.from_dict(data=meta_dict_file, orient='index').T

    return meta_df

def dynamic(row):
    return "{{{}}}".format(",".join(["'{}':'{}'".format(k,v) for k, v in row.to_dict().items()]))

def parser_v8(lines,all_field_type):
    
    # all_field_type = []
    all_list_type = []
    all_record_type = []
    main_cols = get_column_details('columns')
    app_log.info('Parsing file now.')
    try:
        for index, data in enumerate(lines):
            # if data.startswith('Field'):
            #     parsed_field = parse_field(lines[index])
            #     all_field_type.append(parsed_field)
            if data.startswith('List'):
                df_name = lines[index].replace('\n', "").split(" ")[-1]
                column_data = lines[index:]
                column_end = lines[index:].index('}')
                columns = " ".join(column_data[2:column_end])

                columns = columns.split('{ ')[-1]

                columns = columns.lower().split(", ")
                columns = tuple(map(lambda x: x.split(" ")[-1], columns))

                main_data = column_data[column_end + 1:]

                data_end = main_data.index('}')
                main_data = main_data[2:data_end]
                main_data = list(map(clean_list_data, main_data))

                if df_name == 'DefectList':
                    all_list_type.append(
                        {"df_name": df_name, "columns": columns, "main_data": main_data})
                else:
                    continue

            if data.startswith('Record'):
                parsed_record = parse_record(lines[index])
                all_record_type.append(parsed_record)
            else:
                continue
    except RuntimeError as exe:
        app_log.error(f'something is wrong while parsing file {exe}')
    main_data_ind = next((i for i, item in enumerate(
        all_list_type) if item["df_name"] == "DefectList"), None)
    meta_df = process_header_meta_v8(all_record_type, all_field_type)
    main_df = pd.DataFrame(data=[i for i in all_list_type[main_data_ind]
                        ["main_data"]], columns=all_list_type[main_data_ind]["columns"])
    main_df = main_df.rename(columns={'searchfovsem': 'fov'})
    # """dynamic column addition """
    dynamic_col = list(set(main_df.columns) -
                    set(main_cols.get('main_cols').keys()))
    main_df.insert(loc=0, column='dynamic', value="")
    main_df.insert(loc=0, column='aspectratio', value="")
    # fov_val = main_df['searchfovsem'].astype('float64').max() if 'searchfovsem' in tuple(main_df.columns) else None
    # main_df.insert(loc=0, column='fov', value=fov_val)
    main_df['dynamic']= main_df[dynamic_col].to_dict('records')
    if 'semxsize' in main_df.columns and 'semysize' in main_df.columns:
        main_df['aspectratio'] = main_df[['semxsize','semysize']].astype(float).min(axis=1)/main_df[['semxsize','semysize']].astype(float).max(axis=1)
        main_df['aspectratio'].replace([np.inf, -np.inf], 0.0, inplace=True)
        main_df['aspectratio'] = main_df['aspectratio'].astype(float)
    main_df.drop(dynamic_col, axis=1, inplace=True)
    # main_df = main_conversion(main_df)
    meta_df['defect_count'] = len(main_df)
    
    return main_df, meta_df   

def get_meta_final(init_meta, current_meta):
    init_meta.update(current_meta)
    meta_df = pd.DataFrame([init_meta])
    meta_df = meta_df[get_column_details('v8')]
    meta_final = header_conversion(meta_df)
    return meta_final

def parse_klarf(filename):
    """
    This is main driver function which iterate over file and parse it.
    param: filename
    return: main df and meta data
    """
    try:
        final_dict = dict()
        parse_dict = dict()
        all_field_type = []
        app_log.info('Reading file now.')
        with open(filename, 'r') as handle:
            lines1 = handle.readlines()
        lines = list(map(str.strip, lines1))
        for index, data in enumerate(lines):
            if data.startswith('Field'):
                parsed_field = parse_field(lines[index])
                all_field_type.append(parsed_field)
        slot_list=[ind for ind,val in enumerate(lines) if "WaferRecord" in val]
        if len(slot_list)>1:
            for key,vl in enumerate(slot_list):
                if key == 0:
                    data_lines = lines[:slot_list[key+1]]
                elif key == (len(slot_list)-1):
                    data_lines = lines[vl:]
                else:
                    data_lines = lines[vl:slot_list[key+1]]
                main_df, meta = parser_v8(data_lines,all_field_type)

                if 'test' not in main_df.columns:
                    main_df.insert(loc = 0, column = 'test', value = pd.NA)

                missing_columns = list(set(list(get_columns_info()['main_cols'].keys())) - set(main_df.columns))
                if 'fov' in missing_columns:

                    if 'searchfovsem' not in set(main_df.columns):
                        app_log.error("Searchfovsem  missing in klarf")
                        return {"error":"Searchfovsem  missing in klarf"}
                    else:
                        missing_columns.remove('fov')
                if missing_columns:
                    return {"error":f"The columns {missing_columns} are missing in klarf"}
                # cont = 0 
                # for i in list(get_columns_info()['main_cols'].keys()):

                #     if i not in set(main_df.columns):
                #         cont = 1
                #         break
                # if cont:
                #     continue
                main_df = main_conversion(main_df)
                current_meta = meta.T.to_dict()[0]
                if key == 0:
                    init_meta = meta.T.to_dict()[0]
    
                meta_final = get_meta_final(init_meta, current_meta)
                for i in ['lotrecord', 'recipeid', 'waferrecord', 'stepid','resulttimestamp','deviceid','xdiepitch','ydiepitch']:
                    main_df[i] = meta_final.loc[0,i]

                dict_final_data = {'prefix_metadata':meta_final,'main_data':main_df}   
                slot = meta_final['slotnumber'].iloc[0]
                if slot in final_dict:   
                    final_dict[slot] = final_dict[slot]+1
                    parse_dict.update({
                                        f"slot:{slot}_{final_dict[slot]}": dict_final_data}) 
                else:
                    final_dict[slot]=1
                    parse_dict.update({
                                        f"slot:{slot}": dict_final_data})
        else:
            main_df, meta_df = parser_v8(lines,all_field_type)

            if 'test' not in main_df.columns:
                main_df.insert(loc = 0, column = 'test', value = pd.NA)
            missing_columns = list(set(list(get_columns_info()['main_cols'].keys())) - set(main_df.columns))
            if 'fov' in missing_columns:
                if 'searchfovsem' not in set(main_df.columns):
                    app_log.error("Searchfovsem  missing in klarf")
                    return {"error":"Searchfovsem  missing in klarf"}
                else:
                    missing_columns.remove('fov')
            if missing_columns:
                return {"error":f"The columns {missing_columns} are missing in klarf"}
            # for i in list(get_columns_info()['main_cols'].keys()):
            #     if i not in set(main_df.columns):
            #         app_log.error(f'The column {i} is missing in klarf')
            #         return {"error": f'The column {i} is missing in klarf'}
            main_df = main_conversion(main_df)
            meta_df = meta_df[get_column_details('v8')]
            meta_final = header_conversion(meta_df)
            for i in ['lotrecord', 'recipeid', 'waferrecord', 'stepid','resulttimestamp','deviceid','xdiepitch','ydiepitch']:
                main_df[i] = meta_final.loc[0,i]
            dict_final_data = {'prefix_metadata':meta_final,'main_data':main_df}   
            slot = meta_final['slotnumber'].iloc[0]
            parse_dict.update({f"slot:{slot}": dict_final_data})

        return parse_dict
    except Exception as e:
        app_log.exception(e)
        return {"error": f'{e}'}




def header_conversion(meta_df):
    """
    This function is used for value conversions and renaming columns of meta dataframe
    """
    datetime_format = '%Y-%m-%d %H:%M:%S'
    meta_df['xdiepitch'] = float(meta_df['XDIEPITCH'].astype(float))/1000
    meta_df['ydiepitch'] = float(meta_df['YDIEPITCH'].astype(float))/1000
    meta_df['rfg'] = 1
    meta_df.drop(columns = ['XDIEPITCH','YDIEPITCH'], inplace=True)
    orient = {
        0: 'DOWN',
        90: 'LEFT',
        180: 'UP',
        270: 'RIGHT'
    }
    cols_dict = {}
    meta_df['OrientationMarkLocation'] = orient[int(float(
        meta_df['OrientationMarkLocation']))]
    cols = list(meta_df.columns)
    for i in cols:
        cols_dict.update({i: i.lower()})
    meta_df.rename(cols_dict, axis=1, inplace=True)
    meta_df['resulttimestamp'] = pd.to_datetime(
        meta_df['resulttimestamp']).dt.strftime(datetime_format)
    meta_df['recipetimestamp'] = pd.to_datetime(
        meta_df['recipetimestamp']).dt.strftime(datetime_format)
    meta_df['filetimestamp'] = pd.to_datetime(
        meta_df['filetimestamp']).dt.strftime(datetime_format)
    return meta_df


def main_conversion(main_df):
    """
    This function is used for value conversions and renaming columns of main dataframe
    """
    main_cols = get_column_details('columns').get('main_cols')
    for i, k in main_cols.items():
        if i in get_column_details('columns').get('v8_conversion'):
            main_df[i] = (main_df[i].astype(k))/1000
        else:
            main_df[i] = main_df[i].astype(k)
    return main_df

#waferrecord is the field on which if we split the file should get appropriate output.
if __name__ == "__main__":
    final_data = parse_klarf(
        r'C:\Users\x0143654\Downloads\1.8_Multi_Klarf - Copy_03_19_23_10_26_37_370.001')
