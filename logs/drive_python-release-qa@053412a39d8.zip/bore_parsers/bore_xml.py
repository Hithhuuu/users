"""XML parse for DRive """
import os
import sys
import xmltodict
import pandas as pd
from datetime import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_logger,get_column_details, get_columns_info
app_log = get_logger('bore_parser_xml')

def extract_xml_df(file_path):
    """
    this function accepts file path and reads, parse XML files to dataframes 
    """
    
    with open(file_path) as xml_file:
        data_dict = xmltodict.parse(xml_file.read(), dict_constructor=dict)
    xml_df =  pd.DataFrame.from_dict(data = data_dict.get('JobFile'),orient='index').T
    df_cols =  get_column_details('columns').get('xml_bore_cols')
    xml_df.rename(df_cols,axis=1,inplace=True)
    xml_df_col=list(xml_df.columns.str.lower())
    df_cols=list(df_cols.values())
    sorted_xml_df_col = sorted(xml_df_col)
    sorted_df_cols = sorted(df_cols)
    if sorted_xml_df_col==sorted_df_cols:
    # if xml_df_col.sort()==df_cols.sort():
    #     app_log.info(xml_df.T)
    #     return xml_df
        xml_df['doassistenabled'].iloc[0]='Yes' if xml_df['doassistenabled'].iloc[0]=='true' else 'No'
        # date = datetime.strptime(xml_df['recipelastmodifieddate'].iloc[0], "%d_%m_%Y").date()
        # converted_date = date.strftime("%Y-%m-%d")
        # xml_df['recipelastmodifieddate'] = converted_date
        xml_df['recipelastmodifieddate'] = pd.to_datetime(xml_df['RecipeLastModified'], format='%m-%d-%Y, %H:%M:%S').dt.strftime('%Y-%m-%d %H:%M:%S')
        xml_df = xml_df.drop('RecipeLastModified', axis=1)
        app_log.info(xml_df.T)
        return xml_df
    else:
        raise Exception("Missing column in xml file")
    # except Exception as e:
    #     app_log.error(f"Error while loading data. {e}")
    #     return {"error":e}



    

def extract_csv_df(file_path):
    try:
        csv_df = pd.read_csv(file_path, index_col=False)
        return csv_df
    except Exception as e:
        app_log.error(f"Error while loadind data. {e}")
        return {"error":e}
    
# if __name__ == "__main__":
#     # abc=extract_xml_df(
#     #     f'C:\\Users\\x0143654\\Downloads\\alex_bore.xml')
#     cde = extract_xml_df(f'C:\\Users\\x0143654\\Downloads\\test_bore_Recipe_data.xml')
#     print(cde)
