"""v7 and v8 Klarf parser """

import os
import sys
import math
import json
import pandas as pd
import numpy as np

sys.path.append(os.path.abspath(
    os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_logger, get_columns_info, get_column_details
from bore_parsers.bore_xml import extract_xml_df,extract_csv_df
from bore_parsers.bore_v8_klarf import parse_klarf

app_log = get_logger('bore_v7_parser')

class klarf_v7:
    def __init__(self,filename, context):
        
        config = get_columns_info()
        self.filename=filename
        self.prefix_end=config['KLARF']['prefix_end']
        self.suffix_start=config['KLARF']['suffix_start']
        self.suffix_data_start=config['KLARF']['suffix_data']['suffix_data_start']
        self.suffix_data_end=config['KLARF']['suffix_data']['suffix_data_end']
        self.break_point=config['KLARF']['main_data_breakpoint']
        self.multi_klarf_file_split_point='WaferID'
        self.context=context


    def list_file(self):
        ''' This function returns a list of lines from file'''
        app_log.info(f'Parser has entered the function and ready to read the file', extra=self.context)
        try:
            try:
                with open(self.filename, 'rt') as g:
                    lines = g.readlines()
            except:
                try:
                    with open(self.filename, 'rt', encoding = "ISO-8859-1") as g:
                        lines = g.readlines()
                except Exception as e:
                    app_log.error(f'issue in reading file {e}',extra=self.context)
            return lines
        except:
            app_log.error('Error in reading lines v7 file, function --- list_file', extra=self.context)

    def columns(self, lines):
        
        app_log.info(f'Extraction of column names', extra=self.context)
        try:
            columnsname = ''
            ls = [i for i in range(0, len(lines)) if self.prefix_end in lines[i]]
            for i in lines[ls[0]:ls[0] + 1]:
                columnsname += i

            list_col = columnsname.strip('\n').replace(';', '').split()
            list_col = list_col[2:]
            return list_col
        except:
            app_log.error('Error in extraction of columns, function --- columns', extra=self.context)


    def prefix_metadata(self, prefix):
        '''converting to prefix_metadata dataframe'''
        app_log.info(f'Parsing the prefix metadata', extra=self.context)
        try:
            meta=('').join(prefix)
            meta_mid=meta.replace('\n','')
            meta_mid=meta_mid.split(';')
            meta_mid=list(filter(None, meta_mid))
            meta_final={}
            for i in meta_mid:
                lst=i.split(' ',1)
                if lst[0] in meta_final:
                    value=[('; ').join(meta_final[lst[0]]+[lst[1]])]
                    meta_final.update({f'{lst[0]}':value})
                else:
                    meta_final.update({f'{lst[0]}':[lst[1]]})
            
            df_meta=pd.DataFrame.from_dict(meta_final)

            return df_meta
        except:
            app_log.error('Error in prefix metadata parsing, function --- prefix_metadata', extra=self.context)


    def suffix_metadata(self, suffix):

        app_log.info(f'Parsing the suffix metadata', extra=self.context)
        try:
            s=('').join(suffix).split(';\n')
            for i in s:
                if self.suffix_data_start in i:
                    col=i
                if self.suffix_data_end in i:
                    val=i
            
            df_meta_suffix = pd.DataFrame()  
            try:
                cols=col.split('\n')[1].strip().split()
            except:
                cols=col.split(' ',2)[2].strip().split()
            vals=val.split('\n')
            for i in vals[1:]:
                try:
                    df=pd.DataFrame([i.strip().split()],columns=cols)
                except:
                    df=pd.DataFrame()
                df_meta_suffix = df_meta_suffix.append(df, ignore_index = True)

            return df_meta_suffix
        except:
            app_log.error('Error in suffix metadata parsing, function --- suffix_metadata', extra=self.context)

    def header_conversion(self, meta_df):
        """
        This function is used for value conversions and renaming columns of meta dataframe
        """
        datetime_format = '%Y-%m-%d %H:%M:%S'
        meta_df = meta_df.replace('"','',regex=True)
        meta_df['XDIEPITCH'] = meta_df['DiePitch'].str.split().str[0].astype(float)
        meta_df['YDIEPITCH'] = meta_df['DiePitch'].str.split().str[1].astype(float)
        meta_df['SampleSize'] = (meta_df['SampleSize'].str.split().str[1].astype(int))*1000
        # meta_df['SampleCenterLocation'] = meta_df['SampleCenterLocation'].apply(lambda x: f"{int(x.split(',')[0]) / 1000},{int(x.split(',')[1])/1000}")
        columns_to_convert = ['DieOrigin', 'SampleCenterLocation']

        # Iterate over the columns
        for column in columns_to_convert:
            # Split the coordinates and convert them to float
            meta_df[column] = meta_df[column].apply(lambda x: str(x).replace(' ', ','))
        if 'DeviceID' in meta_df.columns and 'RecipeTimeStamp' not in meta_df.columns:
            if 'SetupID' in  meta_df.columns:
                recipeid =  meta_df['SetupID'].str.split()
                meta_df['RecipeID'] =  recipeid.str[0]
                meta_df['RecipeTimeStamp'] =  pd.to_datetime(recipeid.str[1] +' '+ recipeid.str[2]).dt.strftime(datetime_format)
            else:
                recipeid =  meta_df['DeviceID'].str.split()
                meta_df['RecipeID'] =  recipeid.str[0]
                if not math.isnan(recipeid.str[1]):
                    meta_df['RecipeTimeStamp'] =  pd.to_datetime(recipeid.str[1] +' '+ recipeid.str[2]).dt.strftime(datetime_format)
                else:
                    meta_df['RecipeTimeStamp']=""
        

        inspectionstationid = meta_df['InspectionStationID'].str.split()
        meta_df['InspectionStationID'] = inspectionstationid.str[2]
        meta_df['InspectionStationModel'] = inspectionstationid.str[1]

        meta_df['ResultTimeStamp'] = pd.to_datetime(
            meta_df['ResultTimestamp']).dt.strftime(datetime_format)
        
        # meta_df['FileTimestamp'] = pd.to_datetime(
        #     meta_df['FileTimestamp']).dt.strftime(datetime_format)
            
        # meta_df.insert(loc=0,column='DeviceID',value=0)    #remove this line it tells whether klarf is correct or not
        meta_df = meta_df[get_column_details('v7_bore')]
        meta_df['rfg'] = 1
        cols_dict = {}
        col = {'LotID':'LotRecord', 'WaferID':'WaferRecord', 'Slot':'SlotNumber'}
        meta_df.rename(col, axis=1, inplace=True)

        cols = list(meta_df.columns)
        for i in cols:
            cols_dict.update({i: i.lower()})
        meta_df.rename(cols_dict, axis=1, inplace=True)  

        return meta_df  

    def data_conversion(self, meta, main_df):
        main_cols = get_column_details('columns')
        dynamic_col = list(set(main_df.columns) -
                         set(main_cols.get('bore_cols').keys())) # Need to check main_cols just need to change bore cols here
        main_df.insert(loc=0, column='dynamic', value="")
        main_df.insert(loc=0, column='aspectratio', value="")
        fov_val = main_df['searchfovsem'].astype('float64') if 'searchfovsem' in tuple(main_df.columns) else None
        main_df.insert(loc=0, column='fov', value=fov_val)
        if len(dynamic_col) > 0:       
            # main_df['dynamic'] = main_df[dynamic_col].to_dict('records')
            main_df[dynamic_col] = main_df[dynamic_col].astype(str)
            main_df['dynamic'] = main_df[dynamic_col].to_dict('records')
        main_df['aspectratio'] = main_df[['semxsize','semysize']].astype(float).min(axis=1)/main_df[['semxsize','semysize']].astype(float).max(axis=1)
        main_df['aspectratio'].replace([np.inf, -np.inf], 0.0, inplace=True)
        main_df['aspectratio'] = main_df['aspectratio'].astype(float)
        main_df.drop(dynamic_col, axis=1, inplace=True)
        # main_df = main_conversion(main_df)
        meta['defect_count'] = len(main_df)

        meta_final = self.header_conversion(meta)
        main_df = self.main_conversion(main_df)
        for i in ['lotrecord', 'stepid','resulttimestamp','deviceid','xdiepitch','ydiepitch']: # do we need sample centre and all in main
            main_df[i] = meta_final.loc[0,i]
        main_df.drop('searchfovsem',axis=1, inplace=True)
        if main_df['dynamic'].iloc[0] == '':
            main_df['dynamic'] = [{} for _ in range(0,len(main_df))]

        return meta_final, main_df

    def parser_v7(self,data,filename_csv):
        lines=data
        for indx,val in enumerate(lines):
            if self.prefix_end in val:
                prefix_end_indx=indx
                break
        for i in reversed(lines):
            if self.suffix_data_start in i:
                suffix_data_start_indx=lines.index(i)
                break
        for i in reversed(lines):
            if self.suffix_start in i:
                app_log.error('need to work on logic')

        df_meta_prefix = self.prefix_metadata(lines[:prefix_end_indx])
        df_meta_suffix = self.suffix_metadata(lines[suffix_data_start_indx:])

        # main_df= self.parse(lines[prefix_end_indx:suffix_data_start_indx])
        main_df = extract_csv_df(filename_csv)
        # main_df = main_df.drop('Unnamed: 40', axis=1)
        main_df.columns = [x.lower().replace(" ", "") for x in main_df.columns]
        missing_columns = set(list(get_columns_info()['bore_cols'].keys())) - set(main_df.columns)
        if missing_columns:
            app_log.error(f'The columns {missing_columns} are missing in csv')
            error = f'The columns {missing_columns} missing in csv'
            raise Exception(error)
        # for i in list(get_columns_info()['bore_cols'].keys()):
        #     if i not in set(main_df.columns):
        #         app_log.error(f'The column {i} is missing in csv')
        #         raise Exception ( f'The column {i} is missing in csv')
               

        return df_meta_prefix, df_meta_suffix, main_df

    def parse(self, lines):
        
        try:
            app_log.info(f'Extraction of column names', extra=self.context)
            list_col = lines[0].strip('\n').lower().replace(';', '').split()
            list_col = list_col[2:]
        except:
            app_log.error('Error in extraction of columns', extra=self.context)

        try:
            app_log.info(f'Extraction of Main data', extra=self.context)
            if len(lines)<2:
                app_log.info('file has no main data')
                return pd.DataFrame()
            data_lines = lines[1:]
            values = []
            for i in data_lines:
                line_data = i.replace(';','').strip('\n').strip().split()
                if len(line_data) == len(list_col):
                    values.append(line_data)
                elif not len(line_data) % len(list_col):
                    for i in range(0,int(len(line_data)/len(list_col))):
                        values.append(line_data[i*len(list_col):(i+1)*len(list_col)])
                # else:
                #     app_log.error('Error in parsing multiple defect in one line, function --- parse', extra=self.context)

            # values[-1][-1]=values[-1][-1].split(';')[0]
            df = pd.DataFrame(data=values, columns=list_col)

            return df.dropna().reset_index(drop=True)
        except:
            app_log.error('Error in main_data parsing, function --- parse', extra=self.context)

    #not required for now wide parse
    def wide_parse(self, df_columns, data_lines, image_name):
        
        try:
            list_col=df_columns
            values = []
            for i in data_lines:
                val=i.strip('\n').strip().split()
                if len(val) > len(list_col)-1:
                    v=val[:len(list_col)-1]
                    imagename=image_name.replace(';\n','').split(' ')[1]
                    image_info=json.dumps({'image_name':imagename})
                    v.append(image_info)
                    values.append(v)
                else:
                    val.append("N")
                    values.append(val)
            if values:
                values[-1][-2]=values[-1][-2].split(';')[0]
                df = pd.DataFrame(data=values, columns=list_col)
            else:
                return
            return df[1:]
        except:
            app_log.error('Error in main_data parsing, function --- wide_parse', extra=self.context)

    def main_conversion(self, main_df):
        """
        This function is used for value conversions and renaming columns of main dataframe
        """
        main_cols = get_column_details('columns').get('bore_cols')
        for i, k in main_cols.items():
            main_df[i] = main_df[i].astype(k)
        return main_df
    
    def data_validation(self,main_df, meta_df):
        """
        This function is to validate defects based on conditions 
        """
        classnumber = meta_df['nvdclass'].astype(int)
        undefined = meta_df['unclassifiedclass'].astype(int)
        main_df = main_df[((main_df['reviewstatus'] == 1) | (main_df['reviewstatus'] == 2) | (main_df['defectdo'] == 1) | (main_df['defectdo'] == 2)) & ~((main_df['classnumber'] == classnumber[0]) & (main_df['defectdo'] == 0)) & ~((main_df['classnumber'] == undefined[0]) & (main_df['adrhighscore'] == 0))]
        if len(main_df)==0:
            raise Exception ('No defects left after validation')
        return main_df

    def v7_df(self,product,csvfile,xml_df):
        try:
            parse_dict = dict()
            final_dict = dict()
            lines=self.list_file()
            # WaferID split file based on this keyword if multiple then multiple slots are present
            slot_list=[ind for ind,val in enumerate(lines) if self.multi_klarf_file_split_point in val]
            if len(slot_list)>1:
                df_meta_prefix_initial = self.prefix_metadata(lines[:slot_list[0]])
                for k,v in enumerate(slot_list):
                    if k < len(slot_list)-1:
                        data=lines[v:slot_list[k+1]]
                    else:
                        data=lines[v:]

                    df_meta_prefix, df_meta_suffix, main_df =self.parser_v7(data,csvfile)  
                    if 'test' not in main_df.columns:
                        main_df.insert(loc = 0, column = 'test', value = "")    
                    # next line is hard coded in accordance to the multi wafer files in DRive
                    if k>0 and 'DieOrigin' in df_meta_prefix_initial.columns:
                        df_meta_prefix_initial.drop(['DieOrigin'], axis=1, inplace=True)
                    df_meta_prefix_final = df_meta_prefix_initial.join(df_meta_prefix)
                    prdct = [i for i in ['DeviceID','SetupID'] if i.lower() == product.lower()]
                    product = prdct[0] if prdct else product
                    if "DeviceID" not in df_meta_prefix_final.columns or product.lower()!="deviceid":
                        if product in df_meta_prefix_final.columns:
                            df_meta_prefix_final["DeviceID"] = df_meta_prefix_final[product]
                            product_id =  df_meta_prefix_final[product].str.split()
                            df_meta_prefix_final["DeviceID"] =  product_id.str[0]
                            df_meta_prefix_final["RecipeID"] =  product_id.str[0]
                            df_meta_prefix_final['RecipeTimeStamp'] =  pd.to_datetime(product_id.str[1] +' '+ product_id.str[2]).dt.strftime('%Y-%m-%d %H:%M:%S')
                            df_meta_prefix_final.drop([product], axis=1, inplace=True)

                    df_meta_prefix_final_data = df_meta_prefix_final.join(xml_df[["nvdclass","unclassifiedclass"]])
                    main_df = self.data_validation(main_df, df_meta_prefix_final_data)
                    df_meta_final, main_df = self.data_conversion(df_meta_prefix_final, main_df)
                    main_df['manualdoassist'] = 'true' if len(main_df[(main_df['defectdo'] == 1) | (main_df['defectdo'] == 2)]) > 0 else 'false'
                    dict_final_data = {'prefix_metadata':df_meta_final,'main_data':main_df,'suffix_metadata':df_meta_suffix}
                    slot = df_meta_final['slotnumber'].iloc[0]
                    if slot in final_dict:   
                        final_dict[slot]=final_dict[slot]+1
                        parse_dict.update({
                                            f"slot:{slot}_{final_dict[slot]}": dict_final_data}) 
                    else:
                        final_dict[slot]=1
                        parse_dict.update({
                                            f"slot:{slot}": dict_final_data})
            else:
                df_meta_prefix_final, df_meta_suffix, main_df =self.parser_v7(lines,csvfile)
                #test needs to be such a value so as it can be converted to INT 
                if 'test' not in main_df.columns:
                    main_df.insert(loc = 0, column = 'test', value = "")

                prdct = [i for i in ['DeviceID','SetupID'] if i.lower() == product.lower()]
                product = prdct[0] if prdct else product
                if "DeviceID" not in df_meta_prefix_final.columns or product.lower()!="deviceid":
                    if product in df_meta_prefix_final.columns:
                        df_meta_prefix_final["DeviceID"] = df_meta_prefix_final[product]
                        product_id =  df_meta_prefix_final[product].str.split()
                        df_meta_prefix_final["DeviceID"] =  product_id.str[0]
                        df_meta_prefix_final["RecipeID"] =  product_id.str[0]
                        df_meta_prefix_final['RecipeTimeStamp'] =  pd.to_datetime(product_id.str[1] +' '+ product_id.str[2]).dt.strftime('%Y-%m-%d %H:%M:%S')
                        df_meta_prefix_final.drop([product], axis=1, inplace=True)
                df_meta_prefix_final_data = df_meta_prefix_final.join(xml_df[["nvdclass","unclassifiedclass"]])
                main_df = self.data_validation(main_df, df_meta_prefix_final_data)
                df_meta_final, main_df = self.data_conversion(df_meta_prefix_final, main_df)
                main_df['manualdoassist'] = 'true' if len(main_df[(main_df['defectdo'] == 1) | (main_df['defectdo'] == 2)]) > 0 else 'false'
                dict_final_data={'prefix_metadata':df_meta_final,'main_data':main_df,'suffix_metadata':df_meta_suffix}
                slot = df_meta_final['slotnumber'].iloc[0]
                parse_dict.update({f"slot:{slot}": dict_final_data})            

            app_log.info(f'Parsing succesfully completed', extra=self.context)
            return parse_dict  
        except Exception as e:
            app_log.error('Issue in file parsing,  function --- v7_df', extra=self.context)
            raise (e)

def extract_klarf_files(file_path, xml_df,filename_csv):
    '''This function checks the version of klarf files and return the output'''
    input_file=file_path.replace('\\','/').rsplit('/',1)[1]
    context = {"file_name": input_file,'filetype':'klarf'}
    path = file_path
    config = get_columns_info()

    try:       
        if input_file.endswith(('.jpg','.html','.pdf','.emsa')):
            app_log.info('file not allowed')
            return 

        app_log.info(context)   
        try:
            with open(path, 'rt') as g:
                lines = g.readlines()
        except:
            try:
                with open(path, 'rt', encoding = "ISO-8859-1") as g:
                    lines = g.readlines()
            except Exception as e:
                app_log.error(f'issue in reading file {e}',extra=context)

        if len(lines)<1:
            app_log.info('file is empty')
            app_log.error("Empty file")
            return {"error":"Empty file"}
            
        
        # if xml_df['deviceid'].iloc[0].lower() not in (" ").join(lines).lower() or ("setupid" not in (" ").join(lines).lower()):
        #     app_log.info('file is to be rejected')
        #     return
        if xml_df['deviceid'].iloc[0] is not None:
            if xml_df['deviceid'].iloc[0].lower()  in (" ").join(lines).lower():
                product = xml_df['deviceid'].iloc[0]
            elif ("deviceid"  in (" ").join(lines).lower()):
                product="deviceid"  
            elif ("setupid"  in (" ").join(lines).lower()):
                product= "setupid"

        spot = lines[0]
        version_list=config['KLARF']['version']

        ver_out=''
        for version, ver_list in version_list.items():
            for k in ver_list:
                if k in spot:
                    ver_out=version
                    break
            if ver_out:
                break

        if ver_out=='v7':

            app_log.info(f'Parsing the data for v7 files', extra=context)
            obj7=klarf_v7(path, context)
            '''dictionary of dataframes'''
            final_data=obj7.v7_df(product,filename_csv,xml_df)      
            return final_data
        elif ver_out=='v8':
            
            app_log.info(f'Parsing the data for v8 files', extra=context)
            # obj8 = klarf_v8(path,product)
            # '''dictionary of dataframes'''
            # final_data = obj8.parser_v8()
            final_data = parse_klarf(path,filename_csv=filename_csv,xml_df=xml_df)
            return final_data
        else:
            raise Exception('file type not found')
    except Exception as e:
        app_log.error(f"Failed Parsing , {e}")
        raise Exception(e)

if __name__ =='__main__':
    abc = extract_xml_df (r"C:\Users\x0143654\Downloads\Files\Files\1.1_Pattern_1000_defects_SQA_Slot_18_03_28_24_02_01_14_369_Recipe_data.xml")
    main_meta_data = extract_klarf_files(file_path=r'C:\Users\x0143654\Downloads\Files\Files\1.1_Pattern_1000_defects_SQA_Slot_18_03_28_24_02_01_14_369.001', xml_df=abc,filename_csv=r'C:\Users\x0143654\Downloads\Files\Files\1.1_Pattern_1000_defects_SQA_Slot_18_03_28_24_02_01_14_369_Per_Run_Data.csv')
    # breakpoint()