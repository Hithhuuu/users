import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import  get_logger
from api.common.fastapi_app import get_query_with_pool
import yaml

app_log = get_logger("droppartition")

async def drop_partiton(query, table_name):
    app_log.info(f"Partition select query: {query}")
    # cursor.execute(query)
    partitions = await get_query_with_pool(query,resp_type=list)
    for partition in partitions:
        app_log.info(f"partition to delete {partition}")
        app_log.info(f"Dropping partitions {partition[0]}")
        detach_query = f"ALTER TABLE drive.{table_name} DETACH PARTITION '{partition[0]}'"
        # cursor.execute(detach_query)
        await get_query_with_pool(detach_query)
        drop_query = f"ALTER TABLE drive.{table_name} DROP PARTITION '{partition[0]}'"
        # cursor.execute(drop_query)
        await get_query_with_pool(drop_query)
        app_log.info(f"Completed dropping partition {partition[0]} from {table_name}")

async def start_drop_partition():
    try:
        with open("api/services/datacleanup/datacleanup.yaml") as file:
            config = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
        no_of_days = config["cleanup"]["db_cleanup"]*7
        app_log.info(f'no_of_days {no_of_days}')
        query1 = f"select distinct partition from system.parts where database = 'drive' and table = 'drive_defect_main' and modification_time <= date_sub(DAY, {no_of_days}, toDate(now()))"
        await drop_partiton(query1, 'drive_defect_main')

        # with open("api/services_bore/bore_datacleanup/bore_datacleanup.yaml") as file:
        #     config_bore = yaml.load(file, Loader=yaml.SafeLoader)
        #     file.close()
        # no_of_days = config_bore["cleanup"]["db_cleanup"]*7
        # app_log.info(f'no_of_days {no_of_days}')
        # query2 = f"select distinct partition from system.parts where database = 'drive' and table = 'bore_defect_main' and modification_time <= date_sub(DAY, {no_of_days}, toDate(now()))"
        # await drop_partiton(query2, 'bore_defect_main')
        # cursor.close()
        # connection.close()

    except Exception as e:
        import traceback
        app_log.info("Error while optiimizing the table")
        app_log.error(traceback.format_exc())

# if __name__=="__main__":
#     import asyncio
#     asyncio.run(start_drop_partition())
