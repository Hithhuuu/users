# import os
# import time
# import sys
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
# from api.common.utils import get_logger
# from api.common.common import update_job_status, move_bore_file,execute_query,get_query_with_pool
# from api.common.fastapi_app import get_query_with_pool

# app_log = get_logger("bore_rejectedfiles")

# async def bore_rejected():
#     try:
#         # conn = connection_pool.connect()
#         # cursor = conn.cursor()
#         # con = getdbconnection()
#         p= "select id,xml_file_name,klarf_file_name,csv_file_name ,err_message,job_start_time,job_status,job_end_time,xml_file_path,klarf_file_path,csv_file_path ,job_duration,job_type from bore_job_log final where re_try=3 and job_status='failed'"
#         data=await get_query_with_pool(p)
#         data = data.to_dict(orient='records')

#         for item in data:
#             klarf_file = item["klarf_file_path"]
#             xml_file = item["xml_file_path"]
#             csv_file = item["csv_file_path"]
#             err_message = item["err_message"]
#             klarf_path, xml_path,csv_path= move_bore_file(klarf_file, xml_file,csv_file, 'rejected')
#             item['xml_file_path']=xml_path
#             item['klarf_file_path']=klarf_path
#             item['csv_file_path'] = csv_path

#             update_query = """
#                 INSERT INTO bore_job_log
#                 SELECT
#                     id,
#                     xml_file_name,
#                     klarf_file_name,
#                     csv_file_name,
#                     job_type,
#                     job_start_time,
#                     job_end_time,
#                     job_duration,
#                     'rejected' AS job_status,
#                     '{err_message}' AS err_message,
#                     '{xml_file_path}' AS xml_file_path,
#                     '{klarf_file_path}' AS klarf_file_path,
#                     '{csv_file_path}' AS csv_file_path,
#                     cdt,
#                     re_try
#                 FROM
#                     bore_job_log FINAL
#                 WHERE
#                     id = {id}
#             """
#             update_query = update_query.format(**item)
#             await get_query_with_pool(update_query)
#             # execute_query(conn,update_query)
#             # conn.close()

#             # await update_job_status({'job_id':item['id'],'err_message':err_message,'job_status': 'rejected','xml_file_path':klarf_path,'klarf_file_path':xml_path,'final_rejection':True})

#     except Exception as err:
#         app_log.info(f"some issues with rejected file {err}")

# # # if __name__ =='__main__':
# # #     import asyncio
# # #     asyncio.run(bore_rejected())

