# import os
# import re
# import sys
# from datetime import datetime, timedelta
# import yaml
# import shutil
# import time

# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
# from api.common.utils import get_env_config, get_logger
# from api.common.common import execute_query, update_job_status
# from api.common.fastapi_app import get_query_with_pool


# """Config file to get the all the variable defined in the file"""
# env_config = get_env_config()

# """ Calling the logger object to get all the logs """
# app_log = get_logger('bore_cleanup')
# env = os.getenv("env")
# base_path = env_config[env]['watchdog_pick_location']['src']

# with open("api/services_bore/bore_datacleanup/bore_datacleanup.yaml") as file:
#     config = yaml.load(file, Loader=yaml.SafeLoader)
#     file.close()

# def remove_folder(path):
# 	# removing the folder
# 	if not shutil.rmtree(path):
# 		app_log.info(f"{path} is removed successfully")
# 	else:
# 		app_log.error(f"Unable to delete the {path}")

# def get_file_or_folder_age(path):

# 	# getting ctime of the file/folder and time will be in seconds
# 	ctime = os.stat(path).st_ctime
# 	return ctime

# async def bore_db_cleanup():
#     """  """
#     try:
#         # connection = get_dbconnection()
#         endDate = datetime.now()
#         no_of_days = config["cleanup"]["db_cleanup"]*7
#         app_log.info(f'no_of_days {no_of_days}')
#         startDate = (endDate - timedelta(days=no_of_days)).strftime("%Y-%m-%d %H:%M")
#         endDate = endDate.strftime("%Y-%m-%d %H:%M")
#         fetch_files = f"SELECT id, klarf_file_name FROM bore_job_log FINAL WHERE less(formatDateTime(toDate(cdt), '%Y-%m-%d %H:%M'), ('{startDate}'))"
#         app_log.info(f'Fetched files: {fetch_files}')
#         # delete_file_data = execute_query(connection, fetch_files, fetch='all')
#         delete_file_data = await get_query_with_pool(fetch_files)
#         delete_file_data = delete_file_data.to_dict(orient='records')
#         app_log.info(f'Files to be deleted {delete_file_data}')
#         if len(delete_file_data)>1:
#             jobid_list_to_delete = [i['id'] for i in delete_file_data]
#         else:
#             # connection.close()
#             return app_log.info("NO files to be deleted")

#         #just changing these files rfg to zero, deleteion of records from table will happen in different script which will run once a week
#         rfg_query = f" Insert into bore_map_header select mapid,jobid, deviceid, stepid, lotrecord, semtoolid, semrecipename, orientationmarklocation, samplesize, dieorigin, samplecenterlocation, resulttimestamp, xdiepitch, ydiepitch, rod, doassistenabled, semga, platformtype, nvdclass, slotnumber, unclassifiedclass, recipelastmodifieddate, defect_count,0 as rfg 1 FROM bore_map_header final where rfg = 1 and jobid in {jobid_list_to_delete}"
#         app_log.info(rfg_query)
#         await get_query_with_pool(rfg_query)
#         # cursor = connection.cursor()
#         # cursor.execute(rfg_query)
#         # cursor.close()
#         # connection.close()

#     except Exception as e:
#         app_log.error(f"Something went wrong in uploading file.. {repr(e)}")
#         app_log.exception(e)


# async def bore_data_clean():
#     """ data cleanup from archive as well as from database tables """
#     try:
#         app_log.info('Looking for new log files now.')
#         await bore_db_cleanup()

#         """ logic to delete folders with date before than the configured weeks """
#         processed_path = os.path.join(base_path, 'processed')
#         if os.path.exists(processed_path):
#             no_of_days = config["cleanup"]["file_cleanup"]*7
#             app_log.info(f'no_of_days {no_of_days}')
#             before_this_to_delete = time.time() - (no_of_days * 24 * 60 * 60)
#             for root_folder, folders, files in os.walk(processed_path):
#                 if root_folder != processed_path:
#                     if before_this_to_delete >= get_file_or_folder_age(root_folder):
#                         remove_folder(root_folder)

#         else:
#             app_log.warning(f"{processed_path}, Does not exist!")
#     except Exception as e:
#         app_log.error(f"Something went wrong in cleanup data file.. {repr(e)}")
#         app_log.exception(e)

# async def bore_optimize_tables():

#     tables_to_optimize = ['bore_job_log','bore_map_header','bore_defect_main']
#     # connection = connection_pool.connect()
#     # cursor = connection.cursor()

#     for i in tables_to_optimize:
#         if i == 'bore_defect_main':
#             query = f"select distinct partition from system.parts where database = 'drive' and table='{i}' and modification_time >= date_sub(DAY, 1, toDate(now()))"
#             app_log.info(query)
#             # cursor.execute(query)
#             partitions = await get_query_with_pool(query,resp_type=list)
#             for partition in partitions:
#                 app_log.info(f"partition to Optimize  {partition}")
#                 app_log.info(f"Starting to Optimize partition {partition[0]}")
#                 optimize_query = f"OPTIMIZE table drive.{i} PARTITION tuple({partition[0]}) FINAL"
#                 # cursor.execute(optimize_query)
#                 await get_query_with_pool(optimize_query)
#                 app_log.info(f"Completed Optimizing partition {partition[0]}")
#         else:
#             optimize_query = f"OPTIMIZE TABLE {i} FINAL "
#             # cursor.execute(optimize_query)
#             await get_query_with_pool(optimize_query)
#             app_log.info("Table Optimized")

#     # cursor.close()
#     # connection.close()

# # # if __name__ == "__main__":
# # #     app_log.info("Data cleanup is schduleded once a day")
# # #     data_clean()
# # #     optimize_tables()
# # #     app_log.info(f"{'*'*10} PROCESS COMPLETED {'*'*10}")