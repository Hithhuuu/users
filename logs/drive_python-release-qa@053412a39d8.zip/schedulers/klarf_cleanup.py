import os
import time
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.common.utils import get_logger
from api.common.common import update_job_status, move_file_rejected,execute_query
from api.common.fastapi_app import get_query_with_pool
app_log = get_logger("rejectedfiles")

def delete(directory):
    current_time=time.time()
    app_log = get_logger("erased_file")
    for filename in os.listdir(directory):
        file_path=os.path.join(directory,filename)
        if os.path.isfile(file_path):
            file_time=os.path.getctime(file_path)
            if file_time <(current_time-(24*60*60)):
                os.remove(file_path)
                app_log.info(f'{filename} deleted succesfully at {time.ctime()}')

async def rejected():
    try:
        # conn = connection_pool.connect()
        # cursor = conn.cursor()
        # con = getdbconnection()
        p= "select id,xml_file_name,klarf_file_name,err_message,job_status,xml_file_path,klarf_file_path,job_start_time,job_end_time,job_duration,job_type from drive_job_log final where re_try=3 and job_status='failed'"
        # data=execute_query(conn,p)
        data = await get_query_with_pool(p)
        data = data.to_dict(orient='records')
        for item in data:
            klarf_file = item["klarf_file_path"]
            xml_file = item["xml_file_path"]
            err_message = item["err_message"]
            klarf_path, xml_path= move_file_rejected(klarf_file, xml_file, 'rejected')
            item['xml_file_path']=xml_path
            item['klarf_file_path']=klarf_path

            update_query = """
                INSERT INTO drive_job_log
                SELECT
                    id,
                    xml_file_name,
                    klarf_file_name,
                    job_type,
                    job_start_time,
                    job_end_time,
                    job_duration,
                    'rejected' AS job_status,
                    '{err_message}' AS err_message,
                    '{xml_file_path}' AS xml_file_path,
                    '{klarf_file_path}' AS klarf_file_path,
                    cdt,
                    re_try
                FROM
                    drive_job_log FINAL
                WHERE
                    id = {id}
            """
            update_query = update_query.format(**item)
            await get_query_with_pool(update_query)
        # conn.close()

            # await update_job_status({'job_id':item['id'],'err_message':err_message,'job_status': 'rejected','xml_file_path':klarf_path,'klarf_file_path':xml_path,'final_rejection':True})

    except Exception as err:
        app_log.info(f"some issues with rejected file {err}")
        app_log.exception(Exception)


