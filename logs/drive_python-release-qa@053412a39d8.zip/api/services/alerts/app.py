from api.common.fastapi_app import app
from api.services.alerts.routes import alerts_handler


app.include_router(alerts_handler.router)