import json
import traceback
import pandas as pd
from datetime import datetime, timedelta
from api.common.common import get_header_defect_condition ,env_config
from io import BytesIO
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from api.common.fastapi_app import get_query_with_pool
from api.common.utils import get_logger, queries
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle ,PageBreak
from reportlab.lib import colors
import copy
import os
from api.services.alerts.routes.alerts_model import Alerts

app_log = get_logger("alerts_validation")

alerts = Alerts()

class Validation:
    """This class provides methods to get alert"""

    def __init__(self):
        """Initializing alert queries"""
        self.queries = queries["alerts"]
        # self.utils = AlertUtils()

    async def get_daily_alerts(self):
        try:
            query_to_execute = self.queries['daily_alerts']
            app_log.info('geeting daily alrts data')
            data=await get_query_with_pool(query_to_execute, resp_type="dict")
            for items in data:
                items['dataselectionfilters'] = json.loads(items['dataselectionfilters'])
                items['dashboardfilters'] = json.loads(items['dashboardfilters'])
                file_name = await alerts.process_filtered_data(items,frequency = 'Daily')
                app_log.info('sending email for daily alerts')
                email=json.loads(items['reportinvitees'])
                name = items['reportname']
                if file_name:
                    await alerts.send_mail(attachment=file_name , email=email , name = name)
                if os.path.exists(f'{file_name}'):
                    os.remove(f'{file_name}')
            resp = {'mssg':'alert emails sent sucessfully'}
        except Exception as e:
            app_log.exception(e)
            resp = {'error': " Daily alert API failed"}
        return resp
    
    async def get_weekly_alerts(self):
        try:
            query_to_execute = self.queries['weekly_alerts']
            app_log.info('geeting weekly alrts data')
            data=await get_query_with_pool(query_to_execute, resp_type="dict")
            for items in data:
                items['dataselectionfilters'] = json.loads(items['dataselectionfilters'])
                items['dashboardfilters'] = json.loads(items['dashboardfilters'])
                file_name = await alerts.process_filtered_data(items,frequency = 'weekly')
                app_log.info('sending email for weekly alerts')
                email=json.loads(items['reportinvitees'])
                name = items['reportname']
                if file_name:
                    await alerts.send_mail(attachment=file_name , email=email , name = name)
                if os.path.exists(f'{file_name}'):
                    os.remove(f'{file_name}')
            resp = {'mssg':'alert emails sent sucessfully'}
        except Exception as e:
            app_log.exception(e)
            resp = {'error': "weekly alert API failed"}
        return resp
