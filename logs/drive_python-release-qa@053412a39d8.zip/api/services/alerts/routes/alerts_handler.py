"""Handler file for alerts"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends, Request
from api.common.fastapi_app import verify_jwt
from api.common.scheduler import scheduler_cron
from api.services.alerts.routes.alerts_model import Alerts
from api.common.utils import get_user
from api.common.fastapi_app import app
from typing import Optional
from api.services.alerts.routes.alert_validate import Validation
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))


router = APIRouter(prefix="/alerts",dependencies=[Depends(verify_jwt)])
alerts = Alerts()
alert_validation= Validation()
# alerthistory = AlertHistory()
# alertvalidate = AlertValidate()


@router.get("")
async def getalerts(request: Request):
    """On GET returns list of alerts as JSON"""
    response = await alerts.get_alerts(data={"userid": get_user(request)['userid']})
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("")
async def createalerts(request: Request,body : dict):
    """On POST request creates alerts """
    body['username'] = get_user(request)['userid']
    response = await alerts.create_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("")
async def updatealerts(request: Request,body : dict):
    """On PUT updates alerts based on alert id """
    body['username'] = get_user(request)['userid']
    response = await alerts.update_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.delete("")
async def deletealerts(request: Request,body : dict):
    """On DELETE removes alerts """
    body['username'] = get_user(request)['userid']
    response = await alerts.delete_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/details")
async def alertsdetails(request: Request,body : dict):
    """On POST request return alert details based on id as JSON"""
    response = await alerts.get_details(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/notification")
async def updatealerts(request: Request, body: Optional[dict] = None):
    """On PUT updates alerts based on alert id """
    # body['username'] = get_user(request)['userid']
    payload = {"userid": get_user(request)['userid']}
    if body and "seenAt" in body:
        payload["seenAt"] = body["seenAt"]
    response = await alerts.get_notification(data=payload)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

# @scheduler_cron(cron_expression = '* * * * *')
# @router.post("/daily")
# async def createalerts(request: Request):
#     """On POST request creates alerts """
#     # body['username'] = get_user(request)['userid']
#     response = await alert_validation.get_daily_alerts()
#     if isinstance(response, dict) and "error" in list(response.keys()):
#         return JSONResponse(
#             status_code=400,
#             content={"message": response.get("error")},
#         )
#     return JSONResponse(response)

# @scheduler_cron(cron_expression = '*/5 * * * *')
# @router.post("/weekly")
# async def createalerts(request: Request):
#     """On POST request creates alerts """
#     # body['username'] = get_user(request)['userid']
#     response = await alert_validation.get_weekly_alerts()
#     if isinstance(response, dict) and "error" in list(response.keys()):
#         return JSONResponse(
#             status_code=400,
#             content={"message": response.get("error")},
#         )
#     return JSONResponse(response)