"""this model provides methods for CRUD operation on alerts """
import json
import traceback
import pandas as pd
from datetime import datetime, timedelta
from api.common.common import get_header_defect_condition ,env_config
from io import BytesIO
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from api.common.fastapi_app import get_query_with_pool
from api.common.utils import get_logger, queries
from reportlab.lib import colors ,fonts
import copy
import os
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import A4, C5,B5 ,landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, PageBreak, Paragraph
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader



app_log = get_logger("alerts")
watermark = 'api/common/watermark.png'
png_image = 'api/common/Alertscreen.png'


class Alerts:
    """This class provides methods to get alert"""

    def __init__(self):
        """Initializing alert queries"""
        self.queries = queries["alerts"]
        self.utils = AlertUtils()

    async def get_alerts(self,data):
        """Gets the list of alerts for the current user.

        Args:
            data (dict): The data containing the user ID.

        Returns:
            dict: The response containing the list of alerts or an error message.
        """
        try:
            app_log.info("Preparing to get alert list")
            if data.get('userid')!= 'superuser':
                query_to_execute = self.queries['get_alert'].format(**{"username":data.get('userid')})
                resp=await get_query_with_pool(query_to_execute, resp_type="dict")
            else:
                resp = await get_query_with_pool(self.queries['get_superuser_alert'], resp_type="dict")
            response = await self.utils.response_formatter(resp)
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert get API failed"}
        return response

    async def create_alert(self,data):
        """Inserts data to create an alert.

        Args:
            data (dict): The data containing the alert details.

        Returns:
            dict: The response indicating the success or failure of the alert creation.
        """
        try:
            app_log.info("Preparing to save alert")
            query_data = await self.utils.prepare_data(data, op_type="insert")
            query_to_execute = self.queries['create_alert'].format(**query_data)
            await get_query_with_pool(query_to_execute,resp_type="None")
            resp = {"msg": f"Alert created successfully"}
            if data.get('basics')['reportfrequency'] ==  "Immediately" and data.get('basics')['status'] == 'on' :
                file_name = await self.process_filtered_data(data,create = 'create')
                if file_name:
                    await self.send_mail(attachment=file_name , email=data.get('basics')['invitees'],name = data.get('basics')['reportname'])
                    status_query = self.queries['alert_status'].format(**query_data)
                    await get_query_with_pool(status_query,resp_type="None")
                if os.path.exists(f'{file_name}'):
                    os.remove(f'{file_name}')

        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert create API failed"}
        return resp
    
    async def send_mail(self, **kwargs):
        try:
            """
            Sends an email with the specified content, receiver, subject, and optional attachment.

            Args:
                content (str): The content of the email.
                receiver (str): The email address of the receiver.
                subject (str): The subject of the email.
                attachment (str, optional): The file path of the attachment (if any). Defaults to None.

            Returns:
                None
            """
            EMAIL_SIGNATURE = '''<div> Hello <span style='text-transform: capitalize'></span>
                                </div><br /><div>Please find attached the PDF file
                                generated based on alerts created to the Inspection
                                Navigation – Map Summary Table.</div><div><br/>
                                Thanks<br/> DRive Alerts</div> <style type='text/css'>
                                div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva,
                                Verdana, sans-serif;}    table,    tr,    td, th {
                                border-width: 1px;border-color: #ccc;border-style: solid;
                                border-collapse: collapse;      text-align: left;
                                padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma,
                                Geneva, Verdana, sans-serif;      align: left;      align-items: left;}
                                tr:nth-child(even) {background: #efefef}    tr:nth-child(odd)
                                {background: #FFF}  </style>'''

            email_content =  EMAIL_SIGNATURE
            your_smtp_port = env_config.get('smtp_port')
            host = env_config.get('host')
            msg = MIMEMultipart()
            msg["From"] = env_config.get('server_mail')
            msg["To"] = ', '.join(kwargs.get('email'))
            msg["Subject"] = f"Alert : {kwargs.get('name')}"
            if kwargs.get("attachment"):
                attach_file_name = kwargs.get("attachment")
                with open(attach_file_name, "rb") as file:
                    attachment_content = MIMEApplication(file.read())
                    attachment_content.add_header(
                        "Content-Disposition", "attachment", filename=attach_file_name
                    )
                    msg.attach(attachment_content)
            msg.attach(MIMEText(email_content, "html"))
            with smtplib.SMTP(host, your_smtp_port) as server:
                server.send_message(msg)
            app_log.info(f"Mail sent to {kwargs.get('email')}")
        except Exception as e:
            app_log.exception(e)
            raise e

    def get_lastinspectionupdate(self, row):
        count = row['inspectiontimestamp_count'] - 1 if row['inspectiontimestamp_count'] >= 1 else row['inspectiontimestamp_count']
        date = pd.to_datetime(row['inspectiontimestamp_max']).strftime("%d/%m/%y") if row['inspectiontimestamp_max'] != "" else ""
        return f"""{date} ({count} older)""" if count != 0 else f"""{date}"""

    async def process_filtered_data(self,data,create = None,frequency = None):
        try:
            filter_query = await self.make_query(data)
            if create:
                min_timestamp = data.get('dataselectionfilters')['selectedFilters']['daterange']['resulttimestamp']['min']
                max_timestamp = data.get('dataselectionfilters')['selectedFilters']['daterange']['resulttimestamp']['max']
                startdate = datetime.strptime(min_timestamp, "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                enddate = datetime.strptime(max_timestamp, "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                # Format the condition string with the min and max values
                condition = f"and resulttimestamp between '{startdate}' and '{enddate}' "
            else:
                max_timestamp = datetime.now().strftime('%d-%m-%YT%H:%M:%S')
                max_datetime = datetime.strptime(max_timestamp, '%d-%m-%YT%H:%M:%S')
                date_range = data.get('dataselectionfilters')['selectedFilters']['daterange']['dateRange']
                numeric_value, unit = date_range.split()
                if unit == 'week' or unit == 'weeks':
                    time_delta = timedelta(weeks=int(numeric_value))
                elif unit == 'day' or unit == 'days':
                    time_delta = timedelta(days=int(numeric_value))
                elif unit == 'month' or unit == 'months':
                    time_delta = timedelta(days=int(numeric_value) * 30)  # Approximating months as 30 days
                elif unit == 'year' or unit == 'years':
                    time_delta = timedelta(days=int(numeric_value) * 365)  # Approximating years as 365 days
                else:
                    raise ValueError(f"Invalid unit: {unit}")
                new_min_datetime = max_datetime - time_delta
                new_min_timestamp = new_min_datetime.strftime("%Y-%m-%d %H:%M:%S")
                new_max_timestamp = max_datetime.strftime("%Y-%m-%d %H:%M:%S")

                startdate = new_min_timestamp
                enddate = new_max_timestamp
                condition = f"and resulttimestamp between '{startdate}' and '{enddate}' "
            filter_query['header_condition'] += " " + condition
            query_to_execute = self.queries['get_allfilters'].format(**filter_query)
            filter_query['update_row'] = ""
            filter_query['defects_condition'] = ""
            filter_query['fov_margin'] = 1
            execute = self.queries['alert_validation'].format(**filter_query)
            all_row = await get_query_with_pool(execute,resp_type='df')
            if len(all_row) >= 1: all_row["Last Inspection Update"] = all_row.apply(lambda x: self.get_lastinspectionupdate(x), axis=1)
            unique_id_allrows = []
            filter_applied_uid = []
            element_for_pdf = []
            if len(all_row) >0:
                unique_id_allrows = all_row['unique_id'].to_list()
            all_filters = await get_query_with_pool(query_to_execute,resp_type="df")
            if len(all_filters)>0:
                filter_applied_uid = all_filters['unique_id'].to_list()
            without_filter_uid = set(unique_id_allrows) - set(filter_applied_uid)
            if without_filter_uid:
                unfiltered_df = all_row[all_row['unique_id'].isin(without_filter_uid)]
                unfiltered_df = unfiltered_df.assign(**{'Alert Date Range':data['dataselectionfilters']['selectedFilters']['daterange']['dateRange']})
                unfiltered_dict = unfiltered_df.to_dict(orient='records')

                for i in range(len(unfiltered_dict)):
                    dashboard_filters_copy = copy.deepcopy(data['dashboardfilters'])
                    exceeded_thresholds = self.validate_thresholds(unfiltered_dict[i], dashboard_filters_copy)
                    keys_to_remove = ['unique_id', 'inspectiontimestamp_count','inspectiontimestamp_max']

                    unfiltered_dict[i] = {key: value for key, value in unfiltered_dict[i].items() if key not in keys_to_remove}
                    if exceeded_thresholds:
                        element_for_pdf.append(unfiltered_dict[i])

            all_filters = all_filters.to_dict(orient='records')
            for i in range(len(all_filters)):
                q_data = all_filters[i]
                query_data = json.loads(q_data['allfilters'])
                unique_id = q_data['unique_id']
                query_data = get_header_defect_condition(query_data)
                update_row = f"where unique_id = '{unique_id}'"
                query_data["update_row"] = update_row
                query_to_execute = self.queries["alert_validation"].format(**query_data)
                data_output = await get_query_with_pool(query_to_execute, resp_type="df")
                # df = pd.DataFrame.from_dict(data_output)
                if len(data_output) >= 1: data_output["Last Inspection Update"] = data_output.apply(lambda x: self.get_lastinspectionupdate(x), axis=1)
                data_output = data_output.assign(**{'Alert Date Range':data['dataselectionfilters']['selectedFilters']['daterange']['dateRange']})
                data_output = data_output.to_dict(orient = 'records')
                if len(data_output) > 0:
                    element = data_output[0]
                    dashboard_filters_copy = copy.deepcopy(data['dashboardfilters'])
                    exceeded_thresholds = self.validate_thresholds(element, dashboard_filters_copy)
                    keys_to_remove = ['unique_id', 'inspectiontimestamp_count','inspectiontimestamp_max']
                    element = {key: value for key, value in element.items() if key not in keys_to_remove}
                    if exceeded_thresholds:
                        element_for_pdf.append(element)
            app_log.info(f"The rows which exceded the thresold are {element_for_pdf}")
            if len(element_for_pdf):
                info = {}
                if data.get('dashboardfilters')['xyOffset']['required']:
                    info['X Offset [μm]'] = {
                        'warningLevel': data.get('dashboardfilters')['xyOffset']['warningLevel'],
                        'errorLevel': data.get('dashboardfilters')['xyOffset']['errorLevel']
                    }

                    info['Y Offset [μm]'] = {
                        'warningLevel': data.get('dashboardfilters')['xyOffset']['warningLevel'],
                        'errorLevel': data.get('dashboardfilters')['xyOffset']['errorLevel']
                    }

                if data.get('dashboardfilters')['xyDistribution']['required']:
                    info['X Distribution [μm]'] = {
                        'warningLevel': data.get('dashboardfilters')['xyDistribution']['warningLevel'],
                        'errorLevel': data.get('dashboardfilters')['xyDistribution']['errorLevel']
                    }

                    info['Y Distribution [μm]'] = {
                        'warningLevel': data.get('dashboardfilters')['xyDistribution']['warningLevel'],
                        'errorLevel': data.get('dashboardfilters')['xyDistribution']['errorLevel']
                    }

                if data.get('dashboardfilters')['dof']['required']:
                    info['DoF[%]'] = {
                        'warningLevel': data.get('dashboardfilters')['dof']['warningLevel'],
                        'errorLevel': data.get('dashboardfilters')['dof']['errorLevel']
                    }
                if data.get('dashboardfilters')['lastInspectionRecipe']:
                    info['Last Inspection Update'] = True
                if frequency:
                    basics_info = [
                    (data['reportname'],304,355),
                    ('Inspection Navigation Monitoring',314,265),
                    (data['reportfrequency'].replace('"',''),286,210),
                    (data.get('username'),440,328),
                    (datetime.now().strftime( '%d-%m-%y %H-%M-%S'),295,328)
                ]
                else:
                    basics_info = [
                        (data.get('basics')['reportname'],304,355),
                        ('Inspection Navigation Monitoring',314,265),
                        (data.get('basics')['reportfrequency'],286,210),
                        (data.get('username'),440,328),
                        (datetime.now().strftime( '%d-%m-%y %H-%M-%S'),295,328)
                    ]
                app_log.info('starting pdf generation')
                resp = self.generate_pdf_table(element_for_pdf,info,basics_info)
            else:
                resp = None
            app_log.info('pdf sucessfully generated')
        except Exception as e:
            app_log.exception(e)
            raise e
        return resp
    
    def validate_thresholds(self,element, dashboard_filters):
        try:
            app_log.info('validating the thresold')
            thresholds = {}
            dashboard_filters = copy.deepcopy(dashboard_filters)
            dashboard_filters['X Offset [μm]'], dashboard_filters['Y Offset [μm]'] = dashboard_filters['xyOffset'], dashboard_filters['xyOffset']
            dashboard_filters['X Distribution [μm]'], dashboard_filters['Y Distribution [μm]'] = dashboard_filters['xyDistribution'], dashboard_filters['xyDistribution']
            dashboard_filters['DoF[%]'] = dashboard_filters['dof']
            del dashboard_filters['xyOffset']
            del dashboard_filters['xyDistribution']
            del dashboard_filters['dof']
            for field in ['X Offset [μm]', 'Y Offset [μm]', 'X Distribution [μm]', 'Y Distribution [μm]', 'DoF[%]']:
                if dashboard_filters[field]['required']:
                    thresholds[field] = {
                        'warning': (dashboard_filters[field]['warningLevel']),
                        'error': (dashboard_filters[field]['errorLevel'])
                    }
                else:
                    thresholds[field] = None

            exceeded_thresholds = []
            if element['inspectiontimestamp_count'] > 1 and dashboard_filters['lastInspectionRecipe'] == True :
                exceeded_thresholds.append(('lastInspectionRecipe', 'warning'))
            for field, levels in thresholds.items():
                value = element[field]
                if levels is not None:
                    if field in ['X Offset [μm]', 'Y Offset [μm]']:
                        value = abs(float(value))
                    if levels['error'] is not None and levels['error'] != '' and value!= 'NA' and  value > float(levels['error']) :
                        exceeded_thresholds.append((field,value, 'error'))
                    elif levels['warning'] is not None and levels['warning'] != '' and value!= 'NA' and value > float(levels['warning']):
                        exceeded_thresholds.append((field,value,'warning'))
        except Exception as e:
            app_log.info(e)
            raise e
        return exceeded_thresholds


    def generate_pdf_table(self, elements, info, basic_info):
        # Create a new PDF document with landscape A4 page size
        try:
            page_width, page_height = landscape(B5)
            file_name = f"DRive_Alert_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.pdf"
            pdf = canvas.Canvas(file_name, pagesize=(page_width, page_height))
            image = ImageReader(png_image)
            image_width = image.getSize()[0]
            image_height = image.getSize()[1]
            pdf.drawImage(image, 0, 0, width=page_width, height=page_height)

            for text, x, y in basic_info:
                if text == basic_info[0][0]:
                    pdf.setFont('Helvetica-Bold', 10)
                    pdf.setFillColor(colors.white)
                    pdf.drawString(x, y, text)
                elif text == basic_info[3][0] or text == basic_info[4][0]:
                    pdf.setFont('Helvetica', 8)
                    pdf.setFillColor(colors.white)
                    pdf.drawString(x, y, text)
                else:
                    pdf.setFont('Helvetica', 8)
                    pdf.setFillColor(colors.black)
                    pdf.drawString(x, y, text)

            pdf.setFillColor(colors.black)
            self.add_watermark_and_page_number(pdf, watermark, 1, len(elements) + 1)
            pdf.showPage()
            for i, item in enumerate(elements):
                info_table_data = [['Label', 'Current Value', 'Error Threshold', 'Warning Threshold']]
                for field, value in info.items():
                    field_value = ''
                    if field in item:
                        field_value = item[field]
                    if isinstance(value, dict):
                        warning_level = value.get('warningLevel', '')
                        error_level = value.get('errorLevel', '')
                    else:
                        warning_level = ''
                        error_level = ''
                    info_table_data.append([field, field_value, error_level, warning_level])

                info_table = Table(info_table_data, colWidths=[104, 79, 75.5, 92])
                info_table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.white),
                                                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                                                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                                ('FONTSIZE', (0, 0), (-1, 0), 9.6),
                                                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                                                ('MAXWIDTH', (0, 0), (-1, -1), 1.2*inch),
                                                ('GRID', (0, 0), (-1, -1), 1, colors.black)]))

                for row in range(1, len(info_table_data)):
                    value = abs(info_table_data[row][1]) if info_table_data[row][0] =="Y Offset [μm]" or info_table_data[row][0] =="X Offset [μm]" else info_table_data[row][1]
                    error_level = info_table_data[row][2]
                    warning_level = info_table_data[row][3]
                    last_inspection_update = info_table_data[row][1]
                    if value and error_level and float(value) > float(error_level):
                        info_table.setStyle(TableStyle([('BACKGROUND', (0, row), (-1, row), colors.Color(1, 0.5, 0.6)),
                                                        ('TEXTCOLOR', (0, row), (-1, row), colors.black)]))
                    elif value and warning_level and float(value) > float(warning_level):
                        info_table.setStyle(TableStyle([('BACKGROUND', (0, row), (-1, row), colors.Color(1, 0.75, 0.5)),
                                                        ('TEXTCOLOR', (0, row), (-1, row), colors.black)]))
                    if info_table_data[row][0] == 'Last Inspection Update':
                        if 'older' in last_inspection_update:
                            info_table.setStyle(TableStyle([('BACKGROUND', (0, row), (-1, row), colors.Color(1, 0.5, 0.6)),
                                        ('TEXTCOLOR', (0, row), (-1, row), colors.black)]))
                main_table_data = [['Label', 'Value']]
                for key, value in item.items():
                    if not any(info_row[0] == key for info_row in info_table_data[1:]):
                        main_table_data.append([key, value])

                main_table = Table(main_table_data)
                main_table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.white),
                                                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                                                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                                ('FONTSIZE', (0, 0), (-1, 0), 9.6),
                                                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                                                ('GRID', (0, 0), (-1, -1), 1, colors.black)]))

                if i != 0:
                    pdf.showPage()
                info_table_width, info_table_height = info_table.wrap(2, 0)
                main_table_width, main_table_height = main_table.wrap(2, 0)
                main_table.drawOn(pdf, page_width/13, 140)  # Draw main table at the specified position
                # info_table._colWidths=[103.16, 50.92, 75.36, 74.02]
                info_table.drawOn(pdf, 350, 200)  # Draw info table at the specified position
                pdf.setFont('Helvetica', 10)
                pdf.setFillColor(colors.black)
                pdf.setFont("Helvetica-Bold", 12)
                pdf.drawString(0.5 * inch, 6.2 * inch, f"Note : Rows which exceeded the defined threshold value")
                # Add a page number and watermark
                self.add_watermark_and_page_number(pdf, watermark, i + 2, len(elements) + 1)

            pdf.save()
        except Exception as e:
            app_log.info(e)
            raise e


        # Return the file name and the PDF document
        return file_name

    def add_watermark_and_page_number(self,pdf, watermark, current_page, total_pages):
        # Add the watermark image
        try:
            pdf.drawImage(watermark, 1, 6, width=180, height=35)

            # Add the "APPLIED MATERIALS CONFIDENTIAL" text
            pdf.setFont("Helvetica", 8)
            pdf.drawRightString(685, 18, "APPLIED MATERIALS CONFIDENTIAL")

            # Add the page number
            pdf.setFont("Helvetica", 8)
            pdf.drawCentredString(330, 18, f"Page {current_page}/{total_pages}")
        except Exception as e:
            app_log.info(e)
            raise e
    
    async def make_query(self,data):
        """This function is used to create queries"""
        # cols = ['product','layer','inspectiontool','resulttimestamp']
        query_data = {}
        query_condition = []
        for i in data['dataselectionfilters']['selectedFilters'].keys():
            # if  i == "resulttimestamp":
            #     startdate = data['dataselectionfilters']['selectedFilters'].get('resulttimestamp').get('min')
            #     enddate = data['dataselectionfilters']['selectedFilters'].get('resulttimestamp').get('max')
            #     startdate = datetime.strptime(startdate, "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
            #     enddate = datetime.strptime(enddate, "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
            #     query_condition.append(f"{i} BETWEEN ('{startdate}') and ('{enddate}')")
            if len((data['dataselectionfilters']['selectedFilters'].get(i,[]))) >0 and i!='daterange':
                query_condition.append( f"{i} in {tuple(data['dataselectionfilters']['selectedFilters'].get(i,[]))}")
        query_data['header_condition'] = f"and {' and '.join(query_condition)}"
        for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("inspectiontool", "inspectionstationmodel")]:
             query_data['header_condition'] = query_data['header_condition'].replace(f"{old_key} in", f"{new_key} in")
        # query_data['header_cdtn'] = f"and {' and '.join(query_condition)}".replace('layer','stepid').replace(
        #     'inspectiontool','inspectionstationmodel').replace('product','deviceid')
        return query_data
    
    async def update_alert(self,data):
        """Updates an existing alert.

        Args:
            data (dict): The data containing the updated alert details.

        Returns:
            dict: The response indicating the success or failure of the alert update.
        """
        try:
            app_log.info("Preparing to update alert")
            if data.get("reportstatus"):
                query_data = {
                    "id" : data.get('id'),
                    "reportstatus" : f'"{data.get("reportstatus")}"',
                    "reportname" : f'{data.get("reportname")}',
                    "username" : f'{data.get("username")}'
                }
                query_to_execute = self.queries['update_alertstatus'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                resp = await self.get_alerts({"userid": data.get("username")})
                query = self.queries['Immediate_alertstatus'].format(**query_data)
                alert_data = await get_query_with_pool(query,resp_type="df")
                alert_data_dict = alert_data.to_dict(orient='records')
                new_data = {
                'basics': {
                    'reportname': alert_data_dict[0]['reportname'],
                    'status': alert_data_dict[0]['reportstatus'].strip('"'),
                    'invitees': eval(alert_data_dict[0]['reportinvitees']),
                    'type': 'Inspection Monitoring',
                    'reportfrequency': alert_data_dict[0]['reportfrequency'].strip('"')
                },
                'dataselectionfilters':json.loads(alert_data_dict[0]['dataselectionfilters']),
                'dashboardfilters':json.loads(alert_data_dict[0]['dashboardfilters']),
                'username':data['username']     
                    }
                if new_data.get('basics')['reportfrequency'] ==  "Immediately" and new_data.get('basics')['status'] == 'on':
                    file_name = await self.process_filtered_data(new_data)
                    if file_name:
                        await self.send_mail(attachment=file_name , email=new_data.get('basics')['invitees'] ,name = new_data.get('basics')['reportname'] )
                        status_query = self.queries['alert_status'].format(**query_data)
                        await get_query_with_pool(status_query,resp_type="None")
                    if os.path.exists(f'{file_name}'):
                        os.remove(f'{file_name}')
            else:
                query_data = await self.utils.prepare_data(data, op_type="update")
                query_to_execute = self.queries['update_alert'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                resp = {"msg": "Alert updated successfully"}
                if data.get('basics')['reportfrequency'] ==  "Immediately" and data.get('basics')['status'] == 'on':
                    file_name = await self.process_filtered_data(data)
                    if file_name:
                        await self.send_mail(attachment=file_name , email=data.get('basics')['invitees'] ,name = data.get('basics')['reportname'] )
                        status_query = self.queries['alert_status'].format(**query_data)
                        await get_query_with_pool(status_query,resp_type="None")
                    if os.path.exists(f'{file_name}'):
                        os.remove(f'{file_name}')


        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert update API failed"}
        return resp

    async def delete_alert(self,data):
        """Deletes an alert based on the alert ID.

        Args:
            data (dict): The data containing the alert ID.

        Returns:
            dict: The response indicating the success or failure of the alert deletion.
        """
        try:
            app_log.info("Preparing to delete alert")
            query_to_execute = self.queries['delete_alert'].format(**{"id":data.get('id')})
            await get_query_with_pool(query_to_execute,resp_type="None")
            if data.get('username') == 'superuser':
                query_data = {
                    "id" : data.get('id')
                }
                query_to_execute = self.queries['get_alert_creator'].format(**query_data)
                created_by = await get_query_with_pool(query_to_execute,resp_type='dict')
                app_log.info(f"The alert was created by {created_by[0]['username']}")
                for items in created_by:
                    if items['username'] != 'superuser':
                        query_data = {
                        "id" : items['id'],
                        "username" : f"{items['username']}",
                        "short_desc": f"The alert {items['reportname']} has been deleted by {data.get('username')}",
                        "updated_by" : data.get('username'),
                        "cdt" : datetime.now()
                    }
                        app_log.info(f"{self.queries['Create_notification'].format(**query_data)}")
                        await get_query_with_pool(self.queries['Create_notification'].format(**query_data))
            resp = {"msg": "Alert deleted successfully"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert delete API failed"}
        return resp
    

    async def get_notification(self,data):
        """Provides the list of notifications"""
        try:
            app_log.info("Preparing to get alert notification")
            query_to_execute = self.queries['get_notification'].format(**{"username":data.get('userid')})
            resp=await get_query_with_pool(query_to_execute , resp_type="dict")
            if data.get('seenAt'):
                seenAt = datetime.strptime(
                data.get('seenAt'), "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                query_data = {"username":data.get('userid'),"seenAt":seenAt}
                # query_to_execute = self.queries['get_notification'].format(**query_data)
                # resp = await get_query_with_pool(query_to_execute , resp_type="dict")
                query_to_execute = self.queries['Update_notification'].format(**query_data)
                await get_query_with_pool(query_to_execute)
                query_to_execute = self.queries['get_notification'].format(**{"username":data.get('userid')})
                resp=await get_query_with_pool(query_to_execute , resp_type="dict")
        except Exception as e:
            app_log.exception(e)
            resp = {'error': "Alert notification API failed"}
        return resp

    async def get_details(self,data):
        """Provides details of an alert based on the alert ID.

        Args:
            data (dict): The data containing the alert ID.

        Returns:
            dict: The response containing the alert details or an error message.
        """
        try:
            app_log.info("Preparing to get alert details")
            query_to_execute = self.queries['get_alertdetails'].format(**{"id":data.get('id')})
            resp=await get_query_with_pool(query_to_execute , resp_type="dict")
            response = await self.utils.response_formatter(resp)
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert details API failed"}
        return response

class AlertUtils():
    """This class provides utility methods for CRUD operations on auto alerts"""

    async def prepare_data(self, data, op_type):
        """Formats the input data to insert into the database.

        Args:
            data (dict): The data containing the alert details.
            op_type (str): The operation type, either "insert" or "update".

        Returns:
            dict: The formatted data dictionary.
        """
        try:
            datetime_format = '%Y-%m-%d %H:%M:%S'
            dataselectionfilters = data.get('dataselectionfilters', '')
            dataselectionfilters.update({"type":data.get('basics').get("type")})
            if op_type == "insert":
                reportdayselected = data.get('basics').get('reportSchedule').get('when')
                data_dict = {
                    "reportname": f"""{data.get("basics").get('reportname')}""",
                    "username":data.get('username'),
                    "dashboardConnectedCount": len(data.get('dashboardfilters')) \
                        if data.get('dashboardfilters') else '' ,
                    "reportcreateddate":
                        pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency":
                    f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency', ''))}",
                    "reportstatus": f"{json.dumps(data.get('basics').get('status', ''))}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                    "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                    "rfg" : 1
                }

            elif op_type == "update":
                reportdayselected = data.get('basics').get('reportSchedule').get('when')
                data_dict = {
                    "id": data.get("id"),
                    "reportname": f"""{data.get("basics").get('reportname')}""",
                    "username":data.get('username'),
                    "dashboardConnectedCount": len(data.get('dashboardfilters')) \
                        if data.get('dashboardfilters') else '' ,
                    "reportcreateddate":
                        pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency":
                    f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency', ''))}",
                    "reportstatus": f"{json.dumps(data.get('basics').get('status', ''))}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                    "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                    "rfg" : data.get('rfg') if data.get('rfg',[]) else "rfg"
                }
        except Exception as err:
            app_log.error(f"{traceback.format_exc()}")
            app_log.error(f"Error while preparing data {err}")
            data_dict = {"error": f"Error while preparing data {err}"}

        return data_dict

    async def response_formatter(self,data):
        resp_list=[]
        for d, val in enumerate(data):
            resp = {}
            for i,k in data[d].items():
                try:
                    resp.update({i:json.loads(k)})
                except (Exception, TypeError):
                    resp.update({i:k})
            resp_list.append(resp)
        return resp_list
