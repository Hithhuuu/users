"""Schema for payload of mapsummary table"""
from typing import Union,Optional
from pydantic import BaseModel
class mapsummarytable(BaseModel):
    """ Payload detail for mapsummary table"""
    filter: dict[str,dict]
    inputs: Union[dict,None] = {}
    sort: Union[dict, None] = None
    limit: Union[int, None] = None
    order: Union[list,None] = None
    table_type : Union[str,None] = None
    offset:Union[int, None] = None
