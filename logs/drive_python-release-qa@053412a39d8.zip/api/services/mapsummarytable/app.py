"""File for Fast api"""
from api.common.fastapi_app import app
from api.services.mapsummarytable.routes import map_summary_table_handler
app.include_router(map_summary_table_handler.router)
