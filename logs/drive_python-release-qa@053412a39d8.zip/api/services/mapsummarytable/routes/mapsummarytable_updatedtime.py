"""File to update time in MST"""
import traceback
from api.common.utils import (
    get_queries2,
    get_logger
)
from api.common.fastapi_app import get_query_with_pool

app_log = get_logger("updatedtime")


class updatedtime:
    """Class for Live Update in MST"""
    def __init__(self):

        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2('map_summary_table')

    async def get(self):
        try:
            #cursor = self.connection.cursor()
            query_to_execute = self.queries["read_updated_time"]
            app_log.info(f"read Query: {query_to_execute}")
            #cursor.execute(query_to_execute)
            data_output=await get_query_with_pool(query_to_execute,resp_type="list")

            app_log.info("Preparing response for map summary table")
            if len(data_output) > 0:
                resp = {"updated": "true"}
            else:
                resp = {"updated": "false"}
        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error in getting latest time {e}")

        return resp
