"""Handler file for MST"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter,Depends, Request
from fastapi.encoders import jsonable_encoder
from api.common.fastapi_app import verify_jwt
from api.services.mapsummarytable.routes.map_summary_table_model import (
    map_summary_table,map_summary_combinedtable
)
from api.services.mapsummarytable.routes.mapsummarytable_updatedtime import (
    updatedtime,
)
from api.common.utils import get_logger
from api.services.mapsummarytable.schema import mapsummarytable
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

app_log = get_logger("map_summary_table")
router = APIRouter(dependencies=[Depends(verify_jwt)])

@router.post("/mapsummarytable")
async def post(request: Request, body:mapsummarytable ):
    """Post method for MST"""
    value = map_summary_table()
    authorization_header = request.headers.get("Authorization")
    body=jsonable_encoder(body)
    body['authorization_header']=authorization_header
    resp = await value.get_map_summary_values(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.get("/mapsummarytable/updatedtime")
async def get():
    """Get method for live update"""
    time = updatedtime()
    resp = await time.get()
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)

@router.post("/mapsummarytable/combineddata")
async def posts(request: Request, body:mapsummarytable ):
    """Post method for MST"""
    value = map_summary_combinedtable()
    authorization_header = request.headers.get("Authorization")
    body=jsonable_encoder(body)
    body['authorization_header']=authorization_header
    resp = await value.get_map_summary_combinedvalues(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)