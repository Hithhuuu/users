"""Model file for MST"""
import traceback
import json
import itertools
from datetime import datetime
import pandas as pd
from api.common.utils import get_queries2,get_logger
from api.common.common import get_header_defect_condition
from api.common.fastapi_app import get_query_with_pool
from api.common.auth import extract_user_id

app_log = get_logger("mapsummarytable")


class map_summary_table:
    """class for MST"""
    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2('map_summary_table')

    async def table_order(self,userid):            
        try:
            # userid = await extract_user_id(data.get("authorization_header"))
            query_d = {}
            query_d ['userid'] = userid
            # query_d ['table_type'] = data.get("table_type")
            query_to_execute = self.queries["get_order"].format(**query_d)
            app_log.info("getting the column order")
            dt_order = await get_query_with_pool(query_to_execute, resp_type="dict")
            if len(dt_order)<1:
                query_to_execute = self.queries["get_default"].format(**query_d)
                default_order= await get_query_with_pool(query_to_execute, resp_type="dict")
                order= json.loads(default_order[0]['ordermst'] )
            else:
                order = json.loads(dt_order[0]['ordermst'])

            return order
    
        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}

    def get_lastinspectionupdate(self, row):
        count = row['inspectiontimestamp_count'] - 1 if row['inspectiontimestamp_count'] >= 1 else row['inspectiontimestamp_count']
        date = pd.to_datetime(row['inspectiontimestamp_max']).strftime("%d/%m/%y") if row['inspectiontimestamp_max'] != "" else ""
        return f"""{date} ({count} older)""" if count != 0 else f"""{date}"""

    async def check_filter(self,save_query_data):
        try:
            query_to_execute = self.queries["check_filter"].format(
                **{"unique_id": int(save_query_data["unique_id"])}
            )
            app_log.info(f"CHECK IF FILTER EXISTS QUERY: {query_to_execute}")

            filter_exist=await get_query_with_pool(query_to_execute)
            if len(filter_exist) != 0:
                query_to_execute = self.queries["remove_exist_filter"].format(
                    **{"unique_id": int(save_query_data["unique_id"])}
                )
                app_log.info(f"Removing existing value QUERY: {query_to_execute}")
                await get_query_with_pool(query_to_execute)
        except Exception as e:
            app_log.exception(e)


    async def get_map_summary_values(self, data):
        """Function to get MST values"""
        try:
            resp = dict()
            userid = await extract_user_id(data.get("authorization_header"))
            data.pop("authorization_header")
            app_log.info("Preparing response for map summary table")
            app_log.info(f"filter values paylaod {data}")
            update_row = ""
            if (
                len(
                    data.get("filter").get("secondary_filter").get("wafer_level_filter")
                )
                == 0
                and len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("defect_level_filter")
                )
                == 0
                and len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("dynamic_filter")
                )
                == 0
                and data.get("inputs",{}).get("unique_id")
                and float(data.get("filter").get("secondary_filter").get("fov_margin", 0)) == 1.0
                # or data.get("filter").get("secondary_filter").get("fov_margin", 0) == 1
            ):
                save_query_data = {}
                save_query_data["unique_id"] = data.get("inputs").get("unique_id")
                await self.check_filter(save_query_data)
                update_row = (
                    f"where unique_id = '{data.get('inputs').get('unique_id')}'"
                )

            elif (
                len(
                    data.get("filter").get("secondary_filter").get("wafer_level_filter")
                )
                != 0
                or len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("defect_level_filter")
                )
                != 0
                or len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("dynamic_filter")
                )
                != 0
                # or data.get("filter").get("secondary_filter").get("fov_margin", 1) != 1
                or data.get("inputs",{}).get("unique_id")
            ):
                save_query_data = {}
                save_query_data["unique_id"] = data.get("inputs").get("unique_id")
                await self.check_filter(save_query_data)
                filters = data.copy()
                filters.pop("inputs")
                filter_data = json.dumps(filters)
                save_query_data["allfilters"] = filter_data
                query_to_execute = self.queries["save_filter"].format(**save_query_data)
                #cursor.execute(query_to_execute)
                await get_query_with_pool(query_to_execute)
                update_row = (
                    f"where unique_id = '{data.get('inputs').get('unique_id')}'"
                )
            query_data = get_header_defect_condition(data)
            if "fov_margin" not in query_data:
                query_data["fov_margin"] = 1

            query_data["limit"] = (
                f'Limit {data.get("offset")},{data.get("limit")}'
                if data.get("limit", 0)
                else ""
            )
            query_data["update_row"] = update_row
            column_sort_query = ""
            if data.get("sort"):
                columns_sort_query = [
                    f"{key} {value} "
                    for key, value in data["sort"].items()
                    if data["sort"][key]
                ]
                column_sort_query = " , ".join(columns_sort_query)
                column_sort_query = column_sort_query.replace("lastinspectionupdate", "inspectiontimestamp_max")
            query_data["sort_order"] = (
                f"ORDER by {column_sort_query} , unique_id ASC" if column_sort_query else "ORDER by product ASC  , layer ASC  , inspectiontool ASC , unique_id ASC"
            )

            query_to_execute = self.queries["get_map_summary_table_values"].format(
                **query_data
            )
            app_log.info(query_to_execute)
            
            data_output=await get_query_with_pool(query_to_execute,resp_type="dict")
            df = pd.DataFrame.from_dict(data_output)

            if not update_row:
                if len(data_output) < 1:
                    resp["data"] = []
                    query_to_execute = self.queries["last_fileupload_time"]
                    file_time=await get_query_with_pool(query_to_execute,resp_type="list")
                    resp["updatedon"] = file_time[0][0]
                    resp["limit"] = data.get("limit")
                    resp["order"] = await self.table_order(userid)
                    resp["offset"] = data.get("offset")
                    resp["total"] = len(data_output)

                    return resp

                query_to_execute = self.queries["present_filter"].format(
                **{"unique_id": df["unique_id"].to_list()}
                )
                app_log.info(query_to_execute)

                data_df=await get_query_with_pool(query_to_execute,resp_type="df")
                df.insert(loc = 1, column = "isFilterAvailable", value = "no")
                df.loc[df["unique_id"].isin(data_df["unique_id"]),"isFilterAvailable"] = "yes"
                alert = {}
                alert['userid'] = userid
                query = self.queries["check_alert"].format(**alert)
                df_alert=await get_query_with_pool(query,resp_type= 'df')
                df.insert(loc = 1, column = "isAlertAvailable", value = "no")
                df.loc[df["unique_id"].isin(df_alert["unique_id"]),"isAlertAvailable"] = "yes"
            else:
                if len(data_output) < 1:
                    query_data ={}
                    query_data["layer"] = data.get("filter").get("primary_filter").get("layer")[0]
                    query_data["product"] = data.get("filter").get("primary_filter").get("product")[0]
                    query_data["inspectiontool"] = data.get("filter").get("primary_filter").get("inspectiontool")[0]
                    query_data["doassistenabled"] = data.get("filter").get("primary_filter").get("doassistenabled")[0]
                    query = self.queries["get_diepitch"].format(**query_data)
                    default_data = await get_query_with_pool(query,resp_type="dict")
                    default = {
                    "layer": default_data[0]['stepid'],
                    "product": default_data[0]['deviceid'],
                    "inspectiontool": default_data[0]['inspectionstationmodel'],
                    "doassistenabled": default_data[0]['doassistenabled'],
                    "xoffset": "NA",
                    "yoffset": "NA",
                    "xdistribution": "NA",
                    "ydistribution": "NA",
                    "xdiepitch":default_data[0]['xdiepitch'],
                    "ydiepitch":default_data[0]['ydiepitch'],
                    "noofwafer": 0,
                    "noofdefectdo": 0,
                    "noofdefectado":0,
                    "resulttimestamp":"NA",
                    "noofdoi": 0,
                    "unique_id": data.get('inputs').get('unique_id'),
                    "dof": "NA",
                    "lastinspectionupdate": "NA"
                    }
                    df = pd.DataFrame([default])
            if len(data_output) >= 1: df["lastinspectionupdate"] = df.apply(lambda x: self.get_lastinspectionupdate(x), axis=1)
            final_data = df.round(3).to_dict(orient="records")
            # alert = {}
            # alert['userid'] = userid
            # query = self.queries["check_alert"].format(**alert)
            # alert_unique_id=await get_query_with_pool(query,resp_type= 'df')
            # if final_data[0]['unique_id'] in alert_unique_id['unique_id'].tolist():
            #     unique_id = {}
            #     unique_id['unique_id'] = final_data[0]['unique_id']
            #     query = self.queries["get_filters_for_alert"].format(**unique_id)
            #     alert_filters=await get_query_with_pool(query,resp_type= 'dict')
            #     query_unupdated = self.queries["get_unupdated_filters"].format(**unique_id)
            #     unupdated_filters = await get_query_with_pool(query_unupdated,resp_type= 'dict')
            #     unupdated_filters = json.loads(unupdated_filters[0]['dataselectionfilters'])
            #     alert_data = {}
            #     alert_data['selectedRows'] = final_data[0]
            #     alert_data['filters'] = json.loads(alert_filters[0]['filters'])
            #     dataselectionfilters = json.dumps(alert_data)
            #     alert_data ['dataselectionfilters'] = f''' '{dataselectionfilters}' as dataselectionfilters1'''
            #     alert_data['unique_id'] = final_data[0]['unique_id']
            #     query_to_execute = self.queries["data_updation_in_alert"].format(**alert_data)
            #     await get_query_with_pool(query_to_execute)
            resp["data"] = final_data
            if not update_row:
                app_log.info("Getting the total row count")
                query_to_execute = self.queries["total_data"].format(**query_data)
                result=await get_query_with_pool(query_to_execute,resp_type="dict")
                query_to_execute = self.queries["last_fileupload_time"]

                file_time=await get_query_with_pool(query_to_execute,resp_type='list')
                resp["updatedon"] = file_time[0][0]
                resp["limit"] = data.get("limit")
                resp["order"] = await self.table_order(userid)
                resp["offset"] = data.get("offset")
                resp["total"] = len(result)

        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error while preparing data {e}")

        return resp
    
class map_summary_combinedtable:
    """class for MST"""
    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2('map_summary_table')

    async def table_order(self,data):            
        try:
            userid = await extract_user_id(data.get("authorization_header"))
            query_d = {}
            query_d ['userid'] = userid
            query_to_execute = self.queries["get_order"].format(**query_d)
            app_log.info("geeting table order")
            dt_order = await get_query_with_pool(query_to_execute, resp_type="dict")
            if len(dt_order) < 1:
                query_to_execute = self.queries["get_default"].format(**query_d)
                default_order= await get_query_with_pool(query_to_execute, resp_type="dict")
                order= json.loads(default_order[0]['ordermst'] )
            else:
                order = json.loads(dt_order[0]['ordermst'])

            return order
    
        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}

    def get_lastinspectionupdate(self, row):
        count = row['inspectiontimestamp_count'] - 1 if row['inspectiontimestamp_count'] >= 1 else row['inspectiontimestamp_count']
        date = pd.to_datetime(row['inspectiontimestamp_max']).strftime("%d/%m/%y") if row['inspectiontimestamp_max'] != "" else ""
        return f"""{date} ({count} older)""" if count != 0 else f"""{date}"""

    async def get_map_summary_combinedvalues(self, data):
        """Function to get MST values"""
        try:
            #cursor = self.connection.cursor()
            resp = dict()
            app_log.info("Preparing response for map summary table")
            app_log.info(f"filter values paylaod {data}")         
            query_data = get_header_defect_condition(data)
            query_data["fov_margin"] = (
                data.get("filter").get("secondary_filter").get("fov_margin", 1)
            )

            query_to_execute = self.queries["get_map_summary_combinedtable_values"].format(
                **query_data
            )
            app_log.info(query_to_execute)

            data_output=await get_query_with_pool(query_to_execute,resp_type="dict")
            df = pd.DataFrame.from_dict(data_output)
                
            if len(data_output[0]["layer"]) < 1:
                default = {
                "layer": ", ".join(data.get("filter").get("primary_filter").get("layer")),
                "product": ", ".join(data.get("filter").get("primary_filter").get("product")),
                "inspectiontool": ", ".join(data.get("filter").get("primary_filter").get("inspectiontool")),
                "doassistenabled": ", ".join(set(data.get("filter").get("primary_filter").get("doassistenabled"))),
                "xoffset": "NA",
                "yoffset": "NA",
                "xdistribution": "NA",
                "ydistribution": "NA",
                "noofwafer": 0,
                "noofdefectdo": 0,
                "noofdefectado":0,
                "resulttimestamp":"NA",
                "noofdoi": 0,
                "unique_id": data.get('inputs').get('unique_id'),
                "dof": "NA",
                "lastinspectionupdate ": "NA"
                }
                df = pd.DataFrame([default])
            else:
                data_output[0]['inspectiontool'] = ", ".join(sorted(data_output[0]['inspectiontool']))
                data_output[0]['product'] = ", ".join(data_output[0]['product']) 
                data_output[0]['layer'] = ", ".join(data_output[0]['layer'])
                data_output[0]['doassistenabled'] = ", ".join(data_output[0]['doassistenabled'])
                df = pd.DataFrame.from_dict(data_output)
                df["lastinspectionupdate"] = df.apply(lambda x: self.get_lastinspectionupdate(x), axis=1)
            final_data = df.round(3).to_dict(orient="records")

            resp["order"] = await self.table_order(data)
            resp["data"] = final_data

        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error while preparing data {e}")

        return resp
