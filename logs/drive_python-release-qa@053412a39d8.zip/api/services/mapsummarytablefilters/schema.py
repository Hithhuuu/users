"""Schema for payload of mapsummary filters"""
from datetime import datetime
from pydantic import BaseModel,validator
class mapsummaryfilters(BaseModel):
    """payload detail for mapsummarytable filters"""
    resulttimestamp:dict[str,str]
    @validator('resulttimestamp')
    def convert(cls,value):
        """Function for converting datetimr to appropiate format"""
        xyz={}
        for key in value:
            xyz[key]=datetime.strptime(value[key],'%d-%m-%YT%H:%M:%S')
            xyz[key]=datetime.strftime(xyz[key] ,'%d-%m-%YT%H:%M:%S')
        return xyz
    product:list[str]
    layer:list[str]
    inspectiontool:list[str]
    doassistenabled: str
    unique_id:int


class adddynamicfilters(BaseModel):
    """payload detail for adding dynamic filters"""
    column_name: str
    label :str
    type : str

class deletedyanamicfilters(BaseModel):
    """payload detail for deleting filters"""
    column_name: str
    label :str
    type : str
