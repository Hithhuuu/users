"""Module for tracing back error"""
import traceback
from datetime import datetime
import json
import pandas as pd
from api.common.utils import  get_queries2, get_logger, get_columns_info
from api.common.fastapi_app import get_query_with_pool


app_log = get_logger("mapsummarytablefilters")


class Mapsummarytablefilters:
    """Used for getting defect data based on global filters"""

    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2("mapsummarytablefilters")
        self.columns = get_columns_info()

    async def get(self, data):
        """Getting data based on filters"""
        try:
            app_log.info("Preparing data for Map Summary Table")
            app_log.info(f"Map Summary Payload {data}")
            query_data = {}
            unique_id = data.get("unique_id", 0)
            
            app_log.info("Getting the applied filters if any")
            query_to_execute = self.queries["read_filter_value"].format(
                **{"unique_id": unique_id}
            )
            
            filter_val = await get_query_with_pool(query_to_execute,resp_type="list")
            applied_filters = {}
            if not data.get("reset"):
                if filter_val:
                    applied_filters = json.loads(filter_val[0][0])

            app_log.info("Getting the defects based on keys")
            query_data = await self.make_query(data)
            query_to_execute = self.queries["read_defects"].format(**query_data)
            app_log.info(query_to_execute)
            data_df = await get_query_with_pool(query_to_execute,resp_type="df")
            data_df = data_df.round(3)
            app_log.info(self.queries["read_dynamic_filter"])
            dynamic_data = await get_query_with_pool(self.queries["read_dynamic_filter"],resp_type="dict")
            wafer_level = self.columns["wafer_level_filter"]
            defect_level = self.columns["defect_level_filter"]
            
            defect_filter_value = {
                "aspectratio": {
                    "min": str(
                        0
                        if pd.isna(data_df["aspectratio"].min())
                        else data_df["aspectratio"].min()
                    ),
                    "max": str(
                        0
                        if pd.isna(data_df["aspectratio"].max())
                        else data_df["aspectratio"].max()
                    ),
                },
                "semdsize": {
                    "min": str(
                        0 if pd.isna(data_df["semdsize"].min()) else data_df["semdsize"].min()
                    ),
                    "max": str(
                        0 if pd.isna(data_df["semdsize"].max()) else data_df["semdsize"].max()
                    ),
                },
                "adrhighscore": {
                    "min": str(
                        0
                        if pd.isna(data_df["adrhighscore"].min())
                        else data_df["adrhighscore"].min()
                    ),
                    "max": str(
                        0
                        if pd.isna(data_df["adrhighscore"].max())
                        else data_df["adrhighscore"].max()
                    ),
                },
            }
            wafer_filter_value = {}

            data_output = {
                "wafer_level_filters": {},
                "defect_level_filters": {},
                "dynamic_filters": {},
                "fov_margin": ""
            }

            data_output["fov_margin"] = applied_filters.get("filter", {}).get("secondary_filter", {}).get("fov_margin", "1")

            for wafer_filter in wafer_level:
                if (
                    applied_filters.get("filter", {})
                    .get("secondary_filter", {})
                    .get("wafer_level_filter", {})
                    .get(wafer_filter["value"], {})
                    .get("selected")
                ):
                    data_output["wafer_level_filters"][f"{wafer_filter['value']}"] = {
                        "values": wafer_filter_value.get(
                            f"{wafer_filter['value']}",
                            sorted(data_df[f"{wafer_filter['value']}"].unique().tolist(), reverse=True),
                        ),
                        "type": wafer_filter["type"],
                        "label": wafer_filter["label"],
                        "selected": applied_filters["filter"]["secondary_filter"][
                            "wafer_level_filter"
                        ][wafer_filter["value"]].get("selected"),
                    }
                else:
                    data_output["wafer_level_filters"][f"{wafer_filter['value']}"] = {
                        "values": wafer_filter_value.get(
                            f"{wafer_filter['value']}",
                            sorted(data_df[f"{wafer_filter['value']}"].unique().tolist(), reverse=True),
                        ),
                        "type": wafer_filter["type"],
                        "label": wafer_filter["label"],
                    }
            for filter in defect_level:
                if (
                    applied_filters.get("filter", {})
                    .get("secondary_filter", {})
                    .get("defect_level_filter", {})
                    .get(filter["value"], {})
                    .get("selected")
                ):
                    data_output["defect_level_filters"][f"{filter['value']}"] = {
                        "values": defect_filter_value.get(
                            f"{filter['value']}",
                            data_df[f"{filter['value']}"].unique().tolist(),
                        ),
                        "type": filter["type"],
                        "label": filter["label"],
                        "selected": applied_filters.get("filter", {})
                        .get("secondary_filter", {})
                        .get("defect_level_filter", {})
                        .get(filter["value"], {})
                        .get("selected"),
                    }
                else:

                    if filter['value'] != 'defectid':
                        data_output["defect_level_filters"][f"{filter['value']}"] = {
                            "values": defect_filter_value.get(
                                f"{filter['value']}",
                                data_df[f"{filter['value']}"].unique().tolist(),
                            ),
                            "type": filter["type"],
                            "label": filter["label"],
                        }
                    else:
                        data_output["defect_level_filters"][f"{filter['value']}"] = {
                            "values": [],
                            "type": filter["type"],
                            "label": filter["label"],
                        }

            for data in dynamic_data:
                if (
                    applied_filters.get("filter", {})
                    .get("secondary_filter", {})
                    .get("dynamic_filter", {})
                    .get(data["columnname"], {})
                    .get("selected")
                ):
                    data_output["dynamic_filters"][f"{data['columnname']}"] = {
                        "values": []
                        if data["type"] in ["input","csvfield"]
                        else {"min": "", "max": ""},
                        "type": data["type"],
                        "label": data["label"],
                        "selected": applied_filters["filter"]["secondary_filter"][
                            "dynamic_filter"
                        ][data["columnname"]].get("selected"),
                    }
                else:
                    data_output["dynamic_filters"][f"{data['columnname']}"] = {
                        "values": []
                        if data["type"] in ["input","csvfield"]
                        else {"min": "", "max": ""},
                        "type": data["type"],
                        "label": data["label"],
                    }

        except Exception as excep:
            app_log.error(traceback.format_exc())
            app_log.exception(excep)
            return {"error": str(excep)}

        return data_output


    async def make_query(self,data):
            """This function is used to create queries"""
            query_data = {}
            query_condition = []
            query_cdtn_defect = []
            condition_mapping = {
            "platformtype": query_condition,
            "manualdoassist": query_cdtn_defect,
            "semga": query_condition,
            "rod":query_condition,
            "recipetimestamp": query_condition,
            "inspectionstationid":query_condition,
            "waferrecord":query_condition,
            "lotrecord":query_cdtn_defect,
            "semtoolid":query_condition,
            "semrecipename":query_condition
        }
            for i in data.get('filter').get('secondary_filter').keys():
                if len((data.get('filter').get('secondary_filter').get(i,[]))) >0:
                    query = f"{i} in {tuple(data.get('filter').get('secondary_filter').get(i, []))}"
                    if i in condition_mapping:
                        condition_mapping[i].append(query)
                    else:
                        query_cdtn_defect.append(query)
            for i in data.get('filter').get('primary_filter').keys():
                if  i == "resulttimestamp":
                    startdate = data.get('filter').get(
                        'primary_filter').get('resulttimestamp').get('min')
                    enddate = data.get('filter').get(
                        'primary_filter').get('resulttimestamp').get('max')
                    startdate = datetime.strptime(startdate,
                        "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                    enddate = datetime.strptime(enddate,
                        "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                    query_condition.append(f"{i} BETWEEN ('{startdate}') and ('{enddate}')")
                elif len((data.get('filter').get('primary_filter').get(i,[]))) >0:
                    query_condition.append( f"{i} in {tuple(data.get('filter').get('primary_filter').get(i,[]))}")
            query_data['header_cdtn'] = f"and {' and '.join(query_condition)}"
            for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("inspectiontool", "inspectionstationmodel")]:
                query_data['header_cdtn'] = query_data['header_cdtn'].replace(f"{old_key} in", f"{new_key} in")
            if len(query_cdtn_defect) > 0:
                query_data['defect_cdtn'] = f"and {' and '.join(query_cdtn_defect)}"
                for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("inspectiontool", "inspectionstationmodel")]:
                    query_data['defect_cdtn'] = query_data['defect_cdtn'].replace(f"{old_key} in", f"{new_key} in")
            else:
                query_data['defect_cdtn'] = ''
            return query_data