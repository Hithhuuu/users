"""File for addittion and deletion of dynamic filters"""
import traceback
from api.common.utils import (
    get_queries2,
    get_logger,
    get_columns_info

)
import re
from api.common.fastapi_app import get_query_with_pool
app_log = get_logger("dynamicfilter")
class dynamicfilter:
    """Class for dynamic filters"""
    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2("mapsummarytablefilters")
        self.mapping = get_columns_info()

    async def create(self, data):
        """Function for Adding the dynamic filters"""
        try:
            app_log.info(f"get creation paylaod for dynamic filters {data}")
            app_log.info("Preparing to add new dynamic filter")
            query_data = data
            wafer_level_filter_list = [i['value'] for i in self.mapping['wafer_level_filter']]
            defect_level_filter_list = [i['value'] for i in self.mapping['defect_level_filter']]
            global_level_filter_list = [i['value'] for i in self.mapping['global_level_filter']]

            rep = re.findall("[^a-zA-Z_]",data["column_name"])
            if rep:
                resp = {"error": "value input not valid"}
                return resp

            if (str(data["column_name"]).lower() in wafer_level_filter_list) or (str(data["column_name"]).lower() in defect_level_filter_list) or (str(data["column_name"]).lower() in global_level_filter_list):
                resp = {"error": "value already in default filters"}
                return resp

            data["column_name"] = str(data["column_name"]).lower()    

            query_to_execute = self.queries['dynamic_filter_exist'].format(**query_data)
            app_log.info(f"check whether dynamic filter already exist Query: {query_to_execute}")
            resp = await get_query_with_pool(query_to_execute,resp_type="list")
            if len(resp) > 0:
                resp = {"error": "dynamic filter already exist"}
                return resp

            query_to_execute = self.queries["add_dynamic_filters"].format(**query_data)
            app_log.info(f"Insert dynamic filter Query: {query_to_execute}")
            resp = await get_query_with_pool(query_to_execute)
            app_log.info(f"New Dynamic Filter Added Successfully")
            resp =  {
                        "value": []
                        if data["type"] in ["input" , "csvfield"]
                        else {"min": "", "max": ""},
                        "type": data["type"],
                        "label": data["label"],
                    }

        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error in creating new dynamic filter {e}")

        return resp


    async def delete(self, data):
        """Function for deleting the dynamic filters"""
        try:
            app_log.info("Preparing to Delete dynamic filter")
            delete = data
            query_to_execute = self.queries["delete_dynamic_filter"].format(**delete)
            app_log.info(f"delete Query: {query_to_execute}")
            resp = await get_query_with_pool(query_to_execute)
            resp = {"msg": f"Successfully deleted"}

        except Exception as e:
            app_log.info(traceback.format_exc())
            app_log.error(e)
            resp = {"error": "Delete dynamic filter api failed"}

        return resp

    # def __del__(self):
    #     """Close the connection"""
    #     app_log.info("DB Connection closed")
    #     self.connection.close()
