"""Mst filters handler file"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends
from fastapi.encoders import jsonable_encoder
from api.common.fastapi_app import verify_jwt,app
from api.common.utils import get_logger
from api.services.mapsummarytablefilters.schema import(
    mapsummaryfilters,adddynamicfilters,deletedyanamicfilters)
from api.services.mapsummarytablefilters.routes.mapsummarytablefilters_model import (
    Mapsummarytablefilters,
)
from api.services.mapsummarytablefilters.routes.dynamicfilter import (
    dynamicfilter,
)

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

app_log = get_logger("summarytablefilter")
router = APIRouter(dependencies=[Depends(verify_jwt)])


@router.post("/summaryfilters")
async def post(body: dict):
    """Getting the data from db with key values"""
    filter_data = Mapsummarytablefilters()
    body=jsonable_encoder(body)
    resp = await filter_data.get(body)

    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/summaryfilters/dynamicfilters")
async def posts(body: adddynamicfilters):
    """Getting the data from db with key values"""
    create_dynamic_filter = dynamicfilter()
    body=jsonable_encoder(body)
    resp = await create_dynamic_filter.create(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": resp["error"]},
        )
    return JSONResponse(content=resp)


@router.delete("/summaryfilters/dynamicfilters")
async def delete(body: deletedyanamicfilters):
    """Delete dynamic filter from the application"""
    delete_dynamic_filter = dynamicfilter()
    body=jsonable_encoder(body)
    resp = await delete_dynamic_filter.delete(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)
