"""fast api app file for mst filters"""
from api.common.fastapi_app import app
from api.services.mapsummarytablefilters.routes import (
    mapsummarytablefilters_handler,
)

app.include_router(mapsummarytablefilters_handler.router)
