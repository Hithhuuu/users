from api.common.fastapi_app import app
from api.services.order.routes import order_handler


app.include_router(order_handler.router)
