from api.common.fastapi_app import app 
from api.services.upload.routes import upload_handler

app.include_router(upload_handler.router)