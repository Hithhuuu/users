import datetime
import os
from api.common.fastapi_app import app
from fastapi import APIRouter
from schedulers.schedulers import scheduler_cron
from watchdog_process.drive_watchdog import file_watcher
from schedulers.klarf_cleanup import rejected,delete
# from schedulers.bore_klarf_cleanup import bore_rejected
from schedulers.drop_partition import start_drop_partition
from schedulers.data_cleanup import data_clean,optimize_tables
# from schedulers.bore_datacleanup import bore_data_clean,bore_optimize_tables
from api.common.utils import get_logger
from api.services.alerts.routes.alert_validate import Validation

router= APIRouter()

app_log=get_logger("upload")

@app.on_event("startup")
@scheduler_cron(interval=True,minutes=1)
async def klarf_cron():
    """Triggers tool upload on 1min interval """
    app_log.info("file watching and rejection started")
    await file_watcher()
    await rejected()
    # await bore_rejected()

@app.on_event("startup")
@scheduler_cron(cron_expression = '* */1 * * *')
async def klarfs_cron():
    """Triggers tool upload on 1hour interval """
    env = os.getenv("env")
    if env!="prd":
        delete(r'/Application/local/motor/data/drive/lz/today/reports/')
        # delete(r'/Application/local/motor/data/drive/yet_to_process/')
    else:
        delete(r'/usr/local/motor/data/drive/lz/today/reports/')
        # delete(r'/usr/local/motor/data/drive/yet_to_process/')

@app.on_event("startup")
@scheduler_cron(cron_expression = '0 0 * * *')
async def klarfs_crons():
    """Triggers tool upload on runs every day at 12:00 AM """
    await start_drop_partition()
    await data_clean()
    await optimize_tables()
    # await bore_data_clean()
    # await bore_optimize_tables()

# @app.on_event("startup")
# @scheduler_cron(cron_expression = '30 1 */1 * *')
# async def kill_chromium():
#     """Triggers kill chromium every day at 01:30 AM """
#     os.popen("kill $(ps -ef | grep '/chromium-browser/' | grep -v grep | awk '{print $2}')").read()


@app.on_event("startup")
@scheduler_cron(cron_expression = '0 0 */1 * *')
async def daily_alerts():
    alert_v = Validation() 
    await alert_v.get_daily_alerts()

@app.on_event("startup")
@scheduler_cron(cron_expression = '0 0 * * 6')
async def weekly_alerts():
    alert_v = Validation() 
    await alert_v.get_weekly_alerts()