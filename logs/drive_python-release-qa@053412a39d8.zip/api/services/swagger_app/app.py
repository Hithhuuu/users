from api.common.utils import get_logger
from api.common.fastapi_app import app
from api.services.charts.routes import charts_api_handler
from api.services.datacleanup.routes import datacleanup_handler
from api.services.exports.routes import export_handler
from api.services.globalfilters.routes import globalfilters_handler
from api.services.mapsummarytable.routes import map_summary_table_handler
from api.services.mapsummarytablefilters.routes import mapsummarytablefilters_handler
from api.services.order.routes import order_handler

app_log = get_logger("swagger")
app_log.info("getting all apis details")

app.include_router(charts_api_handler.router)
app.include_router(datacleanup_handler.router)
app.include_router(export_handler.router)
app.include_router(globalfilters_handler.router)
app.include_router(map_summary_table_handler.router)
app.include_router(mapsummarytablefilters_handler.router)
app.include_router(order_handler.router)