"""Schema for payload of export"""
from pydantic import BaseModel
class exports(BaseModel):
    """Payload detail for export"""
    filter: dict[str,dict]
    inputs: dict
