"""Handler file for export filter"""
import os
import io
import datetime
import asyncio
from fastapi.responses import (JSONResponse,FileResponse,StreamingResponse,Response)
from fastapi import (APIRouter,Depends,UploadFile, Request)
from fastapi.encoders import jsonable_encoder
from api.common.fastapi_app import verify_jwt,app
from api.services.exports.routes.export_model import Export, ExportPage, ExportPageCombine
from api.services.exports.schema import exports

router = APIRouter(dependencies=[Depends(verify_jwt)])


@router.post("/export")
async def post(body: dict,response: Response):
    """Getting the data from db with key values"""
    export = Export()
    body=jsonable_encoder(body)
    resp= await export.get_excel(body)
    if "Nodata" in list(resp.keys()):
        return Response(
            status_code=204,
            #content='',
        )
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )

    file_name=f"export/{resp['file_name']}"
    with open(file_name,"rb") as fi:
        contents=fi.read()
    blob_data = io.BytesIO(contents)
    if os.path.exists(f"{file_name}"):
        os.remove(f"{file_name}")
    response = Response(content=blob_data.getvalue())
    response.headers['Content-Type'] = 'application/octet-stream'
    return response

@router.post("/export/combineddata")
async def post(body: dict,response: Response):
    """Getting the data from db with key values"""
    export = Export()
    body=jsonable_encoder(body)
    resp= await export.get_combined_excel(body)
    if "Nodata" in list(resp.keys()):
        return Response(
            status_code=204,
            #content='',
        )
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )

    file_name=f"export/{resp['file_name']}"
    with open(file_name,"rb") as fi:
        contents=fi.read()
    blob_data = io.BytesIO(contents)
    if os.path.exists(f"{file_name}"):
        os.remove(f"{file_name}")
    response = Response(content=blob_data.getvalue())
    response.headers['Content-Type'] = 'application/octet-stream'
    return response
    # response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    # with open(file_name,"rb") as fi:
    #     contents=fi.read()

    # if os.path.exists(f"{file_name}"):
    #     os.remove(f"{file_name}")

    # return Response(contents)

@router.post("/export/page_level")
async def posts(request: Request, body: dict,response: Response):
    """Getting the data from db with key values"""
    export = ExportPage()
    authorization_header = request.headers.get("Authorization")
    body=jsonable_encoder(body)
    body["authorization_header"] = authorization_header
    resp= await export.get_excel(body)
    # if os.path.exists(body['file_name']):
    #     os.remove(body['file_name'])
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"}
        )
    return JSONResponse(content={'msg':'export trigger'})

@router.post("/export/page_level/combineddata")
async def combine_export(request: Request, body: dict,response: Response):
    """Getting the data from db with key values"""
    export = ExportPageCombine()
    authorization_header = request.headers.get("Authorization")
    body=jsonable_encoder(body)
    body["authorization_header"] = authorization_header
    resp= await export.get_page_combine_export(body)
    if "Nodata" in list(resp.keys()):
        return Response(
            status_code=204,
        )
    file_name=f"{resp['file_name']}"
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    #async def upload_file(file_name):
    with open(file_name,"rb") as fi:
        contents=fi.read()

    if os.path.exists(f"{file_name}"):
        os.remove(f"{file_name}")

    return Response(content=contents)