"""File for Fast api"""
from api.common.fastapi_app import app
from api.services.exports.routes import export_handler


app.include_router(export_handler.router)
