"""Schema for pyaload of charts"""
from typing import Union
from pydantic import BaseModel
class charts(BaseModel):
    """Payload detail for charts"""
    filter: dict[str,dict]
    inputs: dict

class defect_detail(BaseModel):
    """Payload detail for defect table"""
    filter: dict[str,dict]
    inputs: Union[dict, None] = None
    sort: Union[dict, None] = None
    limit:Union[int, None] = None
    table_type : Union[str,None] = None
    offset:Union[int, None] = None