"""defect_table model file"""
import traceback
from api.common.utils import (
    get_logger,
    get_columns_info,
    get_column_details,
    get_queries2
)
from api.common.common import get_header_defect_condition
from api.common.fastapi_app import get_query_with_pool
from api.common.auth import extract_user_id
import json

app_log = get_logger("defect_table")


class defect_table:
    """ "class creation for defect table."""

    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2("charts")
        self.mapping = get_columns_info()

    async def table_order(self,data):            
        try:
            userid = await extract_user_id(data.get("authorization_header"))
            query_d = {}
            query_d ['userid'] = userid
            query_to_execute = self.queries["get_order"].format(**query_d)
            dt_order = await get_query_with_pool(query_to_execute, resp_type="dict")
            if len(dt_order)<1:
                query_to_execute = self.queries["get_default"].format(**query_d)
                default_order= await get_query_with_pool(query_to_execute, resp_type="dict")
                app_log.info("getting the default order")
                order= json.loads(default_order[0]['orderdt'] )
            else:
                    app_log.info("getting the custom order")
                    dynamic_filter = await get_query_with_pool(self.queries['d_filter'],resp_type="df")
                    dynamic_filter_columnname = dynamic_filter['columnname'].tolist()
                    dynamic_filter_label = dynamic_filter['label'].tolist()
                    flag = True
                    filtered_order = json.loads(dt_order[0]['orderdt'])
                    for items in json.loads(dt_order[0]['orderdt'] ):
                        if items.get("columnname") not in dynamic_filter_columnname and items.get("isdynamic")==True :
                            flag = False
                            filtered_order = [d for d in filtered_order  if d.get('columnname') != items.get("columnname")]
                        
                        elif items.get("columnname")  in dynamic_filter_columnname and items.get("isdynamic")==True and items.get("label") not in dynamic_filter_label:
                            flag = False
                            filtered_order = [d for d in filtered_order if  d.get('label') != items.get("label")]
                    if flag:
                        order = json.loads(dt_order[0]['orderdt'] )
                    else:
                        order = filtered_order
            d_filter = await get_query_with_pool(self.queries['d_filter'],resp_type="dict")
            for dictionary in d_filter:
                dictionary['isselected'] = False
                dictionary['isdynamic'] = True
            order.extend([p for p in d_filter if p['columnname'] not in [item['columnname'] for item in order]])
            app_log.info("Successfully retrieved order")        
            return order
        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}

    async def get_defect_table_values(self, data):
        """ "Function for getting the detail defect Table"""
        try:
            columns_info = get_column_details("columns")
            defect_cols = columns_info["defect_cols"].split()
            #cursor = self.connection.cursor()
            app_log.info("Preparing response for detailed table")
            app_log.info(f"filter values paylaod {data}")
            query_data = get_header_defect_condition(data)
            query_data["fov_margin"] = (
                data["filter"]["secondary_filter"]["fov_margin"]
                if data["filter"]["secondary_filter"]["fov_margin"]
                else 1
            )
            query_data["limit"] = data.get("limit")
            query_data["offset"] = data.get("offset")
            column_sort_query = ""
            if data.get("sort"):
                columns_sort_query = [
                    f"{key} {value} "
                    for key, value in data["sort"].items()
                    if data["sort"][key]
                ]
                column_sort_query = " , ".join(columns_sort_query)
            query_data["sort_order"] = (
                f"ORDER by {column_sort_query},defectid ASC" if column_sort_query else "ORDER by defectid ASC"
            )
            # p = f"(select columnname,label from drive_dynamic_filter final where rfg='1')"

            data_out =await get_query_with_pool(self.queries['d_filter'],resp_type="dict")
            dynamics_condition_query = []
            select_query = []
            for d in data_out:
                if f"{d['columnname']}" not in (defect_cols):
                    dynamics_condition_query.append(
                        f"defects.dynamic['{d['columnname']}'] as {d['columnname']}"
                    )
                    select_query.append(f"defects.{d['columnname']}")
                if f"({d['columnname']})" not in self.mapping["detail_table_mapping"].keys():
                    self.mapping["detail_table_mapping"][f"{d['columnname']}"] = f"{d['label']}"

            select_query = " , ".join(select_query)
            dynamic_condition_query = " , ".join(dynamics_condition_query)
            query_data["dynamic_condition"] = (
                f",{dynamic_condition_query}" if dynamic_condition_query else ""
            )
            query_data["select_query"] = (
                f",{select_query}" if dynamic_condition_query else ""
            )
            
            query_to_execute = self.queries["filter_query"].format(**query_data)
            app_log.info(query_to_execute)
            resp = dict()

            data_output = await get_query_with_pool(query_to_execute,resp_type="df")
            resp["data"] = data_output.round(3).to_dict(orient="records")

            total_query_to_execute = self.queries["total_data"].format(**query_data)
            resp["order"] = await self.table_order(data)
            resp["limit"] = data.get("limit")
            resp["offset"] = data.get("offset")
            result = await get_query_with_pool(total_query_to_execute,resp_type="dict")
            for d in result:
                resp["total"] = d["count"]
            
        except Exception as err:
            app_log.exception(err)
            app_log.error("Defect table API Failed")
            return {"error": err}
        return resp
