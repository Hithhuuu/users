from api.common.fastapi_app import app
from api.services.charts.routes import charts_api_handler


app.include_router(charts_api_handler.router)
