"""Schema for payload of globalfilters"""
from pydantic import BaseModel,validator
from datetime import datetime
class gfilters(BaseModel):
    """Payload detail for global filters"""
    startDate:str
    endDate:str
    @validator('startDate','endDate',pre=True,always=True)
    def change_format(cls,v):
        """Function to change datetime format"""
        formatted= datetime.strptime(v, '%d-%m-%YT%H:%M:%S')
        return datetime.strftime(formatted, '%d-%m-%YT%H:%M:%S')
