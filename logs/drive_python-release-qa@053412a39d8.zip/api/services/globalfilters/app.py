"""Fast api app file"""
from api.common.fastapi_app import app
from api.services.globalfilters.routes import globalfilters_handler


app.include_router(globalfilters_handler.router)
