"""Handler file for Global filter"""
from fastapi.responses import JSONResponse
from fastapi import APIRouter,Depends
from fastapi.encoders import jsonable_encoder
from api.common.fastapi_app import verify_jwt,app
from api.services.globalfilters.routes.globalfilters_model import globalfilters
from api.common.utils import get_logger
from api.services.globalfilters.schema import gfilters

app_log = get_logger("globalfilters")
router = APIRouter(dependencies=[Depends(verify_jwt)])


@router.post("/globalfilters")
async def post(body: dict):
    """Post method for Population of Global filters"""
    globalfilter = globalfilters()
    # body=jsonable_encoder(body)
    resp = await globalfilter.get_filter_values(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)