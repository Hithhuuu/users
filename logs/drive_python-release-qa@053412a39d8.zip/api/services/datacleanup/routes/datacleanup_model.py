"""Model file for datacleanup"""
from api.common.utils import get_logger
import yaml

app_log = get_logger("datacleanup")


class datacleanups:
    def __init__(self):
        """Initialize template."""
        with open("api/services/datacleanup/datacleanup.yaml") as file:
            self.config = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()

    async def get_values(self):
        try:
            app_log.info(f"getting current values for cleanup")
            data_output = {
                "file_cleanup": self.config["cleanup"]["file_cleanup"],
                "db_cleanup": self.config["cleanup"]["db_cleanup"]
            }
            return data_output

        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}


    async def new_input(self, data):
        try:
            app_log.info(f"payload data is {data}")
            self.config["cleanup"]["file_cleanup"] = data.file_cleanup
            self.config["cleanup"]["db_cleanup"] = data.db_cleanup

            with open("api/services/datacleanup/datacleanup.yaml","w") as file:
                yaml.dump(self.config, file)
                file.close()

            data_output = {
                "file_cleanup": data.file_cleanup,
                "db_cleanup": data.db_cleanup
            }
            return data_output

        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}