"""Schema for payload of datacleanup"""
from pydantic import BaseModel
class PayloadData(BaseModel):
    """Payload detail for datacleanup"""
    file_cleanup: int
    db_cleanup: int