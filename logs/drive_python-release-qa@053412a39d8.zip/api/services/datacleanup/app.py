"""Fast api app file for data cleanup"""
from api.common.fastapi_app import app
from api.services.datacleanup.routes import datacleanup_handler
app.include_router(datacleanup_handler.router)