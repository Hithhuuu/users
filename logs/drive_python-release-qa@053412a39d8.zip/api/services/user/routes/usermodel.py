"""model file for users"""
import os
import time
import sys
import json
from datetime import datetime, timedelta
import bcrypt
from jwt import encode
from api.common.utils import (
    get_queries2,
    get_logger,
    env_config,
    decrypt,
    encrypt
)
from api.common.fastapi_app import get_query_with_pool
#from api.utils.common import execute_query
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
app_log = get_logger("user")
class users():
    """class of user for the user_api"""
    def __init__(self):
        '''Initializing user instance'''
        # self.connection =connection_pool.connect()
        self.queries = get_queries2('user')
        # self.conn = con_pool

    async def get(self):
        '''Get list of users'''
        try:
            app_log.info('Get list of users')
            app_log.info(self.queries['read'])
            #data = pd.read_sql(self.queries['read'], self.connection)#.to_json(orient='records')
            data = await get_query_with_pool(self.queries["read"])
            data=data.to_json(orient='records')
            # data=data.to_json(orient='columns')
            data = {'encryptedData': encrypt(f'{data}', bytes(env_config["password_secret_key"]
                                                              , 'utf-8')).decode('ascii')}
            # data =execute_query(self.connection, self.queries["read"])
            # data=json.dumps(data)
            # data = {'encryptedData': encrypt(f'{data}', bytes(env_config["password_secret_key"],
            #                                                  'utf-8')).decode('ascii')}
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            app_log.error(e)
            return{'error': str(e)}
        return (data)

    def get_password(self, password):
        ''' Decode the users password '''
        salt = bcrypt.gensalt()
        password = bcrypt.hashpw(password.encode(), salt)
        return password.decode()

    async def create(self, data):
        '''creates new user'''
        try:
            app_log.info('Create user')
            data = json.loads(decrypt(data['encryptedData'],
                                       bytes(env_config["password_secret_key"], 'utf-8')). \
                decode("utf-8"))
            ''' Check user exists '''
            if data['userid'] == 'default':
                return {'msg': 'User already exists', 'status_code': 400}
            user_exists_query = self.queries['user_exists'].format(**data)
            app_log.info(f'user EXISTS QUERY: {user_exists_query}')
            users = await get_query_with_pool(
                user_exists_query, "dict"
            )

            if len(users):
                return {"msg": "user exists"}
            ''' Encrypt user password '''
            pass_word = decrypt(data["password"], bytes(env_config["password_secret_key"]
                                                        , 'utf-8')).decode("utf-8")
            data['password'] = self.get_password(pass_word)
            ''' Create new user '''
            isadmin = "Y" if data.get('isadmin')=="Y" else "N"
            rfg = 1 if data.get('isactive')=="Y" else 2
            data.update(
                {
                    "isadmin":isadmin,
                    "rfg":rfg
                }
            )

            user_create_query = self.queries['create'].format(**data)
            app_log.info(f'user CREATE QUERY: {user_create_query}')
            await get_query_with_pool(user_create_query)
        except Exception as e:
            print("error in user creation", e)
            import traceback
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return{'error': str(e)}
        return{'msg': 'user created'}

    def prepare_query(self, data):
        query_data = []
        for key, value in data.items():
            if key == "isactive":
                rfg = 1 if data.get('isactive')=="Y" else 2
                query_data.append(f"rfg = '{rfg}'")
            elif key == "isadmin":
                isadmin = "N" if data.get('isadmin')=="N" else "Y"
                query_data.append(f"isadmin = '{isadmin}'")
            elif key != "userid" and key !="udt" and key != "cdt" and key != "currentPassword":
                query_data.append(
                    f"{key} = '{value}'"                    
                )
        return " , ".join(query_data)

    async def update(self, data):
        '''Update user record'''
        try:
            app_log.info('Update user Record')
            data = json.loads(decrypt(data['encryptedData'],
                                       bytes(env_config["password_secret_key"], 'utf-8')). \
                decode("utf-8"))
            app_log.info('Authenticating users')
            # data_keys = list(data.keys())
            # # if 'isactive' in data_keys:
            # #     app_log.info("Updating active users")
            user_auth_query = self.queries['authenticate_update'].format(**data)
            app_log.info(f"user AUTH QUERY: {user_auth_query}")
            user_data = await get_query_with_pool(user_auth_query, "dict")
            if len(user_data) <= 0 or user_data[0]['rfg']==0:
                 return({"msg":f"userID not valid"})
            user_data = user_data[0]
            if data.get("currentPassword", '') != '':
                pass_word = decrypt(data["currentPassword"],
                                     bytes(env_config["password_secret_key"], 'utf-8')).decode("utf-8")
                ''' Verify user input password and user data password are equal or not '''
                if not bcrypt.checkpw( pass_word.encode(),user_data["password"].encode()):
                    return({"msg":f"Current password is incorrect for user {data['userid']}."})
            if data.get('password'):
                pass_word = decrypt(data["password"], bytes(env_config["password_secret_key"], 'utf-8')).decode("utf-8")
                data['password'] = self.get_password(pass_word)

            # TODO update active/inactive user
            query_data = self.prepare_query(data)
            data['select_param'] = query_data
            user_update_query = self.queries['update'].format(**data)
            app_log.info(f"user UPDATE QUERY: {user_update_query}")
            await get_query_with_pool(user_update_query, "dict")
        except Exception as e:
            import traceback
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return{'error': str(e)}
        return{"msg":f"user {data['userid']} updated successfully"}

    async def delete(self, data):
        '''Delete user'''
        try:
            app_log.info('Delete users')
            data['userid'] = "', '".join(data['userid'])
            user_delete_query = self.queries['delete'].format(**data)
            app_log.info(f'user DELETE QUERY: {user_delete_query}')
            await get_query_with_pool(user_delete_query)
            for i in range(30):
                count_query = self.queries["user_count"].format(**data)
                app_log.info(f" count query : {count_query}")
                count = await get_query_with_pool(count_query)
                app_log.info(f" count is {count['count'].iloc[0]}")
                if count['count'].iloc[0] != 0:
                    break
                time.sleep(0.2)
            app_log.info("Deleted successful")
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}

    async def auth(self, data):
        """Authentication users with username and password"""
        try:
            user_data = await self.data(data)
            if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
                return {
                    "status": "error",
                    "status_code": 401,
                    "content": "userID not valid",
                }

            user_data = user_data[0]
            pass_word = decrypt(
                data["password"], bytes(env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")

            if self.check_password(user_data["password"], pass_word):
                to_encode = {
                    "some": "payload",
                    "userid": data["userid"],
                    "a": {2: True},
                    "exp": datetime.utcnow() + timedelta(minutes=480),
                }
                encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
                jwt_key = (
                    encoded.decode("utf-8") if (isinstance(encoded, bytes)) else encoded
                )
                response_data = {
                    "jwt": jwt_key,
                    "userid": user_data["userid"],
                    "username": user_data["email"],
                    "firstname": user_data["firstname"],
                    "isadmin": "Y" if user_data["isadmin"] == "Y" else "N",
                    "displayName": user_data["firstname"] + " " + user_data["lastname"],
                    "expiredAt": str(to_encode["exp"]),
                }
                response = {
                    "encryptedData": encrypt(
                        f"{response_data}".replace("'", '"'),
                        bytes(env_config["password_secret_key"], "utf-8"),
                    ).decode("ascii")
                }
                app_log.info("Successfully authenticated")

                return response

            return {
                "status": "error",
                "status_code": 401,
                "content": "Authentication failed",
            }
        except Exception as e:
            app_log.exception(e)
            return {
                "status": "error",
                "status_code": 500,
                "content": "Something went wrong",
            }


    # def get_auth_data(self, request):
    #     auth = request.headers.get('Authorization')
    #     options = {
    #         'verify_signature': True,
    #         'verify_exp': True,
    #         'verify_nbf': False,
    #         'verify_iat': True,
    #         'verify_aud': False
    #     }
    #     token = auth.split()[1]
    #     return decode(token, env_config['secret_key'], options=options)

    async def data(self, data):
        ''' Get the user details for Authentication '''
        try:
            app_log.info('Authenticating users')
            user_auth_query = self.queries['authenticate'].format(**data)
            app_log.info(f"user AUTH QUERY: {user_auth_query}")
            user_data = await get_query_with_pool(user_auth_query, "dict")
        except Exception as e:
            app_log.error(e)
            return{'error': str(e)}
        return (user_data)

    def check_password(self, user_password, requested_password):
        '''Check user password'''
        return bcrypt.checkpw(requested_password.encode(), user_password.encode())

    # def __del__(self):
    #     '''On user Instance deletion'''
    #     self.connection.close()
