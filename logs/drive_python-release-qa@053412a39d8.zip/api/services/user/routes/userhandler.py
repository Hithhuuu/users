"""Handler file for users"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import (APIRouter,Depends)
from fastapi.encoders import jsonable_encoder
from api.services.user.routes.usermodel import users
from api.services.user.schema import (authentication,createusers,updateusers,deleteusers)
from api.common.fastapi_app import app,verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
router = APIRouter()

@router.post("/user/auth")
async def auth(body: authentication):
    """On get request return the user\'s list as JSON"""
    user = users()
    body=jsonable_encoder(body)
    response = await user.auth(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )


@router.get("/user",dependencies=[Depends(verify_jwt)])
async def get():
    """On get request return the user\'s list as JSON"""
    user = users()
    return JSONResponse(content=await user.get())


@router.post("/user",dependencies=[Depends(verify_jwt)])
async def post(body: createusers):
    """On post request create the user if doesn't exist"""
    user = users()
    body = jsonable_encoder(body)
    response = await user.create(body)
    if response.get("status_code", 200) == 400:
        return JSONResponse(
            status_code=response.get("status_code"),
            content={"message": response.get("msg")},
        )
    return JSONResponse(content=response)


@router.put("/user",dependencies=[Depends(verify_jwt)])
async def put(body: updateusers):
    """On get request return the user\'s list as JSON"""
    user = users()
    body=jsonable_encoder(body)
    response = await user.update(body)
    if response.get("status_code", 200) == 400:
        return JSONResponse(
            status_code=response.get("status_code"),
            content={"message": response.get("msg")},
        )
    return JSONResponse(content=response)


@router.delete("/user",dependencies=[Depends(verify_jwt)])
async def delete(body: deleteusers):
    """On get request return the user\'s list as JSON"""
    user = users()
    body=jsonable_encoder(body)
    await user.delete(body)
    return JSONResponse(content=await user.get())
