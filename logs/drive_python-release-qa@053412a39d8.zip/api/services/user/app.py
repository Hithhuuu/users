"""app file for user"""
from api.common.fastapi_app import app
from api.services.user.routes import userhandler
app.include_router(userhandler.router)
