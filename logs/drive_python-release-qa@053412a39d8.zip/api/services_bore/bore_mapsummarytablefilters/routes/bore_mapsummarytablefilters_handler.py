"""Mst filters handler file"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends
from fastapi.encoders import jsonable_encoder
from api.services_bore.bore_mapsummarytablefilters.common.fastapi_app import verify_jwt
from api.services_bore.bore_mapsummarytablefilters.common.utils import get_logger
# from api.services_bore.bore_mapsummarytablefilters.schema import(Payload,Response)
from api.services_bore.bore_mapsummarytablefilters.routes.bore_mapsummarytablefilters_model import (
    Mapsummarytablefilters)
from api.services_bore.bore_mapsummarytablefilters.routes.bore_dynamicfilter import (dynamicfilter)
# from api.services_bore.bore_mapsummarytablefilters.schema import (
#     DynamicFilterManipulator,AddFilterResponse,DeleteFilterResponse)
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

app_log = get_logger("summarytablefilter")
router = APIRouter(dependencies=[Depends(verify_jwt)])


@router.post("/summaryfilters",tags=['DRive'])
async def post(body:dict):
    """Getting the data from db with key values"""
    filter_data = Mapsummarytablefilters()
    body=jsonable_encoder(body)
    resp = await filter_data.get(body)

    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/summaryfilters/dynamicfilters",tags=['DRive'])
async def posts(body: dict):
    """Getting the data from db with key values"""
    create_dynamic_filter = dynamicfilter()
    body=jsonable_encoder(body)
    resp = await create_dynamic_filter.create(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": resp["error"]},
        )
    return JSONResponse(content=resp)


@router.delete("/summaryfilters/dynamicfilters",tags=['DRive'])
async def delete(body: dict):
    """Delete dynamic filter from the application"""
    delete_dynamic_filter = dynamicfilter()
    body=jsonable_encoder(body)
    resp = await delete_dynamic_filter.delete(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)
