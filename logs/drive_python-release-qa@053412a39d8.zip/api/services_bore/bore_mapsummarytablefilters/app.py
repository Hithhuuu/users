"""fast api app file for mst filters"""
from api.services_bore.bore_mapsummarytablefilters.common.fastapi_app import app
from api.services_bore.bore_mapsummarytablefilters.routes import (
    bore_mapsummarytablefilters_handler,
)

app.include_router(bore_mapsummarytablefilters_handler.router)
