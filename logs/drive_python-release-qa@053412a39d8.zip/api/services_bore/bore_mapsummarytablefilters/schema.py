'''Schema For Summary Filters'''
from typing import Optional, Union
from pydantic import BaseModel,Field


class ResultTimestamp(BaseModel):
    '''Time Stamp for Inspection Results for Summary Filters'''
    min: str = Field(None, example= "04-1-2009T10:51:12")
    max: str = Field(None, example="09-02-2024T10:51:12")

class Payload(BaseModel):
    '''Payload class, Values for Payload is passsed'''
    resulttimestamp: ResultTimestamp
    semvisiontool: Union[list, None] = Field([], example=["Bore_Sample"])
    product: Union[list, None] = Field([], example=["Bore_Sample_8"])
    layer: Union[list, None] = Field([], example=["Bore_Sample_8"])
    recipename: Union[list, None] = Field([], example=["Bore_Sample"])
    unique_id: Optional[str] = Field(None,example= "1454937703358768176")


class DynamicFilterManipulator(BaseModel):
    """Payload detail for adding or deleting dynamic filters"""
    column_name : str = Field(None,example="dfgh")
    label: str = Field(None,example="dfgh")
    type: str = Field(None,example="range")


class Response(BaseModel):
    '''Response model for Summary Filters'''
    wafer_level_filters:Optional[dict[str, dict]] = Field(None, example={
        "platformtype": {
        "values": [
            "SEMVisionG7"
        ],
        "type": "multidropdown",
        "label": "Platform Type"
        },
        "semga": {
        "values": [
            "false"
        ],
        "type": "multidropdown",
        "label": "SEMGA"
        },
        "rod": {
        "values": [
            "false"
        ],
        "type": "multidropdown",
        "label": "ROD"
        },
        "recipelastmodified": {
        "values": [
            "2024-02-03",
            "2024-02-02"
        ],
        "type": "multidropdown",
        "label": "Sem Recipe Last Modified Date",
        "selected": [
            "2024-02-02"
        ]
        },
        "runorder": {
        "values": [
            3,
            2,
            1
        ],
        "type": "multidropdown",
        "label": "Run Order"
        },
        "scanset": {
        "values": [
            5,
            4,
            3
        ],
        "type": "multidropdown",
        "label": "Scan Set"
        },
        "scansettype": {
        "values": [
            "NOT ADR",
            "ADR"
        ],
        "type": "multidropdown",
        "label": "Scan Set Type"
        },
        "opticstype": {
        "values": [
            "SEM"
        ],
        "type": "multidropdown",
        "label": "Optics Type"
        },
        "lotrecord": {
        "values": [
            "Drive_Sample_4",
            "Drive_Sample_3",
            "Drive_Sample_1",
            "Bore_Sample_2",
            "Bore_Sample"
        ],
        "type": "multidropdown",
        "label": "Lot ID"
        },
        "waferid": {
        "values": [
            "ENeladmati_2",
            "Bore_WaferID_1"
        ],
        "type": "multidropdown",
        "label": "Wafer ID"
        }})
    defect_level_filters:Optional[dict[str, dict]] = Field(None, example={
        "semdsize": {
        "values": {
            "min": "451.0",
            "max": "3150.0"
        },
        "type": "range",
        "label": "Defect Size"
        },
        "aspectratio": {
        "values": {
            "min": "0.016",
            "max": "0.623"
        },
        "type": "range",
        "label": "Aspect Ratio"
        },
        "adrhighscore": {
        "values": {
            "min": "1480.16",
            "max": "9929.51"
        },
        "type": "range",
        "label": "ADR Score"
        },
        "classnumber": {
        "values": [
            88,
            22,
            15,
            10,
            7,
            5,
            0
        ],
        "type": "multidropdown",
        "label": "ADC Class"
        },
        "test": {
        "values": [
            1
        ],
        "type": "multidropdown",
        "label": "Test Index"
        }
    })
    dynamic_filters: Optional[dict[str, dict]] = Field(None, example={
        "dfgh": {
        "values": {
            "min": "",
            "max": ""
        },
        "type": "range",
        "label": "dfgh"
        }
    })


class AddFilterResponse(BaseModel):
    '''Response model when creating a dynamic_filter'''
    __root__:dict = Field({},example=
    {
    "value": {
        "min": "0.6",
        "max": "01.3"
    },
    "type": "range",
    "label": "dfgh"
    })
# class DeleteFilterResponse(BaseModel):
#     '''Return a response when a dynamic filter is deleted'''
#     __root__: dict = Field({},example={"message":"Dynamic Filter Successfully Deleted"})
