"""File for Fast api"""
from api.services_bore.bore_mapsummarytable.common.fastapi_app import app
from api.services_bore.bore_mapsummarytable.routes import bore_mapsummarytable_handler
app.include_router(bore_mapsummarytable_handler.router)
