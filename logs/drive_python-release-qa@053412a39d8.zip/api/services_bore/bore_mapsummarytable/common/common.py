"""common python file for the application"""
import os
import zlib
import itertools
# import json
import shutil
# import re
from datetime import datetime
# from glob import glob
from api.services_bore.bore_mapsummarytable.common.fastapi_app import get_query_with_pool
# from api.services_bore.bore_mapsummarytable.common.auth import jwtauth
from api.services_bore.bore_mapsummarytable.common.utils import (
    get_logger,
    get_env_config,
    get_column_details,
)


app_log = get_logger("common")
env_config = get_env_config()
columns_info = get_column_details("columns")
# date_regex = '\d{2}\-\d{2}\-\d{4}'


class zlib1:
    """Compress the response"""

    def zipit(self, resp):
        '''Compress the response using zlib compression'''
        gzip_compress = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
        content = gzip_compress.compress(str.encode(resp)) + gzip_compress.flush()
        compressed_content_length = len(content)
        return content, compressed_content_length


def execute_query(connection, query, fetch="all"):
    """Execute the cursor with provided query and increased memory"""

    # This is with new execute settings, memory is in GB
    memory_executor_settings = {0: "2G", 1: "4G", 2: "10G"}
    cursor = connection.cursor()
    for v in list(memory_executor_settings.values()):
        try:
            memory = v
            cursor.set_settings({"max_memory_usage": memory})
            cursor.execute(query)
            app_log.info(f"QUERY EXECUTED SUCCESSFULLY\nMEMORY SETTING: {v}B")
            if fetch == "all":
                data = cursor.fetchall()
            elif fetch == "one":
                data = cursor.fetchone()
                data = [data]
            elif fetch == "None":
                return []
            col = cursor._columns
            data = list(
                map(lambda row: dict(itertools.zip_longest(list(col), row)), data)
            )
            cursor.close()
            return data

        except Exception as e:
            if "memory limit" not in str(e).lower():
                app_log.error(
                    f"QUERY EXECUTION FAILED\nMEMORY SETTING: {v}B\nERROR: {e}"
                )
                raise RuntimeError(f"Query Execution Failed. Error: {e}")
            app_log.warning(f"QUERY EXECUTION FAILED\nMEMORY SETTING: {v}B\nERROR: {e}")

    raise RuntimeError(
        f"Query did not execute with 10GB limit. Please consider simplifying the query."
    )


def file_move(src_path, dst_path):
    '''Move a file from the source path to the destination path'''
    try:
        filename = os.path.basename(src_path)

        if os.path.isfile(os.path.join(dst_path, filename)):
            os.remove(os.path.join(dst_path, filename))

        shutil.move(src_path, dst_path)
        app_log.info(f"Successfully moved {src_path} to {dst_path}.")

        return os.path.join(dst_path, filename)
    except Exception as e:
        app_log.error(f"Unable to copy this file.")
        app_log.exception(e)

    return None


def move_file(src_path, xml_src_path, status="archive"):
    '''Move a file and its XML counterpart to a specific status folder.'''
    try:
        dst_path = "rejected" if status == "rejected" else status
        env = os.getenv("env")
        # watch_path = env_config[env]['watchdog_pick_location']['src']
        watch_path = r'C:\Users\x0143654\OneDrive - Applied Materials\files'
        dst_path = os.path.join(
            watch_path, dst_path)

        if not os.path.exists(dst_path):
            os.makedirs(dst_path)

        return file_move(src_path, dst_path),file_move(xml_src_path, dst_path)
    except Exception as e:
        app_log.error(f"Unable to copy this file.")
        app_log.exception(e)

    return None

def move_bore_file(src_path, xml_src_path,csv_src_path, status="archive"):
    '''Move a file, its XML counterpart, and
        its CSV counterpart to a specific status folder (for Bore application).'''
    try:
        dst_path = "rejected" if status == "rejected" else status
        env = os.getenv("env")
        # watch_path = env_config[env]['watchdog_pick_location']['src']
        watch_path = r'C:\Users\x0143654\OneDrive - Applied Materials\files'
        dst_path = os.path.join(
            watch_path, dst_path, datetime.strftime(datetime.today(), "%d%b%Y")
        )

        if not os.path.exists(dst_path):
            os.makedirs(dst_path)

        return file_move(src_path, dst_path),file_move(xml_src_path, dst_path),file_move(csv_src_path, dst_path)
    except Exception as e:
        app_log.error(f"Unable to copy this file.")
        app_log.exception(e)

    return None



def file_copy(src_path, dst_path):
    '''Copy a file from the source path to the destination path.'''
    try:
        filename = os.path.basename(src_path)
        if os.path.isfile(dst_path):
            os.remove(dst_path)
        shutil.copy(src_path, dst_path)
        app_log.info(f"Successfully copied {src_path} to {dst_path}.")
        return os.path.join(dst_path, filename)
    except Exception as e:
        app_log.error(f"Unable to copy this file.")
        app_log.exception(e)
    return None

def copy_file_with_status(src_path, xml_src_path, status="archive"):
    '''Copy a file and its XML counterpart to a specific status folder.'''
    try:
        dst_path = "rejected" if status == "rejected" else status
        env = os.getenv("env")
        # watch_path = env_config[env]['watchdog_pick_location']['src']
        watch_path = r'C:\Users\x0143654\OneDrive - Applied Materials\files'
        dst_path = os.path.join(
            watch_path, dst_path, datetime.strftime(datetime.today(), "%d%b%Y")
        )
        if not os.path.exists(dst_path):
            os.makedirs(dst_path)

        # src_filename = os.path.basename(src_path)
        # dst_filename = os.path.join(dst_path, src_filename)

        return file_copy(src_path, dst_path),file_copy(xml_src_path, dst_path)  # Assuming you want to copy the XML file to the same destination

    except Exception as e:
        app_log.error("Unable to copy this file.")
        app_log.exception(e)
    return None


async def update_job_status(kwargs):
    """This function is used update the status in job_log table"""
    try:
        job_dict = {}
        # db_conn = get_dbconnection()
        # db_cur = db_conn.cursor()

        job_dict["job_id"] = kwargs.get("job_id", None)
        job_dict["job_status"] = kwargs.get("job_status", "queued")
        job_dict["xml_file_path"] = kwargs.get("xml_file_path").replace("\\", "/")
        job_dict["klarf_file_path"] = kwargs.get("klarf_file_path").replace("\\", "/")


        if job_dict["job_status"] == "queued":
            job_dict["xml_file_name"] = os.path.basename(job_dict["xml_file_path"])
            job_dict["klarf_file_name"] = os.path.basename(job_dict["klarf_file_path"])

            # Update status: queued
            #change now() to NULL
            insert_query = """
                INSERT INTO drive_job_log (xml_file_name, klarf_file_name, job_type, job_start_time, job_status, xml_file_path, klarf_file_path, cdt)
                VALUES ('{xml_file_name}', '{klarf_file_name}', 'upload', NOW(), 'queued', '{xml_file_path}', '{klarf_file_path}', NOW())
            """
            insert_query = insert_query.format(**job_dict)
            # execute_query(db_conn, fetch_files, fetch='all')
            await get_query_with_pool(insert_query)
            # db_cur.execute(insert_query)
            # # db_cur.commit()
            # db_cur.close()
        elif job_dict["job_id"]:
            # Update status: picked/Success/Failed/rejected
            job_dict["job_start_time"] = (
                "NOW()" if job_dict["job_status"] == "picked" else "job_start_time"
            )
            job_dict["job_end_time"] = (
                "NOW()" if job_dict["job_status"] != "picked" else "job_end_time"
            )
            job_dict["job_duration"] = (
                "TIMESTAMPDIFF(SECOND, job_start_time, NOW())"
                if job_dict["job_status"] != "picked"
                else "job_duration"
            )
            job_dict["err_message"] = str(kwargs.get("err_message", "")).replace("'",'"')
            job_dict["re_try"] = (
                "re_try + 1" if job_dict["job_status"] == "failed" else "re_try"
            )
            if kwargs.get("final_rejection",False):
                job_dict["job_end_time"] = (
                    "job_end_time"
                )
                job_dict["job_duration"] = (
                    "job_duration"
                )
            update_query = """
                INSERT INTO drive_job_log
                SELECT
                    id,
                    xml_file_name,
                    klarf_file_name,
                    job_type,
                    {job_start_time} AS job_start_time,
                    {job_end_time} AS job_end_time,
                    {job_duration} AS job_duration,
                    '{job_status}' AS job_status,
                    '{err_message}' AS err_message,
                    '{xml_file_path}' AS xml_file_path,
                    '{klarf_file_path}' AS klarf_file_path,
                    cdt,
                    {re_try} AS re_try
                FROM
                    drive_job_log FINAL
                WHERE
                    id = {job_id}
            """
            update_query = update_query.format(**job_dict)
            await get_query_with_pool(update_query)
            # db_cur.execute(update_query)
            # db_cur.commit()
            # db_cur.close()
        else:
            raise ValueError("Missing Job id.")

    except Exception as e:
        app_log.error("Failed to update job status.")
        app_log.exception(e)


def get_header_defect_condition(data):
    '''Get the header and defect conditions for the MST query based on the provided filter data.'''
    defects_condition = []
    header_condition = []
    query_data = {}
    defect_cols = columns_info["defect_cols"].split()
    # defect_id = data.get('filter',{}).get('secondary_filter',{}).get('defect_level_filter',{}).get('defectid',{}).get('selected',[])
    # if defect_id:
    #     defect_id= defect_id[0].split(',')
    #     defect_id = [x for x in defect_id]
    #     data['filter']['secondary_filter']['defect_level_filter']['defectid']['selected'] = defect_id
    for i, k in data["filter"]["primary_filter"].items():
        if i == "resulttimestamp":
            query_str = f"(header.{i}) between '{datetime.strptime(k['min'],'%d-%m-%YT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')}' and '{datetime.strptime(k['max'],'%d-%m-%YT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')}'"
        if i!="runorder" and i!= "resulttimestamp":
            query_str = f"header.{i} in {tuple(k)}"

        header_condition.append(query_str)

    for v in ["wafer_level_filter", "defect_level_filter", "dynamic_filter"]:
        for q, w in data["filter"]["secondary_filter"][v].items():
            if v == "dynamic_filter":
                q = f"toFloat64OrNull(defects.dynamic['{q}'])" if v == "dynamic_filter" and q not in (defect_cols) else q
            if isinstance(w["selected"][0], dict):
                if not w['selected'][0].get('min') or not w['selected'][0].get('max'):
                    continue
                # if q == "recipetimestamp":
                #     query_str = f" header.{q} between '{datetime.strptime(w['selected'][0]['min'],'%d-%m-%YT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')}' and '{datetime.strptime(w['selected'][0]['max'],'%d-%m-%YT%H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')}'"
                # else:
                min_value = "" if w['selected'][0].get('min') == "" else float(w['selected'][0].get('min'))
                max_value = "" if w['selected'][0].get('max') == "" else float(w['selected'][0].get('max'))
                query_str = f" header.{q} between {min_value} and {max_value}"
            else:
                # if q == "recipetimestamp":
                #     query_str = f"If(LENGTH(header.{q})>4, toString(toDate(header.{q})), '') in {tuple(w['selected'])}"
                # else:
                if v == "dynamic_filter" or q=="defectid":
                    w['selected'] = w['selected'][0].split(',')
                query_str = f"header.{q} in {tuple(w['selected'])}"
            if v in ["defect_level_filter"] or q == "manualdoassist":
                defects_condition.append(query_str.replace("header.", "defects."))
            elif q in ['runorder','scanset','scansettype','opticstype','waferid']:
                defects_condition.append(query_str.replace("header.", "defects."))
            elif v in ["dynamic_filter"]:
                defects_condition.append(query_str.replace("header.", ""))
            else:
                header_condition.append(query_str)

    # if "fov_margin" in data["filter"]["secondary_filter"]:
    #     query_data["fov_margin"] = (
    #     data.get("filter").get("secondary_filter").get("fov_margin", 1)
    #     )

    header_str = " and ".join(header_condition)
    for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("semvisiontool", "semtoolid"),("recipename","semrecipename"),("recipelastmodified","recipelastmodifieddate")]:
        header_str = header_str.replace(f"header.{old_key}", f"header.{new_key}")
    defects_str = (
        " and ".join(defects_condition)
        # .replace("layer", "stepid")
        # .replace("product", "deviceid")
    )
    query_data["header_condition"] = f" and {header_str}"
    query_data["defects_condition"] = (
        f" and {defects_str}" if len(defects_condition) >= 1 else f"{defects_str}"
    )
    return query_data



async def update_job_status_bore(kwargs):
    """This function is used update the status in job_log table"""
    try:
        job_dict = {}
        # db_conn = get_dbconnection()
        # db_cur = db_conn.cursor()
        job_dict["job_id"] = kwargs.get("job_id", None)
        job_dict["job_status"] = kwargs.get("job_status", "queued")
        job_dict["xml_file_path"] = kwargs.get("xml_file_path").replace("\\", "/")
        job_dict["klarf_file_path"] = kwargs.get("klarf_file_path").replace("\\", "/")
        if kwargs.get("csv_file_path"):
            job_dict["csv_file_path"] = kwargs.get("csv_file_path").replace("\\", "/")

        if job_dict["job_status"] == "queued":
            job_dict["xml_file_name"] = os.path.basename(job_dict["xml_file_path"])
            job_dict["klarf_file_name"] = os.path.basename(job_dict["klarf_file_path"])
            job_dict["csv_file_name"] = os.path.basename(job_dict["csv_file_path"])
            # Update status: queued
            #change now() to NULL
            insert_query = """
                INSERT INTO bore_job_log (xml_file_name, klarf_file_name,csv_file_name, job_type, job_start_time, job_status, xml_file_path, klarf_file_path,csv_file_path, cdt)
                VALUES ('{xml_file_name}', '{klarf_file_name}', '{csv_file_name}','upload', NOW(), 'queued', '{xml_file_path}', '{klarf_file_path}','{csv_file_path}', NOW())
            """
            insert_query = insert_query.format(**job_dict)
            await get_query_with_pool(insert_query)
            # db_cur.execute(insert_query)
            # # db_cur.commit()
        elif job_dict["job_id"]:
            # Update status: picked/Success/Failed/rejected
            job_dict["job_start_time"] = (
                "NOW()" if job_dict["job_status"] == "picked" else "job_start_time"
            )
            job_dict["job_end_time"] = (
                "NOW()" if job_dict["job_status"] != "picked" else "job_end_time"
            )
            job_dict["job_duration"] = (
                "TIMESTAMPDIFF(SECOND, job_start_time, NOW())"
                if job_dict["job_status"] != "picked"
                else "job_duration"
            )
            job_dict["err_message"] = str(kwargs.get("err_message", "")).replace("'",'"')
            job_dict["re_try"] = (
                "re_try + 1" if job_dict["job_status"] == "failed" else "re_try"
            )
            if kwargs.get("final_rejection",False):
                job_dict["job_end_time"] = (
                    "job_end_time"
                )
                job_dict["job_duration"] = (
                    "job_duration"
                )
            update_query = """
                INSERT INTO bore_job_log
                SELECT
                    id,
                    xml_file_name,
                    klarf_file_name,
                    csv_file_name,
                    job_type,
                    {job_start_time} AS job_start_time,
                    {job_end_time} AS job_end_time,
                    {job_duration} AS job_duration,
                    '{job_status}' AS job_status,
                    '{err_message}' AS err_message,
                    '{xml_file_path}' AS xml_file_path,
                    '{klarf_file_path}' AS klarf_file_path,
                    '{csv_file_path}' AS csv_file_path,
                    cdt,
                    {re_try} AS re_try
                FROM
                    bore_job_log FINAL
                WHERE
                    id = {job_id}
            """
            update_query = update_query.format(**job_dict)
            await get_query_with_pool(update_query)
            # db_cur.execute(update_query)
            # # db_cur.commit()
            # db_cur.close()
        else:
            raise ValueError("Missing Job id.")

    except Exception as e:
        app_log.error("Failed to update job status.")
        app_log.exception(e)
