"""Model file for MST"""
import traceback
import json
# from datetime import datetime
import pandas as pd
from api.services_bore.bore_mapsummarytable.common.utils import (
    get_queries2, get_logger)
from api.services_bore.bore_mapsummarytable.common.common import get_header_defect_condition
from api.services_bore.bore_mapsummarytable.common.fastapi_app import get_query_with_pool
from api.services_bore.bore_mapsummarytable.common.auth import extract_user_id

app_log = get_logger("bore_mapsummarytable")


class map_summary_table:
    """class for MST"""
    def __init__(self):
        """Initialize template."""
        # self.connection = conn_pool
        self.queries = get_queries2('bore_map_summary_table')

    async def table_order(self,userid):
        '''Retrieve the table order for the given user ID.'''
        try:
            # userid = await extract_user_id(data.get("authorization_header"))
            query_d = {}
            query_d ['userid'] = userid
            # query_d ['table_type'] = data.get("table_type")
            query_to_execute = self.queries["get_order"].format(**query_d)
            dt_order = await get_query_with_pool(query_to_execute, resp_type="dict")
            if len(dt_order)<1:
                query_to_execute = self.queries["get_default"].format(**query_d)
                default_order= await get_query_with_pool(query_to_execute, resp_type="dict")
                order= json.loads(default_order[0]['ordermst'] )
            else:
                order = json.loads(dt_order[0]['ordermst'])

            return order

        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}

    def get_recipelastmodified(self, row):
        '''Get the last inspection update information for a row in the MST.'''
        count = row['recipelastmodified_count'] - 1 if row['recipelastmodified_count'] >= 1 else row['recipelastmodified_count']
        date = pd.to_datetime(row['recipelastmodified']).strftime("%d/%m/%y") if row['recipelastmodified'] != "" else ""
        return f"""{date} ({count} older)""" if count != 0 else f"""{date}"""

    async def check_filter(self,save_query_data):
        '''Check if a filter already exists and remove it if necessary.'''
        query_to_execute = self.queries["check_filter"].format(
            **{"unique_id": int(save_query_data["unique_id"])}
        )
        app_log.info(f"CHECK IF FILTER EXISTS QUERY: {query_to_execute}")

        filter_exist=await get_query_with_pool(query_to_execute)
        if len(filter_exist) != 0:
            query_to_execute = self.queries["remove_exist_filter"].format(
                **{"unique_id": int(save_query_data["unique_id"])}
            )
            app_log.info(f"Removing existing value QUERY: {query_to_execute}")
            await get_query_with_pool(query_to_execute)

    async def get_map_summary_values(self, data):
        """function to retrieve the values for the Map Summary Table 
            based on the provided filter criteria."""
        try:
            resp = dict()
            userid = await extract_user_id(data.get("authorization_header"))
            data.pop("authorization_header")
            app_log.info("Preparing response for map summary table")
            app_log.info(f"filter values paylaod {data}")
            update_row = ""
            if (
                len(
                    data.get("filter").get("secondary_filter").get("wafer_level_filter")
                )
                == 0
                and len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("defect_level_filter")
                )
                == 0
                and len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("dynamic_filter")
                )
                == 0
                and data.get("inputs",{}).get("unique_id")
                # and float(data.get("filter").get("secondary_filter").get("fov_margin", 0)) == 1.0
                # or data.get("filter").get("secondary_filter").get("fov_margin", 0) == 1
            ):
                save_query_data = {}
                save_query_data["unique_id"] = data.get("inputs").get("unique_id")
                await self.check_filter(save_query_data)
                update_row = (
                    f"where unique_id = '{data.get('inputs').get('unique_id')}'"
                )

            elif (
                len(
                    data.get("filter").get("secondary_filter").get("wafer_level_filter")
                )
                != 0
                or len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("defect_level_filter")
                )
                != 0
                or len(
                    data.get("filter")
                    .get("secondary_filter")
                    .get("dynamic_filter")
                )
                != 0
                # or data.get("filter").get("secondary_filter").get("fov_margin", 1) != 1
                or data.get("inputs",{}).get("unique_id")
            ):
                save_query_data = {}
                save_query_data["unique_id"] = data.get("inputs").get("unique_id")
                await self.check_filter(save_query_data)
                filters = data.copy()
                filters.pop("inputs")
                filter_data = json.dumps(filters)
                save_query_data["allfilters"] = filter_data
                query_to_execute = self.queries["save_filter"].format(**save_query_data)
                #cursor.execute(query_to_execute)
                await get_query_with_pool(query_to_execute)
                update_row = (
                    f"where unique_id = '{data.get('inputs').get('unique_id')}'"
                )
            query_data = get_header_defect_condition(data)
            if "fov_margin" not in query_data:
                query_data["fov_margin"] = 1

            query_data["limit"] = (
                f'Limit {data.get("offset")},{data.get("limit")}'
                if data.get("limit", 0)
                else ""
            )
            query_data["update_row"] = update_row
            column_sort_query = ""
            if data.get("sort"):
                columns_sort_query = [
                    f"{key} {value} "
                    for key, value in data["sort"].items()
                    if data["sort"][key]
                ]
                column_sort_query = " , ".join(columns_sort_query)
                column_sort_query = column_sort_query.replace("lastinspectionupdate", "inspectiontimestamp_max")
            query_data["sort_order"] = (f"ORDER by {column_sort_query} , unique_id ASC" if column_sort_query else "ORDER by product ASC  , layer ASC  , semtoolid ASC , unique_id ASC")
            if len((data.get('filter').get('primary_filter').get('runorder',[])))>0:
                query_data['runorder'] = f"and runorder in {tuple((data.get('filter').get('primary_filter').get('runorder',[])))}"
            else:
                query_data['runorder'] = ""
            query_to_execute = self.queries["get_map_summary_table_values"].format(**query_data)

            app_log.info(query_to_execute)
            data_output=await get_query_with_pool(query_to_execute,resp_type="dict")
            df = pd.DataFrame.from_dict(data_output)

            if not update_row:
                if len(data_output) < 1:
                    resp["data"] = []
                    query_to_execute = self.queries["last_fileupload_time"]
                    file_time=await get_query_with_pool(query_to_execute,resp_type="list")
                    resp["updatedon"] = file_time[0][0]
                    resp["limit"] = data.get("limit")
                    resp["order"] = await self.table_order(userid)
                    resp["offset"] = data.get("offset")
                    resp["total"] = len(data_output)

                    return resp

                query_to_execute = self.queries["present_filter"].format(
                **{"unique_id": df["unique_id"].to_list()}
                )
                app_log.info(query_to_execute)

                data_df=await get_query_with_pool(query_to_execute,resp_type="df")
                df.insert(loc = 1, column = "isFilterAvailable", value = "no")
                df.loc[df["unique_id"].isin(data_df["unique_id"]),"isFilterAvailable"] = "yes"
            else:
                if len(data_output) < 1:
                    query_data ={}
                    query_data["layer"] = data.get("filter").get("primary_filter").get("layer")[0]
                    query_data["product"] = data.get("filter").get("primary_filter").get("product")[0]
                    query_data["semvisiontool"] = data.get("filter").get("primary_filter").get("semvisiontool")[0]
                    query_data["recipename"] = data.get("filter").get("primary_filter").get("recipename")[0]
                    query = self.queries["get_diepitch"].format(**query_data)
                    default_data = await get_query_with_pool(query,resp_type="dict")
                    default = {
                    "layer": default_data[0]['stepid'],
                    "product": default_data[0]['deviceid'],
                    "semvisiontool": default_data[0]['semtoolid'],
                    "recipename": default_data[0]['semrecipename'],
                    "xoffset": "NA",
                    "yoffset": "NA",
                    "xoffsetmax":"NA",
                    "yoffsetmax":"NA",
                    "runorder":data.get("filter").get("primary_filter").get("runorder")[0],
                    "noofwafer": 0,
                    "noofdoi": 0,
                    "unique_id": data.get('inputs').get('unique_id'),
                    "recipelastmodified":"NA"
                    }
                    df = pd.DataFrame([default])
            if len(data_output) >= 1: df["recipelastmodified"] = df.apply(lambda x: self.get_recipelastmodified(x), axis=1)
            final_data = df.round(3).to_dict(orient="records")

            resp["data"] = final_data
            if not update_row:
                app_log.info("Getting the total row count")
                query_to_execute = self.queries["total_data"].format(**query_data)
                result=await get_query_with_pool(query_to_execute,resp_type="dict")
                query_to_execute = self.queries["last_fileupload_time"]

                file_time=await get_query_with_pool(query_to_execute,resp_type='list')
                resp["updatedon"] = file_time[0][0]
                resp["limit"] = data.get("limit")
                resp["order"] = await self.table_order(userid)
                resp["offset"] = data.get("offset")
                resp["total"] = len(result)

        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error while preparing data {e}")

        return resp
