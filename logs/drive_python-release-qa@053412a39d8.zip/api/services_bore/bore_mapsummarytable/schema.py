'''Schema for Payload and response for BORE_MST'''
from typing import List, Optional, Union
from pydantic import BaseModel, Field


class ResultTimestamp(BaseModel):
    '''Time Stamp for Inspection Results'''
    min: str = Field(None, example="09-08-2023T01:40:51")
    max: str = Field(None, example="09-02-2024T01:41:31")

class PrimaryFilter(BaseModel):
    ''' Input values of Primary Filter for Inspection Queries '''
    semvisiontool: Union[list, None] = Field([], example=["Bore_Sample"])
    product: Union[list, None] = Field([], example=["Bore_Sample_3"])
    layer: Union[list, None] = Field([], example=["Bore_Sample_3",])
    recipename: Union[list, None] = Field([], example=["Bore_Sample"])
    resulttimestamp: ResultTimestamp


class SecondaryFilter(BaseModel):
    '''Secondary Filter class include wafer_levl, defect_level and dynamic_level filters'''
    wafer_level_filter: Optional[dict[str, dict]] = Field(None, example={
        "lotrecord": {"selected": ["Bore_Sample"]},
        "waferid": {"selected": ["ENeladmati_2"]}
    })
    defect_level_filter: Optional[dict[str, dict]] = Field(None, example={
        "aspectratio": {"selected": [{"min": "0.016", "max": "0.624"}]},
        "adrhighscore": {"selected": [{"min": "1480.15", "max": "9929.52"}]}
    })
    dynamic_filter: Optional[dict[str, dict]] = Field(None, example={
        "dfgh": {"selected": [{"min": "", "max": ""}]}
    })
    # fov_margin : Optional[str] = Field(None, example="1")

class Filter(BaseModel):
    '''Primary Filter is passed for MST'''
    primary_filter: PrimaryFilter
    secondary_filter:Optional[SecondaryFilter]


class Payload(BaseModel):
    '''Payload class for mapsummarytable '''
    filter: Filter
    sort: Optional[dict]
    limit:Optional[int]
    offset: Optional[int]
    inputs:  Optional[dict] = Field({}, example={"unique_id": "1454937703358768176"})

class Response(BaseModel):
    '''Response Model of MST'''
    data: List[dict] = Field([{}], example=[{
        "layer": "Bore_Sample_3",
        "product": "Bore_Sample_3",
        "semvisiontool": "Bore_Sample",
        "recipename": "Bore_Sample",
        "runorder": 2,
        "recipelastmodified": "01/10/24",
        "recipelastmodified_count": 1,
        "xoffset": 0,
        "yoffset": 0,
        "xoffsetmax": 0,
        "yoffsetmax": 0,
        "noofwafer": 1,
        "noofdoi": 11,
        "unique_id": "1454937703358768176"
    }])
