"""Schema for pyaload of bore_charts"""
from typing import Union,List,Optional
from pydantic import BaseModel,Field

class ResultTimestamp(BaseModel):
    '''Time Stamp for Inspection Results'''
    min: str = Field(None, example="08-08-2023T14:32:32")
    max: str = Field(None, example="08-02-2024T14:34:35")

class PrimaryFilter(BaseModel):
    ''' Input values of Primary Filter for Inspection Queries '''
    semvisiontool: Union[list, None] = Field([], example=["Bore_Sample"])
    product: Union[list, None] = Field([], example=["Bore_Sample_3"])
    layer: Union[list, None] = Field([], example=["Bore_Sample_3",])
    recipename: Union[list, None] = Field([], example=["Bore_Sample"])
    resulttimestamp: ResultTimestamp


class SecondaryFilter(BaseModel):
    '''Secondary Filter class include wafer_levl, defect_level and dynamic_level filters'''
    wafer_level_filter: Optional[dict[str, dict]] = Field(None, example={
        "lotrecord": {"selected": ["Bore_Sample"]},
        "waferid": {"selected": ["ENeladmati_2"]}
    })
    defect_level_filter: Optional[dict[str, dict]] = Field(None, example={
        "aspectratio": {"selected": [{"min": "0.016", "max": "0.624"}]},
        "adrhighscore": {"selected": [{"min": "1480.15", "max": "9929.52"}]}
    })
    dynamic_filter: Optional[dict[str, dict]] = Field(None, example={
        "dfgh": {"selected": [{"min": "", "max": ""}]}
    })
class Filter(BaseModel):
    '''Filter class includes both level of filters,
        Primary and Secondary'''
    primary_filter: PrimaryFilter
    secondary_filter:Optional[SecondaryFilter]

class Payload(BaseModel):
    """Payload detail for bore_charts"""
    filter: Filter
    inputs: dict = Field(None, example={"unique_id": "1454937703358768176"})


class defect_detail(BaseModel):
    """Payload detail for defect table"""
    filter: Filter
    inputs: dict = Field(None, example={"unique_id": "1454937703358768176"})
    sort: Optional[dict] = Field(None, example={"stepid": "ASC"})
    limit:Union[int, None] = Field(None, example=10)
    offset:Union[int, None] = None

class ChartsResponse(BaseModel):
    '''Response Model for bore_charts'''
    data: List[dict] = Field([{}], example=[
        {
            "yaxis_nomdo": 0.0,
            "xaxis_nomdo": 0.0,
            "defectid": 74,
            "semtoolid": "Bore_Sample",
            "adrhighscore": 3450.72,
            "product": "Bore_Sample_3",
            "layer": "Bore_Sample_3",
            "runnumber": 2,
            "defectsize": 1434.0,
            "aspectratio": 0.113,
            "waferid": "ENeladmati_2",
            "lotid": "Bore_Sample"
        },
        {
            "yaxis_nomdo": 0.0,
            "xaxis_nomdo": 0.0,
            "defectid": 100,
            "semtoolid": "Bore_Sample",
            "adrhighscore": 1978.93,
            "product": "Bore_Sample_3",
            "layer": "Bore_Sample_3",
            "runnumber": 2,
            "defectsize": 3069.0,
            "aspectratio": 0.374,
            "waferid": "ENeladmati_2",
            "lotid": "Bore_Sample"
        }])
    max_fov:int = Field(example = 4)

class DefectTableResponse(BaseModel):
    '''Response Model for bore defet table'''
    data: List[dict] = Field([{}], example=[
        {
            "xOffset": 0.0,
            "yOffset": 0.0,
            "semtoolid": "Bore_Sample_8",
            "deviceid": "Bore_Sample_8",
            "stepid": "Bore_Sample_8",
            "doassistenabled": "Yes",
            "orientationmarklocation": "DOWN",
            "rod": "false",
            "semga": "false",
            "semrecipename": "Bore_Sample_8",
            "recipelastmodifieddate": "2024-10-01",
            "platformtype": "SEMVisionG7",
            "lotrecord": "Bore_Sample",
            "waferid": "ENeladmati_2",
            "resulttimestamp": "2024-01-15 14:28:04",
            "xdiepitch": 20000.0,
            "samplesize": 300000,
            "samplecenterlocation": "18877.16,3134.72",
            "dieorigin": "0.0,0.0",
            "runorder": 3,
            "scanset": 5,
            "scansettype": "ADR",
            "opticstype": "SEM",
            "workingpoint": "RES,MPSI,0.5mm,600.0V,9000.0V,-300.0V,2000.0pA,0.0deg,0.0deg,-2900.0V,10,C,Production",
            "scanrate": "3",
            "pixelsize": 4.166,
            "frames": 8,
            "ydiepitch": 6760.069,
            "defectid": 3,
            "xrel": 2059.595,
            "yrel": 3460.166,
            "xreladr": 2059.595,
            "yreladr": 3460.166,
            "xreldo": 2060.0,
            "yreldo": 3460.0,
            "xreladrdo": 2059.595,
            "yreladrdo": 3460.166,
            "semxsize": 725.0,
            "semysize": 1913.0,
            "semdsize": 2045.0,
            "aspectratio": 0.379,
            "adrhighscore": 9929.51,
            "classnumber": 10,
            "nvdclass": "1",
            "fov": 4.0,
            "reviewstatus": 1,
            "defectdo": 0,
            "xindex": -1.0,
            "yindex": -12.0,
            "xindexdo": -1.0,
            "yindexdo": -12.0,
            "xindexadr": -1.0,
            "yindexadr": -12.0,
            "xindexadrdo": -1.0,
            "yindexadrdo": -12.0,
            "new": "",
            "tmp.1": 1
        }])
    order: List[dict] = Field([{}], example=[
    {
      "columnname": "semtoolid",
      "isselected": "true",
      "isdynamic": "false",
      "sort": "DESC",
      "label": "SEM Tool ID"
    },
    {
      "columnname": "deviceid",
      "isselected": "true",
      "isdynamic": "false",
      "sort": "DESC",
      "label": "Product"
    }])
    limit: int = Field(example = 10)
    offset: int = Field(example = 0)
    total: int = Field(example = 33)

class WaferMapResponse(BaseModel):
    '''Response model for bore wafer map'''
    __root__: List[dict] = Field([{}], example=[
    {
        "layer": "Bore_Sample_8",
        "product": "Bore_Sample_8",
        "semvisiontool": "Bore_Sample_8",
        "lotid": "Bore_Sample",
        "waferid": "ENeladmati_2",
        "runnumber": 2,
        "xoffset": 0.0,
        "yoffset": 0.0,
        "xindex": -1.0,
        "yindex": -12.0,
        "vectorlength": 3380.0345,
        "vector angle": 0.0
    }])

class WaferDetailResponse(BaseModel):
    '''Response model for bore wafer details'''
    __root__: dict = Field({},example =
    {
    "samplesize": 300000,
    "xdiepitch": 20000.0,
    "ydiepitch": 6760.069,
    "orientationmarklocation": "DOWN",
    "samplecntreloaction_x": "18877.16",
    "samplecntreloaction_y": "3134.72"
})
