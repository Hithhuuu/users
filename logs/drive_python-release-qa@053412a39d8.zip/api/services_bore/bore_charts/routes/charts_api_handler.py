"""Handler file for charts"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends, Request
from fastapi.encoders import jsonable_encoder
from api.services_bore.bore_charts.common.fastapi_app import verify_jwt
# from api.services_bore.bore_charts.schema import(
#     Payload,ChartsResponse,defect_detail,WaferMapResponse,DefectTableResponse,WaferDetailResponse)
from api.services_bore.bore_charts.routes.defect_table_model import defect_table
from api.services_bore.bore_charts.routes.charts_api_model import Charts
from api.services_bore.bore_charts.routes.bore_waferdetails import wafers,wafermap

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))


router = APIRouter(dependencies=[Depends(verify_jwt)])

@router.post("/charts",tags=['DRive'])
async def post(body: dict):
    """For handling post request for charts"""
    chart_data = Charts()
    body = jsonable_encoder(body)
    resp = await chart_data.get(body)
    if "error" in resp:
        return JSONResponse(
            status_code = 400,
            content = {"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/charts/waferdetails",tags=['DRive'])
async def posts(body:dict):
    """For handling post request for charts"""
    wafer_details = wafers()
    body = jsonable_encoder(body)
    resp = await wafer_details.get(body)
    if "error" in resp:
        return JSONResponse(
            status_code = 400,
            content = {"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/charts/wafermap",tags=['DRive'])
async def post_wafermap(body: dict):
    """For handling post request for charts"""
    wafer_details = wafermap()
    body = jsonable_encoder(body)
    resp = await wafer_details.get(body)
    if "error" in resp:
        return JSONResponse(
            status_code = 400,
            content = {"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)


@router.post("/charts/defecttable",tags=['DRive'])
async def defect_post(request :Request, body: dict):
    """ "Post method for defect table"""
    value = defect_table()
    authorization_header = request.headers.get("Authorization")
    body = jsonable_encoder(body)
    body['authorization_header'] = authorization_header
    resp = await value.get_defect_table_values(data = body)
    return JSONResponse(resp)
