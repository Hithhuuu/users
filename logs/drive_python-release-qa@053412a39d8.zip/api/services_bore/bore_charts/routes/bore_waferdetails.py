"""Model file for charts"""
import math
from api.services_bore.bore_charts.common.utils import get_logger,get_queries2
from api.services_bore.bore_charts.common.common import execute_query, get_header_defect_condition
from api.services_bore.bore_charts.common.fastapi_app import get_query_with_pool

app_log = get_logger("bore_waferdetail")
class wafers:
    def __init__(self):
        """Initializing instance"""
        # self.connection = conn_pool
        self.queries = get_queries2("bore_charts")



    async def get(self, data):
        """To Get the wafer details with or without the filter"""
        try:
            query_data = get_header_defect_condition(data)
            query_to_execute = self.queries["wafer_details"].format(**query_data)
            result = await get_query_with_pool(query_to_execute,resp_type="dict")
            if result[0]['orientationmarklocation'] == "DOWN":
                samplecenterlocation = result[0]["samplecenterlocation"]
                samplecenterlocation_parts = samplecenterlocation.split(',')
                samplecntreloaction_x = str(samplecenterlocation_parts[0].strip())
                samplecntreloaction_y = str(samplecenterlocation_parts[1].strip())
                result[0]["samplecntreloaction_x"] = samplecntreloaction_x
                result[0]["samplecntreloaction_y"] = samplecntreloaction_y
                del result[0]["samplecenterlocation"]
                return result[0]
            else:
                return []
        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}


class wafermap:
    def __init__(self):
        """Initializing instance"""
        # self.connection = conn_pool
        self.queries = get_queries2("bore_charts")


    async def get(self, data):
        """To Get the wafer details with or without the filter"""
        try:
            query_data = get_header_defect_condition(data)
            query_data['runorder'] = tuple(data.get('filter').get('primary_filter').get('runorder',[]))
            query_to_execute = self.queries["wafer_map"].format(**query_data)
            result = await get_query_with_pool(query_to_execute,resp_type="dict")
            result_filtered = [item for item in result if item['xoffset'] != 0.0 and item['yoffset'] != 0.0]
            if len(result_filtered) == 0 or result_filtered[0]['orientationmarklocation'] !='DOWN' :
                    return []
            else:
                for item in result_filtered:
                    xoffset = item['xoffset']
                    yoffset = item['yoffset']
                    vector_angle_rad = math.atan2(yoffset, xoffset)
                    vector_angle_deg = math.degrees(vector_angle_rad)
                    item['vector angle'] = vector_angle_deg

        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}
        return result_filtered
