"""Model file for charts"""
from api.services_bore.bore_charts.common.utils import get_logger,get_queries2
from api.services_bore.bore_charts.common.common import execute_query, get_header_defect_condition
from api.services_bore.bore_charts.common.fastapi_app import get_query_with_pool

app_log = get_logger("chart")
class Charts:
    def __init__(self):
        """Initializing instance"""
        # self.connection = conn_pool
        self.queries = get_queries2("bore_charts")

    async def stacking(self, data, query_data, mdo_type):
        query_data["zoom_condition"] = ""
        xcord = data.get("xcord", {})
        ycord = data.get("ycord", {})
        if xcord:
            query_data["zoom_condition"] = (
                query_data["zoom_condition"]
                + f" and (xaxis_{mdo_type} between {xcord['min']} and {xcord['max']}) "
            )
        if ycord:
            query_data["zoom_condition"] = (
                query_data["zoom_condition"]
                + f" and (yaxis_{mdo_type} between {ycord['min']} and {ycord['max']}) "
            )

        query_to_execute = self.queries[f"read_chart_{mdo_type}"].format(**query_data)

        return query_to_execute

    async def get(self, data):
        """To Get the charts data with or without the filter"""
        try:
            query_data = get_header_defect_condition(data)
            query_data['runorder'] = tuple(data.get('filter').get('primary_filter').get('runorder',[]))
            total_query_to_execute = self.queries["total_data"].format(**query_data)
            result = await get_query_with_pool(total_query_to_execute,resp_type="dict")
            datapoint_count = result[0].get("count", 0)
            mdo_type = data["inputs"].get("mdo_type",0)
            if datapoint_count > 3000 and mdo_type == 0:
                query_to_execute = self.queries["read_charts_data"].format(**query_data)
                data_df = await get_query_with_pool(query_to_execute,resp_type="df")

            elif mdo_type == 0:
                query_to_execute = self.queries["read_chart_data_less_points"].format(**query_data)
                data_df = await get_query_with_pool(query_to_execute,resp_type="df")

            else:
                inputs = data.get("inputs")
                query_to_execute = await self.stacking(inputs, query_data, mdo_type)
                data_df = await get_query_with_pool(query_to_execute,resp_type="df")

            if len(data_df)!=0:
                max_fov = int(data_df["fov"].max())
                data_df = data_df.drop(["fov"], axis=1)
                data_dict = data_df.sort_values(by="semtoolid").round(3).to_dict("records")
            else:
                return {"data": [], "max_fov": ""}

            result = {"data": data_dict, "max_fov": max_fov}
            return result
        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}
