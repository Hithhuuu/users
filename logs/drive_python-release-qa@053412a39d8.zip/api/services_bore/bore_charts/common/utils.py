"""Utils file for application"""
import os
import sys
import logging
from glob import glob
import base64
from hashlib import md5
from logging.handlers import TimedRotatingFileHandler
import yaml
from asynch import pool as pool_async
from asynch.connection import Connection, connect
import sqlalchemy as sa
from Crypto.Cipher import AES
from Crypto import Random
# from clickhouse_driver import connect
import sqlalchemy.pool as pool

FORMATTER = logging.Formatter(
    "%(asctime)s — %(name)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s"
)
LOG_FILE = "logs/drive.log"
CONFIG_FILE = "./api/configs/config.yaml"
COLUMNS_FILE = "./api/configs/columns.yaml"

## uncomment in your local
# os.environ["APP_SERVER"] = "dcilpb1826"
# os.environ["DB_SERVER"] = "dcilpb1827"


def get_env_config():
    """Return the config read from config.yaml file"""
    env = os.getenv("env")
    if env is None:
        env = "local"
    with open(CONFIG_FILE) as file:
        try:
            config = yaml.load(
                file.read().format(**dict(os.environ)), Loader=yaml.SafeLoader
            )
        except Exception as e:
            config = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return config["env"][env.lower()]


def configs():
    """Return the repeated strings from config.yaml file"""
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config


def get_repeated_strings():
    """Return the repeated strings from config.yaml file"""
    with open(CONFIG_FILE) as file:
        config = yaml.load(file, Loader=yaml.SafeLoader)
    return config["repeated_strings"]


def unpad(data):
    """doing unpaddling"""
    return data[: -(data[-1] if type(data[-1]) == int else ord(data[-1]))]

def bytes_to_key(data, salt, output=48):
    """creates key_iv"""
    assert len(salt) == 8, len(salt)
    data += salt
    key = md5(data).digest()
    final_key = key
    while len(final_key) < output:
        key = md5(key + data).digest()
        final_key += key
    return final_key[:output]


def pad(data):
    """adds padding"""
    bs = 16
    return data + (bs - len(data) % bs) * chr(bs - len(data) % bs)


def encrypt(password, key):
    """Encrypts password"""
    data = pad(password)
    salt = Random.new().read(8)
    key_iv = bytes_to_key(key, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return base64.b64encode(b"Salted__" + salt + aes.encrypt(bytes(data, "utf-8")))


def decrypt(encrypted, passphrase):
    """Decrypts password"""
    encrypted = base64.b64decode(encrypted)
    assert encrypted[0:8] == b"Salted__"
    salt = encrypted[8:16]
    key_iv = bytes_to_key(passphrase, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return unpad(aes.decrypt(encrypted[16:]))




async def get_async_connection_pool():
    """Creates and returns a Connection Pool"""
    return await pool_async.create_pool(
        minsize=6,
        maxsize=10,
        host=env_config["db_hostname"],
        port=9000,
        database="drive",
        user= decrypt(env_config["db_userid"], bytes(
            env_config["password_secret_key"], "utf-8")).decode("utf-8"),
        password= decrypt(env_config["db_password"], bytes(
            env_config["password_secret_key"], "utf-8")).decode("utf-8")
    )



def get_queries2(service):
    '''Retrieves queries from a YAML file based on the provided service name'''
    path = os.path.abspath(os.getcwd())
    query_files = glob(path + "/api/*/*/"+f"{service}.yaml", recursive=True)
    queries = dict()
    for qfile in query_files:
        # key = os.path.splitext(os.path.basename(qfile))[0]
        with open(qfile) as file:
            queries[service] = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
    return queries[service]


def get_env_config():
    """Return the config read from config.yaml file"""
    env = os.getenv("env")
    if env is None:
        env = "dev"
    param_dict = dict(os.environ)
    param_dict["env"] = env
    with open(CONFIG_FILE) as file:
        config = yaml.load(file.read().format(**param_dict), Loader=yaml.SafeLoader)
        file.close()
    return config["env"]


def create_directories():
    """Initialize all required directories"""
    for d in get_env_config()["directories"].values():
        if not (os.path.isdir(d)):
            os.mkdir(d)
    return True



def get_common_queries():
    """Get common queries used across api"""
    path = os.path.abspath(os.getcwd())
    common_query_file = path + "/queries/common.yaml"
    queries = {}
    with open(common_query_file) as file:
        queries["common"] = yaml.load(file, Loader=yaml.SafeLoader)
    return queries


def get_queries():
    '''Retrieve queries from YAML files in the specified directory
        and return them as a dictionary'''
    path = os.path.abspath(os.getcwd())
    query_files = glob(path + "/api/*/*/*.yaml", recursive=True)
    queries = dict()
    for qfile in query_files:
        key = os.path.splitext(os.path.basename(qfile))[0]
        with open(qfile) as file:
            queries[key] = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
    return queries


def get_console_handler():
    '''Create a console handler for logging to the console.'''
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def get_file_handler(log_file):
    '''Create a file handler for logging to a file, with log file rotation based on time.'''
    file_handler = TimedRotatingFileHandler(log_file, when="midnight", backupCount=30)
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_config():
    """Return the config read from config.yaml file"""
    env = os.getenv("env")
    if env is None:
        env = "dev"
    param_dict = dict(os.environ)
    param_dict["env"] = env
    with open(CONFIG_FILE) as file:
        config = yaml.load(file.read().format(**param_dict), Loader=yaml.SafeLoader)
        file.close()
    return config


def get_logger(logger_name):
    """
    Creates a logger for the api's
    param: logger name
    return: logger object
    """
    create_directories()
    logger = logging.getLogger(logger_name)
    # better to have too much log than not enough
    logger.setLevel(logging.DEBUG)
    logger.addHandler(get_console_handler())
    logger.addHandler(get_file_handler(f"logs/{logger_name}.log"))
    # with this pattern, it's rarely necessary to propagate the error up to parent
    logger.propagate = False
    return logger


def get_columns_info():
    """Return the config read from columns.yaml file"""
    with open("api/configs/columns.yaml") as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
        file.close()
    return columns


def get_column_details(key):
    """Gets the details from columns file in config"""
    with open(COLUMNS_FILE) as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
    if key in ["v7", "v8"]:
        return columns[f"header_meta_for_{key}_file"]
    elif key == "filter":
        return columns["filter_dict"]
    elif key == "alias":
        return columns["alias_dict"]
    elif key == "header_cols":
        return columns["header_cols"]
    elif key == "columns":
        return columns


# reused variables
config = configs()
env_config = get_env_config()
#queries2 = get_queries2()
#queries = get_queries()
# common_query = get_common_queries()["common"]
