from api.services_bore.bore_charts.common.fastapi_app import app
from api.services_bore.bore_charts.routes import charts_api_handler

app.include_router(charts_api_handler.router)
