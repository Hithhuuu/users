"""Handler file for Export"""
import os
from fastapi.responses import JSONResponse,Response
from fastapi import APIRouter,Depends, Request
from fastapi.encoders import jsonable_encoder
from api.services_bore.bore_export.common.fastapi_app import verify_jwt
from api.services_bore.bore_export.routes.bore_export_model import Export
from api.services_bore.bore_export.common.utils import get_logger, get_user
# from api.services_bore.bore_export.schema import Payload,Response

router = APIRouter(prefix='/export',  dependencies=[Depends(verify_jwt)])
export = Export()


@router.post("/trigger",tags=['DRive'])
async def triggerexport(body: dict, request: Request):
    """Post method for triggering page export"""
    body=jsonable_encoder(body)
    body['username'] = get_user(request).get("userid")
    resp = await export.trigger(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"}
        )
    return JSONResponse(content=resp)


@router.get("/fetchfilter",tags=['DRive'])
async def savefilter(request: Request):
    """Post method for Population of Global filters"""
    query_params = request.query_params
    id = query_params.get('id')

    resp = await export.fetch_filter(id)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"}
        )
    return JSONResponse(content=resp)



@router.post("/rowlevel")
async def post(body: dict,response: Response):
    """Getting the data from db with key values"""
    export = Export()
    # body=jsonable_encoder(body)
    resp= await export.get_excel(body)
    if "Nodata" in list(resp.keys()):
        return Response(
            status_code=204,
            #content='',
        )
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    file_name=f"export/{resp['file_name']}"
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    #async def upload_file(file_name):
    with open(file_name,"rb") as fi:
        contents=fi.read()

    if os.path.exists(f"{file_name}"):
        os.remove(f"{file_name}")

    return Response(content=contents)