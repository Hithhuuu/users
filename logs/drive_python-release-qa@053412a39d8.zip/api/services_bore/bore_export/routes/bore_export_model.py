"""Model file for Export"""
import os
import json
import asyncio
import smtplib
import datetime
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from datetime import datetime
from html2image import Html2Image
from PIL import Image
from io import BytesIO
from pyppeteer import launch
from promise import Promise
from pptx import Presentation
from pptx.util import Inches
from fpdf import FPDF
from fpdf.fonts import FontFace
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from api.common.auth import extract_user_id
from api.services_bore.bore_export.common.utils import get_queries2,get_logger,get_column_details,get_columns_info, env_config
from api.services_bore.bore_export.common.fastapi_app import get_query_with_pool
from api.services_bore.bore_export.common.common import get_header_defect_condition

hti = Html2Image()

app_log = get_logger("bore_export")
watermark = 'api/common/watermark.png'



def gen_coordinate(val):
    """Function for generating fov coordinate"""
    return [(-val / 2), (-val / 2), (val), (val)]

def create_img(df, type):
    """Functipon for creating the image"""
    defectcolor = "#12D81A"
    if type == "after":
        edgecolor = "#D91C1C"
    elif type == "without":
        edgecolor = "#1CA2D9"

    left, bottom, width, height = gen_coordinate(float(max(df['fov'])))
    rect = Rectangle(
        (left, bottom), width, height, edgecolor=edgecolor, fill=False, alpha=1
    )
    fig, ax = plt.subplots(figsize=(5.8, 4))
    ax.add_patch(rect)
    # if "fov_margin_user" in df.columns and type == "without":
    #     edgecolor_filter = "#D91C1C"
    #     fov_margin_user = max(df["fov_margin_user"].astype(float))
    #     fov_inner = fov_margin_user * float(max(df["Search Fov SEM"]))
    #     if fov_margin_user < 1.0:
    #         left_filter, bottom_filter, width_filter, height_filter = gen_coordinate(
    #             float(fov_inner)
    #         )
    #         rect_inner = Rectangle(
    #             (left_filter, bottom_filter),
    #             width_filter,
    #             height_filter,
    #             edgecolor=edgecolor_filter,
    #             fill=False,
    #             alpha=1,
    #             linestyle="dotted",
    #         )
    #         ax.add_patch(rect_inner)

    ax.scatter(df[f"xaxis_{type}_mdo"], df[f"yaxis_{type}_mdo"], c=defectcolor, s=5)
    ax.axvline(0, c="black", ls="-")
    ax.axhline(0, c="black", ls="-")
    xlim = ( max(df["fov"].astype(int)))
    ylim = (max(df["fov"].astype(int)))
    if xlim > ylim:
        plt.ylim(-xlim - 1, xlim + 1)
        plt.xlim(-xlim - 1, xlim + 1)
    else:
        plt.ylim(-ylim - 1, ylim + 1)
        plt.xlim(-ylim - 1, ylim + 1)

    plt.xlabel("X Offset [μm]")
    plt.ylabel("Y Offset [μm]")
    plt.title(f"True Defects {type} MDO")
    f_name = (
        f"export/{type}_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.png"
    )
    plt.savefig(f"{f_name}", dpi=200)
    plt.close()
    return f_name

async def prepare_query_data_for_export(data, query_data, mapping):
    # query_data["fov_margin"] = (
    #     data["filter"]["secondary_filter"]["fov_margin"]
    #     if data["filter"]["secondary_filter"]["fov_margin"]
    #     else 1
    # )
    app_log.info(f"{query_data =}")
    columns_info = get_column_details("columns")
    defect_cols = columns_info["bore_defect_cols"].split()
    p = f"(select columnname,label from bore_dynamic_filter final where rfg='1')"
    data_out = await get_query_with_pool(p, resp_type="dict")
    dynamics_condition_query = []
    select_query = []
    for d in data_out:
        if f"{d['columnname']}" not in (defect_cols):
            dynamics_condition_query.append(
                f"""defects.dynamic['{d["columnname"]}'] as "{d['label']}" """
            )
            select_query.append(f"""defects."{d['label']}" """)
        if f"({d['columnname']})" not in mapping["bore_detail_table_mapping"].keys():
            mapping["bore_detail_table_mapping"][f"{d['columnname']}"] = f"{d['label']}"

    select_query = " , ".join(select_query)
    dynamic_condition_query = " , ".join(dynamics_condition_query)
    query_data["dynamic_condition"] = (
        f",{dynamic_condition_query}" if dynamic_condition_query else ""
    )
    query_data["select_query"] = f",{select_query}" if dynamic_condition_query else ""
    return query_data

async def table_order(auth_head):
    try:
        userid = await extract_user_id(auth_head)
        query_d = {}
        query_d ['userid'] = userid
        query_to_execute = get_queries2("export")["get_order"].format(**query_d)
        dt_order = await get_query_with_pool(query_to_execute, resp_type="dict")
        if len(dt_order) < 1:
            query_to_execute = get_queries2("export")["get_default"].format(**query_d)
            default_order= await get_query_with_pool(query_to_execute, resp_type="dict")
            order= json.loads(default_order[0]['ordermst'] )
        else:
            order = json.loads(dt_order[0]['ordermst'])

        return order

    except Exception as exception:
        app_log.exception(exception)
        return {"error": "Something went wrong"}

class Export():
    def __init__(self) -> None:
        '''This method initializes the class variables'''
        self.queries = get_queries2("bore_export")
        self.mapping = get_columns_info()

    async def trigger(self, data):
            """
            Triggers the export process for the given data.

            Args:
                data: The data to be exported.

            Returns:
                A dictionary with a message indicating that the page level export has started.
            """
            await self.save_filter(data)
            loop = asyncio.get_event_loop()
            loop.create_task(self.export(data))
            return {'msg':'page level export started'}

    async def export(self, data):
        '''This method generates the page level export for the given id and type'''
        try :
            filename  = f"Bore_Sight_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}"

            ppt = Presentation()

            # browser = await launch({'autoClose': False,'headless':False,'options' : {'args': ['use-gl=swiftshader', '--enable-webgl']}})
            browser = await launch({'autoClose': False,'headless':True, 'executablePath': '/bin/chromium-browser', 'options' : {'args': ['use-gl=swiftshader', '--enable-webgl']}})
            page = await browser.newPage()
            await page.setViewport({
                                    'width': 1920,
                                    'height': 1080,
                                    })
            await page.goto(f'http://{os.getenv("APP_SERVER")}/drive/#/',timeout=60000)
            await page.waitForSelector('.login-box')
            await page.type('#username', 'superuser')
            await page.type('#password', 'password')
            await Promise.all([
            page.click("button[type='submit']",{'waitUntil': 'networkidle0'}),
            ])
            await page.goto(f'http://{os.getenv("APP_SERVER")}/drive/#/bmdashboard/export?id={data.get("id")}')
            await page.waitForSelector('.vp-body-row')
            cookies = await page.cookies()
            parent_element = await page.querySelectorAll('.vp-body-row')
            if not parent_element:
                return
            slide_layout = ppt.slide_layouts[6]
            pdf = FPDF(orientation="landscape", format="a4")
            for i,k in enumerate(parent_element):
                pdf.add_page()
                pdf.set_margins(6.35, 12.7)
                pdf.set_auto_page_break(False)
                pdf.set_draw_color(255, 255, 255)
                pdf.set_line_width(0.5)
                slide = ppt.slides.add_slide(slide_layout)
                await self.create_screenshot(data.get('id'),cookies, i,browser,slide,pdf)
            if data.get('type') == 'pdf'  :
                pdf.output(f"{filename}.pdf")
                await self.send_mail(attachment=f"{filename}.pdf", email = data.get('users'), subject = f"Navigation and Boresight Monitoring Auto report_{datetime.now().strftime('%d-%m-%Y')}")
                if os.path.exists(f"{filename}.pdf"):
                    os.remove(f"{filename}.pdf")
            elif data.get('type') == 'ppt' :
                ppt.save(f"{filename}.pptx")
                await self.send_mail(attachment=f"{filename}.pptx",email = data.get('users'), subject = f"Navigation and Boresight Monitoring Auto report_{datetime.now().strftime('%d-%m-%Y')}")
                if os.path.exists(f"{filename}.pptx"):
                    os.remove(f"{filename}.pptx")
            await browser.close()
        except Exception as e:
            await browser.close()
            kill_chromium = '''kill $(ps -ef | grep '/chromium-browser/' | grep -v grep | awk '{print $2}')'''
            dr_files = os.popen(kill_chromium).read()
            app_log.error(f"Error in Export: {e}")

    async def send_mail(self, **kwargs):
        """
        Sends an email with the specified content, receiver, subject, and optional attachment.

        Args:
            content (str): The content of the email.
            receiver (str): The email address of the receiver.
            subject (str): The subject of the email.
            attachment (str, optional): The file path of the attachment (if any). Defaults to None.

        Returns:
            None
        """
        EMAIL_SIGNATURE = '''<div> Hello <span style='text-transform: capitalize'></span>
                            </div><br /><div>Please find attached the PDF/PPT file
                            generated based on the filters applied to the Boresight
                            Navigation – Map Summary Table.</div><div><br/>
                            Thanks<br/> DRive Auto Reports</div> <style type='text/css'>
                            div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva,
                            Verdana, sans-serif;}    table,    tr,    td, th {
                            border-width: 1px;border-color: #ccc;border-style: solid;
                            border-collapse: collapse;      text-align: left;
                            padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma,
                            Geneva, Verdana, sans-serif;      align: left;      align-items: left;}
                            tr:nth-child(even) {background: #efefef}    tr:nth-child(odd)
                            {background: #FFF}  </style>'''

        email_content =  EMAIL_SIGNATURE
        your_smtp_port = env_config.get('smtp_port')
        host = env_config.get('host')
        msg = MIMEMultipart()
        msg["From"] = env_config.get('server_mail')
        msg["To"] = ', '.join(kwargs.get('email'))
        msg["Subject"] = kwargs.get("subject")
        if kwargs.get("attachment"):
            attach_file_name = kwargs.get("attachment")
            with open(attach_file_name, "rb") as file:
                attachment_content = MIMEApplication(file.read())
                attachment_content.add_header(
                    "Content-Disposition", "attachment", filename=attach_file_name
                )
                msg.attach(attachment_content)
        msg.attach(MIMEText(email_content, "html"))
        with smtplib.SMTP(host, your_smtp_port) as server:
            server.send_message(msg)
        app_log.info(f"Mail sent to {kwargs.get('email')}")

    async def create_screenshot(self, id, cookies, iterator,browser,slide,pdf):
        ''' This method creates the screenshot for the given id and iterator'''
        page = await browser.newPage()
        await page.setViewport({
                                    'width': 2220,
                                    'height': 1280,
                                })
        for cookie in cookies:
            await page.setCookie(cookie)
        await page.goto(f'http://{os.getenv("APP_SERVER")}/drive/#/bmdashboard/export?id={id}')
        await page.waitForSelector('.vp-body-row')
        await page.waitForSelector(selector='.vp-body-row',timeout=60000)
        parent_element = await page.querySelectorAll('.vp-body-row')
        if not parent_element:
            return
        await parent_element[iterator].click()
        data = await parent_element[iterator].querySelectorAllEval('.vp-body-cell  ', '''(elements) => {
            return elements.map(element => {
                const className = element.className;
                const childText = element.querySelector('.vp-span-child-text') ?
                            element.querySelector('.vp-span-child-text').innerText : null;
                return { className, childText };
            });
        }''')
        dict_obj = {
                i.get('className').split('-header')[0].split('vp-body-cell')[-1].strip(): i.get('childText')
                for i in data
            }
        await page.waitForSelector(selector='.UT-boresight-filter-apply-button',timeout=60000)
        await page.click(selector='.UT-boresight-filter-apply-button')
        await page.waitForSelector('#chart-expand')
        await page.click(selector='#chart-expand')
        await page.evaluate('''() => {
                    const element = document.querySelector('.navbar');
                    element.remove()
                }''')
        image_path = f'export/scr_{id}_{iterator}.jpeg'
        await page.waitFor(1000)
        await page.evaluate('''() => {
                    const element = document.querySelector('.distributionCircle');
                    element.style.pointerEvents = 'none';
        }''')
        await page.screenshot({'path': image_path,
                            'type': 'jpeg',
                            'quality': 100,}
                            )
        await self.create_html_img(slide, dict_obj,image_path,pdf)
        return

    async def create_html_img(self,slide , dic , image_path , pdf):
        '''This method creates the html image for the given dictionary and image path'''
        html_str = ''' <!DOCTYPE html>
                            <html>

                            <head>
                                <style>
                                    body {
                                            width: 1950px;
                                            height: 890px;
                                            margin: 0;
                                            padding: 0;
                                            box-sizing: border-box;
                                            background-color: "#FFFFFF";
                                        }
                                    .main-container {
                                            padding: 30px 20px;
                                            background-color: "#FFFFFF";
                                        }
                                    .water-mark-container {
                                            margin: 1% 2%;
                                            display: flex;
                                            justify-content: space-between;
                                        }
                                    .water-mark-right {
                                        position: absolute;
                                        bottom: 10px;
                                        right: 320px;
                                    }
                                    .water-mark-left {
                                        position: absolute;
                                        bottom: 10px;
                                        left: 320px;
                                    }
                                    table {
                                            margin-top: 15px;
                                            margin: auto;
                                            width: 50%;
                                        }
                                    th,
                                    td {
                                            padding: 5px;
                                        }
                                    th {
                                            background-color: #6195C9;
                                            color: white;
                                        }
                                    td {
                                            background-color: #EDF1F6;
                                            /* word-break: break-word; */
                                        }
                                    .image-wrapper {
                                        display: flex;
                                        margin: 0 auto;
                                        margin-top: 50px;
                                        height: 700px;
                                        width: 100%;
                                        justify-content: center;
                                        align-items: center;
                                        }
                                    img {
                                            height: 100%;
                                        }
                                </style>
                            </head>

                            <body>
                                <div class="main-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>SEMVision Tool</th>
                                                <th>Product</th>
                                                <th>Layer</th>
                                                <th>Recipe Name</th>
                                                <th>Recipe Last Modified</th>
                                                <th># Of Wafers</th>
                                                <th># Of DOIs</th>
                                                <th>Run Order</th>
                                                <th>Avg X Offset [um]</th>
                                                <th>Avg Y Offset [um]</th>
                                                <th>Max X Offset [um]</th>
                                                <th>Max Y Offset [um]</th>
                                            </tr>
                                        </thead>
                                        '''
        html_str += f'''<tbody>
                                    <td>{dic['semvisiontool']}</td>
                                    <td>{dic['product']}</td>
                                    <td>{dic['layer']}</td>
                                    <td>{dic['recipename']}</td>
                                    <td>{dic['recipelastmodified']}</td>
                                    <td>{dic['noofwafer']}</td>
                                    <td>{dic['noofdoi']}</td>
                                    <td>{dic['runorder']}</td>
                                    <td>{dic['xoffset']}</td>
                                    <td>{dic['yoffset']}</td>
                                    <td>{dic['xoffsetmax']}</td>
                                    <td>{dic['yoffsetmax']}</td>
                                </tbody>
                            </table>
                            <div class="image-wrapper">
                                </br>
                                </br>
                                <img src="{os.path.join(os.getcwd(),image_path)}"/>
                            </div>
                            <div class="water-mark-container">
                                <div class="water-mark-left">
                                    <img src="{os.path.join(os.getcwd(),watermark)}" />
                                </div>
                            </div>
                            <div class="water-mark-container">
                                <div class="water-mark-right">
                                    APPILED MATERIALS CONFIDENTIAL
                                </div>
                            </div>

                        </div>
                    </body>
                    </html>'''
        path = f'''{image_path.split('.')[0].split('scr_')[-1]}.png'''
        hti.screenshot(html_str=html_str,save_as=path)
        self.add_pdf_image(pdf,dic,path = os.path.join(os.getcwd(),image_path))
        slide.shapes.add_picture(path, left=Inches(-1.8), top=Inches(0), height=Inches(7.5))
        if os.path.exists(path):
            os.remove(path)
        if os.path.exists(image_path):
            os.remove(image_path)
        return

    def add_pdf_image(self,pdf,dic,path):
        '''This method adds the image to the pdf'''
        TABLE_DATA = {"SEMVision Tool" : "semvisiontool" ,
                            "Product" : "product",
                            "Layer" : "layer",
                            "Recipe Name" : "recipename",
                            "Recipe Last Modified" : "recipelastmodified" ,
                            "# Of Wafers" : "noofwafer",
                            "# Of DOIs" : "noofdoi",
                            "Run Order" : "runorder",
                            "Avg X Offset [um]" : "xoffset",
                            "Avg Y Offset [um]" : "yoffset",
                            "Max X Offset [um]" : "xoffsetmax",
                            "Max Y Offset [um]" : "yoffsetmax"}
        pdf.set_font("helvetica", size=10)
        blue = (97, 149, 201)
        grey = (237, 241, 246)
        white = (255, 255, 255)
        with pdf.table(
            align="CENTER",
            first_row_as_headings=False,
            borders_layout="INTERNAL",
        ) as table:
            row = table.row()
            cell_style = FontFace(emphasis="BOLD", color=white, fill_color=blue)
            for ind,val in TABLE_DATA.items():
                    row.cell(ind.replace("μ","u"), style=cell_style)
            row = table.row()
            cell_style1 = FontFace(fill_color=grey)
            for ind,val in TABLE_DATA.items():
                row.cell(dic[val], style=cell_style1)
        pdf.image(os.path.join(os.getcwd(),watermark), h=12 , w=40,x=5,y=195)
        pdf.set_y(-15)
        pdf.set_font("helvetica", "I", 8)
        pdf.cell(0, 10, f"Page {pdf.page_no()}/{{nb}}", align="C")
        pdf.set_x(-15)
        pdf.set_y(-15)
        pdf.set_font("helvetica", "I", 8)
        pdf.cell(0, 10, f"APPLIED MATERIALS CONFIDENTIAL", align="R")
        pdf.image(path, h=135 , w=280,x=10,y=50)

    async def save_filter(self, data):
        """
        Save a filter with the given data and ID.

        Args:
            data (dict): The filter data to be saved.
            id (int): The ID of the filter.

        Returns:
            None
        """
        query_data = {
            "id": int(data.get('id')),
            "username": data.get('username'),
            "filters": json.dumps(data),
            "rfg": '1'
        }
        query_to_execute = self.queries["insert_export_filter"].format(
            **query_data
        )
        await get_query_with_pool(query_to_execute, resp_type="None")

    async def fetch_filter(self, data):
        """Fetch the primary filter applied for a particular id"""
        query_data = {
            "id" : data
        }
        query_to_execute = self.queries["fetch_export_filter"].format(
            **query_data)
        resp = await get_query_with_pool(query_to_execute,resp_type = "dict")
        if resp:
            resp = json.loads(resp[0].get('primary_filter'))
        return resp

    async def get_excel(self, data):
        """To export data for individual row data"""
        app_log.info(f"Starting Export defect table and charts")
        file_name = (
            f"Export_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.xlsx"
        )
        query_data = get_header_defect_condition(data)
        query_data = await prepare_query_data_for_export(data, query_data, self.mapping)
        query_data['runorder'] = tuple(data.get('filter').get('primary_filter').get('runorder',[]))
        query_to_execute = self.queries["export"].format(**query_data)
        app_log.info(query_to_execute)
        data_output = await get_query_with_pool(query_to_execute, resp_type="df")
        if len(data_output) < 1:
            return {"Nodata": "No data for selected filters "}
        df = pd.DataFrame.from_dict(data_output)
        # if data["filter"]["secondary_filter"]["fov_margin"]:
        #     df["fov_margin_user"] = data["filter"]["secondary_filter"]["fov_margin"]
        drop_cols = [
            "yaxis_without_mdo",
            "xaxis_without_mdo"
        ]
        graph_col = [
            "yaxis_without_mdo",
            "xaxis_without_mdo",
            "fov"
        ]
        # after_img = create_img(df[graph_col].drop_duplicates(), "after")
        html = data.get('wafermap')
        height = data.get('dimensions')['height']
        width = data.get('dimensions')['width']
        abc = rf"""
                <!DOCTYPE html>
            <style>
            body{{
                height: 800px;
                width: 800px;
            }}
            .main{{
                    height: {height}px;
                    width: {width}px;
                    background-color: white;
                    display: flex;
                    justify-content: center;
                    }}
            </style>
            <html>
            <body>
        <div class='main'>
        {html} </div>
            </body>
            </html>
        """
        path= f"wafermap_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.png"
        wafer_map_img = hti.screenshot(html_str=abc,save_as=path)
        wafer_map_resized = Image.open(path)
        wafer_map_resized = wafer_map_resized.resize((3000,1800),Image.BICUBIC)  # Specify desired dimensions
        wafer_map_resized.save(path)
        before_img = create_img(df[graph_col].drop_duplicates(), "without")
        writer = pd.ExcelWriter(f"export/{file_name}", engine="xlsxwriter")
        df.drop(drop_cols, axis=1).to_excel(writer, sheet_name="Data", index=False)
        # df.to_excel(writer, sheet_name='Data', index=False)
        workbook = writer.book
        ws = workbook.add_worksheet("chart")
        file = open(before_img, "rb")
        before_data = BytesIO(file.read())
        file.close()
        # image = Image.open(wafer_map_img)
        # file = open(wafer_map_img, "rb")
        # after_data = BytesIO(file.read())
        # file.close()
        ws.insert_image("N4",path)
        ws.insert_image("C4", before_img, {"image_data": before_data})
        workbook.close()
        if os.path.exists(f"{before_img}"):
            os.remove(f"{before_img}")
        if os.path.exists(f"{path}"):
            os.remove(f"{path}")
        return {"file_name": file_name}