"""Fast api app file"""
from api.services_bore.bore_export.common.fastapi_app import app
from api.services_bore.bore_export.routes import bore_export_handler


app.include_router(bore_export_handler.router)
