"""Auth file for application"""
from typing import Optional
from jose import jwt
from jose.jwt import decode
from jose.exceptions import JWTError
from fastapi import HTTPException, Depends, FastAPI, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from api.services_bore.bore_datacleanup.common.utils import env_config

secret_key = env_config['secret_key']

auth_scheme = HTTPBearer()


async def verify_jwt(authorization: HTTPAuthorizationCredentials = Depends(auth_scheme)):
    '''Verify the JWT token for authentication.'''
    jwt_token = authorization.credentials
    try:
        decode(jwt_token, secret_key, algorithms="HS256")
    except JWTError:
        raise HTTPException(status_code=401, detail="Unauthorized token")


async def get_auth_data(request : Request, authorization_header):
    '''Extract authentication data from the request.'''
    if not (request.url.path.endswith("/auth")):
        jwt_token = authorization_header.split()[1]
        data = decode(jwt_token, secret_key, algorithms="HS256")
        return data

async def extract_user_id(authorization_header: Optional[str]) -> str:
    '''Extract the user ID from the authorization header.'''
    if authorization_header is None:
        raise HTTPException(status_code=401, detail="Authorization header is missing")

    try:
        _, token = authorization_header.split()
        payload = jwt.decode(token, secret_key, algorithms=["HS256"])
        return payload.get("userid")
    except (ValueError, JWTError):
        raise HTTPException(status_code=401, detail="Invalid token")
