"""Fast api setup for application"""
import time
import itertools
import datetime
import pandas as pd
from jwt import decode
from jose.exceptions import JWTError
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from api.services_bore.bore_datacleanup.common.utils import get_async_connection_pool, get_logger
from api.services_bore.bore_datacleanup.common.utils import env_config

secret_key = env_config['secret_key']
auth_scheme = HTTPBearer()
app_log = get_logger("fastapi")

app = FastAPI(
    title='DRive',
    description='DRIVE BORESIGHT'
)


@app.on_event("startup")
async def startup():
    """Event handler for application startup."""
    try:
        app.state.pool = await get_async_connection_pool()
        app_log.info("Starting the service")
    except Exception as e:
        app_log.error(e)


@app.on_event("shutdown")
async def shutdown():
    """Event handler for application shutdown."""
    try:
        await app.state.pool.wait_closed()
        await app.state.pool.terminate()
        app_log.info("Shutdown complete")
    except Exception as e:
        app_log.error(e)


async def get_query_with_pool(query, resp_type="df"):
    """Run a query using an async connection pool."""
    conn = await app.state.pool.acquire()
    app_log.debug(f"Query to be executed:\n{query}")
    memory_executor_settings = ["2G", "4G", "10G"]
    try:
        async with conn.cursor() as cur:
            if len(query) > 262144:
                await cur.execute("SET max_query_size = 9999999")
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        app_log.error(f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}")
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")
                    app_log.warning(f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}")
            data = await cur.fetchall()
            col = cur._columns
            if resp_type == "df":
                data = pd.DataFrame(data, columns=col)
            elif resp_type == "dict":
                data = list(map(lambda row: dict(itertools.zip_longest(list(col), row)), data))
                if len(data) != 0:
                    data = [{k: " ".join(val.split("\x00")).strip() if isinstance(val, str) else val for k, val in d.items()} for d in data]
    except Exception as e:
        app_log.exception(f"Query Execution Failed: {str(e)}")
        await app.state.pool.release(conn)
        raise e
    await app.state.pool.release(conn)
    return data


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Middleware to add the processing time of each request as a response header."""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


async def verify_jwt(request: Request, authorization: HTTPAuthorizationCredentials = Depends(auth_scheme)):
    """Verify the JWT token passed in the authorization header."""
    if not (request.url.path.endswith("/auth")):
        jwt_token = authorization.credentials
        try:
            decode(jwt_token, secret_key, algorithms="HS256")
        except JWTError:
            raise HTTPException(status_code=401, detail="Unauthorized token")
        except Exception as e:
            raise HTTPException(status_code=401, detail=str(e) if str(e) else "Unauthorized token")


app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def insert_data(query, list_data):
    """Insert data from a list of tuples or a list of dictionaries."""
    conn = await app.state.pool.acquire()
    app_log.debug("Inserting data using query:\n%s", query)
    start_time = datetime.datetime.now()
    try:
        async with conn.cursor() as cursor:
            cursor.set_settings({"max_memory_usage": "10G"})
            await cursor.execute(query, list_data)
        time_taken = datetime.datetime.now() - start_time
        app_log.info("Data inserted successfully in %s", time_taken)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:\n%s", str(err))
        raise err
    await app.state.pool.release(conn)
