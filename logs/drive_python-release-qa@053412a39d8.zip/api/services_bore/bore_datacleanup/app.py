"""Fast api app file for data cleanup"""
from api.services_bore.bore_datacleanup.common.fastapi_app import app
from api.services_bore.bore_datacleanup.routes import bore_datacleanup_handler
app.include_router(bore_datacleanup_handler.router)