"""Handler file for data cleanup"""
from fastapi.responses import JSONResponse
from fastapi import (APIRouter,Depends)
from api.services_bore.bore_datacleanup.routes.bore_datacleanup_model import datacleanups
from api.services_bore.bore_datacleanup.schema import PayloadData
from api.services_bore.bore_datacleanup.common.fastapi_app import verify_jwt
#from fastapi.encoders import jsonable_encoder

router =APIRouter(dependencies=[Depends(verify_jwt)])

@router.get("/datacleanup")
async def get_current_values():
    """For getting current values based on request for data cleanup"""
    data_cleanup = datacleanups()
    resp = await data_cleanup.get_values()
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)

@router.post("/datacleanup")
async def post_new_data(data: PayloadData):
    """For handling post request for data cleanup"""
    data_cleanup = datacleanups()
    resp = await data_cleanup.new_input(data)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)

