from api.services_bore.bore_order.common.fastapi_app import app
from api.services_bore.bore_order.routes import bore_order_handler


app.include_router(bore_order_handler.router)
