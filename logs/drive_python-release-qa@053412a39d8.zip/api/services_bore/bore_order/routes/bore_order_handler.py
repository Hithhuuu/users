"""Handler file for charts"""
import os
import sys
from fastapi.responses import JSONResponse
from fastapi import APIRouter,Depends,Request
from fastapi.encoders import jsonable_encoder
from api.services_bore.bore_order.common.fastapi_app import verify_jwt
# from api.services_bore.bore_order.schema import PayloadExample,OrderResponse
from api.services_bore.bore_order.routes.bore_order_model import Orders
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

router = APIRouter(dependencies=[Depends(verify_jwt)])

@router.post("/order",tags=['DRive'])
async def post(request: Request,body: dict):
    """For handling post request for charts"""
    authorization_header = request.headers.get("Authorization")
    order_data = Orders()
    body=jsonable_encoder(body)
    body['authorization_header']=authorization_header
    resp = await order_data.order(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)
