'''Model file for charts'''
import json
from api.services_bore.bore_order.common.utils import get_logger,get_queries2,env_config
from api.services_bore.bore_order.common.auth import extract_user_id
from api.services_bore.bore_order.common.fastapi_app import get_query_with_pool

secret_key = env_config['secret_key']

app_log = get_logger("bore_order")
class Orders:
    '''Model class for handling chart orders."'''
    def __init__(self):
        '''Initializing instance'''
        self.queries = get_queries2("bore_order")

    async def order(self, data):
        '''Handles the order data and 
            returns a dictionary indicating the success or error status of the order.'''
        try:
            userid = await extract_user_id(data.get("authorization_header"))
            query_data={
                'mstorder' : "''",
                'dtorder': "''"
            }
            query_data['userid'] = userid
            entry_check = self.queries["entry_check"].format(**query_data)
            have_entry = await get_query_with_pool(entry_check)
            if len(have_entry) <1:
                if data.get("table_type")=="mst":
                    ordermst = json.dumps(data.get("order"))
                    query_data['mstorder'] = f''' '{ordermst}' '''
                    entry_creation = self.queries["entry_creation"].format(**query_data)
                    await get_query_with_pool(entry_creation)
                if data.get("table_type")=="dt":
                    orderdt = json.dumps(data.get("order"))
                    query_data['dtorder'] = f''' '{orderdt}' '''
                    entry_check = self.queries["entry_creation"].format(**query_data)
                    await get_query_with_pool(entry_check)
                return {'message':'order sucessfully entered'}
            else:
                if data.get("table_type")=="mst":
                    ordermst = json.dumps(data.get("order"))
                    query_data['order_cdtn'] = f''' '{ordermst}' as ordermst1, orderdt'''
                if data.get("table_type")=="dt":
                    orderdt = json.dumps(data.get("order"))
                    query_data['order_cdtn'] = f''' ordermst, '{orderdt}' as orderdt1'''
                updating_order = self.queries["updating_order"].format(**query_data)
                await get_query_with_pool(updating_order)
                return {'message':'Order sucessfully updated'}

        except Exception as exception:
            app_log.exception(exception)
            return {"error": "Something went wrong"}
