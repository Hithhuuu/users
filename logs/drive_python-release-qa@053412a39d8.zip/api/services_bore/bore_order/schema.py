"""Schema for pyaload of order"""
from typing import List
from pydantic import BaseModel,Field

class OrderItem(BaseModel):
    '''Class represents attributes of an order item '''
    columnname: str
    isselected: bool
    isdynamic: bool
    sort: str
    label: str

class Payload(BaseModel):
    '''Represents the (Bore_Order) payload for ordering 
        with a list of order items and table type.'''
    order: List[OrderItem]
    table_type: str


class PayloadExample(BaseModel):
    '''Represents an example payload for ordering.
       Attributes:
        - order: A list of dictionaries representing the order items.
        - table_type: A string representing the table type.'''

    order: List[dict] = Field([{}], example = [
        {
        "columnname": "semvisiontool",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "SEMVision Tool"
        },
        {
        "columnname": "product",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Product"
        },
        {
        "columnname": "layer",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Layer"
        },
        {
        "columnname": "recipename",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Recipe Name"
        },
        {
        "columnname": "runorder",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Run Order"
        },
        {
        "columnname": "recipelastmodified",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Recipe Last Modified"
        },
        {
        "columnname": "noofwafer",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "# of Wafers"
        },
        {
        "columnname": "noofdoi",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "# of DOIs"
        },
        {
        "columnname": "xoffset",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Avg X Offset [μm]"
        },
        {
        "columnname": "yoffset",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Avg Y Offset [μm]"
        },
        {
        "columnname": "xoffsetmax",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Max X Offset [μm]"
        },
        {
        "columnname": "yoffsetmax",
        "isselected": "true",
        "isdynamic": "false",
        "sort": "DESC",
        "label": "Max Y Offset [μm]"
        }
    ])
    table_type: str=Field("", example = "mst")

class OrderResponse(BaseModel):
    '''Return a example response for bore order api'''
    __root__: dict = Field({},example={"message":"Order sucessfully updated"})
