"""Handler file for Global filter"""
from fastapi.responses import JSONResponse
from fastapi import APIRouter,Depends
from fastapi.encoders import jsonable_encoder
from api.services_bore.bore_globalfilters.common.fastapi_app import verify_jwt
from api.services_bore.bore_globalfilters.routes.bore_globalfilters_model import GlobalFilters
from api.services_bore.bore_globalfilters.common.utils import get_logger
from api.services_bore.bore_globalfilters.schema import Payload,Response

app_log = get_logger("globalfilters")
router = APIRouter(dependencies=[Depends(verify_jwt)])


@router.post("/globalfilters",tags=['DRive'],response_model=Response)
async def post(body: dict):
    """Post method for Population of Global filters"""
    globalfilter = GlobalFilters()
    body=jsonable_encoder(body)
    resp = await globalfilter.get_filter_values(body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"}
        )
    return JSONResponse(content=resp)
