"""Model file for Global filters"""
import traceback
from datetime import datetime
from api.services_bore.bore_globalfilters.common.utils import get_queries2,get_logger
from api.services_bore.bore_globalfilters.common.fastapi_app import get_query_with_pool
app_log = get_logger("bore_globalfilters")
class GlobalFilters:
    """Class generation for Global filters"""
    def __init__(self):
        """Initialize template."""
        self.queries = get_queries2("bore_globalfilters")

    async def get_filter_values(self, data):
        """Function for getting values for Global filters"""
        try:
            app_log.info("Preparing response for report history")
            app_log.info(f"filter values paylaod {data}")
            query_data =  await self.make_query(data)
            query_to_execute = self.queries["read_global_filter_values"].format(
                **query_data
            )
            app_log.info(f"read Query: {query_to_execute}")

            data_df = await get_query_with_pool(query_to_execute,resp_type="df")
            data_output = {
                "semvisiontool": sorted(data_df["semtoolid"].unique().tolist()),
                "product": sorted(data_df["deviceid"].unique().tolist()),
                "layer": sorted(data_df["stepid"].unique().tolist()),
                # "doassistenabled": ["Yes", "No"],
                "recipename" : sorted(data_df["semrecipename"].unique().tolist()),
                "runorder" : sorted(data_df["runorder"].unique().tolist())
            }

        except Exception as e:
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return KeyError(f"Error while preparing data {e}")

        return data_output

    async def make_query(self,data):
        """This function is used to create queries"""
        query_data = {}
        query_condition = []
        query_cdtn_defect =[]
        for i in data.get('filter').get('primary_filter').keys():
            if  i == "resulttimestamp":
                startdate = data.get('filter').get(
                    'primary_filter').get('resulttimestamp').get('min')
                enddate = data.get('filter').get(
                    'primary_filter').get('resulttimestamp').get('max')
                startdate = datetime.strptime(startdate,
                    "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                enddate = datetime.strptime(enddate,
                    "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                query_condition.append(f"{i} BETWEEN ('{startdate}') and ('{enddate}')")
            elif i =="runorder" and len(data.get('filter').get('primary_filter').get(i))>0 :
                query_cdtn_defect.append(
                    f"{i} in {tuple(data.get('filter').get('primary_filter').get(i,[]))}")
            elif len((data.get('filter').get('primary_filter').get(i,[]))) >0:
                query_condition.append(
                    f"{i} in {tuple(data.get('filter').get('primary_filter').get(i,[]))}")
        query_data['header_cdtn'] = f"and {' and '.join(query_condition)}"
        for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("semvisiontool", "semtoolid"),("recipename","semrecipename"),("recipelastmodified","recipelastmodifieddate")]:
            query_data['header_cdtn'] = query_data['header_cdtn'].replace(f"{old_key} in", f"{new_key} in")
        if len(query_cdtn_defect)>0:
            query_data['defect_cdtn'] = f"and {' and '.join(query_cdtn_defect)}"
            for old_key, new_key in [("layer", "stepid"), ("product", "deviceid"), ("semvisiontool", "semtoolid"),("recipename","semrecipename"),("recipelastmodified","recipelastmodifieddate")]:
                query_data['defect_cdtn'] = query_data['defect_cdtn'].replace(f"{old_key} in", f"{new_key} in")
        else:
            query_data['defect_cdtn'] = ""
        return query_data
