"""Fast api app file"""
from api.services_bore.bore_globalfilters.common.fastapi_app import app
from api.services_bore.bore_globalfilters.routes import bore_globalfilters_handler


app.include_router(bore_globalfilters_handler.router)
