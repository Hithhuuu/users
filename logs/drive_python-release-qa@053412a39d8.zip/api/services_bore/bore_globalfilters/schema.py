'''Schema For Global Filters'''
from typing import List, Union
from pydantic import BaseModel,Field

class ResultTimestamp(BaseModel):
    '''Time range for fetching Inspection Results'''
    min: str = Field(None, example="08-08-2023T14:32:32")
    max: str = Field(None, example="08-02-2024T14:34:35")

class PrimaryFilter(BaseModel):
    '''Global Filter values for inspection queries'''
    semvisiontool: Union[list, None] = Field([], example=["Bore_Sample"])
    product: Union[list, None] = Field([], example=["Bore_Sample_3"])
    layer: Union[list, None] = Field([], example=["Bore_Sample_3",])
    recipename: Union[list, None] = Field([], example=["Bore_Sample"])
    resulttimestamp: ResultTimestamp

class Filter(BaseModel):
    '''Primary Filter for Global Filters'''
    primary_filter: PrimaryFilter


class Payload(BaseModel):
    '''Payload class for Global filters '''
    filter: Filter

class Response(BaseModel):
    '''Response model for Globalfilters'''
    semvisiontool: List[str] = Field([], example=["Bore_Sample"])
    product: List[str] = Field([], example=["Bore_Sample_3"])
    layer: List[str] = Field([], example=["Bore_Sample_3"])
    recipename: List[str] = Field([], example=["Bore_Sample"])
