'''Configures the FastAPI application by including routers for various Bore API endpoints.'''
from api.common.utils import get_logger
from api.common.fastapi_app import app
from api.services_bore.bore_globalfilters.routes import bore_globalfilters_handler
from api.services_bore.bore_mapsummarytable.routes import bore_mapsummarytable_handler
from api.services_bore.bore_mapsummarytablefilters.routes import bore_mapsummarytablefilters_handler
from api.services_bore.bore_charts.routes import charts_api_handler
from api.services_bore.bore_order.routes import bore_order_handler

app_log = get_logger("bore_swagger")
app_log.info("getting all bore apis details")


app.include_router(bore_globalfilters_handler.router)
app.include_router(bore_mapsummarytable_handler.router)
app.include_router(bore_mapsummarytablefilters_handler.router)
app.include_router(charts_api_handler.router)
app.include_router(bore_order_handler.router)
