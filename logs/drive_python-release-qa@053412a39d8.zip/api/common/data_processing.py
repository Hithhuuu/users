import traceback
import itertools
import numpy as np
import pandas as pd

from parsers.parse_v7_klarf import extract_klarf_files
from parsers.parse_xml import extract_xml_df
from api.common.fastapi_app import get_query_with_pool
from api.common.utils import get_logger, config
from api.common.common import update_job_status, move_file_rejected,execute_query
from api.common.fastapi_app import insert_data


app_log = get_logger('data_load')
default_batch_size = config['DEFAULT_BATCH_SIZE']
MAX_NUM_PROCESSES = config['MAX_NUM_PROCESSES']

# app = Celery('tasks', broker=env_config['broker'], backend=env_config['backend'])

# @app.task(bind=True)
async def dataload_tool(xml_file, klarf_file, job_id):
    """
    validates klarf with corresponding xml and inserts data into clickhouse 
    """

    filename = klarf_file.split('/')
    app_log.info(f"Processing Data for {filename=} : {job_id=}")
    await update_job_status({'job_id':job_id,'job_status':'picked','xml_file_path':xml_file,'klarf_file_path':klarf_file})
    try:
        app_log.info(f"Starting xml parser")
        xml_df = extract_xml_df(xml_file)
        if xml_df.empty:
            return {'err_message': 'failed due to xml parsing'}

        if xml_df['stepid'].iloc[0] is None:
            return {'job_id':job_id,'job_status':'rejected','err_message':'XML-Klarf pair not valid','xml_file_path':xml_file,'klarf_file_path':klarf_file}

        parsed_data = extract_klarf_files(klarf_file,xml_df)
        if "error" in parsed_data:
            raise Exception(parsed_data["error"])

        for k, v in parsed_data.items():
            unique_data = await verify_mapname(job_id, xml_df, v['prefix_metadata'], v['main_data'], xml_file, klarf_file)
            if unique_data.get('err_message', []):
                klarf_path, xml_path= move_file_rejected(klarf_file, xml_file, 'rejected')
                await update_job_status({'job_id': unique_data['job_id'], 'job_status': unique_data['job_status'],
                                'err_message': unique_data.get('err_message'),'xml_file_path':xml_path,'klarf_file_path':klarf_path})
                raise Exception("Error while loading data")
            else:
                await push_data(unique_data)
                
        await update_job_status({'job_id':job_id,'job_status':'success','xml_file_path':xml_file,'klarf_file_path':klarf_file})

    except Exception as e:
        await update_job_status({'job_id': job_id, 'job_status': 'failed',
                              'err_message': e,'xml_file_path':xml_file,'klarf_file_path':klarf_file})
        app_log.error(traceback.format_exc())
        app_log.error(f"Error while loading data. {e}")


async def verify_mapname(job_id, xml_df, meta_df, main_df, xml_file, klarf_file):
    """
    This function is to verify xml and klarf Dataframe prior merger 
    """
    # conn = connection_pool.connect()
    # cursor = conn.cursor()
    try:
        meta_data = meta_df.join(xml_df[["rod","doassistenabled","semga","semtoolid","semrecipename","platformtype","nvdclass","unclassifiedclass"]])

        if meta_df.empty:
            return {'job_id':job_id,'job_status':'rejected','err_message':'XML-Klarf pair not valid','xml_file_path':xml_file,'klarf_file_path':klarf_file}


        query = f"""SELECT mapid from drive_map_header FINAL
        where rfg = 1 
        and stepid = '{meta_data['stepid'][0]}' 
        and lotrecord = '{meta_data['lotrecord'][0]}' 
        and waferrecord = '{meta_data['waferrecord'][0]}' 
        and deviceid = '{meta_data['deviceid'][0]}'
        and inspectionstationmodel = '{meta_data['inspectionstationmodel'][0]}'
        and doassistenabled = '{meta_data['doassistenabled'][0]}'
        and inspectionstationid = '{meta_data['inspectionstationid'][0]}'
        and recipetimestamp = '{meta_data['recipetimestamp'][0]}'
        and platformtype='{meta_data['platformtype'][0]}'
        and semtoolid = '{meta_data['semtoolid'][0]}'
        and semga = '{meta_data['semga'][0]}'
        and rod = '{meta_data['rod'][0]}'
        and semrecipename = '{meta_data['semrecipename'][0]}'
        and resulttimestamp = '{meta_data['resulttimestamp'][0]}' """
        data_output=await get_query_with_pool( query=query, resp_type="dict")
        duplicate_id = [i.get('mapid', '') for i in data_output]
        meta_data["jobid"] = job_id
        main_df = data_validation(main_df, meta_data)
        return {'meta_df': meta_data, 'duplicate_ids': duplicate_id, 'main_df': main_df}
    except Exception as e:
        raise Exception(e)


async def push_data(data):
    """
    to push header and main data into clickhouse 
    """
    try:
        duplicate_mapid  = data.get('duplicate_ids')
        # conn = connection_pool.connect()
        # cursor = conn.cursor()
        # con = getdbconnection()
        meta_df = data['meta_df']
        main_df = data['main_df']
        # meta_df=  list(meta_df.columns)
        # cols = ",".join([item.replace("'", "") for item in meta_df.columns])
        if "slotnumber" in meta_df.columns:
            meta_df["slotnumber"] = meta_df["slotnumber"].astype(int)   
        cols = ','.join(list(meta_df.columns))
        query_to_execute = f"INSERT INTO drive.drive_map_header ({cols}) VALUES "
        await insert_data(query_to_execute,[tuple(x) for x in meta_df.to_records(index=False)])
        if duplicate_mapid:
            rfg_query = f"insert into drive_map_header SELECT mapid,jobid,deviceid,stepid,waferrecord,lotrecord,recipeid,semtoolid,semrecipename,slotnumber,orientationmarklocation,inspectionstationid,inspectionstationmodel,resulttimestamp,xdiepitch,ydiepitch,rod,doassistenabled,semga,platformtype,nvdclass,unclassifiedclass,defect_count,recipetimestamp, filetimestamp, 0 AS rfg1 FROM drive_map_header dmh final where rfg = 1 and mapid in {duplicate_mapid} "
            app_log.info(f"{rfg_query=}")
            # cursor.execute(rfg_query)
            await get_query_with_pool(query=rfg_query,resp_type="df")

        #meta_df = meta_df.append(pd.Series(), ignore_index=True)
        #meta_df.to_sql('drive_map_header', con, if_exists='append', index=False)

        mapid_query = f"""SELECT mapid from drive_map_header FINAL
        where rfg = 1 
        and stepid = '{meta_df['stepid'][0]}' 
        and lotrecord = '{meta_df['lotrecord'][0]}' 
        and waferrecord = '{meta_df['waferrecord'][0]}' 
        and deviceid = '{meta_df['deviceid'][0]}'
        and inspectionstationmodel = '{meta_df['inspectionstationmodel'][0]}'
        and doassistenabled = '{meta_df['doassistenabled'][0]}'
        and inspectionstationid = '{meta_df['inspectionstationid'][0]}'
        and recipetimestamp = '{meta_df['recipetimestamp'][0]}'
        and platformtype='{meta_df['platformtype'][0]}'
        and semtoolid = '{meta_df['semtoolid'][0]}'
        and semga = '{meta_df['semga'][0]}'
        and rod = '{meta_df['rod'][0]}'
        and semrecipename = '{meta_df['semrecipename'][0]}'
        and resulttimestamp = '{meta_df['resulttimestamp'][0]}' """
        mapid=await get_query_with_pool(query=mapid_query, resp_type="dict")
        main_df['mapid'] = mapid[0]['mapid']
        """spliting main df accoring to chunksize"""
        splits = round(1 if main_df.shape[0] < int(
            default_batch_size) else main_df.shape[0] / int(default_batch_size))
        main_df_split = np.array_split(main_df, splits)
        #start_processes(push_main_data, main_df_split, splits)
        await push_main_data(main_df)
        # cursor.close()
        # conn.close()
    except Exception as e:
        rfg_query = f"insert into drive_map_header SELECT mapid,jobid,deviceid,stepid,waferrecord,lotrecord,recipeid,semtoolid,semrecipename,slotnumber,orientationmarklocation,inspectionstationid,inspectionstationmodel,resulttimestamp,xdiepitch,ydiepitch,rod,doassistenabled,semga,platformtype,nvdclass,unclassifiedclass,defect_count,recipetimestamp,filetimestamp,  0 AS rfg1 FROM drive_map_header dmh final where rfg = 1 and stepid ='{meta_df['stepid'][0]}' and  deviceid = '{meta_df['deviceid'][0]}'  and  waferrecord = '{meta_df['waferrecord'][0]}' and recipeid  = '{meta_df['recipeid'][0]}' and lotrecord = '{meta_df['lotrecord'][0]}' "
        app_log.info(f"{rfg_query=}")
        # cursor.execute(rfg_query)
        await get_query_with_pool(query=rfg_query)
        raise Exception(e)


async def push_main_data(df_to_push):
    """
    to push data into main table after DataFrame split based on chunck size
    """
    # con = getdbconnection()
    try:
        app_log.info(f"{df_to_push.shape}")
        df_to_push = df_to_push.reset_index(drop=True)
        cols = ','.join(list(df_to_push.columns))
        app_log.info(cols)
        query_to_execute = f"INSERT INTO drive.drive_defect_main ({cols}) VALUES "
        await insert_data(query_to_execute,[tuple(x) for x in df_to_push.to_records(index=False)])

    except Exception as e:
        # to check in case to failuer at this point how to give failed status in job logs
        app_log.error(f"File Upload Error: {traceback.format_exc()}")
        raise Exception (e)


def start_processes(process_func, iterator, num_chunks, ret_flg=0):
    """
    Start processes to process iterator in process functions.

    :param process_func: The process function called for each iterator
    :type process_func: func
    :param iterator: Data iterator
    :type iterator: iter
    :param iterator: The number of chunks to be processed
    :type iterator: int
    """
    # Create the process pool
    if num_chunks > MAX_NUM_PROCESSES:
        num_processes = MAX_NUM_PROCESSES
    else:
        num_processes = num_chunks

    app_log.info(
        f"Sending {num_chunks} batches to {num_processes} worker processes")
    pdc_pool_object = Pool(num_processes)

    try:
        # Spawn processes to process iterator
        if ret_flg == 0:
            pdc_pool_object.imap(process_func, iterator)
            pdc_pool_object.close()
            pdc_pool_object.join()
        else:
            main_df_split = pd.concat(
                pdc_pool_object.imap(process_func, iterator))
            pdc_pool_object.close()
            pdc_pool_object.join()
            return main_df_split
        app_log.debug("Multiprocessing workers closed and joined")
    except Exception as err:
        """Terminate the processes if failed"""
        pdc_pool_object.close()
        pdc_pool_object.join()
        raise RuntimeError(
            f"Multiprocessing workers terminated: {err}") from err

    app_log.info(f"Total {num_chunks} batches processed and sent")


def data_validation(main_df, meta_df):
    """
    This function is to validate defects based on conditions 
    """
    classnumber = meta_df['nvdclass'].astype(int)
    undefined = meta_df['unclassifiedclass'].astype(int)
    main_df['manualdoassist'] = 'true' if len(
        main_df[(main_df['defectdo'] == 1) | (main_df['defectdo'] == 2)]) > 0 else 'false'
    main_df = main_df[((main_df['reviewstatus'] == 1) | (main_df['reviewstatus'] == 2) | (main_df['defectdo'] == 1) | (main_df['defectdo'] == 2)) & ~((main_df['classnumber'] == classnumber[0]) & (main_df['defectdo'] == 0)) & ~((main_df['classnumber'] == undefined[0]) & (main_df['adrhighscore'] == 0)) & ~((main_df['semxsize'] <= 0) & (main_df['semysize'] <= 0))]
    if len(main_df)==0:
        raise Exception ('No defects left after validation')
    return main_df



