uvicorn api.timetrend.app:app --port 7090
uvicorn api.timetrend.app:app --port 7091
uvicorn api.timetrend.app:app --port 7092
uvicorn api.timetrend.app:app --port 7093
uvicorn api.timetrend.app:app --port 7094
uvicorn api.timetrend.app:app --port 7095