import tornado
from api.alert.alert_api.alerthandler import (
    AlertHandler,
    AlertHistoryHandler,
    AlertFilterHandler,
    AlertValidationHandler,
    SaveAlertHistHandler,
    AlertBaseLineHandler,
    AlertDetailHandler,
    AlertListHandler,
)


services = {
    "alert": [
        tornado.web.url(r"/alert", AlertHandler),
        tornado.web.url(r"/alert/alertdetails", AlertDetailHandler),
        tornado.web.url(r"/alert/history", AlertHistoryHandler),
        tornado.web.url(r"/alert/filter", AlertFilterHandler),
        tornado.web.url(r"/alert/getvalidalert", AlertValidationHandler),
        tornado.web.url(r"/alert/getimmvalidalert", AlertValidationHandler),
        tornado.web.url(r"/alert/savealerthist", SaveAlertHistHandler),
        tornado.web.url(r"/alert/getbaseline", AlertBaseLineHandler),
        tornado.web.url(r"/alert/alertlist", AlertListHandler),
    ]
}
