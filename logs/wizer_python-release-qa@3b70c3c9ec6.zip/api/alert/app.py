"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.alert.alert_api import alerthandler


app.include_router(alerthandler.router)
