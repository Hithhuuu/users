"""Handler for Alert API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.utils.common import get_user
from api.alert.alert_api.alertmodel import AlertModel
from api.alert.alert_api.alertlistmodel import alertlistmodel
from api.alert.alert_api.alertfiltermodel import alertfilter
from api.alert.alert_api.alertvalidatemodel import alertvalidate
from api.alert.alert_api.alertbaseline import alertbaseline
from api.alert.alert_api.alerthistmodel import alerthistorymodel, savehistory
from api.alert.alert_api.rcamodel import RcaCrud
from api.alert.alert_api.rcavalidate import ValidateRca
from api.alert.alert_api.rcahistory import HistoryRca
from api.alert.alert_api.rcalogic import RcaLogic
from api.alert.alert_api.rcaannouncement import RcaAnnouncement
from api.alert.alert_api.fmalertvalidate import ValidateFailureMonitor
from api.utils.fastapi_app import app, validate_authenticity
from api.utils.scheduler import scheduler_cron


router = APIRouter(
    prefix="/alert", dependencies=[Depends(validate_authenticity)])

rca_model = RcaCrud()
rca_validate = ValidateRca()
rca_history = HistoryRca()
rca_logic = RcaLogic()
rca_output = RcaAnnouncement()
alert_baseline = alertbaseline()
alert_validate = alertvalidate()
save_alert_history = savehistory()
alert_history = alerthistorymodel()
alert_list = alertlistmodel()
alert_model = AlertModel()
fmvalidate = ValidateFailureMonitor()


@router.get("")
async def get(request: Request):
    """GET Method for alert """
    response = await alert_model.get_alertlist(
        data={"userid": request.query_params.get("userid",[])}
    )
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("")
async def createalert(request: Request, body : dict):
    """POST Method for alert """
    body["username"] = get_user(request)["userid"]
    response = await alert_model.create_alert(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.put("")
async def updatealert(request: Request, body : dict):
    """PUT Method for alert """
    body["username"] = get_user(request)["userid"]
    response = await alert_model.update_alert(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.delete("")
async def deletealert(request: Request):
    """DELETE Method for alert """
    body = await request.body()
    userid = get_user(request)["userid"]
    response = await alert_model.delete_alert(body, userid)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.get("/alertdetails")
async def get_alertdetails(request: Request):
    """GET Method for handler"""
    response = await alert_model.get_alert_details(
        data={'id': request.query_params.get('id', None)})
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/alertlist")
async def get_alertlist(body :dict):
    """on POST request for alert list"""
    response = await alert_list.get_alert_list(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("/alertlist")
async def update_alertlist(body : dict):
    """on PUT  request for alert list"""
    response =await alert_list.update_alerts(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/history")
async def get_alerthistory(body:dict):
    """on POST request returns history status for alert id """
    response = await alert_history.get_alert_history(
        data=body
    )
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/savealerthist")
async def savealert_history(body: dict):
    """on POST request returns save history for triggered alerts"""
    response = await save_alert_history.history(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.get("/filter")
async def get_filtered_alert(request: Request):
    """ on GET request return filtered alert id"""
    alert_filter = alertfilter()
    report = request.query_params.get("type", None)
    alerttype = request.query_params.get("alerttype", None)
    user = get_user(request)["userid"]
    response = await alert_filter.get_filter_alert(
        data={"report": report, "userid": user, "alerttype": alerttype}
    )
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/getimmvalidalert")
@router.post("/getvalidalert")
async def validate_alert(request: Request, body: dict):
    """on POST request return validated alert response"""
    authorization= request.headers.get("Authorization")
    response = await alert_validate.get_validated_alert(
        data=body, token=authorization.split()[-1]
    )
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/getbaseline")
async def get_baseline_data( body :dict):
    """on POST request return baseline values"""
    response = await alert_baseline.get_baseline(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.get("/rca")
async def get_rca(request: Request):
    """On GET request return rca elert list as JSON"""
    body = {'id': request.query_params.get('id', None)}
    response = await rca_model.get_rca_data(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/rca")
async def create_rca(request: Request, body: dict):
    """On POST request return rca alert as JSON"""
    body['userid'] = request.query_params.get('userid')
    response = await rca_model.create_rca_data(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("/rca")
async def update_rca(request: Request, body: dict):
    """On PUT request return rca alert as JSON"""
    body['userid'] = request.query_params.get('userid')
    response = await rca_model.update_rca_data(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.delete("/rca")
async def delete_rca(body: dict):
    """On DELETE request rca alert"""
    response = await rca_model.delete_rca_data(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/rca/validate")
async def validate(body: dict):
    """On post request rca  alert validate"""
    response = await rca_validate.validate_rca_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/rca/history")
async def create_rca_history(body: dict):
    """On post request rca  alert history"""
    response = await rca_history.post_rca_history(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("/rca/history")
async def update_rca_history(body: dict):
    """On put request rca  alert hsitory"""
    response = await rca_history.put_rca_history(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.get("/rca/logic")
async def get_rca_logic(request: Request):
    """On get request rca  alert logic"""
    body = {'id': request.query_params.get('alertid', None)}
    response = await rca_logic.logic_data(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("/rcaoutput")
async def new_announcement(request: Request, body: dict):
    """On post request rca  alert announcement"""
    body['userid'] = request.query_params.get('userid')
    response = await rca_output.new_announcement(data=body, userid=body["userid"])
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.get("/rcaoutput")
async def get_announcement(request: Request):
    """On get request rca alert announcement"""
    body = {'userid': request.query_params.get('userid')}
    response = await rca_output.get_announcement_of_user(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/fmvalidate")
async def validate_fmalert(request: Request, body : dict):
    """on post request to fm alert validate"""
    response = await fmvalidate.validate_fm_alert(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
async def daily_trigger():
    """Trigger alert daily """
    print("daily alert trigger")
    payload = {
        "alerttype" : "Daily"
    }
    await rca_validate.validate_rca_alert(payload)

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 * * 1")
async def weekly_trigger():
    """Trigger alert weekly """
    print("weekly alert trigger")
    payload = {
        "alerttype" : "Weekly"
    }
    await rca_validate.validate_rca_alert(payload)