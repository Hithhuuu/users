import pandas as pd
import json
import requests
import datetime
import traceback

from api.timetrend.timetrend_api.timetrendmodel import TimeTrend
from api.utils.utils import get_logger, columns_info, env_config,queries, get_queries
from api.utils.common import get_classcode_bin_rank, get_classcode_purity, get_adc_classcode

app_log = get_logger("alert_utils")
alert_log = get_logger('valid_alert')

timetrend =  TimeTrend()
class_mapping = {
    "0":"adc",
    "1":"mdc",
    "2":"adchc"
}

async def get_threshold_alert_data(token, filter, selection, file_data):
    valid_resp = []
    ''' TO GET THRESHOLD ALERT RESPONSE DATA '''
    print(">>>>>>>>>>>>>>",filter.get('dataMeasurement'))

    threshold = filter.get('filters').get('dataMeasurement').get("excursion").get("thby")
    alert_log.info("***"*100)
    alert_log.info(f"filters from alert >>>>>> {threshold}")
    percentage = threshold.get("baselineOptions").get("thbyxvalue")

    class_type = filter.get('filters').get('dataMeasurement').get("classtype")
    adc_class = class_mapping.get(f'{class_type}')
    if (((adc_class=='adc' or adc_class=='mdc') and file_data.get("src_tool").lower() in ['adc']) \
        or ((adc_class=='mdc') and file_data.get("src_tool").lower() in ['klarity']) \
        or(adc_class=='adchc' and file_data.get("src_tool").lower()=='gebi')) \
        and (True in threshold.get("binOptions").values() or threshold.get('doi')):
        if filter.get('action', '') == "doibin" and (("slide" not in filter) \
                        or (filter.get('slide')=="bin")):
            
            payload = get_payload_for_base_line(selection, filter, "doibin", adc_class)
            base_line = await  get_base_line(token, payload)
            if base_line:
                alert_log.info(f"++++++++++++++++++ baseline resp for binrankcount +++++++++++++++++:{base_line}")

                calculated_data = get_calculation(base_line, percentage)
                resp = await bin_rank_count_api(token, filter, selection, adc_class,"bintotal", file_data)
                alert_log.info(f"++++++++++++++++++ bin_rank_count_api response+++++++++++++++++:{resp}")

                valid_data, compared_data_list = get_bin_validated(resp, calculated_data, threshold, 'bin', base_line)
                for compare_data in compared_data_list:
                    valid = {"data":valid_data, "compare_data":compare_data, "selection":selection}   
                    valid_resp.append(valid)

                if threshold.get('doi'):
                    doi_valid_data, doi_compared_data_list = get_doi_validated(resp, calculated_data, threshold, 'doi', base_line)
                    for doi_compare_data in doi_compared_data_list:
                        doi_valid = {"data":doi_valid_data, "compare_data":doi_compare_data, "selection":selection}   
                        valid_resp.append(doi_valid)

                    print("(------)(------)(------)"*100)
                    print(valid_resp)
                    print("(------)(------)(------)"*100)

                
            else:
                valid = {"data":[], "compare_data":{}}
                valid_resp.append(valid)


        elif (file_data.get("src_tool").lower() in ['adc', 'klarity']) \
            and filter.get('action', '') =="rank":
            payload = get_payload_for_base_line(selection, filter, "rank", adc_class)
            base_line = await  get_base_line(token, payload)
            if base_line:
                alert_log.info(f"++++++++++++++++++ baseline resp for bin123api +++++++++++++++++:{base_line}")

                calculated_data = get_calculation(base_line, percentage)
                resp = await bin123api(token, filter, selection, file_data)
                alert_log.info(f"++++++++++++++++++ bin123api +++++++++++++++++:{resp.json()}")

                valid_data, compared_data_list = get_bin_validated(resp, calculated_data, threshold, 'pbin', base_line)

                alert_log.info(f"**************(threshold- bin)get valid data after checking**************:{valid_data}")
                
                for compare_data in compared_data_list:
                    valid = {"data":valid_data, "compare_data":compare_data, "action":"action_rank", "selection":selection}  
                    valid_resp.append(valid)
                

            else:
                valid = {"data":[], "compare_data":{}}
                valid_resp.append(valid)
        

    if True in threshold.get("rankOptions").values():
        if (((adc_class=='adc'or adc_class=='mdc') and file_data.get("src_tool").lower() in ['adc']) or ((adc_class=='mdc') and file_data.get("src_tool").lower() in ['klarity'])   or(adc_class=='adchc' and file_data.get("src_tool").lower()=='gebi'))  and (filter.get('action', '')  == "doibin" and (('slide' not in filter)  or (filter.get('slide')=="rank"))):

            payload = get_payload_for_base_line(selection, filter, "doibin", adc_class)
            base_line = await  get_base_line(token, payload)
            if base_line:
                alert_log.info(f"++++++++++++++++++ baseline resp for bin_rank_count_api +++++++++++++++++:{base_line}")

                calculated_data = get_calculation(base_line, percentage)

                resp = await bin_rank_count_api(token, filter, selection, adc_class,"ranksize", file_data)
                alert_log.info(f"++++++++++++++++++ bin_rank_count_api response+++++++++++++++++:{resp}")
                valid_data, compare_data_list = get_rank_validated(resp, calculated_data, threshold, 'rank',base_line)
                for compare_data in compare_data_list:
                    valid = {"data":valid_data, "compare_data":compare_data, "action":"action_rank", "selection":selection}
                    valid_resp.append(valid)
                
            else:
                valid = {"data":[], "compare_data":{}}
                valid_resp.append(valid)

    if True in threshold.get("kpirankOptions").values() or True in threshold.get("kpibinOptions").values():
        
        if (file_data.get("src_tool").lower() in ['adc', 'klarity']) and filter.get('action', '') == "rank":
            payload = get_payload_for_base_line(selection, filter, "rank", adc_class)
            base_line = await  get_base_line(token, payload)
            if base_line:
                alert_log.info(f"++++++++++++++++++ baseline resp for rank_purity_api +++++++++++++++++:{base_line}")

                calculated_data = get_calculation(base_line, percentage)
                if (
                    (threshold.get('kpibinOptions') and True in threshold['kpibinOptions'].values()) \
                    or (threshold.get('kpirankOptions') and True in threshold['kpirankOptions'].values())
                ):

                    resp = await rank_purity_api(token, filter, selection, None, file_data, 'kpi')
                    alert_log.info(f"++++++++++++++++++ rank6_purity_api +++++++++++++++++:{resp}")

                    valid_data, compare_data_list = get_kpi_validated(resp, calculated_data, threshold, 'kpi', base_line)
                    print(valid_data)
                    print(compare_data_list)
                    for compare_data in compare_data_list:
                        valid = {"data":valid_data, "compare_data":compare_data, "selection":selection}
                        valid_resp.append(valid)

            else:
                valid = {"data":[], "compare_data":{}}
                valid_resp.append(valid)

    if threshold.get("adc") and (file_data.get("src_tool").lower() in ['adc']):
        class_type = filter.get('filters').get('dataMeasurement').get("classtypeadc")
        print("class_type???????????????", class_type)
        adc_class = [class_mapping.get(f'{class_type[0]}'), class_mapping.get(f'{class_type[1]}'), class_mapping.get(f'{class_type[2]}')]
        print("adc_class>>>>>>>>>>>", adc_class)
        payload = get_payload_for_base_line(selection, filter, "adc", adc_class)
        base_line = await  get_base_line(token, payload)
        if base_line:
            calculated_data = get_calculation(base_line, percentage)
            resp = await adc_monitor_api(token, filter, selection, file_data)
            valid_data, compared_data_list = get_adc_validated(resp, calculated_data, threshold,'adc', base_line)
            for compare_data in compared_data_list:
                valid = {"data":valid_data, "compare_data":compare_data}
                valid_resp.append(valid)
            
        else:
            valid = {"data":[], "compare_data":{}}
            valid_resp.append(valid)

    return valid_resp

def get_calculation(base_line, percentage):
    data = {}
    for k,v in base_line.items():
        data.update({
            f'{k}' : v*percentage/100
        })
    return data

def get_payload_for_base_line(data, datafilter, id_type, adc_class):
    ''' TO CREATE PAYLOAD TO GET BASE LINE'''
    alert_log.info(f">>>>>>>>>>>>BASE LINE CREATION FUNCTION<<<<<<<<<<")
    grouplist = datafilter.get('filters').get('dataMeasurement').get("userGroupList")
    grouplistdict = get_groupmapping_format(grouplist)
    if isinstance(adc_class,list):
        f_classcode = "adcClassCode"
    else:
        f_classcode = "binrankClassCode"
        if adc_class=='adchc':
            adc_class = 'ADC HC'
        adc_class = adc_class.upper()

    payload = {"resulttimestamp": data['resulttimestamp'],
        "stepid": data.get('stepid',[]),
        "no_run": "30",
        "no_run_option": "1",
        "fileClassification": "gebi",
        "id": id_type,
        "selectedMapping": {
            "adcclasscode": [data.get('classCode').get("adcclasscode",{})],
            "mdcclasscode": [data.get('classCode').get("mdcclasscode",{})],
            "adchcclasscode": [data.get('classCode').get("adchcclasscode",{})]
        },
        "groupMapping": grouplistdict,
        f"{f_classcode}": adc_class
    }
    payload.update({
        "excludeList":datafilter.get("filters").get("excludeList"),
        "binrank":datafilter['filters']['dataMeasurement'].get("binrank",[]),
        "bin":datafilter['filters']['dataMeasurement'].get("bin",[]),
        "rank":datafilter['filters']['dataMeasurement'].get("rank",[]),
    })
    for i in ['deviceid',"recipeid","inspectionstationid","lotrecord","waferrecord", "toolid"]:
        if data.get(f'{i}'):
            payload.update({
                f"{i}": data.get(f'{i}',[]),
            })
    alert_log.info(f">>PAYLOAD>>{payload}")

    return payload

async def get_base_line(token, payload):
    ''' get base line with api call '''
    alert_log.info(f">>>>>>>>>>>>BASE LINE API CALL FUNCTION<<<<<<<<<<")

    # headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    # url = env_config['server_url']+'/alert/getbaseline'
    # resp = requests.post(url, data=json.dumps(payload), headers=headers)
    # alert_log.info(f">>BASE LINE RESPONSE>>{resp}")
    # alert_log.info(f">>BASE LINE RESPONSE>>{resp.json()}")
    from api.alert.alert_api.alertbaseline import alertbaseline
    baseline =  alertbaseline()
    resp = await baseline.get_baseline(payload)
    return resp

def get_doi_validated(data, baseline,threshold, adc_type, pre_base):
    msg_list = []
    response = {}
    doi_data  = {}
    doi_data_list = []
    run_counter = 0

    if threshold.get("baselineOptions").get("thbyruns", False):
        run_val = threshold.get("baselineOptions").get("thbyrunvalue", 0) 
        
        data = data[:run_val]


        for dt in data:
            if threshold.get("baselineOptions").get("thbyruns", False) and dt.get('total_doi')!=None:
                
                
                index = data.index(dt)
                if (index < len(data)-1) and float(dt.get('total_doi')) < baseline.get("doi")  and (float(data[index+1].get('total_doi')) < baseline.get("doi")):
                    doi_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{adc_type}1defectcount':dt.get('total_doi'),
                        f'{adc_type}1baseline':
                            pre_base.get('doi'),
                        f'{adc_type}1':{
                            'lower':baseline.get('doi')
                        },
                    }
                    doi_data.update(doi_consecutive_dict)
                    response = {
                        'data':dt,
                        'msg':"excusion limit exceeds. Auto alert is triggered",
                        'status':True
                    }
                elif float(dt.get('total_doi')) < baseline.get("doi") and len(data)==1:
                    run_counter = run_counter + 1
                    doi_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{adc_type}1defectcount':dt.get('total_doi'),
                        f'{adc_type}1baseline':
                            pre_base.get('doi'),
                        f'{adc_type}1':{
                            'lower':baseline.get('doi')
                        },
                    }
                    doi_data.update(doi_consecutive_dict)
                    response = {
                        'data':data[0],
                        'msg':"excusion limit exceeds. Auto alert is triggered",
                        'status':True
                    }

        if response:
            msg_list.append(response)
        if doi_data:
            doi_data_list.append(doi_data)

        print("run val--->>"*100)
        print(doi_data_list)

    return msg_list,doi_data_list

def get_adc_validated(data, baseline,threshold, adc_type, pre_base):
    msg_list = []
    response = {}
    adc_data = adc_data2  = {}
    adc_data_list = []
    run_counter = 0
    if threshold.get("baselineOptions").get("thbyruns", False):
        run_val = threshold.get("baselineOptions").get("thbyrunvalue",0)
        app_log.info(f'{run_val=}')
        data = data[:run_val]

        for dt in data:
            if threshold.get("baselineOptions").get("thbyruns", False) and dt.get('diffadcmdc')!=None:
                
                
                index = data.index(dt)
                if (index < len(data)-1) and float(dt.get('diffadcmdc')) < baseline.get("diffadcmdc")  and (float(data[index+1].get('diffadcmdc')) < baseline.get("diffadcmdc")):
                    adc_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{adc_type}1defectcount':dt.get('diffadcmdc'),
                        f'{adc_type}1baseline':
                            pre_base.get('diffadcmdc'),
                        f'{adc_type}1':{
                            'lower':baseline.get('diffadcmdc')
                        },
                    }
                    # adc_consecutive_dict.update({f'{adc_type}1defectcount':dt.get('diffadcmdc')})
                    adc_data.update(adc_consecutive_dict)
                    response = {
                        'data':dt,
                        'msg':"excusion limit exceeds. Auto alert is triggered",
                        'status':True
                    }
                    # break
                elif float(dt.get('diffadcmdc')) < baseline.get("diffadcmdc") and len(data)==1:
                    run_counter = run_counter + 1
                    adc_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{adc_type}1defectcount':dt.get('diffadcmdc'),
                        f'{adc_type}1baseline':
                            pre_base.get('diffadcmdc'),
                        f'{adc_type}1':{
                            'lower':baseline.get('diffadcmdc')
                        },
                    }
                    adc_data.update(adc_consecutive_dict)
                    response = {
                        'data':data[0],
                        'msg':"excusion limit exceeds. Auto alert is triggered",
                        'status':True
                    }

        if response:
            msg_list.append(response)
        if adc_data:
            adc_data_list.append(adc_data)

    for dt in data:

        if threshold.get("baselineOptions").get("thbybaor", False):

            if dt.get('diffadcmdc') < baseline.get('diffadcmdc'):
                adc_data2.update({
                    "postfix":"beloworabove",
                    f'{adc_type}1defectcount':dt.get('diffadcmdc'),
                    f'{adc_type}1baseline':
                        pre_base.get('diffadcmdc'),
                    f'{adc_type}1':{
                        'lower':baseline.get('diffadcmdc')
                    },
                })
                response = {
                    'data':dt,
                    'msg':"excusion limit exceeds. Auto alert is triggered",
                    'status':True
                }
        if adc_data2:
            adc_data_list.append(adc_data2)
        if response:
            msg_list.append(response)

    return msg_list,adc_data_list

def get_kpi_validated(data, baseline, threshold, rank_type, pre_base):
    msg_list = []
    response = {}
    kpi_data = {}
    kpi_data_list = []
    kpi_consecutive_dict = {}
    if 'data' in data:
        data = data.get('data')
    if threshold.get("baselineOptions").get("thbyruns", False):
        run_val =threshold.get("baselineOptions").get("thbyrunvalue", 0) 
        try:
            data.sort(key = lambda date: datetime.datetime.strptime(date.get('resulttimestamp'),'%Y-%m-%d %H:%M:%S'),reverse=True)
        except Exception as e:
            alert_log.info(f'******************Time conversion error in kpi validated****************************')
            data.sort(key = lambda d: d.get('xaxis'),reverse=True)

        data = data[:run_val]
        print(run_val)
        print(data)
        
    for dt in data:
        for rank in ['kpirank1', 'kpirank2', 'kpirank3', 'kpirank4', 'kpirank5', 'kpibin1', 'kpibin2', 'kpibin3', 'kpibin4', 'kpibin5','kpibin6','kpibin7']:
            alert_log.info("$$$$$$$$$$$$$$$$$$$$$$***** consecutive kpi run ************ $$$$$$$$$$")
            if (threshold.get("kpibinOptions").get(rank) or threshold.get("kpirankOptions").get(rank)) and dt.get(rank)!=None:
                index = data.index(dt)
                if (index < len(data)-1)and float(dt.get(rank)) < baseline.get(rank)  and (float(data[index+1].get(rank)) < baseline.get(rank)):                       
                    kpi_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{rank}defectcount':dt.get(rank),
                        f'{rank}baseline':
                            pre_base.get(rank),
                        f'{rank}':{
                            'lower':baseline.get(rank)
                        },              
                    }
                    kpi_data.update(kpi_consecutive_dict)
                    response = {
                        'data':dt,
                        'msg':"msg_excursion_exceed",
                        'status':True
                    }
                elif float(dt.get(rank)) < float(baseline.get(rank)) and len(data)==1:
                    run_counter_bin1 =1
                    kpi_consecutive_dict = {
                        "postfix":"consecutive",
                        f'{rank}defectcount':dt.get(rank),
                        f'{rank}baseline':
                            pre_base.get(rank),
                        f'{rank}':{
                            'lower':baseline.get(rank)
                        },              
                    }
                    kpi_data.update(kpi_consecutive_dict)
                    response = {
                        'data':dt,
                        'msg':"msg_excursion_exceed",
                        'status':True
                    }

                else:
                    response = {}
                if response:
                    msg_list.append(response)
                if kpi_data:
                    kpi_data_list.append(kpi_data)
    print(kpi_data_list)
    return msg_list,kpi_data_list

def get_bin_validated(data, baseline, threshold, bin_type, pre_base= None):
    msg_list = []
    response = {}
    bin_data_list = []
    bin_data = bin_data2 = {}
    msg_excursion_exceed = "excusion limit exceeds. Auto alert is triggered"
    msg_excursion_within = "excusion limit does not exceed. Auto alert is triggered"
    run_counter_bin1=run_counter_bin2= run_counter_bin3= 0
    alert_log.info(f'******************BASE LINE AFTER CALCULATON****************************')
    alert_log.info(data)
    if threshold.get("baselineOptions").get("thbyruns", False):
        run_val = threshold.get("baselineOptions").get("thbyrunvalue", 0) 
        alert_log.info(f'<><><><><><><><><><><><<>{run_val}'*50)

        alert_log.info(f'******************DATA SET FOR CONSESUTIVE****{data}************************')

        try:
            data.sort(key = lambda date: datetime.datetime.strptime(date.get('resulttimestamp'),'%Y-%m-%d %H:%M:%S'),reverse=True)
        except Exception as e:
            alert_log.info(f'******************Time conversion error in bin validated line no 319*******{e}*********************')
            data.sort(key = lambda d: d.get('xaxis'),reverse=True)
        data = data[:run_val]    

    
        for dt in data:
            alert_log.info(baseline)
            alert_log.info(f'******************get_bin_validated****************************')
            alert_log.info(dt)
            alert_log.info(baseline)
            alert_log.info(f'**********************************************')
            bin_no = "3"
            
            if threshold.get("baselineOptions").get("thbyruns", False):
                alert_log.info("$$$$$$$$$$$$$$$$$$$$$$***** consecutive run ************ $$$$$$$$$$")
                if threshold.get("binOptions").get("bin1") and dt.get('bin1')!=None:
                    index = data.index(dt)
                    if (index < len(data)-1)and float(dt.get('bin1')) < baseline.get("bin1")  and (float(data[index+1].get('bin1')) < baseline.get("bin1")):                       
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}1defectcount':dt.get('bin1'),
                            f'{bin_type}1baseline':
                                pre_base.get('bin1'),
                            f'{bin_type}1':{
                                'lower':baseline.get('bin1')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif threshold.get("binOptions").get("bin1") and float(dt.get('bin1')) < float(baseline.get("bin1")) and len(data)==1:

                        run_counter_bin1 = run_counter_bin1 + 1
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}1defectcount':dt.get('bin1'),
                            f'{bin_type}1baseline':
                                pre_base.get('bin1'),
                            f'{bin_type}1':{
                                'lower':baseline.get('bin1')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                if threshold.get("binOptions").get("bin2") and dt.get('bin2')!=None:
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('bin2')) < float(baseline.get("bin2")) and (float(data[index+1].get('bin2')) < baseline.get("bin2")):
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}2defectcount':dt.get('bin2'),
                            f'{bin_type}2baseline':
                                pre_base.get('bin2'),
                            f'{bin_type}2':{
                                'lower':baseline.get('bin2')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif threshold.get("binOptions").get("bin2") and float(dt.get('bin2')) < float(baseline.get("bin2")) and len(data)==1:
                        run_counter_bin2 = run_counter_bin2 + 1
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}2defectcount':dt.get('bin2'),
                            f'{bin_type}2baseline':
                                pre_base.get('bin2'),
                            f'{bin_type}2':{
                                'lower':baseline.get('bin2')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                        
                if threshold.get("binOptions").get("bin3") and dt.get('bin3')!=None:
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('bin3')) < baseline.get("bin3") and (float(data[index+1].get('bin3')) < float(baseline.get("bin3"))):
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}3defectcount':dt.get('bin3'),
                            f'{bin_type}3baseline':
                                pre_base.get('bin3'),
                            f'{bin_type}3':{
                                'lower':baseline.get('bin3')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif threshold.get("binOptions").get("bin3") and float(dt.get('bin3')) < float(baseline.get("bin3")) and len(data)==1:
                        run_counter_bin3 = run_counter_bin3 + 1
                        bin_consecutive_dict = {
                            "postfix":"consecutive",
                            f'{bin_type}3defectcount':dt.get('bin3'),
                            f'{bin_type}3baseline':
                                pre_base.get('bin3'),
                            f'{bin_type}3':{
                                'lower':baseline.get('bin3')
                            },              
                        }
                        bin_data.update(bin_consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
       
        print(":::::::::"*100)
        print(bin_data)
        if bin_data:
            bin_data_list.append(bin_data)
        if response:
            msg_list.append(response)
            

    for dt in data:
        if threshold.get("baselineOptions").get("thbybaor", False):

            if threshold.get("binOptions").get("bin1") and dt.get('bin1') < baseline.get('bin1'):
                
                bin_data2.update({
                    "postfix":"beloworabove",
                    f'{bin_type}1defectcount':dt.get('bin1'),
                    f'{bin_type}1baseline':
                        pre_base.get('bin1'),
                    f'{bin_type}1':{
                        'lower':baseline.get('bin1')
                    },    
                })
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET BIN 1({dt.get("bin1")}) AND BASELINE BIN 1 ({baseline.get("bin1")})<<<<')

            if threshold.get("binOptions").get("bin2") and dt.get('bin2') and dt.get('bin2') < baseline.get('bin2'):
                bin_data2.update({
                    "postfix":"beloworabove",
                    f'{bin_type}2defectcount':dt.get('bin2'), 
                    f'{bin_type}2baseline':
                        pre_base.get('bin2'),
                    f'{bin_type}2':{
                        'lower':baseline.get('bin2')
                    }
                })
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET BIN-2({dt.get("bin2")}) AND BASELINE BIN-2({baseline.get("bin2")})<<<<')

            if threshold.get("binOptions").get("bin3") and dt.get('bin3') and dt.get('bin3') < baseline.get('bin3'):
                bin_data2.update({
                    "postfix":"beloworabove",
                    f'{bin_type}3defectcount':dt.get('bin3'),
                    f'{bin_type}3baseline':
                        pre_base.get('bin3'),
                    f'{bin_type}3':{
                        'lower':baseline.get('bin3')
                    },
                })
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET BIN-3({dt.get("bin3")}) AND BASELINE BIN-3({baseline.get("bin3")})<<<<')

            else:
                postfix = ""
                pass
        if bin_data2:
            bin_data_list.append(bin_data2)
       
        if response:
            msg_list.append(response)
    alert_log.info(f"$$$$$$$$$$$$$$$$$$$$$$bin_data_list ----> {bin_data_list}$$$$$$$$$$")

    return msg_list, bin_data_list
    

def get_rank_validated(data, baseline, threshold, rank_type, pre_base):
    rank_data = {}
    rank_data2 = {}
    rank_data_list = []
    msg_list = []
    rank = 1
    response = {}
    run_counter_rank6=run_counter_rank5=run_counter_rank4=run_counter_rank3=run_counter_rank2=run_counter_rank1 = 0
    msg_excursion_exceed = "excusion limit exceeds. Auto alert is triggered"
    msg_excursion_within = "excusion limit does not exceed. Auto alert is triggered"
    if 'data' in data:
        data = data['data']

    alert_log.info('---!!!!!!!!!!!!!!!!!!!!!!!---'*100)


    if threshold.get("baselineOptions").get("thbyruns", False):
        run_val = threshold.get("baselineOptions").get("thbyrunvalue", 0) 
        try:
            data.sort(key = lambda date: datetime.datetime.strptime(date.get('resulttimestamp'),'%Y-%m-%d %H:%M:%S'),reverse=True)
        except Exception as e:
            alert_log.info(f'******************Time conversion error in rank validated line no 560****************************')
            data.sort(key = lambda d: d.get('xaxis'),reverse=True)
        data = data[:run_val]
        alert_log.info(data)
        alert_log.info("nnnnnnnnnnnn"*50)

        for dt in data:
            alert_log.info(f'******************BASE LINE AFTER CALCULATON IN CONSECUTIVE****************************')
            alert_log.info(baseline)
            alert_log.info(f'******************get_rank_validated****************************')
            alert_log.info(dt)
            alert_log.info(f'**********************************************')
            if threshold.get("baselineOptions").get("thbyruns", False):
                print("<><>^^^>^>>^>^^>>^>>>^>^>^>^>>^>>>^>^>>^>>^>^>^>^>^"*100)
                if threshold.get("rankOptions").get("rank1") and dt.get('rank1') !=None:           
                    index = data.index(dt)
                                   
                    if (index < len(data)-1) and float(dt.get('rank1')) < baseline.get("rank1") and (float(data[index+1].get('rank1')) < baseline.get("rank1")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}1defectcount':dt.get('rank1'),
                            f'{rank_type}1baseline':
                                    pre_base.get('rank1'),
                            f'{rank_type}1':{
                                'lower':baseline.get('rank1')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif float(dt.get('rank1')) < baseline.get("rank1") and len(data)==1:
                        run_counter_rank1 = run_counter_rank1 + 1
                        rank_no = "1"
                        actual_rank = dt.get('rank1')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}1defectcount':dt.get('rank1'),
                            f'{rank_type}1baseline':
                                    pre_base.get('rank1'),
                            f'{rank_type}1':{
                                'lower':baseline.get('rank1')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                if threshold.get("rankOptions").get("rank2") and dt.get('rank2')!=None:
                    
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('rank2')) < baseline.get("rank2") and (float(data[index+1].get('rank2')) < baseline.get("rank2")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}2defectcount':dt.get('rank2'),
                            f'{rank_type}2baseline':
                                    pre_base.get('rank2'),
                            f'{rank_type}2':{
                                'lower':baseline.get('rank2')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif float(dt.get('rank2')) < baseline.get('rank2') and len(data)==1:
                        run_counter_rank2 = run_counter_rank2 + 1
                        rank_no = "2"
                        actual_rank = dt.get('rank2')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}2defectcount':dt.get('rank2'),
                            f'{rank_type}2baseline':
                                    pre_base.get('rank2'),
                            f'{rank_type}2':{
                                'lower':baseline.get('rank2')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }


                if threshold.get("rankOptions").get("rank3") and dt.get('rank3')!=None:
                    
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('rank3')) < baseline.get('rank3') and (float(data[index+1].get('rank3')) < baseline.get("rank3")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}3defectcount':dt.get('rank3'),
                            f'{rank_type}3baseline':
                                    pre_base.get('rank3'),
                            f'{rank_type}3':{
                                'lower':baseline.get('rank3')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif float(dt.get('rank3')) < baseline.get('rank3') and len(data)==1:
                        run_counter_rank3 = run_counter_rank3 + 1
                        rank_no = "3"
                        actual_rank = dt.get('rank3')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}3defectcount':dt.get('rank3'),
                            f'{rank_type}3baseline':
                                    pre_base.get('rank3'),
                            f'{rank_type}3':{
                                'lower':baseline.get('rank3')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }


                
                if threshold.get("rankOptions").get("rank4") and dt.get("rank4")!=None:
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('rank4')) < baseline.get('rank4') and (float(data[index+1].get('rank4')) < baseline.get("rank4")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}4defectcount':dt.get('rank4'),
                            f'{rank_type}4baseline':
                                    pre_base.get('rank4'),
                            f'{rank_type}4':{
                                'lower':baseline.get('rank4')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                            # break
                    elif float(dt.get('rank4')) < baseline.get('rank4') and len(data)==1:
                        run_counter_rank4 = run_counter_rank4 + 1
                        rank_no = "4"
                        actual_rank = dt.get('rank4')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}4defectcount':dt.get('rank4'),
                            f'{rank_type}4baseline':
                                    pre_base.get('rank4'),
                            f'{rank_type}4':{
                                'lower':baseline.get('rank4')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }


                if threshold.get("rankOptions").get("rank5") and dt.get("rank5")!=None:
                    
                    index = data.index(dt)
                    if (index < len(data)-1) and float(dt.get('rank5')) < baseline.get('rank5') and (float(data[index+1].get('rank5')) < baseline.get("rank5")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}5defectcount':dt.get('rank5'),
                            f'{rank_type}5baseline':
                                    pre_base.get('rank5'),
                            f'{rank_type}5':{
                                'lower':baseline.get('rank5')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                            # break
                    elif float(dt.get('rank5')) < baseline.get('rank5') and len(data)==1:
                        run_counter_rank5 = run_counter_rank5 + 1
                        rank_no = "5"
                        actual_rank = dt.get('rank5')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}5defectcount':dt.get('rank5'),
                            f'{rank_type}5baseline':
                                    pre_base.get('rank5'),
                            f'{rank_type}5':{
                                'lower':baseline.get('rank5')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }

                if threshold.get("rankOptions").get("rank6") and dt.get("rank6")!=None and baseline.get('rank6')!=None:
                        
                    index = data.index(dt)
                    print("XXXXXXXXXXXXXXXX"*100)
                    print(dt.get('rank6'))
                    print(baseline.get('rank6'))
                    if (index < len(data)-1) and float(dt.get('rank6')) < baseline.get('rank6') and (float(data[index+1].get('rank6')) < baseline.get("rank6")):
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}6defectcount':dt.get('rank6'),
                            f'{rank_type}6baseline':
                                    pre_base.get('rank6'),
                            f'{rank_type}6':{
                                'lower':baseline.get('rank6')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
                    elif float(dt.get('rank6')) < baseline.get('rank6') and len(data)==1:
                        run_counter_rank6 = run_counter_rank6 + 1
                        rank_no = "6"
                        actual_rank = dt.get('rank6')
                        consecutive_dict = {
                            "postfix":"consecutive",
                            f'{rank_type}6defectcount':dt.get('rank6'),
                            f'{rank_type}6baseline':
                                    pre_base.get('rank6'),
                            f'{rank_type}6':{
                                'lower':baseline.get('rank6')
                            }
                        }
                        rank_data.update(consecutive_dict)
                        response = {
                            'data':dt,
                            'msg':msg_excursion_exceed,
                            'status':True
                        }
        if rank_data:
            rank_data_list.append(rank_data)
        
        alert_log.info("*********AFTER CHECKING CONSECUTIVE RUNSSSSSSS********")
        alert_log.info(response)
        alert_log.info(rank_data_list)
        if response:
            msg_list.append(response)

    for dt in data:
        if threshold.get("baselineOptions").get("thbybaor", False):
            
            if threshold.get("rankOptions").get("rank1") and dt.get('rank1') and dt.get('rank1') < baseline.get('rank1'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}1defectcount':dt.get('rank1'),
                    f'{rank_type}1baseline':
                            pre_base.get('rank1'),
                    f'{rank_type}1':{
                        'lower':baseline.get('rank1')
                    },
                    
                }
                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET RANK-1({dt.get("rank1")}) AND BASELINE RANK-1({baseline.get("rank1")})<<<<')

            if threshold.get("rankOptions").get("rank2") and dt.get('rank2') and dt.get('rank2') < baseline.get('rank2'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}2defectcount':dt.get('rank2'),
                    f'{rank_type}2baseline':
                            pre_base.get('rank2'),
                    f'{rank_type}2':{
                        'lower':baseline.get('rank2')
                    },
                    
                }
                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET RANK-2({dt.get("rank2")}) AND BASELINE RANK-2({baseline.get("rank2")})<<<<')

            if threshold.get("rankOptions").get("rank3") and float(dt.get('rank3')) < baseline.get('rank3'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}3defectcount':dt.get('rank3'),
                    f'{rank_type}3baseline':
                            pre_base.get('rank3'),
                    f'{rank_type}3':{
                        'lower':baseline.get('rank3')
                    },       
                }
                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET RANK-3({dt.get("rank3")}) AND BASELINE RANK-3({baseline.get("rank3")})<<<<')


            if threshold.get("rankOptions").get("rank4") and dt.get('rank4') and dt.get('rank4') < baseline.get('rank4'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}4defectcount':dt.get('rank4'),
                    f'{rank_type}4baseline':
                            pre_base.get('rank4'),
                    f'{rank_type}4':{
                        'lower':baseline.get('rank4')
                    },
                    
                }
                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }

            if threshold.get("rankOptions").get("rank5") and dt.get('rank5') and dt.get('rank5') < baseline.get('rank5'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}5defectcount':dt.get('rank5'),
                    f'{rank_type}5baseline':
                            pre_base.get('rank5'),
                    f'{rank_type}5':{
                        'lower':baseline.get('rank5')
                    },
                    
                }

                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET RANK-5({dt.get("rank5")}) AND BASELINE RANK-5({baseline.get("rank5")})<<<<')


            if threshold.get("rankOptions").get("rank6") and dt.get('rank6') and baseline.get('rank6') and dt.get('rank6') < baseline.get('rank6'):
                thbybaor = {
                    "postfix":"beloworabove",
                    f'{rank_type}6defectcount':dt.get('rank6'),
                    f'{rank_type}6baseline':
                            pre_base.get('rank6'),
                    f'{rank_type}6':{
                        'lower':baseline.get('rank6')
                    },     
                }
                rank_data2.update(thbybaor)
                response = {
                    'data':dt,
                    'msg':msg_excursion_exceed,
                    'status':True
                }
                alert_log.info(f'>>>>ALERT TRIGGERED FOR BELOW BASE LINE FOR DATESET RANK-6({dt.get("rank6")}) AND BASELINE RANK-6({baseline.get("rank6")})<<<<')


            else:
                postfix = ""
                pass
        if rank_data2:
            rank_data_list.append(rank_data2)
        
        
        if response:
            msg_list.append(response)

    

    alert_log.info(f"$$$$$$$$$$$$$$$$$$$$$${rank_data_list=}$$$$$$$$$$$$$$$$$$$")

    return msg_list,rank_data_list

def get_groupmapping_format(userGroupList):
    data_dict = {}
    for rec in userGroupList:
        if rec['groupname'] in data_dict.keys():
            data_dict[rec['groupname']].append(rec['classnumber'])
        else:
            data_dict[rec['groupname']] = [rec['classnumber']]
    
    d = []
    for key , value in data_dict.items():
        d.append( {
            'groupname': key,
            'class': value
        })
    
    groupMapping = {
        "adcclasscode": [
            d
        ],
        "mdcclasscode": [
            d
        ],
    
        "adchcclasscode": [
            d
        ]
    
    }
    return groupMapping

def format_alert_jsons(data_output):
    """Format jsons in the alert details"""
    for resp in data_output:
        resp["dashboardConnectedCount"] = json.loads(
            resp["dashboardConnectedCount"]
        )
        resp["dashboardDetails"] = [
            json.loads(s) for s in resp["dashboardDetails"]
        ]
        resp["template_id"] = (
            int(resp["template_id"][0]) if resp["template_id"] else []
        )
    return data_output

def prepare_data(data, op_type):
    try:
        datetime_format = '%Y-%m-%d %H:%M:%S'
        if op_type == "insert":
            day_list = []
            reportdayselected = data.get('reportdayselected', '')
            if reportdayselected.get('days'):
                day_list.extend(reportdayselected.get('days'))
            if reportdayselected.get('dayNumber'):
                day_list.append(reportdayselected.get('dayNumber'))
            if reportdayselected.get('type') and reportdayselected.get('day'):
                week_number = queries['placement_map'][reportdayselected.get('placement')]
                report_day = f"{week_number}_{reportdayselected.get('day')}"
                day_list.append(report_day)
            if day_list:
                reportrunday = f"{json.dumps(day_list)}"
            data_dict = {
                "reportname": f"{data.get('reportname')}",
                "username":data.get('username'),
                "dashboardConnectedCount": f"{json.dumps(data.get('dashboardConnectedCount',''))}",
                "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                "reportdayselected": f"{json.dumps(data.get('reportdayselected', ''))}",
                "reportrunday": reportrunday,
                "reportfrequency": f"{json.dumps(data.get('reportfrequency', ''))}",
                "reportstatus": f"{json.dumps(data.get('reportstatus', ''))}",
                "reportdownloadformat": f"{json.dumps(data.get('reportdownloadformat', ''))}",
                "reportinvitees": f"{json.dumps(data.get('reportinvitees', ''))}",
                "timetrendanalysisfilters": f"{json.dumps(data.get('timetrendanalysisfilters', ''))}",
                "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                "pastdays": f"{json.dumps(data.get('pastdays',''))}",
                "excludelist": f"{json.dumps(data.get('excludelist',''))}"
            }
        elif op_type == "update":
            day_list = []
            reportrunday = None
            reportdayselected = data.get('reportdayselected', None)
            if reportdayselected:
                if reportdayselected.get('days',None):
                    day_list.extend(reportdayselected.get('days'))
                if reportdayselected.get('dayNumber',None):
                    day_list.append(reportdayselected.get('dayNumber'))
                if reportdayselected.get('type',None) and reportdayselected.get('day',None):
                    week_number = queries['placement_map'][reportdayselected.get('placement')]
                    report_day = f"{week_number}_{reportdayselected.get('day')}"
                    day_list.append(report_day)
                if day_list:
                    reportrunday = f"{json.dumps(day_list)}"
            data_dict = {
                "id": data.get("id"),
                "reportname": f"{json.dumps(data.get('reportname'))}" if data.get('reportname') else "reportname",
                "username": f"'{data.get('username')}'" if data.get('username') else 'username',
                "dashboardConnectedCount": f"{json.dumps(data.get('dashboardConnectedCount'))}" if data.get('dashboardConnectedCount') else "dashboardConnectedCount",
                "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                "reportdayselected": f"'{json.dumps(data.get('reportdayselected'))}'" if data.get('reportdayselected') else "reportdayselected",
                "reportrunday": f"'{reportrunday}'" if reportrunday else "reportrunday",
                "reportfrequency": f"'{json.dumps(data.get('reportfrequency'))}'" if data.get('reportfrequency') else "reportfrequency",
                "reportstatus": f"'{json.dumps(data.get('reportstatus'))}'" if data.get('reportstatus') else "reportstatus",
                "reportdownloadformat": f"'{json.dumps(data.get('reportdownloadformat'))}'" if data.get('reportdownloadformat') else "reportdownloadformat",
                "reportinvitees": f"'{json.dumps(data.get('reportinvitees'))}'" if data.get('reportinvitees') else "reportinvitees",
                "timetrendanalysisfilters": f"'{json.dumps(data.get('timetrendanalysisfilters'))}'" if data.get('timetrendanalysisfilters') else "timetrendanalysisfilters",
                "dataselectionfilters": f"'{json.dumps(data.get('dataselectionfilters'))}'" if data.get('dataselectionfilters') else "dataselectionfilters",
                "dashboardfilters": f"'{json.dumps(data.get('dashboardfilters'))}'" if data.get('dashboardfilters') else "dashboardfilters",
                "pastdays": f"'{json.dumps(data.get('pastdays'))}'" if data.get('pastdays') else "pastdays",
                "excludelist": f"'{json.dumps(data.get('excludelist'))}'" if data.get('excludelist') else "excludelist",
                "rfg" : data.get('rfg') if data.get('rfg',[]) else "rfg"
            }
        return data_dict
    except Exception as err:
        app_log.error(f"{traceback.format_exc()}")
        app_log.error(f"Error while preparing data {err}")
        return {"error": f"Error while preparing data {err}"}

    
def get_kpi_dict(data):
    kpirank_list = ['kpirank1','kpirank2','kpirank3','kpirank4','kpirank5','kpirank6']
    kpibin_list = ['kpibin1','kpibin2','kpibin3','kpibin4','kpibin5','kpibin6','kpibin7']
    kpibin = {}
    kpirank = {}
    if any((k for k in data if k in kpirank_list)):
        for rankdefect in kpirank_list:
            if isinstance(data.get(f'{rankdefect}defectcount'),float) or isinstance(data.get(f'{rankdefect}defectcount'),int):
                kpirank.update({
                    f'{rankdefect}defectcount':data.get(f'{rankdefect}defectcount'),
                    f'{rankdefect}baseline':data.get(f'{rankdefect}baseline'),
                    f'{rankdefect}':data.get(f'{rankdefect}'),

                })
    if any((k for k in data if k in kpibin_list)):

        for bindefect in kpibin_list:
            if isinstance(data.get(f'{bindefect}defectcount'),float) or isinstance(data.get(f'{bindefect}defectcount'),int) :
                kpibin.update({
                    f'{bindefect}defectcount':data.get(f'{bindefect}defectcount'),
                    f'{bindefect}baseline':data.get(f'{bindefect}baseline'),
                    f'{bindefect}':data.get(f'{bindefect}'),

                })
    return kpirank, kpibin

def get_data(data_output, filterdata=False):
    """Get alert data formatted with jsons"""
    resp_list = []
    for data in data_output:
        if filterdata:
            day_dict = json.loads(data.get('reportdayselected'))        
            selected_day_check = str(datetime.datetime.now().strftime('%A')) in day_dict.get("days")
        else:
            selected_day_check = True
        if selected_day_check:
            resp_dict = {}
            for k in data:
                try:
                    val = json.loads(data.get(k))
                    if k == "dashboardfilters":
                        val = format_template_strings(val)
                    if k == "reportname" and isinstance(val, int):
                        val = str(val)
                except Exception:
                    val = data.get(k)
                resp_dict.update({
                    f"{k}":val
                })
            resp_list.append(resp_dict)
    return sorted(resp_list, key = lambda i: i['reportcreateddate'],reverse=True)

def get_adc_class(data):        
    autoonsemclass = []
    for rec in data['selectedMapping'].get('adcclasscode',[]):
        for key, value in rec.items():
            autoonsemclass.extend(value)
    app_log.info("->>>", autoonsemclass)

    
    mansemclass = []
    for rec in data['selectedMapping'].get('mdcclasscode',[]):
        for key, value in rec.items():
            mansemclass.extend(value)
    hunterclass = []
    for rec in data['selectedMapping'].get('adchcclasscode',[]):
        for key, value in rec.items():
            hunterclass.extend(value)
    return mansemclass, autoonsemclass, hunterclass

def get_binrank_class(data):
    all_class = []
    true_class = []
    class_column_mapping = {'adc': 'autoonsemclass', 'mdc': 'mansemclass','adc hc': 'hunterclass' }
    class_type_mapping = {'adc': 'adcclasscode', 'mdc': 'mdcclasscode','adc hc': 'adchcclasscode' }
    selected_class = data.get('binrankClassCode','ADC').lower()
    app_log.info(selected_class)
    app_log.info(class_type_mapping[selected_class])
    for rec in data['selectedMapping'].get(class_type_mapping[selected_class]):
        for key, value in rec.items():
            if key == 'True':
                true_class.extend(value)
            all_class.extend(value)
    if all_class:
        return f" and {class_column_mapping[selected_class]} in {tuple(all_class)} ", true_class, class_column_mapping[selected_class]
    else:
        return '', true_class, class_column_mapping[selected_class]

def prepare_query( data):
    query_list = []
    col_mapping = (columns_info['column_mapping'])

    for key, value in data.items():
        if key in ['autoonsemclass', 'mansemclass', 'hunterclass', 'adcClassCode', 'binrank', 'bin', 'rank']:
            continue
        col = col_mapping.get(key, key)
        if isinstance(value, list):
            query = f"{col} in {tuple(value)}"
            query_list.append(query)
        elif isinstance(value, dict):
            if key == 'resulttimestamp' and data['no_run_option'] == "0":
                query = f" toDate({col}) >= '{value['min'][0:10]}' and toDate({col}) <= '{value['max'][0:10]}'"
                query_list.append(query)

    if len(query_list) > 0:
        condition_query = f" and {' and '.join(query_list)}"
    else:
        condition_query = ""

    return condition_query


def format_template_strings(data):
    for i in range(len(data)):
        if data and data[0]['filters'] \
            and data[i]['filters']['dataMeasurement'] \
            and data[i]['filters']['dataMeasurement']['loadedTemplate'] \
            and data[i]['filters']['dataMeasurement']['loadedTemplate']['template_json']:
            data[i]['filters']['dataMeasurement']['loadedTemplate']['template_json'] = json.dumps(
                data[i]['filters']['dataMeasurement']['loadedTemplate']['template_json'] 
            )
    return data

def get_purity_class(data):
    mdcclasscode = data['groupMapping'].get('mdcclasscode')
    true_class = []
    false_class = []
    for rec in mdcclasscode[0]:
        app_log.info(rec['groupname'])
        if rec['groupname'] == 'True':
            true_class = rec['class']
        elif rec['groupname'] == 'False':
            false_class = rec['class']
    all_class = []
    mdcclasscode_selected = data['selectedMapping'].get('mdcclasscode')
    for rec in mdcclasscode_selected:
        for key, value in rec.items():
            all_class.extend(value)
    app_log.info(f"All Class for purity are: {all_class}")

    return all_class, true_class, false_class


def check_filter_data( response, filter_data):
    flag = False
    resp = response.get('dataselectionfilters')
    for res in resp.keys():
        if resp.get(f'{res}') and res in ["deviceid", "stepid", "recipeid", "inspectionstationid", "toolid"]:
            alert_log.info(f"*********type filter ***************{type(filter_data.get(f'{res}'))} >>>>> {filter_data.get(f'{res}')} and {resp.get(f'{res}')}")

            if resp.get(f'{res}') == filter_data.get(f'{res}'):
                flag = True
                # break
            elif type(resp.get(f'{res}')) == str and [resp.get(f'{res}')] == filter_data.get(f'{res}'):
                flag = True
            elif type(filter_data.get(f'{res}')) == str and resp.get(f'{res}') == [filter_data.get(f'{res}')]:
                flag = True
            else:
                flag = False
                alert_log.info(f"*********FILTER IS NOT MATCHING for {res} ***************{resp.get(f'{res}')} AND {filter_data.get(f'{res}')}")
                break
    return flag


def check_fmfilter_data( response, filter_data,filetype):
    app_log.info(f'{response=}')
    app_log.info("-*-"*100)
    app_log.info(f"{filter_data=}")
    app_log.info("-*-"*100)
    app_log.info(f"{filetype=}")
    app_log.info("-*-"*100)
    flag = False
    resp = response
    filetype=filetype.lower()
    cols_list = ["enlightrecipie", "deviceid", "reviewtool"]

    if  filetype == 'enlight':
        cols_list = [ "deviceid",  "enlightrecipie", "inspectiontool"]
    if  filetype == 'sem':
        cols_list =["semrecipie", "deviceid", "reviewtool"]

    for res in resp.keys():
        if resp.get(f'{res}') and res in cols_list:
            alert_log.info(f"*********type filter ***************{type(filter_data.get(f'{res}'))} >>>>> {filter_data.get(f'{res}')} and {resp.get(f'{res}')}")

            if resp.get(f'{res}') == filter_data.get(f'{res}'):
                flag = True
                # break
            elif type(resp.get(f'{res}')) == str and [resp.get(f'{res}')] == filter_data.get(f'{res}'):
                flag = True
            elif type(filter_data.get(f'{res}')) == str and resp.get(f'{res}') == [filter_data.get(f'{res}')]:
                flag = True
            else:
                flag = False
                alert_log.info(f"*********FILTER IS NOT MATCHING for {res} ***************{resp.get(f'{res}')} AND {filter_data.get(f'{res}')}")
                break
        if res == 'stepid':        
            if filter_data.get('stepid')[0].__contains__(resp.get(res)[0]) :
                flag = True
            else:
                flag = False
    app_log.info(response,filter_data,filetype,flag)
    return flag


class RcaUtils:

    def __init__(self):
        '''Initialize template.'''
        queries = get_queries("alert")
        self.queries = queries['rca']

    def prepare_data(self,data, op_type):
        try:
            datetime_format = '%Y-%m-%d %H:%M:%S'
            day_list = []
            reportdayselected = data.get('basics').get('reportSchedule').get('when')
            kpi_selected =  data['kpis']
            reportrunday = None
            if op_type == "create" and reportdayselected.get('type') and reportdayselected.get('day'):
                week_number = self.queries['placement_map'][reportdayselected.get('placement')]
                report_day = f"{week_number}_{reportdayselected.get('day')}"
                day_list.append(report_day)
            if op_type == "create" and  day_list:
                reportrunday = f"{json.dumps(day_list)}"
            if op_type == "create":
                day_list.extend(reportdayselected.get('days'))
                day_list.append(reportdayselected.get('dayNumber'))
                data_dict = {
                    "reportname": f"{data.get('basics').get('name')}",
                    "username":data.get('userid'),
                    "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency" : f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency'))}",
                    "reportrunday": reportrunday,
                    "reportstatus": f"{data.get('basics').get('status', '')}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "layer": data.get('stepid'),
                    "product": data.get('deviceid'),
                    "output_msg":f"{data.get('output')}",
                    "flowdata":f"{json.dumps(data.get('flowData'))}",
                    "variations":f"{data.get('variation')}",
                    "kpi_selected":f"{json.dumps(kpi_selected)}",
                    "type" : "rca",
                    "usergroup" : f"{json.dumps(data.get('usergroup'))}",
                    "rfg" : 1,
                    "logicenabled" : data.get('logicenabled'),
                }
            elif op_type == "update":
                day_list = []
                reportrunday = None
                if reportdayselected and reportdayselected.get('days',None):
                    day_list.extend(reportdayselected.get('days'))
                if reportdayselected and reportdayselected.get('dayNumber',None):
                    day_list.append(reportdayselected.get('dayNumber'))
                if reportdayselected and reportdayselected.get('type',None) and reportdayselected.get('day',None):
                    week_number = self.queries['placement_map'][reportdayselected.get('placement')]
                    report_day = f"{week_number}_{reportdayselected.get('day')}"
                    day_list.append(report_day)
                if reportdayselected and day_list:
                    reportrunday = f"{json.dumps(day_list)}"
                data_dict = {
                    "id":data.get("id"),
                    "reportname": f"{data.get('basics').get('name')}",
                    "username":data.get('userid'),
                    "reportcreateddate": pd.to_datetime(str(datetime.datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency" : f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency'))}",
                    "reportrunday": reportrunday,
                    "reportstatus": f"{data.get('basics').get('status', '')}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "layer": data.get('stepid'),
                    "product": data.get('deviceid'),
                    "output_msg":f"{data.get('output')}",
                    "flowdata":f"{json.dumps(data.get('flowData'))}",
                    "variations":f"{data.get('variation')}",
                    "kpi_selected":f"{json.dumps(kpi_selected)}",
                    "usergroup" : f"{json.dumps(data.get('usergroup'))}",
                    "logicenabled" : data.get('logicenabled'),
                    "type" : "rca"
                }
            return data_dict
        except KeyError as e:
            app_log.error(f"{traceback.format_exc()}")
            app_log.error(f"Error while preparing data {e}")
            return {"error" : f"Error while preparing data {e}"}

    def grouping(self,data):
        false_group =[]
        true_group =[]
        all_group =[]
        nullclass = []
        null = '(null)'
        for i , k in data.items():
            if i == 'False':
               false_group =  [ int(x) for x in k]
            elif i =='True':
                true_group =  [ int(x) for x in k]
            else:
                nullclass =  [ int(x) for x in k]
        all_group = nullclass+true_group+false_group
        resp = {
            'false_class':tuple(false_group) if len(false_group)>0 else null,
            'true_class':tuple(true_group) if len(true_group)>0 else null,
            'all_class':tuple(sorted(all_group)) if len(all_group)>0 else null
        }
        return resp
    
    def json_formatter(self,data):
        keys = ['reportdayselected','reportfrequency','reportinvitees','flowdata','kpi_selected','usergroup']
        for k in keys:
            data[k] = json.loads(data[k])
        return data

    def query_condtion(self,data):
        keys = ['layer','product','waferid','carrierid','filename']
        str_list = []
        for i in keys:
            if data.get(i):
                str_list.append(f"{i} in ('{data.get(i)}')")
        return " and ".join(str_list)


async def get_valid_alert(token, data, file_data):
    response_data = []
    alert_log.info(
        f"*****************************Proccessing to get valid alert*****************************"
    )
    # data = data[0]
    for i in range(len(data["dashboardfilters"])):

        if (
            data["dashboardfilters"]
            and data["dashboardfilters"][i]["filters"]
            and data["dashboardfilters"][i]["filters"]["dataMeasurement"]
            and data["dashboardfilters"][i]["filters"]["dataMeasurement"]["excursion"]
        ):
            excursion = data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                "excursion"
            ]
            # if excursion['static']:
            #     excursion_val = excursion['static']
            #     if excursion_val['doi']:
            #         alert_log.info('doi')
            #     if excursion_val['bin']:
            #         alert_log.info('bin')
            #     if excursion_val['adc']:
            #         alert_log.info('adc')
            #     if excursion_val['rank']:
            #         alert_log.info('rank')
            if data["dashboardfilters"][i]["filters"]["dataMeasurement"].get(
                "excursionlimit"
            ) == "1" and excursion.get("fixed"):
                alert_log.info(
                    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>--FIXED-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                )
                alert_log.info(f"id--->>>>>{data['id']}")
                class_type = class_mapping.get(
                    f'{data["dashboardfilters"][i]["filters"]["dataMeasurement"]["classtype"]}'
                )

                excursion_val = excursion["fixed"]
                # if excursion_val.get('doi'):
                #     alert_log.info('doi')
                if (
                    excursion_val.get("bin")
                    or (
                        excursion_val.get("binOptions")
                        and True in excursion_val["binOptions"].values()
                    )
                    or excursion_val.get("doi")
                ):
                    alert_log.info(
                        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>--FIXED--BIN-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                    )

                    compare_data = dict(
                        bin1_lower=float(excursion_val["bin1"]["lower"])
                        if excursion_val["bin1"]["lower"]
                        else False,
                        bin1_upper=float(excursion_val["bin1"]["upper"])
                        if excursion_val["bin1"]["upper"]
                        else False,
                        bin2_lower=float(excursion_val["bin2"]["lower"])
                        if excursion_val["bin2"]["lower"]
                        else False,
                        bin2_upper=float(excursion_val["bin2"]["upper"])
                        if excursion_val["bin2"]["upper"]
                        else False,
                        bin3_lower=float(excursion_val["bin3"]["lower"])
                        if excursion_val["bin3"]["lower"]
                        else False,
                        bin3_upper=float(excursion_val["bin3"]["upper"])
                        if excursion_val["bin3"]["upper"]
                        else False,
                        bin4_lower=float(excursion_val["bin4"]["lower"])
                        if excursion_val["bin4"]["lower"]
                        else False,
                        bin4_upper=float(excursion_val["bin4"]["upper"])
                        if excursion_val["bin4"]["upper"]
                        else False,
                        bin5_lower=float(excursion_val["bin5"]["lower"])
                        if excursion_val["bin5"]["lower"]
                        else False,
                        bin5_upper=float(excursion_val["bin5"]["upper"])
                        if excursion_val["bin5"]["upper"]
                        else False,
                    )
                    compare_data = {
                        key: value for key, value in compare_data.items() if value
                    }
                    alert_log.info("$" * 100)
                    alert_log.info(compare_data)
                    if (
                        (
                            (
                                (class_type == "adc" or class_type == "mdc")
                                and file_data.get("src_tool").lower() in ["adc"]
                            )
                            or (
                                (class_type == "mdc")
                                and file_data.get("src_tool").lower() in ["klarity"]
                            )
                            or (
                                class_type == "adchc"
                                and file_data.get("src_tool").lower() == "gebi"
                            )
                        )
                        and (data["dashboardfilters"][i]["action"] == "doibin")
                        and (
                            ("slide" not in data["dashboardfilters"][i])
                            or (data["dashboardfilters"][i].get("slide") == "bin")
                        )
                    ):
                        chartType = "bintotal"

                        resp = await bin_rank_count_api(
                            token,
                            data["dashboardfilters"][i],
                            data["dataselectionfilters"],
                            class_type,
                            chartType,
                            file_data,
                        )
                        alert_log.info(
                            f"**************rank6 purity api response**************:{resp}"
                        )
                        valid_data, compare_data = check_bin_excursion(
                            resp, compare_data, "bin"
                        )
                        alert_log.info(
                            f"**************get valid data after checking**************:{valid_data}"
                        )
                        valid = {
                            "data": valid_data,
                            "compare_data": compare_data,
                            "selection": data["dataselectionfilters"],
                        }

                        if excursion_val.get("doi"):
                            compared_data = dict(
                                doi_lower=float(excursion_val["doi1"]["lower"])
                                if excursion_val.get("doi1")
                                and excursion_val.get("doi1").get("lower")
                                else False,
                                doi_upper=float(excursion_val["doi1"]["upper"])
                                if excursion_val.get("doi1")
                                and excursion_val.get("doi1").get("upper")
                                else False,
                            )
                            doi_valid_data, compared_data = check_doi_excursion(
                                resp, compared_data, "doi"
                            )
                            alert_log.info(
                                f"**************get valid data after checking**************:{valid_data}"
                            )
                            doi_valid = {
                                "data": doi_valid_data,
                                "compare_data": compared_data,
                                "selection": data["dataselectionfilters"],
                            }
                            alert_log.info("--@@--" * 100)
                            alert_log.info(doi_valid)
                            alert_log.info("--@@--" * 100)
                            if doi_valid:
                                response_data.append(doi_valid)

                    elif (data["dashboardfilters"][i].get("action") == "rank") and (
                        file_data.get("src_tool").lower() in ["adc", "klarity"]
                    ):
                        # bin123 purity api call
                        resp = await bin123api(
                            token,
                            data["dashboardfilters"][i],
                            data["dataselectionfilters"],
                            file_data,
                        )
                        valid_data, compare_data = check_bin_excursion(
                            resp, compare_data, "pbin"
                        )
                        alert_log.info(
                            f"**************get valid data after checking**************:{valid_data}"
                        )

                        valid = {
                            "data": valid_data,
                            "compare_data": compare_data,
                            "action": "action_rank",
                            "selection": data["dataselectionfilters"],
                        }
                    else:
                        valid = {}
                    if valid:
                        response_data.append(valid)

                if excursion_val.get("adc") and (
                    file_data.get("src_tool").lower() in ["adc"]
                ):
                    alert_log.info("adc")
                    alert_log.info(
                        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>--FIXED--ADC-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                    )

                    compare_data = dict(
                        adc_lower=float(excursion_val["adc1"]["lower"])
                        if excursion_val["adc1"]["lower"]
                        else False,
                        adc_upper=float(excursion_val["adc1"]["upper"])
                        if excursion_val["adc1"]["upper"]
                        else False,
                    )
                    compare_data = {
                        key: value for key, value in compare_data.items() if value
                    }
                    resp = await adc_monitor_api(
                        token,
                        data["dashboardfilters"][i],
                        data["dataselectionfilters"],
                        file_data,
                    )
                    valid_data, compare_data = check_adc_excursion(
                        resp, compare_data, "adc"
                    )
                    alert_log.info(
                        f"**************get valid data after checking**************:{valid_data}"
                    )
                    valid = {
                        "data": valid_data,
                        "compare_data": compare_data,
                        "selection": data["dataselectionfilters"],
                    }
                    response_data.append(valid)

                if excursion_val.get("rank") or (
                    excursion_val.get("rankOptions")
                    and True in excursion_val["rankOptions"].values()
                ):
                    alert_log.info("rank")
                    alert_log.info(
                        ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>--FIXED--RANK-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                    )

                    compare_data = dict(
                        rank1_lower=float(excursion_val["rank1"]["lower"])
                        if excursion_val["rank1"]["lower"]
                        else False,
                        rank1_upper=float(excursion_val["rank1"]["upper"])
                        if excursion_val["rank1"]["upper"]
                        else False,
                        rank2_lower=float(excursion_val["rank2"]["lower"])
                        if excursion_val["rank2"]["lower"]
                        else False,
                        rank2_upper=float(excursion_val["rank2"]["upper"])
                        if excursion_val["rank2"]["upper"]
                        else False,
                        rank3_lower=float(excursion_val["rank3"]["lower"])
                        if excursion_val["rank3"]["lower"]
                        else False,
                        rank3_upper=float(excursion_val["rank3"]["upper"])
                        if excursion_val["rank3"]["upper"]
                        else False,
                        rank4_lower=float(excursion_val["rank4"]["lower"])
                        if excursion_val["rank4"]["lower"]
                        else False,
                        rank4_upper=float(excursion_val["rank4"]["upper"])
                        if excursion_val["rank4"]["upper"]
                        else False,
                        rank5_lower=float(excursion_val["rank5"]["lower"])
                        if excursion_val["rank5"]["lower"]
                        else False,
                        rank5_upper=float(excursion_val["rank5"]["upper"])
                        if excursion_val["rank5"]["upper"]
                        else False,
                        rank6_lower=float(excursion_val["rank6"]["lower"])
                        if excursion_val["rank6"]["lower"]
                        else False,
                        rank6_upper=float(excursion_val["rank6"]["upper"])
                        if excursion_val["rank6"]["upper"]
                        else False,
                    )
                    compare_data = {
                        key: value for key, value in compare_data.items() if value
                    }
                    if (
                        (
                            (
                                (class_type == "adc" or class_type == "mdc")
                                and file_data.get("src_tool").lower() in ["adc"]
                            )
                            or (
                                (class_type == "mdc")
                                and file_data.get("src_tool").lower() in ["klarity"]
                            )
                            or (
                                class_type == "adchc"
                                and file_data.get("src_tool").lower() == "gebi"
                            )
                        )
                        and data["dashboardfilters"][i]["action"] == "doibin"
                        or (
                            "slide" not in data["dashboardfilters"][i]
                            and data["dashboardfilters"][i].get("slide") == "rank"
                        )
                    ):
                        chartType = "ranksize"
                        resp = await bin_rank_count_api(
                            token,
                            data["dashboardfilters"][i],
                            data["dataselectionfilters"],
                            class_type,
                            chartType,
                            file_data,
                        )
                        alert_log.info(
                            f"**************rank6 purity api response**************:{resp}"
                        )
                        valid_data, compare_data = check_purity_excursion(
                            resp, compare_data, "rank"
                        )
                        alert_log.info(
                            f"**************get valid data after checking**************:{valid_data}"
                        )
                        alert_log.info(
                            f"**************get compare_data after checking**************:{compare_data}"
                        )
                        # data_response = {
                        #     'response':resp.json(),
                        #     'excursion_status':valid_data
                        # }
                        valid = {
                            "data": valid_data,
                            "compare_data": compare_data,
                            "action": "action_rank",
                            "selection": data["dataselectionfilters"],
                        }
                        response_data.append(valid)
                        # break

                    elif data["dashboardfilters"][i]["action"] == "rank":

                        if (
                            excursion_val["rank1"]["lower"]
                            or excursion_val["rank1"]["upper"]
                            or excursion_val["rank2"]["lower"]
                            or excursion_val["rank2"]["upper"]
                            or excursion_val["rank3"]["lower"]
                            or excursion_val["rank3"]["upper"]
                            or excursion_val["rank4"]["lower"]
                            or excursion_val["rank4"]["upper"]
                            or excursion_val["rank5"]["lower"]
                            or excursion_val["rank5"]["upper"]
                            or excursion_val["rank6"]["lower"]
                            or excursion_val["rank6"]["upper"]
                        ) and (file_data.get("src_tool").lower() in ["adc", "klarity"]):
                            chartType = "rank"
                            resp = await rank_purity_api(
                                token,
                                data["dashboardfilters"][i],
                                data["dataselectionfilters"],
                                chartType,
                                file_data,
                            )
                            alert_log.info(
                                f"**************rank purity api response**************:{resp}"
                            )

                            valid_data, compare_data = check_purity_excursion(
                                resp, compare_data, "prank"
                            )

                            alert_log.info(
                                f"**************get valid data after checking**************:{valid_data}"
                            )
                            if valid_data:
                                valid = {
                                    "data": valid_data,
                                    "compare_data": compare_data,
                                    "selection": data["dataselectionfilters"],
                                }
                                response_data.append(valid)
                        # else:
                        #     valid_data = []
                        # if valid_data:
                        #     valid = {"data":valid_data, "compare_data":compare_data, "selection":data['dataselectionfilters']}
                        #     response_data.append(valid)

                if (
                    data["dashboardfilters"][i]["action"] == "rank"
                    and (file_data.get("src_tool").lower() in ["adc", "klarity"])
                    and (
                        (
                            excursion_val.get("kpibinOptions")
                            and True in excursion_val["kpibinOptions"].values()
                        )
                        or (
                            excursion_val.get("kpirankOptions")
                            and True in excursion_val["kpirankOptions"].values()
                        )
                    )
                ):

                    compare_data = dict(
                        rank1_lower=float(excursion_val["kpirank1"]["lower"])
                        if excursion_val["kpirank1"]["lower"]
                        else False,
                        rank1_upper=float(excursion_val["kpirank1"]["upper"])
                        if excursion_val["kpirank1"]["upper"]
                        else False,
                        rank2_lower=float(excursion_val["kpirank2"]["lower"])
                        if excursion_val["kpirank2"]["lower"]
                        else False,
                        rank2_upper=float(excursion_val["kpirank2"]["upper"])
                        if excursion_val["kpirank2"]["upper"]
                        else False,
                        rank3_lower=float(excursion_val["kpirank3"]["lower"])
                        if excursion_val["kpirank3"]["lower"]
                        else False,
                        rank3_upper=float(excursion_val["kpirank3"]["upper"])
                        if excursion_val["kpirank3"]["upper"]
                        else False,
                        rank4_lower=float(excursion_val["kpirank4"]["lower"])
                        if excursion_val["kpirank4"]["lower"]
                        else False,
                        rank4_upper=float(excursion_val["kpirank4"]["upper"])
                        if excursion_val["kpirank4"]["upper"]
                        else False,
                        rank5_lower=float(excursion_val["kpirank5"]["lower"])
                        if excursion_val["kpirank5"]["lower"]
                        else False,
                        rank5_upper=float(excursion_val["kpirank5"]["upper"])
                        if excursion_val["kpirank5"]["upper"]
                        else False,
                        rank6_lower=float(excursion_val["kpirank6"]["lower"])
                        if excursion_val.get("kpirank6")
                        and excursion_val["kpirank6"]["lower"]
                        else False,
                        rank6_upper=float(excursion_val["kpirank6"]["upper"])
                        if excursion_val.get("kpirank6")
                        and excursion_val["kpirank6"]["upper"]
                        else False,
                        bin1_lower=float(excursion_val["kpibin1"]["lower"])
                        if excursion_val["kpibin1"]["lower"]
                        else False,
                        bin1_upper=float(excursion_val["kpibin1"]["upper"])
                        if excursion_val["kpibin1"]["upper"]
                        else False,
                        bin2_lower=float(excursion_val["kpibin2"]["lower"])
                        if excursion_val["kpibin2"]["lower"]
                        else False,
                        bin2_upper=float(excursion_val["kpibin2"]["upper"])
                        if excursion_val["kpibin2"]["upper"]
                        else False,
                        bin3_lower=float(excursion_val["kpibin3"]["lower"])
                        if excursion_val["kpibin3"]["lower"]
                        else False,
                        bin3_upper=float(excursion_val["kpibin3"]["upper"])
                        if excursion_val["kpibin3"]["upper"]
                        else False,
                        bin4_lower=float(excursion_val["kpibin4"]["lower"])
                        if excursion_val["kpibin4"]["lower"]
                        else False,
                        bin4_upper=float(excursion_val["kpibin4"]["upper"])
                        if excursion_val["kpibin4"]["upper"]
                        else False,
                        bin5_lower=float(excursion_val["kpibin5"]["lower"])
                        if excursion_val["kpibin5"]["lower"]
                        else False,
                        bin5_upper=float(excursion_val["kpibin5"]["upper"])
                        if excursion_val["kpibin5"]["upper"]
                        else False,
                        bin6_lower=float(excursion_val["kpibin6"]["lower"])
                        if excursion_val["kpibin6"]["lower"]
                        else False,
                        bin6_upper=float(excursion_val["kpibin6"]["upper"])
                        if excursion_val["kpibin6"]["upper"]
                        else False,
                        bin7_lower=float(excursion_val["kpibin7"]["lower"])
                        if excursion_val["kpibin7"]["lower"]
                        else False,
                        bin7_upper=float(excursion_val["kpibin7"]["upper"])
                        if excursion_val["kpibin7"]["upper"]
                        else False,
                    )
                    alert_log.info("||||||))))" * 100)
                    resp = await rank_purity_api(
                        token,
                        data["dashboardfilters"][i],
                        data["dataselectionfilters"],
                        None,
                        file_data,
                        "kpi",
                    )
                    valid_data, compare_data = check_kpi_excursion(
                        resp, compare_data, "kpi"
                    )
                    alert_log.info(".....", valid_data)
                    alert_log.info(".....", compare_data)

                    if valid_data:
                        valid = {
                            "data": valid_data,
                            "compare_data": compare_data,
                            "selection": data["dataselectionfilters"],
                        }
                        response_data.append(valid)

            if data["dashboardfilters"][i]["filters"]["dataMeasurement"].get(
                "excursionlimit"
            ) == "2" and excursion.get("thby"):
                alert_log.info(
                    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>--THRESHOLD-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
                )
                valid = await get_threshold_alert_data(
                    token,
                    data["dashboardfilters"][i],
                    data["dataselectionfilters"],
                    file_data,
                )
                response_data.extend(valid)

    alert_log.info(
        f"**************Response after append data in common**************:{response_data}"
    )

    return response_data


async def bin_rank_count_api(token, data, sel_filter, class_type, chartType, file_data):
    alert_log.info(
        f"**************Called binrankcount API for valid alert**************"
    )
    classcode = get_classcode_bin_rank(sel_filter.get("classCode"), class_type)

    payload = {
        "userInputs": {
            "xAxis": "run",
            "yAxis": "count",
            "chartType": chartType,
            "offset": 0,
            "rows": 10000,
            "type": class_type.upper(),
            "defaultExclude": False,
            "fileClassification": "gebi",
            "template": sel_filter.get("templates")[0]
            if sel_filter.get("templates")
            else "",
            "groupmapping": data["filters"]["dataMeasurement"].get("userGroupList", []),
            "tooltipdata": {},
        },
        "facetFilters": {
            "singleDropdown": [],
            "multiDropdown": [
                "classcode",
                "stepid",
                "deviceid",
                "recipeid",
                "inspectionstationid",
                "lotrecord",
                "waferrecord",
                "toolid",
            ],
            "rangeFilters": ["resulttimestamp"],
        },
    }
    if data.get("filters").get("excludeList"):
        payload.get("facetFilters").update(
            {"excludeFilters": data.get("filters").get("excludeList")}
        )
    payload.update(
        {
            "facetValues": {
                "no_run": data["filters"]["dataMeasurement"]["no_run"],
                "no_run_option": data["filters"]["dataMeasurement"]["no_run_option"],
                "classcode": classcode,
                "resulttimestamp": [sel_filter["resulttimestamp"]],
                "stepid": [file_data.get("stepid", "")],
                "deviceid": [file_data.get("deviceid", "")],
                "recipeid": [file_data.get("recipeid", "")],
                "inspectionstationid": file_data.get("inspectionstationid").split(" "),
                "waferrecord": [file_data.get("waferrecord", "")],
                "toolid": [file_data.get("toolid", "")]
                if file_data.get("toolid", "")
                else [],
                "highdefectcount": json.loads(
                    data["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ]
                )["dashboardFilters"]["dataMeasurement"].get("highdefectcount", 0),
                "truedoicount": json.loads(
                    data["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ]
                )["dashboardFilters"]["dataMeasurement"].get("truedoicount", 10),
                "highdefectcountenable": json.loads(
                    data["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ]
                )["dashboardFilters"]["dataMeasurement"].get(
                    "highdefectcountenable", "false"
                ),
                "truedoicountenable": json.loads(
                    data["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ]
                )["dashboardFilters"]["dataMeasurement"].get(
                    "truedoicountenable", "true"
                ),
            }
        }
    )
    if data["filters"]["dataMeasurement"].get("bin"):
        payload.get("facetFilters").get("multiDropdown").append("bin")
        payload.get("facetValues").update(
            {"bin": data["filters"]["dataMeasurement"].get("bin", [])}
        )
    if data["filters"]["dataMeasurement"].get("rank"):
        payload.get("facetFilters").get("multiDropdown").append("rank")
        payload.get("facetValues").update(
            {"rank": data["filters"]["dataMeasurement"].get("rank", [])}
        )
    if data["filters"]["dataMeasurement"].get("binrank"):
        payload.get("facetFilters").get("multiDropdown").append("binrank")
        payload.get("facetValues").update(
            {"binrank": data["filters"]["dataMeasurement"].get("binrank", [])}
        )
    # headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    # url = env_config["server_url"] + "/binrankcount"
    # alert_log.info("--->>>" * 100)
    # alert_log.info(json.dumps(payload))
    # alert_log.info("<<<---" * 100)

    # resp = requests.post(url, data=json.dumps(payload), headers=headers)
    # resp = resp.json()
    payload['chartType'] = payload['endpoint'] = "/binrankcount"
    resp = await timetrend.binrankcount(payload)
    alert_log.info(f"response of rank api: {resp}")

    return resp


async def rank_purity_api(token, data, sel_filter, chartType, file_data, api_end_point=None):
    alert_log.info(
        f"**************Called rank API for valid alert**************")
    classcode = get_classcode_purity(sel_filter.get("classCode"))

    payload = {
        "userInputs": {
            "xAxis": "run" if not api_end_point else "",
            # "chartType":chartType,
            "offset": 0,
            "rows": 10000,
            "type": "MDC",
            "defaultExclude": False,
            "fileClassification": "gebi",
            "template": sel_filter.get("templates")[0]
            if sel_filter.get("templates")
            else "",
            "groupmapping": data["filters"]["dataMeasurement"].get("userGroupList", []),
        },
        "facetFilters": {
            "singleDropdown": [],
            "multiDropdown": [
                "classcode",
                "stepid",
                "deviceid",
                "recipeid",
                "inspectionstationid",
                "lotrecord",
                "waferrecord",
                "toolid",
            ],
            "rangeFilters": ["resulttimestamp"],
        },
    }
    if data.get("filters").get("excludeList"):
        payload.get("facetFilters").update(
            {"excludeFilters": data.get("filters").get("excludeList")}
        )
    if sel_filter:
        payload.update(
            {
                "facetValues": {
                    "no_run": data["filters"]["dataMeasurement"]["no_run"],
                    "no_run_option": data["filters"]["dataMeasurement"][
                        "no_run_option"
                    ],
                    "classcode": classcode,
                    "resulttimestamp": [sel_filter["resulttimestamp"]],
                    "stepid": [file_data.get("stepid", "")],
                    "deviceid": [file_data.get("deviceid", "")],
                    "recipeid": [file_data.get("recipeid", "")],
                    "inspectionstationid": file_data.get("inspectionstationid").split(
                        " "
                    ),
                    "waferrecord": [file_data.get("waferrecord", "")],
                    "toolid": [file_data.get("toolid", "")]
                    if file_data.get("toolid", "")
                    else [],
                    "highdefectcount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("highdefectcount", 0),
                    "truedoicount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("truedoicount", 10),
                    "highdefectcountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "highdefectcountenable", "false"
                    ),
                    "truedoicountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "truedoicountenable", "true"
                    ),
                }
            }
        )

    if data["filters"]["dataMeasurement"].get("bin"):
        payload.get("facetFilters").get("multiDropdown").append("bin")
        payload.get("facetValues").update(
            {"bin": data["filters"]["dataMeasurement"].get("bin", [])}
        )
    if data["filters"]["dataMeasurement"].get("rank"):
        payload.get("facetFilters").get("multiDropdown").append("rank")
        payload.get("facetValues").update(
            {"rank": data["filters"]["dataMeasurement"].get("rank", [])}
        )
    if data["filters"]["dataMeasurement"].get("binrank"):
        payload.get("facetFilters").get("multiDropdown").append("binrank")
        payload.get("facetValues").update(
            {"binrank": data["filters"]["dataMeasurement"].get("binrank", [])}
        )
    # headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    # if api_end_point:
    #     end_point = "/kpisummary/kpialert"
    # else:
    #     end_point = "/rankpurity/alert-rank-purity"
    # url = env_config["server_url"] + end_point
    # resp = requests.post(url, data=json.dumps(payload), headers=headers)
    resp = await timetrend.kpialert(payload)
    # resp = resp.json()
    alert_log.info("imp-----")
    alert_log.info(payload)
    alert_log.info(f"{payload}")
    alert_log.info(f"response of rank api: {resp}")
    # if resp and data['filters']['dataMeasurement'].get("rank",[]):
    #     resp = filter_alert_api_data('rank', resp, data['filters']['dataMeasurement'].get("rank",[]))
    # if resp and data['filters']['dataMeasurement'].get("bin",[]):
    #     resp = filter_alert_api_data('bin', resp, data['filters']['dataMeasurement'].get("bin",[]))

    return resp


async def adc_monitor_api(token, data, sel_filter, file_data):
    alert_log.info(
        f"**************Called adc monitor API for valid alert**************"
    )
    payload = {
        "userInputs": {
            "offset": 0,
            "rows": 10000,
            "defaultExclude": False,
            "fileClassification": "gebi",
            "template": sel_filter.get("templates")[0]
            if sel_filter.get("templates")
            else "",
            "groupmapping": data["filters"]["dataMeasurement"].get("userGroupList", []),
        },
        "facetFilters": {
            "singleDropdown": [],
            "multiDropdown": [
                "autoonsemclass",
                "mansemclass",
                "hunterclass",
                "stepid",
                "deviceid",
                "recipeid",
                "inspectionstationid",
                "lotrecord",
                "waferrecord",
                "toolid",
            ],
            "rangeFilters": ["resulttimestamp"],
        },
    }
    if data.get("filters").get("excludeList"):
        payload.get("facetFilters").update(
            {"excludeFilters": data.get("filters").get("excludeList")}
        )

    if data["filters"] and data["filters"]["dataMeasurement"]:
        data_measure = data["filters"]["dataMeasurement"]
        class_code = get_adc_classcode(sel_filter.get("classCode"))
        payload.update(
            {
                "facetValues": {
                    "no_run": data["filters"]["dataMeasurement"]["no_run"],
                    "no_run_option": data["filters"]["dataMeasurement"][
                        "no_run_option"
                    ],
                    "autoonsemclass": class_code.get("adcclasscode", []),
                    "mansemclass": class_code.get("mdcclasscode", []),
                    "hunterclass": class_code.get("adchcclasscode", []),
                    "resulttimestamp": [sel_filter.get("resulttimestamp")],
                    "stepid": [file_data.get("stepid", "")],
                    "deviceid": [file_data.get("deviceid", "")],
                    "recipeid": [file_data.get("recipeid", "")],
                    "inspectionstationid": file_data.get("inspectionstationid").split(
                        " "
                    ),
                    "waferrecord": [file_data.get("waferrecord", "")],
                    "toolid": [file_data.get("toolid", "")]
                    if file_data.get("toolid", "")
                    else [],
                    "highdefectcount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("highdefectcount", 0),
                    "truedoicount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("truedoicount", 10),
                    "highdefectcountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "highdefectcountenable", "false"
                    ),
                    "truedoicountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "truedoicountenable", "true"
                    ),
                }
            }
        )
        if data["filters"]["dataMeasurement"].get("bin"):
            payload.get("facetFilters").get("multiDropdown").append("bin")
            payload.get("facetValues").update(
                {"bin": data["filters"]["dataMeasurement"].get("bin", [])}
            )
        if data["filters"]["dataMeasurement"].get("rank"):
            payload.get("facetFilters").get("multiDropdown").append("rank")
            payload.get("facetValues").update(
                {"rank": data["filters"]["dataMeasurement"].get("rank", [])}
            )
        if data["filters"]["dataMeasurement"].get("binrank"):
            payload.get("facetFilters").get("multiDropdown").append("binrank")
            payload.get("facetValues").update(
                {"binrank": data["filters"]
                    ["dataMeasurement"].get("binrank", [])}
            )

    # headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    # url = env_config["server_url"] + "/adcmonitor"
    # alert_log.info("---" * 100)
    # alert_log.info(json.dumps(payload))
    # alert_log.info("---" * 100)
    # resp = requests.post(url, data=json.dumps(payload), headers=headers)
    # alert_log.info(f"response of ACD api: {resp.json()}")
    payload['chartType'] = 'adcmonitor'
    payload['endpoint'] = '/adcmonitor'
    resp = await timetrend.adcmonitor(payload)

    return resp["chart"]


async def bin123api(token, data, sel_filter, file_data):
    alert_log.info(
        f"**************Called bin123 API for valid alert**************")
    classcode = get_classcode_purity(sel_filter.get("classCode"))
    payload = {
        "userInputs": {
            "xAxis": "run",
            "yAxis": "percentage",
            "offset": 0,
            "rows": 10000,
            "type": "MDC",
            "defaultExclude": False,
            "fileClassification": "gebi",
            "template": sel_filter.get("templates")[0]
            if sel_filter.get("templates")
            else "",
            "groupmapping": data["filters"]["dataMeasurement"].get("userGroupList", []),
        },
        "facetFilters": {
            "singleDropdown": [],
            "multiDropdown": [
                "classcode",
                "stepid",
                "deviceid",
                "recipeid",
                "inspectionstationid",
                "lotrecord",
                "waferrecord",
                "toolid",
            ],
            "rangeFilters": ["resulttimestamp"],
        },
    }
    if sel_filter:
        payload.update(
            {
                "facetValues": {
                    "no_run": data["filters"]["dataMeasurement"]["no_run"],
                    "no_run_option": data["filters"]["dataMeasurement"][
                        "no_run_option"
                    ],
                    "classcode": classcode,
                    "resulttimestamp": [sel_filter["resulttimestamp"]],
                    "stepid": [file_data.get("stepid", "")],
                    "deviceid": [file_data.get("deviceid", "")],
                    "recipeid": [file_data.get("recipeid", "")],
                    "inspectionstationid": file_data.get("inspectionstationid").split(
                        " "
                    ),
                    "lotrecord": [file_data.get("lotrecord", "")],
                    "waferrecord": [file_data.get("waferrecord", "")],
                    "toolid": [file_data.get("toolid", "")]
                    if file_data.get("toolid", "")
                    else [],
                    "highdefectcount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("highdefectcount", 0),
                    "truedoicount": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get("truedoicount", 10),
                    "highdefectcountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "highdefectcountenable", "false"
                    ),
                    "truedoicountenable": json.loads(
                        data["filters"]["dataMeasurement"]["loadedTemplate"][
                            "template_json"
                        ]
                    )["dashboardFilters"]["dataMeasurement"].get(
                        "truedoicountenable", "true"
                    ),
                }
            }
        )
    if data["filters"]["dataMeasurement"].get("bin"):
        payload.get("facetFilters").get("multiDropdown").append("bin")
        payload.get("facetValues").update(
            {"bin": data["filters"]["dataMeasurement"].get("bin", [])}
        )
    if data["filters"]["dataMeasurement"].get("rank"):
        payload.get("facetFilters").get("multiDropdown").append("rank")
        payload.get("facetValues").update(
            {"rank": data["filters"]["dataMeasurement"].get("rank", [])}
        )
    alert_log.info("---" * 100)
    # alert_log.info(json.dumps(payload))
    # alert_log.info("---" * 100)
    # headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    # url = env_config["server_url"] + "/binpurity/binpurity123"
    # payload = {"userInputs":
    #     {"xAxis": "run", "yAxix": "count", "chartType": "ranksize", "offset": 0, "rows": 10000, "type": "MDC", "defaultExclude": False,
    #     "fileClassification": "gebi", "template": "", "groupmapping": [], "tooltipdata": {}},
    #     "facetFilters": {"singleDropdown": [], "multiDropdown": ["classcode", "stepid", "deviceid",
    #     "recipeid", "inspectionid"], "rangeFilters": ["resulttimestamp"]},
    #     "facetValues": {"no_run": "30", "no_run_option": "0", "classcode": ["0", "1", "2", "3", "4", "5", "6", "7"],
    #     "resulttimestamp": [{"min": "2021-08-26T14:40:21.000Z", "max": "2021-09-16T14:40:21.000Z"}], "stepid": ["Right"],
    #     "recipeid": ["nan"], "deviceid": [], "inspectionid": []}
    # }
    # resp = requests.post(url, data=json.dumps(payload), headers=headers)
    payload['chartType'] = payload['endpoint'] = "binpurity123"
    resp = await timetrend.kpi(payload)

    alert_log.info(f"response of binpurty api: {resp}")
    # alert_log.info(f"response of bin123 api: {resp.json()}")

    return resp


def check_kpi_excursion(data, compare_data, type):
    if "data" in data:
        data = data.get("data")
    msg_list = []
    response = {}
    kpi_data = {}
    for dt in data:
        for rank in [
            "rank1",
            "rank2",
            "rank3",
            "rank4",
            "rank5",
            "bin1",
            "bin2",
            "bin3",
            "bin4",
            "bin5",
            "bin6",
            "bin7",
        ]:
            if dt.get(type + rank) != None and (
                (
                    compare_data.get(f"{rank}_lower")
                    and compare_data.get(f"{rank}_lower") > dt.get(type + rank)
                )
                or (
                    compare_data.get(f"{rank}_upper")
                    and compare_data.get(f"{rank}_upper") < dt.get(type + rank)
                )
            ):
                response = {
                    "msg": "excusion limit exceeds. Auto alert is triggered",
                    "data": dt,
                    "status": True,
                }
                kpi_data.update(
                    {
                        f"{type}{rank}defectcount": dt.get(type + rank),
                        f"{type}{rank}": {
                            "sigma": "",
                            "lower": compare_data.get(f"{rank}_lower"),
                            "upper": compare_data.get(f"{rank}_upper"),
                        },
                    }
                )
            if response:
                msg_list.append(response)

            else:
                response = {}
            if response:
                msg_list.append(response)
    alert_log.info(kpi_data)
    return msg_list, kpi_data


def check_doi_excursion(data, compare_data, doi_type):

    msg_list = []
    response = {}
    doi_data = {}
    alert_log.info("--@@--" * 100)
    alert_log.info(data)
    alert_log.info(compare_data)
    alert_log.info("--@@--" * 100)
    for dt in data:
        if (
            compare_data.get("doi_lower")
            and compare_data["doi_lower"] > dt["total_doi"]
        ) or (
            compare_data.get("doi_upper")
            and compare_data["doi_upper"] < dt["total_doi"]
        ):
            response = {
                "msg": "excusion limit exceeds. Auto alert is triggered",
                "data": dt,
                "status": True,
            }
            doi_data.update(
                {
                    f"{doi_type}1defectcount": dt.get("total_doi"),
                    f"{doi_type}1": {
                        "sigma": "",
                        "lower": compare_data.get("doi_lower"),
                        "upper": compare_data.get("doi_upper"),
                    },
                }
            )

        else:
            # response = {
            #     "msg":"excusion limit does not exceed. Auto alert is triggered",
            #     "data":dt,
            #     'status':False

            # }
            response = {}
        if response:
            msg_list.append(response)
    return msg_list, doi_data


def check_adc_excursion(data, compare_data, adc_type):
    msg_list = []
    response = {}
    adc_data = {}
    for dt in data:
        # if response.get('status'):
        #     break
        if (
            compare_data.get("adc_lower")
            and compare_data["adc_lower"] > dt["diffadcmdc"]
        ) or (
            compare_data.get("adc_upper")
            and compare_data["adc_upper"] < dt["diffadcmdc"]
        ):
            response = {
                "msg": "excusion limit exceeds. Auto alert is triggered",
                "data": dt,
                "status": True,
            }
            adc_data.update(
                {
                    f"{adc_type}1defectcount": dt.get("diffadcmdc"),
                    f"{adc_type}1": {
                        "sigma": "",
                        "lower": compare_data.get("adc_lower"),
                        "upper": compare_data.get("adc_upper"),
                    },
                }
            )

        else:
            # response = {
            #     "msg":"excusion limit does not exceed. Auto alert is triggered",
            #     "data":dt,
            #     'status':False

            # }
            response = {}
        if response:
            msg_list.append(response)
    return msg_list, adc_data


def check_bin_excursion(data, compare_data, bin_type):
    msg_list = []
    response = {}
    bin_data = {}
    msg_excursion_exceed = "excusion limit exceeds. Auto alert is triggered"
    msg_excursion_within = "excusion limit does not exceed. Auto alert is triggered"

    for dt in data:
        alert_log.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        alert_log.info(dt)
        alert_log.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        # if response.get('status'):
        #     break
        if (dt.get("bin1") is not None and dt.get("bin1") != "") and (
            (compare_data.get("bin1_lower")
             and compare_data["bin1_lower"] > dt["bin1"])
            or (
                compare_data.get("bin1_upper")
                and compare_data["bin1_upper"] < dt["bin1"]
            )
        ):
            msg = msg_excursion_exceed
            response = {
                "data": dt,
                "msg": msg,
                "status": True,
            }
            bin_data.update(
                {
                    f"{bin_type}1defectcount": dt.get("bin1"),
                    f"{bin_type}1": {
                        "sigma": "",
                        "lower": compare_data.get("bin1_lower"),
                        "upper": compare_data.get("bin1_upper"),
                    },
                }
            )
        # alert_log.info("#$@"*50)
        # alert_log.info(compare_data['bin2_lower'], dt)
        # alert_log.info("#end"*50)
        if (dt.get("bin2") is not None and dt.get("bin2") != "") and (
            (compare_data.get("bin2_lower")
             and compare_data["bin2_lower"] > dt["bin2"])
            or (
                compare_data.get("bin2_upper")
                and compare_data["bin2_upper"] < dt["bin2"]
            )
        ):
            msg = msg_excursion_exceed
            response = {"data": dt, "msg": msg, "status": True}
            alert_log.info("#$@" * 50)
            alert_log.info(f'{bin_type}2defectcount-->{dt.get("bin2")}')
            alert_log.info("#end" * 50)

            bin_data.update(
                {
                    f"{bin_type}2defectcount": dt.get("bin2"),
                    f"{bin_type}2": {
                        "sigma": "",
                        "lower": compare_data.get("bin2_lower"),
                        "upper": compare_data.get("bin2_upper"),
                    },
                }
            )
        if (dt.get("bin3") is not None and dt.get("bin3") != "") and (
            (compare_data.get("bin3_lower")
             and compare_data["bin3_lower"] > dt["bin3"])
            or (
                compare_data.get("bin3_upper")
                and compare_data["bin3_upper"] < dt["bin3"]
            )
        ):
            msg = msg_excursion_exceed
            response = {"data": dt, "msg": msg, "status": True}
            bin_data.update(
                {
                    f"{bin_type}3defectcount": dt.get("bin3"),
                    f"{bin_type}3": {
                        "sigma": "",
                        "lower": compare_data.get("bin3_lower"),
                        "upper": compare_data.get("bin3_upper"),
                    },
                }
            )
        if (dt.get("bin4") is not None and dt.get("bin4") != "") and (
            (compare_data.get("bin4_lower")
             and compare_data["bin4_lower"] > dt["bin4"])
            or (
                compare_data.get("bin4_upper")
                and compare_data["bin4_upper"] < dt["bin4"]
            )
        ):
            msg = msg_excursion_exceed
            response = {"data": dt, "msg": msg, "status": True}
            bin_data.update(
                {
                    f"{bin_type}4defectcount": dt.get("bin4"),
                    f"{bin_type}4": {
                        "sigma": "",
                        "lower": compare_data.get("bin4_lower"),
                        "upper": compare_data.get("bin4_upper"),
                    },
                }
            )
        if (dt.get("bin5") is not None and dt.get("bin5") != "") and (
            (compare_data.get("bin5_lower")
             and compare_data["bin5_lower"] > dt["bin5"])
            or (
                compare_data.get("bin5_upper")
                and compare_data["bin5_upper"] < dt["bin5"]
            )
        ):
            msg = msg_excursion_exceed
            response = {"data": dt, "msg": msg, "status": True}
            bin_data.update(
                {
                    f"{bin_type}5defectcount": dt.get("bin5"),
                    f"{bin_type}5": {
                        "sigma": "",
                        "lower": compare_data.get("bin5_lower"),
                        "upper": compare_data.get("bin5_upper"),
                    },
                }
            )
        # else:
        #     msg = msg_excursion_within
        #     response = {
        #         # 'data':[],
        #         # 'msg':msg,
        #         # 'status':False

        #     }
        if response:
            msg_list.append(response)
    return msg_list, bin_data


def check_purity_excursion(data, compare_data, rank_type):
    msg_list = []
    rank_data = {}
    response = {}
    msg_excursion_exceed = {
        "msg": "excusion limit exceeds. Auto alert is triggered"}
    msg_excursion_within = {
        "msg": "excusion limit does not exceed. Auto alert is triggered"
    }
    if "data" in data:
        data = data["data"]
    if data:
        for dt in data:
            # if response.get('status'):
            #     break
            alert_log.info("***********Rank compare*****************")
            alert_log.info(compare_data)
            alert_log.info(dt)
            alert_log.info("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%" * 100)

            if (
                "rank1" in dt and dt.get(
                    "rank1") is not None and dt.get("rank1") != ""
            ) and (
                (
                    compare_data.get("rank1_lower")
                    and compare_data["rank1_lower"] > dt.get("rank1")
                )
                or (
                    compare_data.get("rank1_upper")
                    and compare_data["rank1_upper"] < dt.get("rank1")
                )
            ):
                msg = msg_excursion_exceed
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}1defectcount": dt.get("rank1"),
                        f"{rank_type}1": {
                            "sigma": "",
                            "lower": compare_data.get("rank1_lower"),
                            "upper": compare_data.get("rank1_upper"),
                        },
                    }
                )
            if (
                "rank2" in dt and dt.get(
                    "rank2") is not None and dt.get("rank2") != ""
            ) and (
                (
                    compare_data.get("rank2_lower")
                    and compare_data["rank2_lower"] > dt["rank2"]
                )
                or (
                    compare_data.get("rank2_upper")
                    and compare_data["rank2_upper"] < dt["rank2"]
                )
            ):
                msg = {"msg": "excusion limit exeeds. Auto alert is triggered"}
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}2defectcount": dt.get("rank2"),
                        f"{rank_type}2": {
                            "sigma": "",
                            "lower": compare_data.get("rank2_lower"),
                            "upper": compare_data.get("rank2_upper"),
                        },
                    }
                )
            if (
                "rank3" in dt and dt.get(
                    "rank3") is not None and dt.get("rank3") != ""
            ) and (
                (
                    compare_data.get("rank3_lower")
                    and compare_data["rank3_lower"] > dt["rank3"]
                )
                or (
                    compare_data.get("rank3_upper")
                    and compare_data["rank3_upper"] < dt["rank3"]
                )
            ):
                msg = msg_excursion_exceed
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}3defectcount": dt.get("rank3"),
                        f"{rank_type}3": {
                            "sigma": "",
                            "lower": compare_data.get("rank3_lower"),
                            "upper": compare_data.get("rank3_upper"),
                        },
                    }
                )
            if (
                "rank4" in dt and dt.get(
                    "rank4") is not None and dt.get("rank4") != ""
            ) and (
                (
                    compare_data.get("rank4_lower")
                    and compare_data["rank4_lower"] > dt["rank4"]
                )
                or (
                    compare_data.get("rank4_upper")
                    and compare_data["rank4_upper"] < dt["rank4"]
                )
            ):
                msg = msg_excursion_exceed
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}4defectcount": dt.get("rank4"),
                        f"{rank_type}4": {
                            "sigma": "",
                            "lower": compare_data.get("rank4_lower"),
                            "upper": compare_data.get("rank4_upper"),
                        },
                    }
                )
            if (
                "rank5" in dt and dt.get(
                    "rank5") is not None and dt.get("rank5") != ""
            ) and (
                (
                    compare_data.get("rank5_lower")
                    and compare_data["rank5_lower"] > dt["rank5"]
                )
                or (
                    compare_data.get("rank5_upper")
                    and compare_data["rank5_upper"] < dt["rank5"]
                )
            ):
                msg = {"msg": "excusion limit exeeds. Auto alert is triggered"}
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}5defectcount": dt.get("rank5"),
                        f"{rank_type}5": {
                            "sigma": "",
                            "lower": compare_data.get("rank5_lower"),
                            "upper": compare_data.get("rank5_upper"),
                        },
                    }
                )
            if (
                ("rank6" in dt and dt.get("rank6")
                 is not None and dt.get("rank6") != "")
                and dt.get("rank6")
                and (
                    (
                        compare_data.get("rank6_lower")
                        and compare_data["rank6_lower"] > dt["rank6"]
                    )
                    or (
                        compare_data.get("rank6_upper")
                        and compare_data["rank6_upper"] < dt["rank6"]
                    )
                )
            ):
                msg = msg_excursion_exceed
                alert_log.info("TREUW" * 50)
                response = {"data": dt, "msg": msg, "status": True}
                rank_data.update(
                    {
                        f"{rank_type}6defectcount": dt.get("rank6"),
                        f"{rank_type}6": {
                            "sigma": "",
                            "lower": compare_data.get("rank6_lower"),
                            "upper": compare_data.get("rank6_upper"),
                        },
                    }
                )
            # else:
            #     msg = msg_excursion_within
            #     response = {
            #         'data':dt,
            #         'msg':msg,
            #         'status':False
            #     }
            if response:
                msg_list.append(response)
    else:
        msg = {"msg": "No data found"}
        response = {
            # 'data':[],
            # 'msg':msg
        }
        if response:
            msg_list.append(response)
    alert_log.info("WWWWWWWW" * 100)
    alert_log.info(rank_data)
    alert_log.info("QQQQQQQQ" * 100)

    return msg_list, rank_data




    