"""this model creates and updates rca history"""
import traceback
import time
from datetime import datetime
from api.utils.utils import  get_logger, get_queries
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger('rca_history')


class HistoryRca():
    """this class provides methods for rca history"""
    def __init__(self):
        """initialisation of rca queries """
        queries = get_queries("alert")
        self.queries = queries['rca']

    async def post_rca_history(self, data):
        """this method creates rca history"""
        try:
            strptime_str = "%d-%m-%YT%H:%M:%S"
            strftime_str= "%Y-%m-%d %H:%M:%S"
            app_log.info(f"get rca history paylaod {data}")
            resp = {"data":[],"numFound":0}
            start_date = datetime.strptime(data.get('startDate'), strptime_str).strftime(strftime_str)
            end_date = datetime.strptime(data.get('endDate'), strptime_str).strftime(strftime_str)
            query_data = {
                'startDate':start_date,
                'endDate':end_date,
                'rca_alert_id':data.get('rca_alert_id')
            }
            query_to_execute = f"{self.queries['read_rca_history'].format(**query_data)}" 
            data_output = await get_query_with_pool(query_to_execute)
            resp = {"data":data_output,"numFound":len(data_output)}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            resp={'error':f"error while preparing data {err}"}

        return resp

    async def put_rca_history(self, data):
        """this method updates rca history"""
        try:
            app_log.info(f"get rca history paylaod {data}")
            date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            query_data = {
                "autoreportid": data.get('alertid'),
                "reportname": data.get('alertname'),
                "filename": data.get('filename'), 
                "username": data.get('username'),
                "status": data.get('status'), 
                "invokefrom": "alerting_report",
                "autoreportidtimestamp": int((datetime.now() - datetime(1970, 1, 1)).total_seconds()),
                "email": data.get('status'), 
                "numberoffiles": 1, 
                "datetime": date_time,
                "deviceid" : data.get('deviceid'),
                'stepid' :data.get('layer'),
                'recipeid': data.get('setupid'),
                'lotrecord': data.get('carrierid')
                }
            query_to_execute = self.queries['create_new_rca_hist'].format(
                **query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"msg": "RCA history updated Successfully"}

        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': f"rca history api failed"}
        return resp
    
