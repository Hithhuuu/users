"""this model provides class and methods for alert filter"""
import traceback

from api.utils.fastapi_app import get_query_with_pool
from api.alert.alert_api.alert_utils import get_data
from api.utils.utils import get_queries, get_logger

app_log = get_logger('alert_filter')

class alertfilter():
    """this class provides methods for alert filters """
    def __init__(self):
        """Initializing filters instance"""
        queries = get_queries("alert")
        self.queries = queries['alert']

    async def get_filter_alert(self, data):
        '''Get the data for filter alert '''
        try:
            app_log.info(f"alert filter payload : {data}")
            condition = ''
            if 'imidiate' in data.get('report'):
                condition = f"and reportfrequency = '\"Immediately\"'"
                if data.get('alerttype') == 'fmonitoring':
                    condition = f"{condition} and dashboardfilters in ('\"\"', '', null,'[]')"
                else:
                    condition = f"{condition} and dashboardfilters not in ('\"\"', '', null,'[]')"
            elif 'All' not in data.get('report'):
                condition = f"and reportfrequency = '\"{data.get('report')}\"'"
            
            if 'DailyWeekly' in data.get('report'):
                query_to_execute = self.queries[f'read_weekly_daily_autoalert'].format(**{'condition':condition})
            else:
                query_to_execute = self.queries[f'read_filter_autoalert'].format(**{'condition':condition})

            data_output = await get_query_with_pool(query_to_execute)
            if 'imidiate' in data.get('report'):
                resp = get_data(data_output)
            elif 'DailyWeekly' in data.get('report'):
                resp = get_data(data_output, True)
            elif 'All' not in data.get('report'):
                resp = get_data(data_output, True)
            elif 'All' in data.get('report'):
                resp = get_data(data_output)

        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return{'error': "alert filter API Failed"}

        return resp


