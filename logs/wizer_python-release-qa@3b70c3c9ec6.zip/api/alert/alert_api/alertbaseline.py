"""this model returns baseline values for alerts """
import traceback

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_queries, get_logger, columns_info
from api.alert.alert_api.alert_utils import get_adc_class,get_binrank_class,prepare_query,get_purity_class

app_log = get_logger('alert_baseline')

class alertbaseline():

    def __init__(self):
        queries = get_queries("alert")
        self.queries = queries['alert']


    async def get_baseline(self, data):
        app_log.info('Preparing response for baseline')
        try:
            col_mapping = (columns_info['column_mapping'])
            rank_bin_condition_list = []
            query_data = dict()
                              
            if data.get("excludeList") and 'bin' not in data.get("excludeList") and data.get("bin"):
                rank_bin_condition_list.append(f' and {col_mapping.get("bin")} in {data.get("bin")}')
            if data.get("excludeList") and 'rank' not in data.get("excludeList") and data.get("rank"):
                rank_bin_condition_list.append(f' and {col_mapping.get("rank")} in {data.get("rank")}')

            if data.get("excludeList") and 'binrank' not in data.get("excludeList") and data.get("binrank"):
                rank_bin_condition_list.append(f' and {col_mapping.get("binrank")} in {data.get("binrank")}')

            if "excludeList" in data:
                for exclude in data.get("excludeList"):
                    rank_bin_condition_list.append(f' and {col_mapping.get(exclude)} not in {data.get(exclude)}') 
                data.pop("excludeList")
        
            if rank_bin_condition_list:
                rank_bin_condition = f"{' '.join(rank_bin_condition_list)}"
            else:
                rank_bin_condition = ''


            query_data['condition'] = prepare_query(data)
            query_data['rank_bin_condition'] = rank_bin_condition

            tab = data['id']
            if tab == 'rank':
                all_class, true_class, false_class = get_purity_class(data)
                if not all_class or not true_class or not false_class:
                    return {}
                query_data['true_class'] = tuple(true_class)
                query_data['false_class'] = tuple(false_class)
                query_data['purity_class_condition'] = f" and mansemclass in {tuple(all_class)}"

            elif tab == 'adc':
                adcmdc_class_condition = []
                mansemclass, autoonsemclass, hunterclass = get_adc_class(data)
                if not mansemclass and not autoonsemclass and not hunterclass:
                    return {}
                if len(autoonsemclass) > 0:
                    adc = f"sum(multiIf(autoonsemclass IN {tuple(autoonsemclass)}, 1, 0))"
                    adcmdc_class_condition.append(f" autoonsemclass IN {tuple(autoonsemclass)} ")

                else:
                    adc = 0

                if len(mansemclass) > 0:
                    mdc = f"sum(multiIf(mansemclass IN {tuple(mansemclass)}, 1, 0))"
                    adcmdc_class_condition.append(f" mansemclass IN {tuple(mansemclass)} ")
                else:
                    mdc = 0

                if len(hunterclass) > 0:
                    adcmdc_class_condition.append(f" hunterclass IN {tuple(hunterclass)} ")


                query_data['diffadcmdc'] = f"{adc} - {mdc} as diffadcmdc"
                query_data['adcmdc_class_condition'] = f" and ( {' or '.join(adcmdc_class_condition)} ) "

            elif tab == 'doibin':
                query_data['binrank_class_condition'], query_data['true_class'], query_data['classcode'] = get_binrank_class(data)
                if query_data['binrank_class_condition'] == '' or not query_data['true_class']:
                    return {}
                query_data['true_class'] = tuple(query_data['true_class'])
            else:
                app_log.info("Not a valid Dashboard Type")
                return {'error_msg': "Not a valid Dashboard Type"}

            query_to_execute = self.queries[f'get_baseline_{tab}'].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)            
            resp=data_output[0]

        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return{'error': str(err)}
        return resp

   