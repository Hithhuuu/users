"""Model for Alerts"""
import json
import traceback

from datetime import datetime
from api.alert.alert_api.alert_utils import (
    prepare_data,
    format_template_strings,
    format_alert_jsons,
    get_data
)
from api.utils.utils import get_queries, get_logger
from api.utils.common import  format_template_json
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("alert")
alert_log = get_logger("valid_alert")


class AlertModel:
    """this class provides methods for crud opertion on alert """
    def __init__(self):
        """Initializing clickhouse connection"""
        queries = get_queries("alert")
        self.queries = queries["alert"]

    def get_data(self, data_output, filterdata=False):
        """Format alert list data"""
        resp_list = []
        for data in data_output:
            if filterdata:
                day_dict = json.loads(data.get("reportdayselected"))
                selected_day_check = str(datetime.now().strftime("%A")) in day_dict.get(
                    "days"
                )
            else:
                selected_day_check = True
            if selected_day_check:
                resp_dict = {}
                for k in data:
                    try:
                        val = json.loads(data.get(f"{k}"))
                        if k == "dashboardfilters":
                            val = format_template_strings(val)
                        if k == "reportname" and isinstance(val, int):
                            val = str(val)
                    except Exception:
                        val = data.get(f"{k}")
                    resp_dict.update({f"{k}": val})
                resp_list.append(resp_dict)
        return sorted(resp_list, key=lambda i: i["reportcreateddate"], reverse=True)

    async def get_alert_details(self, data):
        """ return alert data  """
        try:
            app_log.info("Preparing response to get autoalert data")
            query_to_execute = self.queries["read_autoalert_details"].format(**data)
            data_output = await get_query_with_pool(query_to_execute)
            data_output = get_data(data_output)
            return data_output
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Get AutoAlert API Failed"}


    async def get_alertlist(self, data):
        """Get the alert list"""
        try:
            app_log.info("Preparing response to get autoalert data")
            query_to_execute = self.queries["read_autoalertlist"].format(**data)
            data_output = await get_query_with_pool(query_to_execute)
            format_alert_jsons(data_output)
            return sorted(
                data_output, key=lambda i: i["reportcreateddate"], reverse=True
            )
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "GET alert API failed"}

    async def create_alert(self, data):
        """Create the new alert"""
        try:
            app_log.info("Preparing to create new alert")
            data = format_template_json(data)
            query_data = prepare_data(data, "insert")
            query_to_execute = self.queries["save_report"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            return {"msg": "Alert Saved Successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to save alert"}

    async def update_alert(self, data):
        """Update the data for alert"""
        try:
            app_log.info("Updating alert...")
            data = format_template_json(data)
            query_data = prepare_data(data, "update")
            query_to_execute = self.queries["update_report"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            # get the remaining list of reports
            query_data["userid"] = data["username"]
            select_query = f"{self.queries['read_autoalertlist'].format(**query_data)}"
            data_output = await get_query_with_pool(select_query)
            format_alert_jsons(data_output)
            return data_output
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Failed to update alert"}

    async def delete_alert(self, data, userid):
        """Delete the data for alert"""
        try:
            if isinstance(data,str) or isinstance(data,bytes):
                data =  json.loads(data)    
            app_log.info("Deleting alert data...")
            rca_id = []
            alert_id = []
            if isinstance(data, str) or isinstance(data, bytes):
                data = json.loads(data)
            if isinstance(data, list):
                for i in data:
                    if i.get("type") == "rca":
                        rca_id.append(i.get("id"))
                    else:
                        alert_id.append(i.get("id"))
            if isinstance(data, dict) and data.get("dashboardfilters", []):
                query_to_execute = self.queries["get_dashboards"].format(
                    **{"id": data["id"]}
                )
                dashboardfilter_data = await get_query_with_pool(query_to_execute)
                dashboardfilter_data = json.loads(
                    dashboardfilter_data[0]["dashboardfilters"]
                )
                name_list = [
                    dashboards.get("name", "")
                    for dashboards in data["dashboardfilters"]
                ]
                dashboardfilter_data = [
                    dashboardfilter_data.pop(count)
                    for count, val in enumerate(dashboardfilter_data)
                    if val["name"] not in name_list
                ]
                query_execute = self.queries["update_dashboard"].format(
                    **{
                        "dashboardfilters": f"'{json.dumps(dashboardfilter_data)}'",
                        "id": data["id"],
                        "dashboardconnect": len(name_list),
                    }
                )
                await get_query_with_pool(query_execute, resp_type="None")
            else:
                if len(alert_id) > 0:
                    query_to_execute = self.queries["delete_report"].format(
                        **{"id": tuple(alert_id)}
                    )
                    await get_query_with_pool(query_to_execute, resp_type="None")
                if len(rca_id) > 0:
                    query_to_execute = self.queries["delete_rca_report"].format(
                        **{"id": tuple(rca_id)}
                    )
                    await get_query_with_pool(query_to_execute, resp_type="None")

            select_query = (
                f"{self.queries['read_autoalertlist'].format(**{'userid': userid})}"
            )
            data_output = await get_query_with_pool(select_query)
            resp = format_alert_jsons(data_output)
            return resp
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "alert Delete API Failed"}
