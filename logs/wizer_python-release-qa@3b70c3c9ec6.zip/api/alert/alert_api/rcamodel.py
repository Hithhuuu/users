"""Model for alerts API"""
import traceback
import json
import pandas as pd

from api.utils.fastapi_app import get_query_with_pool
from api.alert.alert_api.alert_utils import RcaUtils
from api.utils.utils import get_queries, get_logger
from api.utils.common import prepare_query_data, prepare_adc_data, get_tooltips
from datetime import datetime 


app_log = get_logger("rca_model")


class RcaCrud: 
    """ This class provides methods to get data for alerts"""
    def __init__(self) :
        """Intialising alerts queries"""
        queries = get_queries("alert")
        self.rca_util = RcaUtils()
        self.rca_query = queries["rca"]

    async def get_rca_data(self,data):
        """ get rca alerts for alert id"""
        try:
            app_log.info("get RCA")
            query_to_execute = self.rca_query['get_rca_details'].format(**{'id':data['id']})
            resp = await get_query_with_pool(query_to_execute)
            keys = ['reportdayselected','reportfrequency','reportinvitees',\
                    'flowdata','kpi_selected','usergroup']
            for i in resp:
                for k in keys:
                    i[k] = json.loads(i[k])
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "rca get api failed"}
        return resp

    async def update_rca_data(self,data):
        """update rca alert """
        try:
            app_log.info("Preparing to update RCA")
            op_type = 'update'
            if data.get('reportstatus'):
                query_data = {
                    'id' : data.get('id'),
                    'reportstatus' :  data.get('reportstatus')
                }
                query_to_execute = self.rca_query['update_rca_status'].format(**query_data)
                get_query_with_pool(query_to_execute,resp_type="None")
            else:
                query_data = self.rca_util.prepare_data(data = data, op_type=op_type)
                query_to_execute = self.rca_query['Set_message_status'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                query_to_execute = self.rca_query['set_isused'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                query_to_execute = self.rca_query['update_rca_report'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
            resp = {"msg": f"RCA {op_type}d Successfully"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': f"rca {op_type} api failed"}
        return resp

    async def create_rca_data(self,data):
        """create rca alert """
        try:
            app_log.info("Preparing to save RCA")
            op_type = 'create'
            query_data = self.rca_util.prepare_data(data, op_type=op_type)
            query_to_execute = self.rca_query['Set_message_status'].format(**query_data)
            await get_query_with_pool(query_to_execute,resp_type="None")
            query_to_execute = self.rca_query['save_rca_report'].format(**query_data)
            await get_query_with_pool(query_to_execute,resp_type="None")
            resp = {"msg": f"RCA {op_type}d Successfully"}         
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': f"rca {op_type} api failed"}
        return resp  

    async def delete_rca_data(self,data):
        """delete rca alert """
        try:
            app_log.info('Preparing to Delete rca alert')
            report_id = data['id']
            query_to_execute = self.rca_query['delete_report'].format(**{'id':report_id})
            await get_query_with_pool(query_to_execute,resp_type="None")
            resp = f"RCA alert deleted"
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "rca delete api failed"}
        return resp  
