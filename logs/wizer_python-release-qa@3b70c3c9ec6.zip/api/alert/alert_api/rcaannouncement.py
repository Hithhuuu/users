import traceback

from api.utils.utils import get_logger, get_queries
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger('rca_announcment')


class RcaAnnouncement():
    def __init__(self):
        '''Initialize template.'''
        queries = get_queries("alert")
        self.queries = queries['rca']

    async def get_announcement_of_user(self, data):
        """this method returns all announcements """
        try:
            user_id = data['userid']
            query_to_execute = self.queries['read_rca_accouncements'].format(
                **{'userid': user_id})
            data_output = await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {'error': f"Error while preparing data {err}"}
        return data_output

    async def new_announcement(self, data, userid):
        """this method creates announcement """
        try:
            if 'to_create' in data['modifiedData']:
                if len(data['modifiedData']['to_create']) > 0:
                    for i in data['modifiedData']['to_create']:
                        app_log.info("Preparing to add new RCA announcement")
                        await self.create_announcement(i)
                else:
                    app_log.info("No Insert performed on announcement")

            if 'to_delete' in data['modifiedData']:
                if len(data['modifiedData']['to_delete']) > 0:
                    for i in data['modifiedData']['to_delete']:
                        app_log.info("Deleting announcement")
                        await self.delete_announcement(i)
                    query_to_execute = self.queries['update_rca_data'].format(
                        **{'userid': userid})
                    await get_query_with_pool(query_to_execute, resp_type="None")
                else:
                    app_log.info("No Delete performed on announcement")

            resp = {'msg': f"All operations Successsfully performed"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
        return resp

    async def create_announcement(self, data):
        try:
            app_log.info("Preparing to add new RCA announcement")
            query_to_execute = self.queries['create_new_accouncement'].format(
                **{'userid': data.get('userid'), 'message': data.get('message')})
            await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)

    async def delete_announcement(self, data):
        try:
            delete = {'userid': data.get('userid'), 'output_id': data.get(
                'output_id'), 'is_used': 0, 'rfg': 0}
            query_to_execute = self.queries['selectedupdate_delete_rca_accouncements'].format(
                **delete)
            await get_query_with_pool(query_to_execute)
            app_log.info({'msg': f"RCA announcement deleted"})

        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
