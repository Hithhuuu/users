"""this model returns rca logic """
import traceback
import json

from api.utils.utils import get_logger, get_queries
from api.utils.fastapi_app import get_query_with_pool


app_log = get_logger('rca_model')



class RcaLogic():
    """this class provide methods for getting rca logic"""
    def __init__(self):
        '''Initialize template.'''
        queries = get_queries("alert")
        self.queries = queries['rca']
    
    async def logic_data(self, data):
        """this method returns logic data"""
        try:
            query_to_execute = self.queries['read_kpi_info'].format(**data)  
            data_output = await get_query_with_pool(query_to_execute)
            kpi_selected = json.loads(data_output[0].get('kpi_selected'))
            for i,k in enumerate(kpi_selected):
                data_output[0]['variations'] = data_output[0].get('variations').replace(f"kpi{i+1}",k.get('type'))
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {'error' :f"Error while preparing data {e}"}
        return data_output