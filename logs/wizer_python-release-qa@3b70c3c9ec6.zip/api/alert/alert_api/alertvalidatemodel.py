"""this model validates alerts based triggers values """
import json
import traceback

from datetime import datetime
from api.alert.alert_api.alert_utils import prepare_data, get_kpi_dict, format_template_strings,  check_filter_data, check_fmfilter_data, get_valid_alert
from api.utils.utils import get_queries, get_logger
from api.utils.fastapi_app import get_query_with_pool
from api.summaries.summaries_api.summariesmodel import Summary
from api.alert.alert_api.alerthistmodel import savehistory

app_log = get_logger('alert_validate')


class alertvalidate():
    """this class provides methods for alert validate """
    def __init__(self):
        """initialising queries for the class """
        queries = get_queries("alert")
        self.queries = queries['alert']

    async def get_validated_alert(self, data, token):
        """Get the data for validated alert"""
        app_log.info(f"***************payload***************-->>{data}")
        all_data_response = {}
        lst = []
        data_response = {}
        data_response_list_new = {}
        data_response_list = {}
        check_flag = True
        counts = 0
        count = 0
        counter_flag = 0
        postfix = {}
        fixedth = {}
        if data.get('alerttype', None) == 'fmonitoring':
            # Fetch all the valid FM alerts
            data_response_list = await self.get_valid_fmalert(data)
        else:
            if data.get('filters') and data.get('filename'):
                filename = data.get('filename')

                get_imm_file_record = self.queries['get_imm_file_record'].format(
                    **{'filename': f"('{filename}')"})
                mapid_record = await get_query_with_pool(get_imm_file_record)

                file_list_output = [
                    {
                        "filename": filename,
                        "mapid": mapid_record[0].get("mapid") if mapid_record else '',
                        "stepid": data.get('filters').get('stepid')[0] if data.get('filters').get('stepid') and isinstance(data.get('filters').get('stepid'), list) else data.get('filters').get('stepid') if data.get('filters').get('stepid') else [None],
                        "deviceid": data.get('filters').get('deviceid')[0] if isinstance(data.get('filters').get('deviceid'), list) else data.get('filters').get('deviceid'),
                        "waferrecord": data.get('filters').get('waferrecord')[0] if isinstance(data.get('filters').get('waferrecord'), list) else data.get('filters').get('waferrecord'),
                        "recipeid": data.get('filters').get('recipeid')[0] if isinstance(data.get('filters').get('recipeid'), list) else data.get('filters').get('recipeid', ''),
                        "lotrecord": data.get('filters').get('lotrecord')[0] if isinstance(data.get('filters').get('lotrecord'), list) else data.get('filters').get('lotrecord', ''),
                        "inspectionstationid": data.get('filters').get('inspectionstationid')[0] if isinstance(data.get('filters').get('inspectionstationid'), list) else data.get('filters').get('inspectionstationid', ''),
                        "toolid": data.get('filters').get('toolid')[0] if isinstance(data.get('filters').get('toolid'), list) else data.get('filters').get('toolid', 'NA'),
                        "src_tool":data.get('fileid').split('|')[-1].lower()
                    }
                ]
                app_log.info(file_list_output)
            else:
                get_file_query = {
                    "Daily": self.queries['daily'],
                    "Weekly": self.queries['weekly']
                }

                file_list = await get_query_with_pool(get_file_query[data.get("alerttype")])

                file_list = list(set([f.get('file_name') for f in file_list]))

                get_file_record = self.queries['get_imm_file_record'].format(
                    **{'file_list': file_list})
                file_list_output = await get_query_with_pool(get_file_record)
            try:
                app_log.info('Preparing response for fiter alert')
                alert_id_list = tuple(data.get('alertid'))
                query_to_execute = self.queries['read_autoalert_by_list_id'].format(
                    **{"alertid": alert_id_list})
                data_output = await get_query_with_pool(query_to_execute)
                resp_output = self.get_data(data_output)

                app_log.info(
                    f"***********get alert response by id*********: {len(resp_output)}")

                if resp_output:
                    # get all template ids
                    query_to_execute_template = self.queries['template_list']
                    template_id_list = await get_query_with_pool(query_to_execute_template, resp_type="list")

                for file_data in file_list_output:
                    file_check_condition = {
                        "frequency": 'Daily' if data.get('alerttype') == 'Daily' else 'Weekly' if data.get("alerttype") == 'Weekly' else f'Immediately',
                    }
                    if file_data.get('src_tool').lower() in ["adc", "klarity"]:
                        file_check_condition.update(
                            {"condition": f"inspectionstationid = '{file_data.get('inspectionstationid')}' and waferrecord='{file_data.get('waferrecord')}' and lotrecord='{file_data.get('lotrecord')}' and stepid='{file_data.get('stepid')}' and deviceid='{file_data.get('deviceid')}' and src_tool in ['adc','klarity']"})
                    elif file_data.get('src_tool').lower() in ["gebi"]:
                        file_check_condition.update(
                            {"condition": f"inspectionstationid = '{file_data.get('inspectionstationid')}' and waferrecord='{file_data.get('waferrecord')}' and lotrecord='{file_data.get('lotrecord')}' and stepid='{file_data.get('stepid')}' and deviceid='{file_data.get('deviceid')}' and src_tool in ['gebi']"})

                    for resp in resp_output:
                        file_check_condition.update({'id': resp.get('id')})
                        file_check_query = self.queries['read_alert_history_email'].format(
                            **file_check_condition)
                        length = await get_query_with_pool(file_check_query, resp_type="length")
                        email_sent_flag = True if len(length) > 0 else False
                        if email_sent_flag:
                            email_query = self.queries['email_status'].format(
                                **{'id': resp.get('id')})
                            email_status_flg = await get_query_with_pool(email_query, resp_type="length")
                            if len(email_status_flg) > 0:
                                continue
                        try:
                            alert_temp = resp.get("dashboardfilters")[0].get("filters")\
                                .get("dataMeasurement").get("loadedTemplate").get("template_id")
                        except Exception as e:
                            app_log.info(
                                f"******get alert template Error line 123******: {e}")
                        if alert_temp in template_id_list:
                            id_list = []
                            app_log.info(resp)
                            if data.get("filters"):
                                check_flag = check_filter_data(
                                    resp, data.get("filters"))
                            else:
                                file_data['inspectionstationid'] = ' '.join(
                                    file_data['inspectionstationid'])[-1]
                                check_flag = check_filter_data(resp, file_data)
                            app_log.info(
                                f"NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")
                            app_log.info(
                                f"valid alert api validate reponse: {check_flag}")
                            app_log.info(
                                f"NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")
                            if resp and check_flag:
                                valid = await get_valid_alert(token, resp, file_data)
                                app_log.info("__-----____------____")
                                app_log.info(valid)
                                for i in valid:
                                    if isinstance(i, list):
                                        valid.remove(i)
                                        valid.extend(i)
                                valid = [i for i in valid if i.get('data')]
                                app_log.info("0000"*100)
                                app_log.info(
                                    f"valid alert api validate reponse: {valid}")
                                app_log.info("0000"*100)

                                if valid and valid[0].get('data') and valid[0].get('data')[0].get('data'):
                                    app_log.info(valid[0].get(
                                        'data')[0].get('data'))
                                    classmetadata = {}
                                    for res_data in valid:
                                        count = count+1
                                        post_check = res_data.get(
                                            'compare_data').get("postfix", False)

                                        if post_check:
                                            id_list.append(
                                                f'{resp["id"]}-{res_data.get("compare_data").get("postfix")}')
                                            postfix_flag = True
                                            fixedth_flag = False
                                        elif not post_check:
                                            id_list.append(f'{resp["id"]}')
                                            postfix_flag = False
                                            fixedth_flag = True
                                        app_log.info("EE"*100)
                                        app_log.info(post_check)
                                        app_log.info(resp["id"])
                                        app_log.info("EE"*100)

                                        for dt in res_data['data']:
                                            counter_flag = counter_flag+1
                                            final = dt.get('data')
                                            compare = res_data.get(
                                                'compare_data')

                                            if dt.get('status'):
                                                app_log.info(final)
                                                app_log.info(compare)
                                                if "doi1" in compare and "total_doi" in final:
                                                    classmetadata.update({
                                                        "doi": compare
                                                    })
                                                elif 'kpirank1' in final or 'kpirank2' in final:
                                                    kpirank, kpibin = get_kpi_dict(
                                                        compare)
                                                    if kpirank:
                                                        classmetadata.update({
                                                            'kpirank': kpirank
                                                        })
                                                    if kpibin:
                                                        classmetadata.update({
                                                            'kpibin': kpibin
                                                        })
                                                elif "bin1" in final and \
                                                    'doi1' not in compare and \
                                                        any(k in compare for k in ("bin1", "bin2", 'bin3')):
                                                    if res_data.get('action') == "action_rank":
                                                        classmetadata.update({
                                                            "pbin": compare
                                                        })
                                                    else:
                                                        classmetadata.update({
                                                            "bin": compare
                                                        })
                                                elif "diffadcmdc" in final:
                                                    classmetadata.update({
                                                        "adc": compare
                                                    })

                                                elif "rank1" in final or "rank6" in final:
                                                    if res_data.get('action') == "action_rank":
                                                        classmetadata.update({
                                                            "rank": compare

                                                        })
                                                    else:
                                                        kpirank, kpibin = get_kpi_dict(
                                                            compare)
                                                        if kpirank:
                                                            classmetadata.update({
                                                                'kpirank': kpirank
                                                            })
                                                        if kpibin:
                                                            classmetadata.update({
                                                                'kpibin': kpibin
                                                            })
                                                else:
                                                    app_log.info(
                                                        "<><><><><><><><><>"*50, final)

                                                if postfix_flag:
                                                    postfix.update(
                                                        classmetadata)
                                                    classmetadata = {}
                                                elif fixedth_flag:
                                                    fixedth.update(
                                                        classmetadata)
                                                    classmetadata = {}
                                                    app_log.info(
                                                        "<><><><><><><><><>"*50, fixedth)

                                    ''' getting file name '''
                                    if data.get('filename'):
                                        filename = data.get('filename')

                                    ''' preparing response '''

                                    counts = counts+1
                                    app_log.info("--"*100)
                                    app_log.info(classmetadata)
                                    app_log.info("!!!"*100)

                                    if fixedth:
                                        fixedth.update({
                                            "username": resp.get("username"),
                                            "invitees": resp.get("reportinvitees"),
                                            "dashboardfilters": resp.get("dashboardfilters"),
                                            "reportname": resp.get("reportname"),

                                        })
                                        if not data.get('filters'):
                                            data_without_id_fixed = {
                                                f"{file_data.get('filename')}": {
                                                    "inspectionstationid": f"{file_data.get('inspectionstationid','')}",
                                                    "waferrecord": f"{file_data['waferrecord']}",
                                                    "lotrecord": file_data['lotrecord'],
                                                    "stepid": file_data['stepid'],
                                                    "toolid": file_data.get('toolid', ''),
                                                    "deviceid": file_data['deviceid'],
                                                    "recipeid": file_data['recipeid'],
                                                    "templates": resp.get('dataselectionfilters')['templates'] if resp.get('dataselectionfilters') and resp.get('dataselectionfilters').get('templates') else [],
                                                    "classmetadata": fixedth,
                                                    "filename": file_data.get('filename'),
                                                    "src_tool": file_data.get('src_tool'),
                                                    "monitor": ['bin', 'rank', 'adc', 'kpibin', 'kpirank'],
                                                }
                                            }
                                        else:
                                            fltr = data.get('filters')
                                            data_without_id_fixed = {
                                                f"{file_data.get('filename')}": {
                                                    "inspectionstationid": f"{fltr.get('inspectionstationid', '')[0]}",
                                                    "waferrecord": fltr.get('waferrecord', ''),
                                                    "lotrecord": fltr.get('lotrecord', ''),
                                                    "stepid": fltr.get('stepid', ''),
                                                    "toolid": valid[0].get('selection').get('toolid')[0] if valid[0].get('selection').get('toolid') else '',
                                                    "deviceid": fltr.get('deviceid', ''),
                                                    "recipeid": fltr.get('recipeid', ''),
                                                    "templates": resp.get('dataselectionfilters')['templates'] if resp.get('dataselectionfilters') and resp.get('dataselectionfilters').get('templates') else [],
                                                    "classmetadata": fixedth,
                                                    "filename": file_data.get('filename'),
                                                    "src_tool": file_data.get('src_tool'),
                                                    "monitor": ['bin', 'rank', 'adc', 'kpibin', 'kpirank'],
                                                }
                                            }

                                        fixedth = {}

                                    if postfix:
                                        postfix.update({
                                            "username": resp.get("username"),
                                            "invitees": resp.get("reportinvitees"),
                                            "dashboardfilters": resp.get("dashboardfilters"),
                                            "reportname": resp.get("reportname"),

                                        })

                                        if not data.get('filters'):
                                            data_without_id_post = {
                                                f"{file_data.get('filename')}": {

                                                    "inspectionstationid": f"{file_data['inspectionstationid']}",
                                                    "waferrecord": f"{file_data['waferrecord']}",
                                                    "lotrecord": file_data['lotrecord'],
                                                    "stepid": file_data['stepid'],
                                                    "toolid": file_data.get('toolid', ''),
                                                    "deviceid": file_data['deviceid'],
                                                    "recipeid": file_data['recipeid'],
                                                    "templates": resp.get('dataselectionfilters')['templates'] if resp.get('dataselectionfilters') and resp.get('dataselectionfilters').get('templates') else [],
                                                    "classmetadata": postfix,
                                                    "filename": file_data.get('filename'),
                                                    "monitor": ['bin', 'rank', 'adc', 'kpibin', 'kpirank'],
                                                }
                                            }
                                        else:
                                            fltr = data.get('filters')
                                            data_without_id_post = {
                                                f"{file_data.get('filename')}": {

                                                    "inspectionstationid": f"{fltr.get('inspectionstationid','')[0]}",
                                                    "waferrecord": fltr.get('waferrecord', ''),
                                                    "lotrecord": fltr.get('lotrecord', ''),
                                                    "stepid": fltr.get('stepid', ''),
                                                    "toolid": valid[0].get('selection').get('toolid')[0] if valid[0].get('selection').get('toolid') else '',
                                                    "recipeid": fltr.get('recipeid', ''),
                                                    "deviceid": fltr.get('deviceid', ''),
                                                    "templates": resp.get('dataselectionfilters')['templates'] if resp.get('dataselectionfilters') and resp.get('dataselectionfilters').get('templates') else [],
                                                    "classmetadata": postfix,
                                                    "filename": file_data.get('filename'),
                                                    "monitor": ['bin', 'rank', 'adc', 'kpibin', 'kpirank'],
                                                }
                                            }
                                        postfix = {}

                                    app_log.info(id_list)
                                    lst.append(file_data.get('filename'))
                                    if id_list:
                                        if f"{resp.get('id')}-consecutive" in data_response_list_new:

                                            data_response_list_new.get(f"{resp.get('id')}-consecutive").update(
                                                data_without_id_post
                                            )
                                        elif f"{resp.get('id')}" in data_response_list_new:
                                            data_response_list_new.get(f"{resp.get('id')}").update(
                                                data_without_id_fixed
                                            )
                                        else:
                                            for i in id_list:
                                                if not f'{i}' in all_data_response:
                                                    if 'consecutive' in i:
                                                        all_data_response = {
                                                            f'{i}': data_without_id_post
                                                        }
                                                    else:
                                                        all_data_response = {
                                                            f'{i}': data_without_id_fixed
                                                        }

                                                    data_response_list_new.update(
                                                        all_data_response)

                                        #  creating entry in alert history
                                        if data.get('alerttype') and data.get('alerttype') in ['weekly', 'daily']:
                                            alert_hist = {
                                                "autoreportid": resp.get("id"),
                                                "username": resp.get("username"),
                                                "reportname": resp.get("reportname"),
                                                "status": "Success",
                                                "datetime": datetime.now(),
                                                "email": "Success",
                                                "invokeFrom": "ui",
                                                "timeTaken": "",
                                                "autoreportidtimestamp": datetime.now().timestamp(),
                                                "numberOfFiles": 1,
                                                "url": "",
                                                "filename": file_data.get('filename')
                                            }
                                            save_hist = savehistory()
                                            await save_hist.history(alert_hist)

                                    ''' adding data into monitor '''
                            else:
                                app_log.info(
                                    f"********filter are not matching for id -- {resp.get('id')}*********")
                                continue
                            if data_response_list_new:
                                data_response_list.update(
                                    data_response_list_new)
                            if data_response:
                                data_response_list.update(data_response)
                            if lst:
                                app_log.info(
                                    f"******** all file list :{set(lst)} -->> {len(set(lst))} *********")
                            else:
                                app_log.info(
                                    f"******** all file list :{lst} -->> {len(lst)} *********")
                        else:
                            app_log.info(
                                f"******** Template does not exists! template id :{alert_temp} *********")

                            query_data = prepare_data(
                                {"rfg": 0, 'id': resp.get('id')}, 'update')
                            query_to_execute_off_alert = self.queries['update_report'].format(
                                **query_data)

                            app_log.info(
                                f"******** query_to_execute_to_off_alert : {query_to_execute_off_alert} *********")
                            await get_query_with_pool(query_to_execute_off_alert, resp_type="None")
                            app_log.info(
                                f"******** Alert id is deleted alert id {resp.get('id')} *********")
                app_log.info(data_response_list)
               
            except Exception as err:
                app_log.error(traceback.format_exc())
                app_log.error(err)
                return {'error': "alert vaidation API Failed-- {err}"}

        return data_response_list

    def get_data(self, data_output, filterdata=False):
        """formats data based on report type"""
        resp_list = []
        for data in data_output:
            if filterdata:
                day_dict = json.loads(data.get('reportdayselected'))
                app_log.info(
                    f"reportdayselected check --------->>{str(datetime.now().strftime('%A')) in day_dict.get('days')}")
                selected_day_check = str(
                    datetime.now().strftime('%A')) in day_dict.get("days")
            else:
                selected_day_check = True
            if selected_day_check:
                resp_dict = {}
                for k in data:
                    try:
                        val = json.loads(data.get(f"{k}"))
                        if k == "dashboardfilters":
                            val = format_template_strings(val)
                        if k == "reportname" and isinstance(val, int):
                            val = str(val)
                    except:
                        val = data.get(f"{k}")
                    resp_dict.update({
                        f"{k}": val
                    })
                resp_list.append(resp_dict)
        return sorted(resp_list, key=lambda i: i['reportcreateddate'], reverse=True)

    async def get_valid_fmalert(self, data):
        """validates failure alerts """
        try:
            app_log.info(f"FM alert payload: {data}")
            failure_resp = {}
            alert_id_list = tuple(data.get('alertid'))
            query_to_execute = self.queries['read_autoalert_by_list_id'].format(
                **{"alertid": alert_id_list})
            data_output = await get_query_with_pool(query_to_execute)
            resp_output = self.get_data(data_output)
            app_log.info(data_output)
            for resp in resp_output:
                resp_filter = {k: [v] if type(
                    v) == str else v for k, v in resp['dataselectionfilters'].items() if v}
                app_log.info(resp_filter)
                # Checking if data["filters"] matches with the filter of Alert
                # resp -> DB , filter_data-> node
                check_flag = False
                if data.get("filters"):
                    check_flag = check_fmfilter_data(response=resp_filter, filter_data=data.get(
                        "filters"), filetype=data['filters'].get('filetype', ['sem'])[0])
                app_log.info(check_flag)
                if check_flag:
                    failuremonitor = Summary()
                    dataselectionfilters = {
                        "stepid": resp_filter.get("stepid", [None])[0],
                        "product": resp_filter.get("deviceid", [None])[0],
                        "enlight_receipe": resp_filter.get("enlightrecipie", [None])[0],
                        "sem_receipe": resp_filter.get("semrecipie", [None])[0],
                        "inspection_tool": resp_filter.get("inspectiontool", [None])[0],
                        "sem_tool": resp_filter.get("reviewtool", [None])[0],
                        "lotid": data.get("filters").get("lotrecord")[0] if data.get("filters").get("lotrecord") != [] else ''
                    }

                    # Fetching failure details
                    failuredata = await failuremonitor.failuresummary(
                        data=dataselectionfilters, alertflag=True, filetype=data['filters'].get('filetype', ['sem'])[0])
                    app_log.info(failuredata)
                    if failuredata and failuredata.get('table'):
                        formatted_fmdata = []
                        for fdata in failuredata['table']:
                            # Filtering for failure conditions only
                            if (
                                fdata["enlight_scan_status"] == "fail"
                                or fdata["sem_review_status"] == "fail"
                                or fdata["defect_explorer_status"] == "fail"
                                or fdata["adc_status"] == "fail"
                                or fdata["doistatus"] == "fail"
                            ):
                                formatted_fmdata.append({
                                    "deviceid": fdata["product"],
                                    "stepid": fdata["layer"],
                                    "lotid": fdata["lotid"],
                                    "waferid": f'{fdata["slotid"]}',
                                    "enlighttimestamp": fdata["enlight_timestamp"],
                                    "enlightreceipe": fdata["enlight_receipe"],
                                    "enlightscanstatus": fdata["enlight_scan_status"],
                                    "semreceipe": fdata["sem_receipe"],
                                    "enlighttool": fdata["enlight_tool"],
                                    "semtool": fdata["sem_tool"],
                                    "semtimestamp": fdata["sem_timestamp"],
                                    "semreviewstatus": fdata["sem_review_status"],
                                    "defectexplorerstatus": fdata["defect_explorer_status"],
                                    "adcstatus": fdata["adc_status"],
                                    "doistatus": fdata["doistatus"],
                                    "workweek": fdata["workweek"]
                                })

                        if formatted_fmdata:
                            failure_resp[resp['id']] = {
                                "data": formatted_fmdata,
                                "username": resp.get("username"),
                                "reportinvitees": resp.get("reportinvitees"),
                                "reportname": resp.get("reportname"),
                                "alertid": f"{resp.get('id')}",
                                "filename":  data.get("filename")
                            }
                    app_log.info(f"FM alert response: {failure_resp}")
        except Exception as err:
            app_log.exception(err)
            failure_resp = {'error': f"alert vaidation API Failed-- {err}"}
        return failure_resp
