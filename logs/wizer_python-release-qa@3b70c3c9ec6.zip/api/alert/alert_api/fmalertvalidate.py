"""model for fm alert validate"""
import traceback
import json
import copy
import asyncio

from datetime import datetime
from api.alert.alert_api.alerthistmodel import  savehistory
from api.summaries.summaries_api.summariesmodel import Summary
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, columns_info, get_queries
from api.utils.common import send_mail

app_log = get_logger('validate_fm')

class ValidateFailureMonitor():
    """this class provides method for validate faliure alert """
    def __init__(self):
        """Intialising fm alert queries"""
        queries = get_queries("alert")
        self.fm_query = queries["alert"]
        self.history  = savehistory()
        self.summaries=  Summary()
    
    async def validate_fm_alert(self, data):
        """this method validates failure log alert  """
        app_log.info(f"payload-->>{data}")
        loop  = asyncio.get_running_loop()
        if data.get("type") == 'Immediately' : 
            data['query_condition'] =  await self.filter_condtition(data) 
            filter_query = self.fm_query['fm_alert_filter'].format(**data)
            resp_output = await get_query_with_pool(filter_query)
            for i in resp_output:
                loop.create_task(self.validate(valid_alert= i,filedata= data))
                # await self.validate(valid_alert=i, filedata=data)

    async def filter_condtition(self,data):
        """this method generates query conditions """
        try:
            cond_dict = [
                "deviceid" ,
                "enlightrecipie" ,
                "semrecipie",
                "inspectiontool",
                "tool_id"
            ]
            alias = {
                "inspectiontool": "inspection_tool_id",
                "tool_id" :"sem_tool_id"
            }
            cond_list = []
            for i in cond_dict:
                if i in list(alias.keys()) and data.get(i) not in ("",[],"NA","None"):
                    cond_list.append(f"JSONExtractString(dataselectionfilters, '{alias.get(i)}') = '[\"{data.get(i)}\"]'") 
                elif data.get(i) not in ("",[],"NA","None"):
                    cond_list.append(f"JSONExtractString(dataselectionfilters, '{i}') = '[\"{data.get(i)}\"]'") 
            if data.get("filetype") !="klarf":
                cond_str = f""" and position(JSONExtractString(dataselectionfilters,'stepid'), '{data.get("stepid")}' )>0""" + f" and ({' or '.join(cond_list)})" if len(cond_list) > 0 else ''
            else:
                cond_str = f" and ({' or '.join(cond_list)})" if len(cond_list) > 0 else ''

            return cond_str 
        except Exception as err:
            app_log.exception(err)

    async def validate(self,valid_alert,filedata):
        """this method generates and validates fm values """
        try:
            dataselection =  json.loads(valid_alert.get("dataselectionfilters"))
            summaries_data = {
                            "stepid": filedata.get("stepid") if len(dataselection.get("stepid",[]))>0 and filedata.get("filetype")!="klarf" else "",
                            "product": filedata.get("deviceid") if len(dataselection.get("deviceid",[])) > 0 else "",
                            "enlight_receipe": filedata.get("enlightrecipie") if len(dataselection.get("enlightrecipie",[])) > 0 else "",
                            "sem_receipe": filedata.get("semrecipie") if len(dataselection.get("semrecipie",[])) > 0 else "",
                            "inspection_tool": filedata.get("inspectiontool") if len(dataselection.get("inspection_tool_id",[])) > 0 else "",
                            "sem_tool": filedata.get("reviewtool") if len(dataselection.get("sem_tool_id",[])) > 0 else "",
                            "lotid": filedata.get("lotrecord") if filedata.get("lotrecord",'') else ''
            }
            app_log.info(f"summaries alert payload: {summaries_data}")
            failuredata = await self.summaries.failuresummary(data=summaries_data, alertflag=True,filetype=filedata.get("filetype") )
            if failuredata and failuredata.get('table'):
                formatted_fmdata = []
                for fdata in failuredata['table']:
                    # Filtering for failure conditions only
                    if (
                        fdata["enlight_scan_status"] == "fail"
                        or fdata["sem_review_status"] == "fail"
                        or fdata["defect_explorer_status"] == "fail"
                        or fdata["adc_status"] == "fail"
                        or fdata["doistatus"] == "fail"
                    ):
                        formatted_fmdata.append({
                            "deviceid": fdata["product"],
                            "stepid": fdata["layer"],
                            "lotid": fdata["lotid"],
                            "waferid": f'{fdata["slotid"]}',
                            "enlighttimestamp": fdata["enlight_timestamp"],
                            "enlightreceipe": fdata["enlight_receipe"],
                            "enlightscanstatus": fdata["enlight_scan_status"],
                            "semreceipe": fdata["sem_receipe"],
                            "enlighttool": fdata["enlight_tool"],
                            "semtool": fdata["sem_tool"],
                            "semtimestamp": fdata["sem_timestamp"],
                            "semreviewstatus": fdata["sem_review_status"],
                            "defectexplorerstatus": fdata["defect_explorer_status"],
                            "adcstatus": fdata["adc_status"],
                            "doistatus": fdata["doistatus"],
                            "workweek": fdata["workweek"]
                        })

                if formatted_fmdata:
                    header_str = f"""
                            <div> Hello <span style='text-transform: capitalize'>{valid_alert.get("username")}</span> </div><br/> <div>The file {filedata.get("filename")} has the following observations</div>
                            <h3> Failure Summary Report: </h3>
                            <table style='width:80%;border-collapse: collapse;'>
                    """
                    tablecolum = {
                                    'enlighttimestamp': 'Enlight time stamp',
                                    'semtimestamp': 'SEM (GEBI) time stamp',
                                    'workweek': 'Work week',
                                    'stepid': 'Layer',
                                    'deviceid': 'Product',
                                    'lotid': 'Lot ID',
                                    'waferid': 'Slot ID',
                                    'enlightreceipe': 'Enlight recipe name',
                                    'semreceipe': 'SEM (GEBI) recipe name',
                                    'enlighttool': 'Enlight tool ID',
                                    'semtool': 'SEM (GEBI) tool ID',
                                    'enlightscanstatus': 'Enlight scan status',
                                    'semreviewstatus': 'SEM (GEBI) review status',
                                    'doistatus': 'DOI rank status',
                                    'defectexplorerstatus': 'Defect explorer status',
                                    'adcstatus': 'ADC status',
                                }
                    cols_str = "<tr>"
                    val_str = ''
                    for key,val in tablecolum.items():
                        cols_str =cols_str+  f"""<td style='background-color: #1CA2D9; color: #fff;border-width: 1px; border-color: #fff;border-style: solid;border-collapse: collapse;padding: 0.2vw;'>{val}</td> """
                    cols_str =cols_str+ "</tr>" 

                    for resp in formatted_fmdata:
                        val_str = val_str + "<tr>"
                        for key,val in tablecolum.items():    
                            if resp.get(key) in (None, ''):
                                val_str = val_str + """ <td style='border-width: 1px;border-color: #ccc;border-style: solid;border-collapse: collapse;padding: 0.2vw;'>NA</td> """
                            elif str(resp.get(key)).lower() == 'pass':
                                val_str = val_str + f""" <td style='color: #51B13F;text-transform: capitalize; border-width: 1px;border-color: #ccc;border-style: solid; border-collapse: collapse;padding: 0.2vw;'><b>{resp.get(key).upper()}</b></td>  """
                            elif str(resp.get(key)).lower() == 'fail':
                                val_str = val_str + f""" <td style='color: #DA3321;text-transform: capitalize; border-width: 1px;border-color: #ccc;border-style: solid; border-collapse: collapse;padding: 0.2vw;'><b>{resp.get(key).upper()}<b></td>"""
                            else:
                                val_str = val_str + f""" <td style='border-width: 1px;border-color: #ccc;border-style: solid;border-collapse: collapse;padding: 0.2vw;'>{resp.get(key)}</td> """
                        val_str = val_str + "</tr>"
                    html_str = header_str + cols_str +val_str + "</table>"
                    for i in json.loads(valid_alert.get("reportinvitees")):
                        app_log.info(f" triggered for report: {valid_alert.get('reportname')} for file: {filedata.get('filename')}")
                        await send_mail(content=html_str, receiver=i, subject=f"Alert :- {valid_alert.get('reportname')}")
                    hist_payload = {
                        "autoreportid" : valid_alert.get("id"),
                        "username":valid_alert.get("username"),
                        "status": "Success",
                        "datetime": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        "email":"Success",
                        "invokeFrom" : "alerting_report",
                        "autoreportidtimestamp" : datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        "numberOfFiles": 1,
                        "url": '',
                        "filename": filedata.get("filename") 
                        }
                    await self.history.history(data=hist_payload)
        except Exception as err:
            app_log.exception(err)
