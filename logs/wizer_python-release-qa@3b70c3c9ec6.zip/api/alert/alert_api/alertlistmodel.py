"""this model returns alert list  """
import traceback
import json

from api.utils.utils import get_queries, get_logger
from api.utils.common import (create_notification, format_template_json)
from api.utils.fastapi_app import get_query_with_pool
from api.alert.alert_api.alert_utils import prepare_data,get_data

app_log = get_logger('alert_list')


class alertlistmodel():
    """this class returns methods for alert list """
    def __init__(self):
        queries = get_queries("alert")
        self.queries = queries['alert']

    async def get_alert_list(self, data):
        '''Get the data for alert history'''
        try:
            app_log.info('Preparing response to get autoalert data')
            query_data = {}
            query_data['template_name'] = f"%\"templates\": [\"{data['template_name']}\"]%"
            query_to_execute = self.queries['read_autoalert_list'].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = get_data(data_output)
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.info(err)
            return{'error': "Get AutoAlert API Failed"}

        return resp

    async def update_alerts(self, data):
        '''Update the data for alert'''
        try:
            app_log.info('Preparing to Update  Autoalerts')
            data_output = {}
            resp = []
            if "alert_ids" in data:
                all_date = data
                data = data.get("alert_ids")
            report_ids = [d['id'] for d in data]
            for report_id in report_ids:
                if "alert_ids" in all_date:
                    class_code = all_date.get("dataselectionfilters").get("classCode")
                    fetch_query = self.queries['fetch_query'].format(**{'report_id':report_id})
                    query_output = await get_query_with_pool(fetch_query)
                    data_selection = json.loads(query_output[0].get("dataselectionfilters"))
                    data_selection.update({"classCode":class_code})
                    query_to_execute = self.queries['update_classcode_report'].format(**{'dataselectionfilters':f"'{json.dumps(data_selection)}'", 'id':report_id})
                else:
                    data = format_template_json(data)
                    query_data = prepare_data(data, 'update')
                    query_to_execute = self.queries['update_report'].format(**query_data)
                try:
                    await get_query_with_pool(query_to_execute, resp_type="None")
                    data_output[f"{report_id}"] = 'Successfully updated.'
                except Exception as err:
                    app_log.info(f"Error while update: {err}")
                    data_output[f"{report_id}"] = 'Update unsuccessfull.'
                resp.append(data_output)
            alert_username_query = self.queries['alert_username_query'].format(**{'report_id':report_ids})
            username = await get_query_with_pool(alert_username_query)
            for user in username:
                short_descp=f"Your alert {user.get('reportname')} has been updated"
                await create_notification([user.get('username')],short_descp)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return{'error': "Autoalert update API Failed"}
        return resp



