"""model for rca alert validate"""
import traceback
import json
import copy
import asyncio

from datetime import datetime
from api.alert.alert_api.rcahistory import HistoryRca
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, columns_info, get_queries
from api.utils.common import send_mail

app_log = get_logger('validate_rca')



class ValidateRca():
    """this class provides method for rca validation"""
    def __init__(self):
        """Intialising rca queries"""
        queries = get_queries("alert")
        self.rca_query = queries["rca"]
        self.history  = HistoryRca()

    async def validate_rca_alert(self, data):
        """this method fetches and validates rca alert"""
        columns = columns_info
        kpi_alias = columns['kpi_alias']
        bin_alias = columns['bin_alias']
        resp = []
        days = {6: 'Sunday', 0: 'Monday', 1: 'Tuesday',
                2: 'Wednesday', 3:  'Thursday', 4: 'Friday', 5: 'Saturday'}
        app_log.info(f"payload-->>{data}")

        ################ immdiate execution ###########################
        if  data.get('filename'):
            file_list_output = [{
                "filename": data.get('filename'),
                "layer": data.get('stepid'),
                "product": data.get('deviceid'),
                "waferid": data.get('waferrecord'),
                "setupid": data.get('recipeid'),
                "carrierid": data.get('lotrecord'),
                "toolid": data.get('inspectionstationid'),
                "reviewtool": data.get('tool_id'),
                "src_tool":data.get('unique_header_id').split('|')[-1].lower(),
                "reportfrequency": "Immediately"
            }]

        else:
            ################ scheduled execution #########################
            get_file_query = {
                "Daily": f"{self.rca_query['daily']}",
                "Weekly": f"{self.rca_query['weekly']}"
            }
            file_list = await get_query_with_pool(get_file_query[data.get("alerttype")])
            file_list = list(set(f.get('file_name') for f in file_list))

            get_file_record = self.rca_query['file_record'].format(
                **{'alert_type': data.get('alerttype'), 'file_list': file_list})
            file_list_output = await get_query_with_pool(get_file_record)

        for filedata in file_list_output:
            try:
                query_to_execute = self.rca_query['read_rcaalert_by_list_id'].format(
                    **filedata)
                data_output = await get_query_with_pool(query_to_execute)
                if data_output:
                    query_data = copy.deepcopy(filedata)
                    for i in data_output:
                        try:
                            alert_resp = copy.deepcopy(filedata)
                            filedata.update({"id": i.get('id')})
                            query_to_execute = self.rca_query['rca_status'].format(
                                **filedata)
                            status = await get_query_with_pool(query_to_execute)
                            # """ email status check for product layer recipe lot"""
                            if ((days.get(datetime.today().weekday()) not in \
                                 json.loads(i.get('reportdayselected')).get("days")) and
                                    data.get("alerttype")) or len(status) > 0:
                                continue
                            alert_resp['deviceid'] = alert_resp['product']
                            alert_resp.pop('product')
                            alert_resp['reportinvitees'] = json.loads(
                                i['reportinvitees'])
                            i = await self.json_formatter(i)
                            alert_resp['alertid'] = i['id']
                            alert_resp['alertname'] = i['reportname']
                            alert_resp['username'] = i['username']
                            alert_resp['variations'] = i['variations']
                            alert_resp['reportstatus'] = i['reportstatus']
                            alert_resp['reportfrequency'] = i['reportfrequency']
                            alert_resp['reportrunday'] = i['reportrunday']
                            query_data['condition'] = await self.query_condtion(
                                filedata)
                            output = {}
                            rules = {}
                            variation = {}
                            classgroups = {
                                "mdc": "mansemclass",
                                "adc": "autoonsemclass",
                                "adchc": "hunterclass"
                            }
                            # """fetch kpi and bin values"""
                            for ind, val in enumerate(i['kpi_selected']):
                                classifications = copy.deepcopy(
                                    val.get('classification'))
                                if classifications:
                                    groups =await self.grouping(
                                        tuple(classifications.values())[0])
                                else:
                                    continue
                                query_data['classcode'] = classgroups.get(
                                    list(val.get('classification').keys())[0])
                                query_data.update(groups)
                                if val.get('type') in kpi_alias.keys():
                                    query_to_execute = self.rca_query['kpi_data'].format(
                                        **query_data)
                                    kpi_val = await get_query_with_pool(query_to_execute)
                                    fetch_val = kpi_val[0].get(
                                        kpi_alias.get(val.get('type')))
                                elif val.get('type') in bin_alias.keys():
                                    query_to_execute = self.rca_query['bin_data'].format(
                                        **query_data)
                                    kpi_val = await get_query_with_pool(query_to_execute)
                                    fetch_val = kpi_val[0].get(
                                        bin_alias.get(val.get('type')))
                                else:
                                    app_log.info(
                                        "did not fetch anything , check paylooad for type")
                                    continue
                                output.update(
                                    {f"kpi{ind+1}": f"{fetch_val} {val.get('operator')} {val.get('value')}"})
                                variation.update(
                                    {f"kpi{ind+1}": f"{val.get('type')}"})
                                rules.update(
                                    {f"rule{ind+1}": f"{val.get('type')} {val.get('operator')} {val.get('value')}, {fetch_val}"})
                            output.update({'AND': 'and', 'OR': 'or'})
                            eval_str = i.get('variations')
                            # """evaluation string for selected kpi"""
                            for key, vals in output.items():
                                eval_str = eval_str.replace(
                                    f'{key}', f'{vals}')
                            for keys, values in variation.items():
                                alert_resp['variations'] = alert_resp.get(
                                    'variations').replace(f"{keys}", f"{values}")
                            eval_str = eval_str.replace(' = ', ' == ').replace(
                                '{', '(').replace('}', ')').rstrip()
                            app_log.info(f"{eval_str} ")
                            if len(eval_str) > 0 and eval(eval_str):
                                alert_resp.update(rules)
                                alert_resp.update(
                                    {'rcannouncement': i.get('rcannouncement')})
                                app_log.info("alert triggered")
                                resp.append(alert_resp)
                                alert_resp['status'] = 'Success'
                                await self.history.put_rca_history(alert_resp)
                        except Exception as err:
                            alert_resp['status'] = 'Failed'
                            await self.history.put_rca_history(alert_resp)
                            app_log.error(traceback.format_exc())
                            app_log.info(f"failed ids : {i} and errored with {err}")
            except Exception as err:
                app_log.error(traceback.format_exc())
                app_log.error(err)
                resp = {'error': "rca vaidation API Failed-- {err}"}
        if len(resp)>0:
            await self.rca_email(resp)        
        return resp

    async def grouping(self, data):
        """group classification for rca validation"""
        false_group = []
        true_group = []
        all_group = []
        nullclass = []
        null = '(null)'
        for i, k in data.items():
            if i == 'False':
               false_group = [int(x) for x in k]
            elif i == 'True':
                true_group = [int(x) for x in k]
            else:
                nullclass = [int(x) for x in k]
        all_group = nullclass+true_group+false_group
        resp = {
            'false_class': tuple(false_group) if len(false_group) > 0 else null,
            'true_class': tuple(true_group) if len(true_group) > 0 else null,
            'all_class': tuple(sorted(all_group)) if len(all_group) > 0 else null
        }
        return resp

    async def json_formatter(self, data):
        """json converter for rca data """
        keys = ['reportdayselected', 'reportfrequency',
                'reportinvitees', 'flowdata', 'kpi_selected', 'usergroup']
        for k in keys:
            data[k] = json.loads(data[k])
        return data

    async def query_condtion(self, data):
        """query condition for rca data"""
        keys = ['layer', 'product', 'waferid', 'carrierid', 'filename']
        str_list = []
        for i in keys:
            if data.get(i):
                str_list.append(f"{i} in ('{data.get(i)}')")
        return " and ".join(str_list)

    async def rca_email(self,data):
        app_log.info("sending mail for rca alert")
        resp = {}
        loop = asyncio.get_running_loop()
        for i in data :
            header_str =  f"""<div> Hello <span style='text-transform: capitalize'>{i.get("username")}</span> </div><br />
                        <div>The file {i.get("filename")} has met the RC announcement alert rules.</div>
                        <h3> Data Selection: </h3>
                        <table style='width:80%;border-collapse: collapse;'>
                        """
            table_data ={
                        "Alert name" :i.get("alertname"),
                        "Product":  i.get("deviceid"),
                        "Layer":   i.get("layer"),
                        "Inspection Tool" :   i.get("toolid") ,
                        "Review Tool"  :  i.get("reviewtool"),
                        "Lot" : i.get("carrierid"), 
                        "Wafer": i.get("waferid"), 
                        "Rule 1": i.get("rule1"),
                        "Rule 2": i.get("rule2"),
                        "Rule 3":i.get("rule3"),
                        "Variation" :i.get("variations"),
                        "RC Announcement" : i.get("rcannouncement")
            }
            table_list= []
            for key,val in table_data.items():
                table_list.append(f"<tr><td style='border:thin solid black'><b>'{key}'</b></td><td style='border:thin solid black'>'{val}'</td></tr>")
            table_str = '\n'.join(table_list)
            email_str = header_str+table_str+"</table>"
            for email in  i.get("reportinvitees"):
                loop.create_task(send_mail(content=email_str, receiver=email, subject=f"Alert :- {i.get('alertname')}"))
                app_log.info("email triggered for rca ")


        
