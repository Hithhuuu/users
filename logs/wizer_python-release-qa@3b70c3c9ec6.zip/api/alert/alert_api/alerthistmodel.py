""" this model is to save history of alerts """
import traceback
import json
import pandas as pd

from datetime import datetime
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_queries, get_logger


app_log =get_logger('alert_history')


class alerthistorymodel():

    def __init__(self):
        queries = get_queries("alert")
        self.queries = queries['alert']

    async def get_alert_history(self, data):
        '''Get the data for alert history'''
        try:
            app_log.info(f"get alert history paylaod {data}")
            resp = {"data":[],"numFound":0}
            start_date = datetime.strptime(data.get('startDate'), "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")

            end_date = datetime.strptime(data.get('endDate'), "%d-%m-%YT%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
            query_data = {
                'startDate':start_date,
                'endDate':end_date,
                'autoreportid':data.get('autoreportid')[0]
            }
            query_to_execute = f"{self.queries['history_status_query'].format(**query_data)}" 
            data_output = await get_query_with_pool(query_to_execute)
            query_to_execute = self.queries['fetch_alert_type'].format(**{'alertid': data.get('autoreportid')[0]})
            alert_type = await get_query_with_pool(query_to_execute)
            alert_type = alert_type[0]

            for i in range(len(data_output)):
                data_output[i]['alerttype'] = alert_type

            resp = {"data":data_output,"numFound":len(data_output)}
        except Exception as e:
            import traceback
            app_log.error(traceback.format_exc())
            app_log.error(e)
            return{'error': "alert history API Failed"}

        return resp
    
class savehistory():

    def __init__(self):
        queries = get_queries("alert")
        self.queries = queries['alert']

    async def history(self, data):
        app_log.info(f"Save history -> Start processing save history AutoReport {data}")
        try:
            #if data.get("report",''):
            values = {}
            for key, val in data.items():
                if val != None:
                    if key == "report":
                        values[key] = json.dumps(val)
                    elif key == "userid":
                        values["username"]=val
                    elif key == "autoreportid":
                        # values[key] = val.split('-')[0]
                        values[key] = val
                    else:
                        values[key] = val
                        
                else:
                    values[key] = ""
                    

            dt_string = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            values['datetime'] = dt_string
            map_header_query = f"select product, layer, setupid, carrierid, waferid, splitByChar(' ', platform)[-1] AS inspectionstationid, src_tool from opwi_map_header final where filename='{data['filename']}' and rfg=1"
            map_header_data_list = await get_query_with_pool(map_header_query)
            app_log.info("**"*100)
            app_log.info(map_header_data_list)
            if map_header_data_list:
                for map_header_data in map_header_data_list:
                    values['deviceid'] = map_header_data['product']
                    values['stepid'] = map_header_data['layer']
                    values['waferrecord'] = map_header_data['waferid']
                    values['recipeid'] = map_header_data['setupid']
                    values['inspectionstationid'] = map_header_data['inspectionstationid']
                    values['lotrecord'] = map_header_data['carrierid']
                    values['src_tool'] = map_header_data['src_tool'].lower()
                    cols_string = [x.lower() for x in list(values.keys())]
                    cols = ",".join(cols_string)

                    values_string = tuple(values.values())
                    data = {}
                    data["cols"] = cols
                    data["values_string"] = values_string

                    query_to_execute = self.queries['savehist_insert_query'].format(**data)
                    await get_query_with_pool(query_to_execute, resp_type="None")

            else:
                    cols_string = [x.lower() for x in list(values.keys())]
                    cols = ",".join(cols_string)
                    values_string = tuple(values.values())
                    data = {}
                    data["cols"] = cols
                    data["values_string"] = values_string

                    query_to_execute = self.queries['savehist_insert_query'].format(**data)
                    await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"success": "Alert history inserted successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            err_message = str(err).replace("\'", "").replace("\"", "")
            app_log.error(f"Something went wrong during delete autoreport:")
            resp = {"error": err_message}
        return resp



