"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.history.history_api import historyhandler


app.include_router(historyhandler.router)
