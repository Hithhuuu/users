"""Return file history for WIZER"""
import json
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi import Request, APIRouter, Depends
from api.history.history_api.historymodel import HistoryModel
from api.utils.fastapi_app import validate_authenticity

history_obj = HistoryModel()

router = APIRouter(prefix="/history")


@router.post("", dependencies=[Depends(validate_authenticity)])
async def post(request: Request):
    """On POST request return file history
    desc: Get the History of the file upload
    params: "username"
    response: [{"uploadedTime":,"fileName":,"size":,"progressPercent":}]
    """
    body = await request.body()
    body = json.loads(body)
    body["endpoint"] = request.url.path
    response = await history_obj.get_file_history(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return PlainTextResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
