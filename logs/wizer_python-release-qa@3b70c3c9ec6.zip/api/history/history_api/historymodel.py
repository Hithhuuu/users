"""Model for history api"""

from api.utils.utils import queries, get_logger
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger('history')
class HistoryModel():
    """Class for model"""
    def __init__(self):
        '''Initializing queries for history'''
        self.queries = queries['history']
   
    async def get_file_history(self, data):
        '''Get file history'''
        try:
            app_log.info('Start of the File History API')
            if data['type'] == 'adc':
                query_to_execute = self.queries['read_adc_history'].format(**data)
            elif data['type'] == 'gebi':
                query_to_execute = self.queries['read_gebi_history'].format(**data)
            data_output = await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.exception(err)
            app_log.info("History API failed")
            return {'error': str(err)}
        return data_output
