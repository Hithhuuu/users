"""autoreport handler"""
import os
import sys
import json
import asyncio

from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.utils.common import get_user
from api.utils.fastapi_app import validate_authenticity
from api.autoreport.autoreport_api.autoreportmodel import AutoReportModel
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from schedulers.auto_reporting import on_demand_execution



router = APIRouter(prefix="/autoreport", dependencies=[Depends(validate_authenticity)])
autoreport = AutoReportModel()


@router.get("")
async def get_autoreport(request : Request):
    """GET method for autoreport"""
    userid = get_user(request)["userid"]
    response = await autoreport.get_report(userid)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.post("")
async def create_autoreport(request: Request, body : dict):
    """POST method for autoreport"""
    userid = get_user(request)["userid"]
    response = await autoreport.save_report(data=body, userid=userid)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)

@router.put("")
async def update_autoreport(request:Request , body : dict):
    """PUT method for autoreport"""
    userid = get_user(request)["userid"]
    response = await autoreport.update_report(data=body, userid=userid)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.delete("")
async def delete(request : Request, body :dict):
    """DELETE method for autoreport"""
    userid = get_user(request)["userid"]
    response =await autoreport.delete_report(data=body, userid=userid)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/autoreportid")
async def get_autoreportid( body : dict):
    """POST method for autoreportid"""
    response = await autoreport.get_report_by_id(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/history")
async def autoreport_history( body:dict):
    """POST method for history"""
    response = await autoreport.get_report_history(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/run")
async def run_autoreport(body :dict):
    """POST method to generate autoreport """
    try:
        if len(body['autoReportIds']) == 0:
            response  = {"error": "autoReportIds is empty"}
        else:
            loop = asyncio.get_running_loop()
            for i in range(len(body['autoReportIds'])):

                report_data = dict()
                report_data['autoReportIds'] = [str(body['autoReportIds'][i])]
                report_data['autoreportidtimestamp'] = [body['autoreportidtimestamp'][i]]
                report_data['username'] = body['username']
                report_data['auth_token'] = body['auth_token']
                report_data['invokedFrom'] = body['invokedFrom']

                auto_report_id = f"{report_data['autoreportidtimestamp'][0]}"
                loop.create_task(on_demand_execution(report_data))
                # on_demand_execution.apply_async((report_data, 1), task_id=auto_report_id,
                #                                     queue='Wzr_Auto_Queue', routing_key='Wzr_Auto_Queue')
            response = {"success": f"Pushed Auto-Report Id to queue -> {body['autoReportIds']}"}
    except Exception :
        response = {'error': "Run (on demand) AutoReport API Failed"}
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/savereporthist")
async def savereporthistory( body : dict):
    """POST method to save history """
    response = await autoreport.history(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/fetchreporthiststatus")
async def fetch_report_status(body :dict):
    """POST method to fetch report history """
    response = await autoreport.historystatus(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
        status_code=400,
        content={"message": response.get("error")},
    )
    return JSONResponse(response)


@router.post("/fetchreport")
async def fetchreport(request: Request , body : dict ):
    """ Save new auto report record """
    body['report'] = request.query_params.get('report', None)
    body["username"] = get_user(request)["userid"]
    response = await autoreport.fetch(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
    status_code=400,
    content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/fetchcustomreporthist")
async def post(body : dict,response_model=list()):
    """ get auto report record """
    response = await autoreport.customer_history(body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
    status_code=400,
    content={"message": response.get("error")},
        )
    return response