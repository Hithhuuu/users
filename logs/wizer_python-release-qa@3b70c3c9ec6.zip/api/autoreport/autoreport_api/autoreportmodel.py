"""this model returns data for autoreport"""
import copy
import json
import traceback
from datetime import datetime

import pandas as pd
import yaml

from api.utils.common import format_template_json, format_template_string
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, queries

app_log = get_logger("autoreport")


class AutoReportModel:
    def __init__(self):
        """Initializing opwi_map_header instance"""
        self.queries = queries["autoreport"]

    def get_data(self, data_output):
        resp_list = []
        for data in data_output:
            resp_dict = {}
            for k in data:
                try:
                    val = json.loads(data.get(f"{k}"))
                    if k == "dashboardfilters":
                        val = format_template_string(val)
                    if k == "reportname" and isinstance(val, int):
                        val = str(val)

                except:
                    val = data.get(f"{k}")
                resp_dict.update({f"{k}": val})
            resp_list.append(resp_dict)
        return sorted(resp_list, key=lambda i: i["reportcreateddate"], reverse=True)

    async def get_report(self, userid):
        """Get the data for the adc pareto"""
        try:
            app_log.info("Preparing response to get autoreport data")
            query_to_execute = self.queries["read_autoreport"].format(
                **{"userid": userid}
            )
            data_output = await get_query_with_pool(query_to_execute)
            resp = self.get_data(data_output)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Get AutoReport API Failed"}

        return resp

    async def get_report_by_id(self, data):
        """Get the data for the adc pareto"""
        try:
            app_log.info("Preparing response to get autoreport data")
            reportid = data.get("id")
            query_format = f"id = {reportid}"
            query_to_execute = self.queries["auto_report"].format(
                **{"condition": query_format}
            )

            data_output = await get_query_with_pool(query_to_execute)
            resp = self.get_data(data_output)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Get AutoReport API Failed"}

        return resp

    async def save_report(self, data, userid):
        """Get the data for the adc,mdc,adchc"""
        try:
            app_log.info("Preparing to Save  Autoreport")
            # self.get_tooltips(query_data, data['userInputs']['tooltipdata'])
            data["username"] = userid
            if data["dashboardfilters"]:
                for i in range(len(data["dashboardfilters"])):
                    if (
                        data["dashboardfilters"]
                        and data["dashboardfilters"][i]["filters"]
                        and data["dashboardfilters"][i]["filters"]["dataMeasurement"]
                        and data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                            "loadedTemplate"
                        ]
                        and data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                            "loadedTemplate"
                        ]["template_json"]
                    ):
                        data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                            "loadedTemplate"
                        ]["template_json"] = json.loads(
                            data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                                "loadedTemplate"
                            ]["template_json"]
                        )
            query_data = self.prepare_data(data, "insert")
            query_to_execute = self.queries["save_report"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"msg": f"Autoreport Saved Successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Autoreport Save API Failed"}
        return resp

    async def delete_report(self, data, userid):
        """Delete the data for autoreport"""
        try:
            app_log.info("Preparing to Delete  Autoreport")
            report_id = data["id"]
            query_to_execute = self.queries["delete_report"].format(
                **{"id": tuple(report_id)}
            )
            await get_query_with_pool(query_to_execute, resp_type="None")
            # get the remaining list of reports
            where_clause = f" and id NOT IN {report_id}"
            select_query = f"{self.queries['read_autoreport'].format(**{'userid':userid})} {where_clause}"
            data_output = await get_query_with_pool(select_query)
            resp = self.get_data(data_output)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Autoreport Delete API Failed"}
        return resp

    def prepare_data(self, data, op_type):
        """prepares data for create and update"""
        try:
            datetime_format = "%Y-%m-%d %H:%M:%S"
            if op_type == "insert":

                day_list = []
                reportdayselected = data.get("reportdayselected", "")
                if reportdayselected.get("days", None):
                    day_list.extend(reportdayselected.get("days"))
                if reportdayselected.get("dayNumber", None):
                    day_list.append(reportdayselected.get("dayNumber"))
                if reportdayselected.get("type", None) and reportdayselected.get(
                    "day", None
                ):
                    week_number = self.queries["placement_map"][
                        reportdayselected.get("placement")
                    ]
                    report_day = f"{week_number}_{reportdayselected.get('day')}"
                    day_list.append(report_day)
                if day_list:
                    reportrunday = f"{json.dumps(day_list)}"
                data_dict = {
                    "reportname": f"{data.get('reportname')}",
                    "username": data.get("username"),
                    "dashboardConnectedCount": f"{json.dumps(data.get('dashboardConnectedCount',''))}",
                    "reportcreateddate": pd.to_datetime(str(datetime.now())).strftime(
                        datetime_format
                    ),
                    "reportdayselected": f"{json.dumps(data.get('reportdayselected', ''))}",
                    "reportrunday": reportrunday,
                    "reportfrequency": f"{json.dumps(data.get('reportfrequency', ''))}",
                    "reportstatus": f"{json.dumps(data.get('reportstatus', ''))}",
                    "reportdownloadformat": f"{json.dumps(data.get('reportdownloadformat', ''))}",
                    "reportinvitees": f"{json.dumps(data.get('reportinvitees', ''))}",
                    "timetrendanalysisfilters": f"{json.dumps(data.get('timetrendanalysisfilters', ''))}",
                    "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                    "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                    "pastdays": f"{json.dumps(data.get('pastdays',''))}",
                    "excludelist": f"{json.dumps(data.get('excludelist',''))}",
                }
            elif op_type == "update":
                day_list = []
                reportrunday = None
                reportdayselected = data.get("reportdayselected", None)
                # if reportdayselected:
                if reportdayselected and reportdayselected.get("days", None):
                    day_list.extend(reportdayselected.get("days"))
                if reportdayselected and reportdayselected.get("dayNumber", None):
                    day_list.append(reportdayselected.get("dayNumber"))
                if (
                    reportdayselected
                    and reportdayselected.get("type", None)
                    and reportdayselected.get("day", None)
                ):
                    week_number = self.queries["placement_map"][
                        reportdayselected.get("placement")
                    ]
                    report_day = f"{week_number}_{reportdayselected.get('day')}"
                    day_list.append(report_day)
                if reportdayselected and day_list:
                    reportrunday = f"{json.dumps(day_list)}"
                data_dict = {
                    "id": data.get("id"),
                    "reportname": f"{json.dumps(data.get('reportname'))}"
                    if data.get("reportname")
                    else "reportname",
                    "username": f"'{data.get('username')}'"
                    if data.get("username")
                    else "username",
                    "dashboardConnectedCount": f"{json.dumps(data.get('dashboardConnectedCount'))}"
                    if data.get("dashboardConnectedCount")
                    else "dashboardConnectedCount",
                    "reportcreateddate": pd.to_datetime(str(datetime.now())).strftime(
                        datetime_format
                    ),
                    "reportdayselected": f"'{json.dumps(data.get('reportdayselected'))}'"
                    if data.get("reportdayselected")
                    else "reportdayselected",
                    "reportrunday": f"'{reportrunday}'"
                    if reportrunday
                    else "reportrunday",
                    "reportfrequency": f"'{json.dumps(data.get('reportfrequency'))}'"
                    if data.get("reportfrequency")
                    else "reportfrequency",
                    "reportstatus": f"'{json.dumps(data.get('reportstatus'))}'"
                    if data.get("reportstatus")
                    else "reportstatus",
                    "reportdownloadformat": f"'{json.dumps(data.get('reportdownloadformat'))}'"
                    if data.get("reportdownloadformat")
                    else "reportdownloadformat",
                    "reportinvitees": f"'{json.dumps(data.get('reportinvitees'))}'"
                    if data.get("reportinvitees")
                    else "reportinvitees",
                    "timetrendanalysisfilters": f"'{json.dumps(data.get('timetrendanalysisfilters'))}'"
                    if data.get("timetrendanalysisfilters")
                    else "timetrendanalysisfilters",
                    "dataselectionfilters": f"'{json.dumps(data.get('dataselectionfilters'))}'"
                    if data.get("dataselectionfilters")
                    else "dataselectionfilters",
                    "dashboardfilters": f"'{json.dumps(data.get('dashboardfilters'))}'"
                    if data.get("dashboardfilters")
                    else "dashboardfilters",
                    "pastdays": f"'{json.dumps(data.get('pastdays'))}'"
                    if data.get("pastdays")
                    else "pastdays",
                    "excludelist": f"'{json.dumps(data.get('excludelist'))}'"
                    if data.get("excludelist")
                    else "excludelist",
                    "rfg": data.get("rfg") if data.get("rfg", []) else "rfg",
                }
            return data_dict
        except KeyError as err:
            app_log.error(f"{traceback.format_exc()}")
            app_log.error(f"Error while preparing data {err}")
            return {"error": f"Error while preparing data {err}"}

    async def update_report(self, data, userid):
        """Get the data for the adc,mdc,adchc"""
        try:
            app_log.info("Preparing to Update  Autoreport")
            report_id = data["id"]
            data = format_template_json(data)
            query_data = self.prepare_data(data, "update")
            query_to_execute = self.queries["update_report"].format(**query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            # get the remaining list of reports
            where_clause = f" and id != {report_id}"
            select_query = f"{self.queries['read_autoreport'].format(**{'userid':userid})} {where_clause}"
            data_output = await get_query_with_pool(select_query)
            resp = self.get_data(data_output)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "Autoreport Update API Failed"}
        return resp

    async def get_report_history(self, data):
        """Get the data for report history"""
        try:
            app_log.info("Preparing response for report history")
            resp = {"data": [], "numFound": 0}
            start_date = datetime.strptime(
                data.get("startDate"), "%d-%m-%YT%H:%M:%S"
            ).strftime("%Y-%m-%d %H:%M:%S")
            end_date = datetime.strptime(
                data.get("endDate"), "%d-%m-%YT%H:%M:%S"
            ).strftime("%Y-%m-%d %H:%M:%S")
            query_data = {
                "startDate": start_date,
                "endDate": end_date,
                "autoreportid": data.get("autoreportid")[0],
            }
            query_to_execute = (
                f"{self.queries['fetch_hist_query'].format(**query_data)}"
            )
            data_output = await get_query_with_pool(query_to_execute)
            resp = {"data": data_output, "numFound": len(data_output)}
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            return {"error": "report history API Failed"}
        return resp

    async def historystatus(self, data):
        """method to fetch history"""
        app_log.info("payload---------------->", data)
        try:
            autoreportidtimestamp = []
            autoreportid = []
            if type(data) == list:
                for item in data:
                    val = item["autoreportidtimestamp"]
                    autoreportidtimestamp.append(val)
                    autoreportid.append(item.get("autoReportIds"))
                autoreportidtimestamp = tuple(autoreportidtimestamp)
            else:
                val = data["autoreportidtimestamp"]
                autoreportidtimestamp = val
                autoreportid = data.get("autoreportid")
            data["autoreportidtimestamps"] = f"('{autoreportidtimestamp}')"
            data["autoreportid"] = list(tuple(autoreportid))
            fetch_query = f"{self.queries['history_status_query'].format(**data)}"
            data_output = await get_query_with_pool(fetch_query)
            resp = data_output
        except Exception as err:
            app_log.error(traceback.format_exc())
            err_message = str(err).replace("'", "").replace('"', "")
            app_log.error(
                f"Something went wrong during fetch history status autoreport:"
                f"{err_message}"
            )
            resp = {"error": err_message}
        return resp

    async def fetch(self, data):
        """method to fetch data"""
        try:
            query_data = None
            if data.get("username"):
                query_data = {"condition": f"username = '{data['username']}' "}
            if data.get("id"):
                query_string = f" id in {tuple(data['id'])} "
                query_data = {"condition": query_string}
            if data.get("report") == "all":
                date_today = datetime.today().date()
                week_of_month = (
                    date_today.isocalendar()[1]
                    - date_today.replace(day=1).isocalendar()[1]
                    + 1
                )
                day_name = date_today.strftime("%A")
                day = date_today.day
                weekday = f"{week_of_month}_{day_name}"

                day_name = '"' + f"{day_name}" + '"'
                day = '"' + f"{day}" + '"'
                weekday = '"' + f"{weekday}" + '"'
                query_string = (
                    f"(reportrunday LIKE '%{day_name}%') OR (reportrunday LIKE '%{day}%')"
                    f" OR (reportrunday LIKE '%{weekday}%')"
                )
                query_data = {"condition": query_string}
            autoreport_query = self.queries["auto_report"].format(**query_data)
            auto_reports = await get_query_with_pool(autoreport_query)
            if len(auto_reports) == 0:
                return json.dumps([], default=str)
            total_cols = (
                self.queries["autoreport_cols"] + self.queries["dashboard_filters"]
            )
            change_key = "id"
            auto_reports = [
                {
                    key: (str(val) if key == change_key else val)
                    for key, val in sub.items()
                }
                for sub in auto_reports
            ]
            for autoreport in auto_reports:
                for list_key in self.queries["data_types"]["list_type"]:
                    if not autoreport.get(list_key):
                        autoreport[list_key] = []
                for list_key in self.queries["data_types"]["dict_type"]:
                    if not autoreport.get(list_key):
                        autoreport[list_key] = {}

                filter_data = []
                for col in total_cols:
                    if autoreport.get(col):
                        autoreport[col] = yaml.load(
                            autoreport.get(col, "[]"), Loader=yaml.FullLoader
                        )
                    if autoreport.get(col) and (
                        col in self.queries["dashboard_filters"]
                    ):
                        filter_copy_data = copy.deepcopy(autoreport.get(col))
                        if isinstance(filter_copy_data, dict):
                            filter_data.append(filter_copy_data)
                        elif isinstance(filter_copy_data, list):
                            for ind_filter in filter_copy_data:
                                sub_data = yaml.load(ind_filter, Loader=yaml.FullLoader)
                                filter_data.append(sub_data)
                    if col in self.queries["dashboard_filters"]:
                        autoreport.pop(col)
                    if col == "imagesettings" and isinstance(autoreport[col], list):
                        for index, value in enumerate(autoreport[col]):
                            if isinstance(value, str):
                                autoreport[col][index] = yaml.load(
                                    value, Loader=yaml.FullLoader
                                )
                autoreport["dashboardfilters"] = filter_data
            resp = auto_reports
        except Exception as err:
            app_log.error(traceback.format_exc())
            err_message = str(err).replace("'", "").replace('"', "")
            app_log.error(f"Something went wrong on fetch autoreport:" f"{err_message}")
            resp = {"error": err_message}
        return resp

    async def history(self, data):
        try:
            app_log.info(f"payload data for saving report history {data}")

            # if data.get("report",''):
            values = {}
            for key, val in data.items():
                if val != None:
                    if key == "report":
                        values[key] = json.dumps(val)
                    elif key == "userid":
                        values["username"] = val
                    else:
                        values[key] = val

                else:
                    values[key] = ""

            dt_string = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            values["datetime"] = dt_string
            cols_string = [x.lower() for x in list(values.keys())]
            cols = ",".join(cols_string)

            values_string = tuple(values.values())
            data = {}
            data["cols"] = cols
            data["values_string"] = values_string
            query_to_execute = self.queries["savehist_insert_query"].format(**data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"success": "Record inserted successfully"}
        except Exception as err:
            app_log.error(traceback.format_exc())
            err_message = str(err).replace("'", "").replace('"', "")
            app_log.error("Something went wrong during delete autoreport:")
            resp = {"error": err_message}
        return resp

    async def customer_history(self, data):
        try:
            query_string = []
            if data.get("autoreportid"):
                query_string.append(
                    f"autoreportid IN {tuple(data.get('autoreportid'))}"
                )
            if data.get("invokefrom"):
                query_string.append(f"invokefrom = {data.get('invokefrom')}")
            data["condition"] = ",".join(query_string)
            fetch_query = self.queries["cust_hist_report"].format(**data)
            resp = await get_query_with_pool(fetch_query)
        except Exception as err:
            app_log.error(traceback.format_exc())
            err_message = str(err).replace("'", "").replace('"', "")
            app_log.error(
                f"Something went wrong during fetch history status autoreport:"
                f"{err_message}"
            )
            resp = {"error": err_message}
        return resp
