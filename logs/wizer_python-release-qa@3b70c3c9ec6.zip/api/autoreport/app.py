"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.autoreport.autoreport_api import autoreporthandler


app.include_router(autoreporthandler.router)
