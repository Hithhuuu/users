"""Handler for user API's"""
from datetime import datetime, timedelta
from fastapi import APIRouter, Request, Depends
from fastapi.responses import JSONResponse
from jwt import encode

from api.user.user_api.usermodel import Users
from api.utils.common import get_user
from api.utils.utils import decrypt, encrypt, env_config
from api.utils.fastapi_app import validate_authenticity

user = Users()
router = APIRouter(prefix="/auth")


@router.get("/user", dependencies=[Depends(validate_authenticity)])
async def get(request: Request):
    """On GET request get notifications"""

    data = {"userid": get_user(request)["userid"]}
    role = get_user(request)["role"]
    data["endpoint"] = request.url.path

    response = await user.get(data) if role in ['admin'] else {}
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("")
async def auth(request: Request, body: dict):
    """Authentication Users with username and password"""
    """ Get the User data """
    user_data = await user.user_data(body)
    if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
        return JSONResponse(
            status_code=401,
            content={"message": "UserID not valid"},
        )
    user_data = user_data[0]
    pass_word = decrypt(
        body["password"], bytes(env_config["password_secret_key"], "utf-8")
    ).decode("utf-8")
    ## Verify user input password and user data password are equal or not
    if await user.check_password(user_data["password"], pass_word):
        to_encode = {
            "some": "payload",
            "userid": body["userid"],
            "a": {2: True},
            "role": user_data['assignedrole'],
            "exp": datetime.utcnow() + timedelta(minutes=480),
        }
        encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
        response_data = {
            "jwt": encoded.decode("utf-8") if (isinstance(encoded, bytes)) else encoded,
            "userid": user_data["userid"],
            "username": user_data["email"],
            "firstname": user_data["firstname"],
            "isadmin": "Y" if user_data["assignedrole"] == "admin" else "N",
            "displayName": f"{user_data['firstname']} {user_data['lastname']}",
            "expiredAt": str(to_encode["exp"]),
        }
        response = {
            "encryptedData": encrypt(
                f"{response_data}".replace("'", '"'),
                bytes(env_config["password_secret_key"], "utf-8"),
            ).decode("ascii")
        }
    else:
        return JSONResponse(
            status_code=401,
            content={"message": "Incorrect userid/password"},
        )
    return JSONResponse(response)


@router.post("/validate", dependencies=[Depends(validate_authenticity)])
async def validate(request: Request):
    """Validate JWT token"""
    userdata = get_user(request)
    user_data = await user.user_data(userdata)
    if not user_data:
        return JSONResponse(
            status_code=401,
            content={"message": "UserID not valid"},
        )
    user_data = user_data[0]
    to_encode = {
        "some": "payload",
        "a": {2: True},
        "exp": datetime.utcnow() + timedelta(minutes=480),
    }
    response = {
        "userid": user_data["userid"],
        "username": user_data["email"],
        "firstname": user_data["firstname"],
        "isadmin": "Y" if user_data["assignedrole"] == "admin" else "N",
        "isTokenValid": True,
        "displayName": user_data["firstname"] + " " + user_data["lastname"],
        "expiredAt": to_encode["exp"],
    }
    return response


@router.post("/refresh", dependencies=[Depends(validate_authenticity)])
async def refresh(request: Request):
    """Refresh JWT token"""
    userdata = get_user(request)
    user_data = await user.user_data(userdata)
    if not user_data:
        return JSONResponse(
            status_code=401,
            content={"message": "UserID not valid"},
        )
    user_data = user_data[0]
    to_encode = {
        "some": "payload",
        "a": {2: True},
        "exp": datetime.utcnow() + timedelta(minutes=480),
    }
    encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
    response_data = {
        "jwt": encoded.decode("utf-8"),
        "userid": user_data["userid"],
        "username": user_data["email"],
        "firstname": user_data["firstname"],
        "isadmin": "Y" if user_data["assignedrole"] == "admin" else "N",
        "displayName": f"{user_data['firstname']} {user_data['lastname']}",
        "expiredAt": to_encode["exp"],
    }
    response = {
        "encryptedData": encrypt(
            f"{response_data}".replace("'", '"'),
            bytes(env_config["password_secret_key"], "utf-8"),
        ).decode("ascii")
    }
    return JSONResponse(response)


@router.post("/user", dependencies=[Depends(validate_authenticity)])
async def post(request: Request, body: dict):
    """On POST request create a new user"""
    body["endpoint"] = request.url.path
    response = await user.create(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("/user", dependencies=[Depends(validate_authenticity)])
async def put(request: Request, body: dict):
    """On PUT request update user details"""
    body["endpoint"] = request.url.path
    response = await user.update(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.delete("/user", dependencies=[Depends(validate_authenticity)])
async def delete(request: Request, body: dict):
    """On DELETE request DELETE user"""
    body["endpoint"] = request.url.path
    response = await user.delete(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
