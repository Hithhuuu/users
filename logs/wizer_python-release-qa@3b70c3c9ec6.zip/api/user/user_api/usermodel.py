"""Model for user API"""

import json
import bcrypt
from api.utils.utils import queries, get_logger, env_config, decrypt, encrypt
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("user")


class Users:
    """User class for model"""

    def __init__(self):
        """Initializing queries for user API"""
        self.queries = queries["user"]

    async def get(self, userdata):
        """Get list of users"""
        try:
            app_log.info("Get list of users")
            query_data = {}
            query_data["userid"] = userdata.get("userid", "")
            data = await get_query_with_pool(self.queries["read"].format(**query_data))
            resp = {
                "encryptedData": encrypt(
                    f"{json.dumps(data)}",
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
            }
        except Exception as err:
            app_log.error("Error while getting user list")
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    def get_password(self, password):
        """Decode the Users password"""
        salt = bcrypt.gensalt()
        password = bcrypt.hashpw(password.encode(), salt)
        return password.decode()

    async def create(self, data):
        """creates new user"""
        try:
            app_log.info("Create user")
            data = json.loads(
                decrypt(
                    data["encryptedData"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
            )
            ## Check user exists
            user_exists_query = self.queries["user_exists"].format(**data)
            users = await get_query_with_pool(user_exists_query)
            if users:
                return {"msg": "user exists"}

            ## Encrypt user password
            pass_word = decrypt(
                data["password"], bytes(env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")
            data["password"] = self.get_password(pass_word)

            ## Create new user
            data["assignedrole"] = (
                "admin" if data.get("isadmin") == "Y" else "normal user"
            )
            data["rfg"] = 1 if data.get("isactive") == "Y" else 2

            user_create_query = self.queries["create"].format(**data)
            await get_query_with_pool(user_create_query, resp_type="None")
        except Exception as err:
            app_log.error("Error while creating new user")
            app_log.exception(err)
            return {"error": str(err)}
        return {"msg": "user created"}

    async def prepare_query(self, data):
        """Prepare the query filter conditions"""
        query_data = []
        for key, value in data.items():
            if key == "isactive":
                rfg = 1 if data.get("isactive") == "Y" else 2
                query_data.append(f"rfg = '{rfg}'")
            elif key == "isadmin":
                assignedrole = "normal user" if data.get("isadmin") == "N" else "admin"
                query_data.append(f"assignedrole = '{assignedrole}'")
            elif key not in ["userid", "udt", "cdt", "currentPassword"]:
                query_data.append(f"{key} = '{value}'")
        return " , ".join(query_data)

    async def update(self, data):
        """Update user record"""
        try:
            app_log.info("Update User Record")
            data = json.loads(
                decrypt(
                    data["encryptedData"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
            )
            app_log.info("Authenticating users")

            user_auth_query = self.queries["authenticate_update"].format(**data)
            user_data = await get_query_with_pool(user_auth_query)
            if not user_data or user_data[0]["rfg"] == 0:
                return {"msg": "UserID not valid"}
            if data.get("currentPassword", "") != "":
                pass_word = decrypt(
                    data["currentPassword"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                ## Verify user input password and user data password are equal or not
                if not bcrypt.checkpw(
                    pass_word.encode(), user_data[0]["password"].encode()
                ):
                    return {
                        "msg": f"Current password is incorrect for user {data['userid']}."
                    }
            if data.get("password"):
                pass_word = decrypt(
                    data["password"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                data["password"] = self.get_password(pass_word)

            data["select_param"] = await self.prepare_query(data)
            user_update_query = self.queries["update"].format(**data)
            await get_query_with_pool(user_update_query, resp_type='None')

        except Exception as err:
            app_log.error("Error while updating user record")
            app_log.exception(err)
            return {"error": str(err)}
        return {"msg": f"user {data['userid']} updated successfully"}

    async def delete(self, data):
        """Delete User"""
        try:
            app_log.info("Delete users")
            data["userid"] = "', '".join(data["userid"])
            user_delete_query = self.queries["delete"].format(**data)
            await get_query_with_pool(user_delete_query, resp_type='None')
        except Exception as err:
            app_log.error("Error while deleting user")
            app_log.exception(err)
            return {"error": str(err)}
        return {"msg": "user deleted successfully"}

    async def user_data(self, data):
        """Get the User details for Authentication"""
        try:
            app_log.info("Authenticating users")
            user_auth_query = self.queries["authenticate"].format(**data)
            user_data = await get_query_with_pool(user_auth_query)
        except Exception as err:
            app_log.error("Error while getting user list")
            app_log.exception(err)
            return {"error": str(err)}
        return user_data

    async def check_password(self, user_password, requested_password):
        """Check User password"""
        return bcrypt.checkpw(requested_password.encode(), user_password.encode())
