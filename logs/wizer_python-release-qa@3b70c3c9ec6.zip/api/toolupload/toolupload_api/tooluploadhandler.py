"""This handler executes tool upload for wizer"""
import os
import datetime
import asyncio

from fastapi import APIRouter
from api.utils.scheduler import scheduler_cron
from api.utils.tool_app import  get_query_with_pool,app
from api.utils.utils import  get_env_config
from schedulers.toolupload_utils import file_watcher,get_logger,log_file_watcher
from schedulers.ftp import WizerFtp

env_config = get_env_config()
router = APIRouter()
tools = env_config['tools']
tool_log = get_logger("tool_upload")

log_tools = {
    'enlight': env_config['wizer_ftp']['enlight_tools'],
    'sem': env_config['wizer_ftp']['sem_tools'],
}
@app.on_event("startup")
@scheduler_cron(interval=True,minutes=1)
async def tool_upload():
    """
    Main function to look for new files in the given tools and accept a directory loc as input and checks for any addition
    or receiver of new file in the same, as it gets one, starts the execution for the file.
    Watcher will check for FileSystem event, which will only check for "*.001" creation.
    """
    tool_log.info(f"started klarf tool upload at {datetime.datetime.now()}")
    for i in [r"ADC/today/reports",r"klarity/today/reports",r"lz/today/reports"]:
    # for i in [r"lz\today\reports"]:
        file_type = i.split('/')[0]
        if i.startswith('lz'):
            for tool_name in tools:
                path = os.path.join(tool_name,i)
                await file_watcher(path,file_type,tool_name)
        else:
            await file_watcher(i,file_type)

@app.on_event("startup")
@scheduler_cron(interval=True,minutes=1)
async def log_upload():
    """
    main function to look for new log file sin the given tools to accept directory as loc as inputh and checks for any addition
    eceiver of new file in the same, as it gets one, starts the execution for the file.
    Watcher will check for FileSystem event, which will only check for "Inspection*.log" creation.
    """
    watch_path = env_config['watchdog_pick_location']['src']
    log_dir = r"today/reports"
    tool_log.info(f"started log tool upload at {datetime.datetime.now()}")

    loop = asyncio.get_running_loop()
    for log_type in ['sem','enlight' ]:
        for tool_name in log_tools[log_type]:
            loop.create_task(log_process(watch_path,log_type,tool_name,log_dir))
        await asyncio.sleep(10)

@app.on_event("startup")
@scheduler_cron(cron_expression="0 6 * * *")
async def drop_partition():
    """creeates task for dropping partiton based on tables"""
    try:
        tablelist = ['opwi_defect_main_wip', 'opwi_defect_main_radial_wip']
        loop = asyncio.get_running_loop()
        for tbl in tablelist:
            loop.create_task(partiton(tbl))
    except Exception as err:
        tool_log.exception(err)


@app.on_event("startup")
@scheduler_cron(cron_expression="0 14 * * *")
async def optimise_table():
    """this method triggers optimisation of tables on DB server based on partition created"""
    try:
        tableList = ['opwi_map_header', 'opwi_user_templates', 'opwi_defect_main',
                     'opwi_job_log', 'wizer_autoreport', 'wizer_autoalert', 'wiz_class_groups']
        for tbl in tableList:
            if tbl == 'opwi_defect_main':
                await optimize_defect_main('opwi_defect_main')
            else:
                query = f"OPTIMIZE table {tbl} final"
                await get_query_with_pool(query, resp_type="None")
    except Exception as err:
        tool_log.exception(err)


@app.on_event("startup")
@scheduler_cron(interval=True, minutes=30)
async def ftp():
    """Triggers ftp connection and pulls files from ftp source """
    tool_log.info(f"ftp triggered {datetime.datetime.now()}")
    ftp = WizerFtp()
    await ftp.ftp_tool()


async def optimize_defect_main(table_name):
    """optimises table based on partitions"""
    query = f"select distinct partition from system.parts where database = 'wiz' and table='{table_name}' and modification_time >= date_sub(DAY, 1, toDate(now()))"
    resp = await get_query_with_pool(query)
    for i in resp:

        optimize_query = f"""OPTIMIZE table wiz.{table_name} PARTITION tuple('{i.get("partition")}') FINAL"""
        await get_query_with_pool(optimize_query, resp_type="None")


async def log_process(watch_path, log_type, tool_name, log_dir):
    """to create a process task for processing logs files in respective tools """
    log_dir_path = os.path.join(watch_path, log_type, tool_name, log_dir)
    if os.path.exists(log_dir_path):
        await log_file_watcher(log_dir_path, log_type, tool_name)


async def partiton(table_name):
    """drops partitons on created tasks """
    query = f"select distinct partition from system.parts where database = 'wiz' and table='{table_name}' and modification_time <= date_sub(DAY, 1, toDate(now()))"
    partition = await get_query_with_pool(query)

    for i in partition:
        tool_log.info(f"Dropping partitions {i.get('partition')}")
        drop_query = f"""ALTER TABLE wiz.{table_name} DROP PARTITION '{i.get("partition")}'"""
        await get_query_with_pool(drop_query, resp_type="None")
