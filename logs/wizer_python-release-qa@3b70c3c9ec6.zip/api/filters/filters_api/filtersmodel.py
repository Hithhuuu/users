"""Model for filters API"""
import datetime
import traceback
import pandas as pd

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_queries, get_logger
from api.utils.common import (
    get_templates_condition,
    prepare_query_filters,
    prepare_query,
    resolve_classcode,
    resolve_true_class,
    prepare_defect_count_filter,
    rca_condition,
)
from api.filters.utils.filter_utils import CustomizedCalendar, WEEKDAY

app_log = get_logger("filters")


class Filters:
    """This class provides methods to get filters"""

    def __init__(self):
        """Initializing filter queries"""
        queries = get_queries("filters")
        self.queries_gfilter = queries["gfilter"]
        self.queries_sfilter = queries["sfilter"]
        self.queries_fmfilter = queries["fmfilter"]
        self.queries_rcafilter = queries["rcafilter"]

    async def gfilter(self, data):
        """Get global filters"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Global Filters API triggered..")
            query_data = {}
            query_data["no_run_option"] = data["no_run_option"]
            if data["no_run_option"] == "0":
                # timestamp query
                query_type = "globalfilter"
                query_data["num_run"] = 10000
            elif data["no_run_option"] == "1":
                # runid query
                query_type = "globalfilter"
                query_data["num_run"] = data["no_run"]
                data.pop("resulttimestamp", "")
            elif data["no_run_option"] == "2":
                # only header data
                query_type = "globalfilter_notemplate"
                data.pop("resulttimestamp", "")

            query_data["condition"] = prepare_query_filters(data)
            (
                query_data["join_condition"],
                query_data["template_condition"],
            ) = get_templates_condition(data)
            query_data["template_owner"] = data["template_owner"]
            app_log.info("Query conditions prepared")
            query_to_execute = self.queries_gfilter[query_type].format(**query_data)
            app_log.info("Query parameters created.")
            data_output = await get_query_with_pool(query_to_execute)
            app_log.info("Formatting data....")
            resp = data_output[0]
            if data["is_acy"]:
                resp.pop("from_date")
                resp.pop("templates")
            if data["no_run_option"] == "2":
                resp = [{"name": k, "values": sorted(v)} for k, v in resp.items()]
            else:
                resp = [
                    {
                        "name": k,
                        "values": sorted(v)
                        if k not in ["from_date", "templates"]
                        else v,
                    }
                    for k, v in resp.items()
                ]
            app_log.info(
                "filters/gfilter api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def get_globalfilter_classes(self, data):
        """Get classcodes for global filters"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Global Filter Classes API triggered..")
            query_data = {}
            query_data["condition"] = prepare_query_filters(data)
            app_log.info("Query parameters created.")
            query_to_execute = self.queries_gfilter["classcodes"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            data_output = data_output[0]
            resp = []
            for cls in data_output["classcodes"]:
                if cls in [0, 1]:
                    resp.append({"classnumber": cls, "groupname": "False"})
                elif cls in [2, 3, 4, 5, 6, 7, 8]:
                    resp.append({"classnumber": cls, "groupname": "True"})
                else:
                    resp.append({"classnumber": cls, "groupname": ""})
            app_log.info(
                "filters/gfilter/classes api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def sfilter(self, data):
        """Get secondary filters"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Secondary Filter API triggered..")
            query_data = {}
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            query_data["truedoicount"] = ""
            query_data["highdefectcount"] = ""
            query_data["classcode"] = resolve_classcode(data)
            query_data["true_class"] = resolve_true_class(data)
            if data["filtertype"] != "accuracy":
                prepare_defect_count_filter(query_data, data, alias="defects")
            query_data["num_run"] = data.get("facetValues", []).get("no_run")

            if data["facetValues"]["no_run_option"] == "0":
                query_data["num_run"] = 10000
            query_to_execute = self.queries_sfilter["secondaryfilter"].format(
                **query_data
            )
            app_log.info("Query parameters created.")
            data_output = await get_query_with_pool(query_to_execute)
            if not data_output:
                return []
            data_formatted = {
                k: sorted(
                    list(
                        set(
                            sum([d.get(k) for d in data_output if k != "runid_val"], [])
                        )
                    )
                )
                for k in set().union(*data_output)
            }
            if data["filtertype"] != "accuracy":
                data_formatted["runid"] = sorted(
                    list(
                        set(
                            dict["runid_val"].replace("::", ": ")
                            for dict in data_output
                        )
                    ),
                    key=lambda x: int(x.split(": ")[0].split(" ")[-1]),
                )
            data_formatted.pop("runid_val")
            resp = [{"name": k, "values": sorted(v)} for k, v in data_formatted.items()]
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as run_error:
            app_log.exception(run_error)
            return {"error": str(run_error)}
        return resp

    async def fmfilter(self, data):
        """Get failure monitoring filters"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Failure Monitoring Filter API triggered..")
            query_data = {"workweek": "", "time_stamp": ""}

            if str(data["daterangeflag"]) == "0" and data.get("type", "") != "":
                query_data[
                    "workweek"
                ] = f"and workweek in {tuple(data.get('workweek')) if isinstance(data['workweek'], list) else tuple([data['workweek']])}"

            else:
                query_data[
                    "time_stamp"
                ] = f"and toDate(enlight_timestamp) BETWEEN '{data['resulttimestamp']['min'][0:10]}' and '{data['resulttimestamp']['max'][0:10]}'"

            app_log.info("Get Failure Monitoring filter")
            query_to_execute = self.queries_fmfilter["read_fmfilter"].format(
                **query_data
            )
            app_log.info("Query parameters created.")
            data_output = await get_query_with_pool(query_to_execute)
            data_output = data_output[0]
            csv = pd.read_csv(
                "configs/log_acceptance.csv",
                header=0,
                names=["deviceid", "stepid", "inspection_recipie", "sem_receipe"],
            )
            csv.rename(
                columns={
                    "enlightrecipie": "inspection_recipie",
                    "semrecipie": "sem_receipe",
                },
                inplace=True,
            )
            data_output.update(csv.to_dict(orient="list"))
            data_output["workweek"] = []
            data_output["workweek"] = ["Custom Range"]
            str_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            my_calendar = CustomizedCalendar(
                start_weekday=WEEKDAY.FRI, indicator_weekday=WEEKDAY.MON
            )
            weeknum = my_calendar.calculate(
                datetime.datetime.now().strptime(str_date, "%Y-%m-%d %H:%M:%S")
            )[1]
            actual = 0
            for i in range(1, 9):
                if (weeknum - (i - 1)) <= 0:
                    actual = weeknum
                    weeknum = 52
                weekloop = f"WW-{weeknum-(i-1-actual)}"
                data_output["workweek"].append(weekloop)

            data_output = {
                key: data_output[key]
                for key in [
                    "stepid",
                    "deviceid",
                    "inspection_recipie",
                    "sem_receipe",
                    "inspection_tool_id",
                    "sem_tool_id",
                    "workweek",
                ]
            }
            resp = [
                {"name": k, "values": sorted(list(set(v)))}
                for k, v in data_output.items()
                if k not in ["workweek"]
            ]

            resp.append({"name": "workweek", "values": data_output["workweek"]})
            app_log.info(
                "filters/fmfilter api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def bafilter(self, data):
        """Get failure monitoring filters"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Budget Analysis Filter API started..")
            query_data = {}
            query_data["true_class"] = [
                d["classnumber"]
                for d in data.get("groupmapping", [])
                if d["groupname"] == "True"
            ]
            query_data["templateid"] = data["templateid"]
            query_data["truedoicount"] = ""
            query_data["highdefectcount"] = ""
            if str(data.get("truedoicountenable")).lower() == "true":
                query_data[
                    "truedoicount"
                ] = f"AND defects.truedoicount >= {data.get('truedoicount',10)}"
            if str(data.get("highdefectcountenable")).lower() == "true":
                query_data[
                    "highdefectcount"
                ] = f" AND defects.highdefectcount <= {data.get('highdefectcount')}"
            query_data["stepid"] = (
                f"{data['stepid'][0]}"
                if isinstance(data.get("stepid", ""), list)
                else f"{data.get('stepid', '')}"
            )
            query_data["layer"] = query_data["stepid"]
            query_data["product"] = (
                f"{data['deviceid'][0]}"
                if isinstance(data.get("deviceid", ""), list)
                else f"{data.get('deviceid', '')}"
            )
            query_data["setupid"] = (
                f"{data['recipeid'][0]}"
                if isinstance(data.get("recipeid", ""), list)
                else f"{data.get('recipeid', '')}"
            )
            query_data["condition"] = [
                f"{k} = '{v}'"
                for k, v in query_data.items()
                if k in ["layer", "product", "setupid"] and v != ""
            ]
            query_data["condition"] = f"and {' and '.join(query_data['condition'])}"
            app_log.info("Query parameters created.")
            query_to_execute = self.queries_gfilter["read_bafilter"].format(
                **query_data
            )
            resp = await get_query_with_pool(query_to_execute)
            app_log.info(
                "filters/bafilter api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def rcafilter(self, data):
        try:
            resp = []
            query_data = {"stepid": "", "product": ""}
            query_data["conditions"] = rca_condition(data)
            query_to_execute = self.queries_rcafilter["read_layer"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = [
                {
                    "name": "stepid",
                    "values": data_output[0].get("layer")
                    if len(data_output) > 0
                    else [],
                },
                {
                    "name": "deviceid",
                    "values": data_output[0].get("product")
                    if len(data_output) > 0
                    else [],
                },
            ]
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {"error": "rca Filter api failed"}
        return resp

    async def rcanodefilter(self, data):
        """to get rca alert list"""
        try:
            app_log.info(f"paylaod for rca alert list {data}")
            keys = {"imidiate": "Immediately"}
            condition = f"and reportfrequency = '\"{keys.get(data.get('report'))}\"'"
            query_to_execute = self.queries_rcafilter["read_rca_filter"].format(
                **{"condition": condition}
            )
            resp = await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            resp = {"error": "alert filter API Failed"}
        return resp

    async def usergroupfilter(self, data):
        """this method provides user grouping for layer and product"""
        try:
            query_data = {}
            class_list = []
            resp = []
            if data.get("summary_flg") == "1":
                layer_list = [f"layer like '%{l}%'" for l in data.get("stepid")]
                query_data["condition"] = f" and ({' or '.join(layer_list)})"
            else:
                layer_str = [
                    f" layer in {tuple(data.get('stepid'))}",
                    f" product in {tuple(data.get('deviceid'))}",
                ]
                query_data["condition"] = f" and {' and '.join(layer_str)}"
            query_to_execute = self.queries_rcafilter["classmaping"].format(
                **query_data
            )
            data_output = await get_query_with_pool(query_to_execute)
            for i in tuple(data_output[0].values()):
                class_list = class_list + i
            for cls in sorted(set(class_list)):
                if cls in [0, 1]:
                    resp.append({"classnumber": cls, "groupname": "False"})
                elif cls in [2, 3, 4, 5, 6, 7, 8]:
                    resp.append({"classnumber": cls, "groupname": "True"})
                else:
                    resp.append({"classnumber": cls, "groupname": ""})
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            resp = {"error": "alert filter API Failed"}
        return resp

    async def kpi_list(self, data):
        """this method gets kpi list for rca"""
        try:
            query_data = {
                "layer": tuple(data.get("stepid")),
                "product": tuple(data.get("deviceid")),
            }
            query_data[
                "condition"
            ] = f" and layer in {tuple(data.get('stepid'))} and product in {tuple(data.get('deviceid'))}"
            query_to_execute = self.queries_rcafilter["classmaping"].format(
                **query_data
            )
            data_output = await get_query_with_pool(query_to_execute)
            data = {
                "ADC": list(set(data_output[0].get("adc"))),
                "ADCHC": list(set(data_output[0].get("adc_hc"))),
                "MDC": list(set(data_output[0].get("mdc"))),
            }
            app_log.debug(data)
            kpi_list = [
                {
                    "chart": "GEBI ADC T",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "GEBI ADC F",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "DR ADC F",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "DR ADC T",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 1 Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 2 Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 3 Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 4 Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 5 Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Purifier Purity",
                    "min": 0,
                    "max": 100,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 1 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Rank 2 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Rank 3 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Rank 4 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Rank 5 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Rank 6 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Bin 1 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Bin 2 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Bin 3 percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "DOI percentage",
                    "min": 0,
                    "max": 100,
                    "classification": data,
                },
                {
                    "chart": "Gebi True Defect",
                    "min": 0,
                    "max": 4000,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Review Count",
                    "min": 0,
                    "max": 4000,
                    "classification": {"MDC": data.get("MDC")},
                },
                {
                    "chart": "Rank 1 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {
                    "chart": "Rank 2 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {
                    "chart": "Rank 3 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {
                    "chart": "Rank 4 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {
                    "chart": "Rank 5 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {
                    "chart": "Rank 6 Count",
                    "min": 0,
                    "max": 4000,
                    "classification": data,
                },
                {"chart": "Bin 1 Count", "min": 0, "max": 4000, "classification": data},
                {"chart": "Bin 2 Count", "min": 0, "max": 4000, "classification": data},
                {"chart": "Bin 3 Count", "min": 0, "max": 4000, "classification": data},
                {"chart": "DOI Count", "min": 0, "max": 4000, "classification": data},
            ]
            operators = ["=", ">", "<", "<=", ">="]
            resp = [
                {"name": "KPI", "values": kpi_list},
                {"name": "Operator", "values": operators},
                {"name": "hunterclass", "values": data.get("ADCHC")},
                {"name": "autoonsemclass", "values": data.get("ADC")},
                {"name": "mansemclass", "values": data.get("MDC")},
            ]

        except Exception as err:
            app_log.exception(err)
            resp = {"error": "RCA kpi filter api failed"}
        return resp
