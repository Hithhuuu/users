"""Handler for Filters API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.filters.filters_api.filtersmodel import Filters
from api.utils.common import get_user
from api.utils.fastapi_app import validate_authenticity

router = APIRouter(prefix="/filters")
filters = Filters()


@router.post("/gfilter", dependencies=[Depends(validate_authenticity)])
async def gfilter(request: Request, body: dict):
    """On POST request return global filters as JSON"""
    userid = get_user(request)["userid"]
    body["template_owner"] = userid
    body['is_acy'] = False
    if not body.get('fileClassification'):
        body['is_acy'] = True
    response = await filters.gfilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/classes", dependencies=[Depends(validate_authenticity)])
async def classes(request: Request, body: dict):
    """On POST request return classcodes as JSON"""
    response = await filters.get_globalfilter_classes(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/sfilter", dependencies=[Depends(validate_authenticity)])
@router.post("/sfilter/accuracy", dependencies=[Depends(validate_authenticity)])
async def sfilter(request: Request, body: dict):
    """On POST request return secondary filters as JSON"""
    body['filtertype'] = request.url.path.split('/')[-1]
    body['endpoint'] = request.url.path
    response = await filters.sfilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/smfilter", dependencies=[Depends(validate_authenticity)])
async def fmfilter(request: Request, body: dict):
    """On POST request return failure monitoring filters as JSON"""
    response = await filters.fmfilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/bafilter", dependencies=[Depends(validate_authenticity)])
async def bafilter(request: Request, body: dict):
    """On POST request return budget analysis filters as JSON"""
    response = await filters.bafilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/rca", dependencies=[Depends(validate_authenticity)])
async def rca(request: Request, body: dict):
    """On POST request return rca filters as JSON"""
    response = await filters.rcafilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


# @router.get("/rca/alertlist")
# async def rca_node(request: Request):
#     """On POST request return rca alert filters as JSON"""
#     user =  get_user(request)
#     body = {
#             'report':request.query_params.get('type',''), 
#             'userid':user.get('userid','')
#     }
#     response = await filters.rcanodefilter(data=body)
#     if isinstance(response, dict) and "error" in list(response.keys()):
#         return JSONResponse(
#             status_code=400,
#             content={"message": response.get("error")},
#         )
#     return JSONResponse(response)

@router.post("/usergroup", dependencies=[Depends(validate_authenticity)])
async def usergroup(request: Request, body : dict):
    """On POST request return usergroup filters as JSON"""
    response = await filters.usergroupfilter(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/rca/kpilist", dependencies=[Depends(validate_authenticity)])
async def rca_kpilist(request: Request, body : dict):
    """On POST request return rca kpilist filters as JSON"""
    response = await filters.kpi_list(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)