"""Utils for filter API"""
from enum import IntEnum
from datetime import datetime, timedelta

WEEKDAY = IntEnum("WEEKDAY", "MON TUE WED THU FRI SAT SUN", start=1)


def workweek(data):
    """Calculate work week"""
    date = datetime.strptime(data["Started on"][0], "%Y-%m-%d %H:%M:%S")
    my_calendar = CustomizedCalendar(
        start_weekday=WEEKDAY.FRI, indicator_weekday=WEEKDAY.MON
    )
    return my_calendar.calculate(date)[1]


def weeknum(dt):
    """return isocalendar"""
    return dt.isocalendar()[1]


def myweeknum(dt):
    """Get week number"""
    offsetdt = dt + timedelta(days=3)
    # you add 3 days to Mon to get to Thu
    return weeknum(offsetdt)


def get_last_friday():
    """Get last friday"""
    now = datetime.now()
    closest_friday = now + timedelta(days=(4 - now.weekday()))
    return (
        closest_friday if closest_friday < now else closest_friday - timedelta(days=7)
    )


class CustomizedCalendar:
    """Class to create customised calendar based on work week"""

    def __init__(self, start_weekday, indicator_weekday=None):
        """Initialize start day"""
        self.start_weekday = start_weekday
        self.indicator_delta = (
            3 if not (indicator_weekday) else (indicator_weekday - start_weekday) % 7
        )

    def get_week_start(self, date):
        """Start day of workweek"""
        delta = date.isoweekday() - self.start_weekday
        return date - timedelta(days=delta % 7)

    def get_week_indicator(self, date):
        """Get indicator of work week"""
        week_start = self.get_week_start(date)
        return week_start + timedelta(days=self.indicator_delta)

    def get_first_week(self, year):
        """Get first week of the year"""
        indicator_date = self.get_week_indicator(datetime(year, 1, 1))
        if indicator_date.year == year:  # The date "year.1.1" is on 1st week.
            return self.get_week_start(datetime(year, 1, 1))
        else:  # The date "year.1.1" is on the last week of "year-1".
            return self.get_week_start(datetime(year, 1, 8))

    def calculate(self, date):
        """Calculate work week"""
        year = self.get_week_indicator(date).year
        first_date_of_first_week = self.get_first_week(year)
        diff_days = (date - first_date_of_first_week).days
        return year, (diff_days // 7 + 1), (diff_days % 7 + 1)
