"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.filters.filters_api import filtershandler


app.include_router(filtershandler.router)