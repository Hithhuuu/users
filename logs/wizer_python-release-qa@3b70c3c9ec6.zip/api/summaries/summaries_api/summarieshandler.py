""" Summaries handler"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.summaries.summaries_api.summariesmodel import Summary
from api.utils.fastapi_app import validate_authenticity
router = APIRouter(prefix="/summaries")
summary = Summary()


@router.post("/failure", dependencies=[Depends(validate_authenticity)])
async def failuresummary(request: Request, body: dict) :
    """For handling failure summary data """
    data = await summary.failuresummary(data=body)
    if isinstance(data, dict) and "error" in list(data.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": data.get("error")},
        )
    return JSONResponse(data)

@router.post("/layer", dependencies=[Depends(validate_authenticity)])   
async def layersummary(request: Request, body: dict):
    """For handling layer summary data """
    data = await summary.layer_summary(data=body)
    if isinstance(data, dict) and "error" in list(data.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": data.get("error")},
        )
    return JSONResponse(data)