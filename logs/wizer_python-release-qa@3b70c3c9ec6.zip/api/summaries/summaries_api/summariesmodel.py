"""Model for summaries API"""
import json
import traceback
import pandas as pd

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import (
    queries,
    get_logger,
)
from api.utils.common import summary_condition

app_log = get_logger("summaries")


class Summary:
    """This class provides methods to get summaries """

    def __init__(self):
        """Initializing filters instance"""
        self.queries = queries["summaries"]

    async def failuresummary(self, data, alertflag=False,filetype=None):
        """Generate failure summary data """
        try:
            resp_data = dict()
            query_data = summary_condition(data, alert_flg=alertflag)
            query_to_execute = self.queries['failure_summery'].format(
                **query_data)
            data_output = await get_query_with_pool(query_to_execute)
            for i, k in enumerate(data_output):
                if data_output[i]['enlight_scan_status'] == 'fail':
                    data_output[i]['sem_review_status'] = 'NA'
                    data_output[i]['doistatus'] = 'NA'
                    data_output[i]['adc_status'] = 'NA'
                    data_output[i]['defect_explorer_status'] = 'NA'
                    data_output[i]['sem_file_json'] = ''
                if ((data_output[i]['sem_review_status'] == 'fail') or
                        (data_output[i]['sem_review_status'].lower() == 'na')):
                    data_output[i]['doistatus'] = 'NA'
                    data_output[i]['adc_status'] = 'NA'
                    data_output[i]['defect_explorer_status'] = 'NA'

            resp_data['table'] = data_output
            resp_data["total"] = data_output[0].get(
                "total") if len(data_output) > 0 else 0
            if not alertflag:
                resp_data['summary'] = {'totalnoofwafer': data_output[0].get("total") if len(data_output) > 0 else '',
                                        'enlightpasspercent': data_output[0].get("enlightpasspercent")if len(data_output) > 0 else '',
                                        'sempasspercent': data_output[0].get("sempasspercent")if len(data_output) > 0 else '',
                                        'doistatuspercent': data_output[0].get("doistatuspercent")if len(data_output) > 0 else '',
                                        'adcstatuspercent': data_output[0].get("adcstatuspercent")if len(data_output) > 0 else '',
                                        'defectexplorerstatuspercent': data_output[0].get("defectexplorerstatuspercent")if len(data_output) > 0 else '', }
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.exception(err)
            return {'error': str(err)}
        return resp_data

    async def layer_summary(self,data):
        """generate layer summary data"""
        try:
            query_data = summary_condition(data)
            query_to_execute = self.queries["layer_summary"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            response  = {
                "tableData" : data_output,
                "total" : data_output[0].get("total") if len(data_output)>0 else 0
            }
        except Exception as err:
            app_log.error(err)
            return {"error": str(err)}
        return response
    
    
        