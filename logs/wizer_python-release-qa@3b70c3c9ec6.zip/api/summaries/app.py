"""fastapi router initialisation"""
from api.utils.fastapi_app import app
from api.summaries.summaries_api import summarieshandler

app.include_router(summarieshandler.router)
