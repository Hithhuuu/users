"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.notification.notification_api import notificationhandler


app.include_router(notificationhandler.router)
