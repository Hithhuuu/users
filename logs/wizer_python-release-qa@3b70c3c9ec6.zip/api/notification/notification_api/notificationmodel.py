"""Model for notification API"""
import datetime

from api.utils.utils import queries, get_logger
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("notification")


class NotificationModel:
    """Model Class for notification API"""

    def __init__(self):
        """Initializing query variables"""
        self.queries = queries["notification"]

    async def get_notification(self, data):
        """Get notification for current user"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            user_id = data['userid']
            query_to_execute = self.queries["read"].format(**{"username": user_id})
            data_output = await get_query_with_pool(query_to_execute)
            return data_output
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": "Notification API Failed"}

    async def update_notification(self, data):
        """Update notification for current user"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            query_to_execute = self.queries["update"].format(
                **{"id": data.get("notification_id")}
            )
            await get_query_with_pool(query_to_execute, resp_type="None")
            return {"msg": "user has seen the notification"}
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": "Notification UPDATE API Failed"}
