"""Handler for Notification API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.notification.notification_api.notificationmodel import NotificationModel
from api.utils.common import get_user
from api.utils.fastapi_app import validate_authenticity

notification = NotificationModel()

router = APIRouter(prefix="/notification")


@router.get("", dependencies=[Depends(validate_authenticity)])
async def get(request: Request):
    """On GET request get notifications"""
    body = get_user(request)
    body["endpoint"] = request.url.path
    response = await notification.get_notification(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("", dependencies=[Depends(validate_authenticity)])
async def put(request: Request, body: dict):
    """On PUT request save notifications"""
    body["endpoint"] = request.url.path
    response = await notification.update_notification(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
