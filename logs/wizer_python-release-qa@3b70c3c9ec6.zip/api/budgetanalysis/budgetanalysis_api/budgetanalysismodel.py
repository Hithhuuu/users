"""Model for budget analysis"""
import statistics
import datetime
import json

from api.utils.fastapi_app import get_query_with_pool, insert_data
from api.utils.utils import queries, get_logger

app_log = get_logger("budgetanalysis")


class BudgetAnalysis:
    """Class for Budget Analysis Model"""

    def __init__(self):
        """Initializing query variables"""
        self.queries = queries["budgetanalysis"]

    async def post(self, data):
        """Budget Analysis"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Budget Analysis API triggered..")
            query_data = {}
            query_data["true_class"] = [
                x["classnumber"]
                for x in data.get("groupmapping", [])
                if x["groupname"] == "True"
            ]
            query_data["class_mapping"] = query_data["true_class"]
            query_data["conditions"] = []
            query_data["batchsize"] = {}
            insert_data_list = []
            cols = [
                "layer",
                "carrierid",
                "waferid",
                "batchsize",
                "templateid",
                "group_mapping",
            ]
            for lot in data["lotids"]:
                query_data["conditions"].append(
                    f"(layer = '{data['stepid'][0]}' and carrierid = '{lot['lot']}' and waferid= '{lot.get('waferid')}')"
                )
                query_data["batchsize"][f'{lot["lot"]}_{lot["waferid"]}'] = lot[
                    "ranklimit"
                ]
                insert_data_list.append(
                    (
                        data["stepid"][0],
                        lot["lot"],
                        lot.get("waferid"),
                        int(lot.get("ranklimit", 200)),
                        int(data["templateid"]),
                        str(query_data["class_mapping"]),
                    )
                )
            query_data["batchsize"] = json.dumps(query_data["batchsize"])
            query_to_execute = f"select distinct mapid from opwi_map_header final where rfg = 1 and ({' or '.join(query_data['conditions'])})"
            data_output = await get_query_with_pool(query_to_execute)
            query_data["mapid"] = [d.get("mapid") for d in data_output]
            query_to_execute = self.queries["budgetanalysis"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = {}
            for output in data_output:
                if output["chart"]:
                    chart = {f"{int(v[0])}": v[1] for v in output["chart"]}
                else:
                    chart = {f"{int(i[0])}": 0 for i in output["batchnumber_count"]}
                ranks = {int(i[0]): i[1] for i in output["rank_count"]}
                cumm_rank_sum = {int(i[0]): i[1] for i in output["cumm_rank_sum"]}
                batches = {i[0]: i[1] for i in output["batchnumber_count"]}
                output["batchrank_count"] = {
                    i[0]: i[1] for i in output["batchrank_count"]
                }
                bin2keys = {i[0][0]: i[1] for i in output["bin2_count"]}
                ranktable = {
                    f"{float(rnk)}": [
                        {
                            "batchnumber": batch,
                            "value": output["batchrank_count"].get((rnk, batch), 0),
                        }
                        for batch in list(batches.keys())
                        if output["batchrank_count"].get((rnk, batch), 0) != 0
                    ]
                    + [
                        {"Total Rank Size": ranks.get(rnk)},
                        {"Total Rank Size (Cummulative)": cumm_rank_sum.get(rnk)},
                    ]
                    + [{"Bin 2 Key": v} for k, v in bin2keys.items() if rnk == k]
                    for rnk in list(ranks.keys())
                }
                ranktable["Batch Size"] = [
                    {"batchnumber": k, "value": v} for k, v in batches.items()
                ]
                resp[f'{output["carrierid"]}_{output["waferid"]}'] = {
                    "output_run1": output["run1"],
                    "output_run2": output["run2"],
                    "chart": [chart],
                    "last_batch": output["last_batch"],
                    "batchsize": output["batchsize"],
                    "ranktable": ranktable,
                    "total_budget": output["run1"] + output["run2"],
                }
            cols = ",".join([item.replace("'", "") for item in cols])
            query_to_execute = f"INSERT INTO wiz.wizer_budgetanalysis ({cols}) VALUES "
            await insert_data(query_to_execute, insert_data_list)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            for i in data.get("lotids"):
                if f"{i.get('lot')}_{i.get('waferid')}" not in resp.keys():
                    resp[f"{i.get('lot')}_{i.get('waferid')}"] = {}
            return resp

        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}

    async def acc_post(self, data):
        """Accumulative Budget Analysis"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("Accumulative Budget Analysis API triggered..")
            data_output = await self.post(data)
            resp = {}
            data_output = {k:v for k,v  in data_output.items() if v }
            run1 = [v["output_run1"] for k, v in data_output.items()]
            run2 = [v["output_run2"] for k, v in data_output.items()]
            resp["output_run1_max"] = float(max(run1)) if run1 else 0
            resp["output_run1_median"] = float(statistics.median(run1)) if run1 else 0
            resp["output_run1_mean"] = float(statistics.mean(run1)) if run1 else 0
            resp["output_run2_max"] = float(max(run2)) if run2 else 0
            resp["output_run2_median"] = float(statistics.median(run2)) if run2 else 0
            resp["output_run2_mean"] = float(statistics.mean(run2)) if run2 else 0
            resp["total_budget"] = resp["output_run1_max"] + resp["output_run2_max"]
            resp["chart"] = [
                {
                    list(data_output.keys()).index(k) + 1: v["output_run1"]
                    for k, v in data_output.items()
                },
                {
                    list(data_output.keys()).index(k) + 1: v["output_run2"]
                    for k, v in data_output.items()
                },
            ]
            resp["lotid"] = list(data_output.keys())

            ranktable_list = [v["ranktable"] for v in data_output.values()]
            app_log.debug(ranktable_list)
            ranktable = {
                k: [
                    {i.get("batchnumber", 0): i.get("value", 0)}
                    for d in ranktable_list
                    for i in d.get(k, [])
                ]
                for k in set().union(*ranktable_list)
            }
            resp["ranktable"] = {
                k1: [
                    {
                        k: sum(d[k] for d in v if k in d and k != 0)
                        for k in set(k for d in v for k in d if k != 0)
                    }
                ]
                for k1, v in ranktable.items()
            }
            resp["ranktable"] = {
                k: v if v[0] else [] for k, v in resp["ranktable"].items()
            }
            resp["last_batch"] = max(list(resp["ranktable"]["Batch Size"][0].keys()))
            resp["ranktable"] = {
                k: [
                    {
                        "batchnumber": k1,
                        "value": v1
                        if k != "Batch Size"
                        else int(v1 / len(resp["lotid"])),
                    }
                    for i in v
                    for k1, v1 in i.items()
                ]
                for k, v in resp["ranktable"].items()
            }
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return resp

        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
