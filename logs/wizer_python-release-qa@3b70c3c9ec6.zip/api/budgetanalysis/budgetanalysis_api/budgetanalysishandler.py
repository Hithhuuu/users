"""Handler for Budget Analysis API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.utils.fastapi_app import validate_authenticity
from api.budgetanalysis.budgetanalysis_api.budgetanalysismodel import BudgetAnalysis

router = APIRouter(prefix="/budgetanalysis", dependencies=[Depends(validate_authenticity)])
budgetanalysis = BudgetAnalysis()


@router.post("")
async def post(request: Request, body: dict):
    """On POST request return Budget Analysis as JSON"""
    body["endpoint"] = request.url.path
    response = await budgetanalysis.post(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/accumulative")
async def accumulative_post(request: Request, body: dict):
    """On POST request return Accumulative Budget Analysis as JSON"""
    body["endpoint"] = request.url.path
    response = await budgetanalysis.acc_post(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
