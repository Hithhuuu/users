"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.budgetanalysis.budgetanalysis_api import budgetanalysishandler


app.include_router(budgetanalysishandler.router)
