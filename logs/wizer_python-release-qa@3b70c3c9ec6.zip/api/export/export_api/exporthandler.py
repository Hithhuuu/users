"""Handler for export api"""
import os

from fastapi.responses import StreamingResponse, JSONResponse
from fastapi import Request, APIRouter, Response, Depends
from api.export.export_api.exportmodel import Export
from api.utils.fastapi_app import validate_authenticity

router = APIRouter(prefix="/export", dependencies=[Depends(validate_authenticity)])
export = Export()


@router.post("/kpisummary")
async def kpiexport(request: Request, body: dict, response: Response):
    """For handling export kpi summary data"""
    file_name = await export.export_kpi(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")


@router.post("/summaries")
async def summariesexport(request: Request, body: dict, response: Response):
    """For handling export  summary data"""
    file_name = await export.export_summaries(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")


@router.post("/rawdata")
async def rawdataexport(request: Request, body: dict, response: Response):
    """For handling export raw data"""
    file_name = await export.raw_data(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")


@router.post("/accuracy")
async def accuracyexport(request: Request, body: dict, response: Response):
    """For handling export accuracy data"""
    file_name = await export.export_accuracy(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")


@router.post("/exportdoi")
async def doiexport(request: Request, body: dict, response: Response):
    """For handling export doi data"""
    file_name = await export.export_doi(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")


@router.post("/accumulativeexport")
async def accudoiexport(request: Request, body: dict, response: Response):
    """For handling export accumulative doi data"""
    body["endpoint"] = request.url.path.split("/")[-1]
    file_name = await export.export_accumulative(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as f:
        lines = f.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))

    return StreamingResponse(gen(), media_type="csv")
