"""Export Model file """
import copy
import pandas as pd
import datetime

from api.utils.fastapi_app import get_query_with_pool
from api.summaries.summaries_api.summariesmodel import Summary
from api.timetrend.timetrend_api.timetrendmodel import TimeTrend
from api.budgetanalysis.budgetanalysis_api.budgetanalysismodel import BudgetAnalysis
from api.utils.utils import queries, get_logger, columns_info, get_queries, common_query
from api.utils.common import (
    prepare_query,
    resolve_classcode,
    get_limit,
    prepare_query_data,
)

app_log = get_logger("export")


class Export:
    """this class gets data for export"""

    def __init__(self):
        """Initializing queries"""
        self.queries = queries["export"]
        self.common_queries = common_query
        combines_queries = get_queries("timetrend")

    async def export_summaries(self, data):
        """gets failure data for export"""
        try:
            type = data.get("type")
            summaries = Summary()

            if type == "failure":
                filename = f"failure_monitor_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                failuredata = await summaries.failuresummary(data)
                app_log.info(f"Failure data len: {len(failuredata['table'])}")
                if len(failuredata["table"]) > 0:
                    # exporting summery data
                    df = pd.DataFrame(failuredata["summary"], index=[0])
                    df.to_csv(f"export/{filename}", index=False)

                    # Adding empty rows to the file
                    with open(f"export/{filename}", "a") as f:
                        f.write("\n" * 2)

                    # exporting table data
                    df = pd.DataFrame(failuredata["table"])
                    df.drop(
                        columns=["enlight_file_json", "sem_file_json"],
                        axis=1,
                        inplace=True,
                    )
                    df.drop_duplicates(keep="first", inplace=True)
                    df.to_csv(f"export/{filename}", mode="a", index=False)
                    # Adding empty rows to the file
                    with open(f"export/{filename}", "a") as f:
                        f.write("\n" * 2)
            else:
                filename = f"layer_summary_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                data = await summaries.layer_summary(data)
                df = pd.DataFrame(data["tableData"])
                df = df.rename(
                    columns={
                        "enlight_timestamp": "Enlight TimeStamp",
                        "sem_timestamp": "SEM (GeBI) TimeStamps",
                        "workweek": "Work Week",
                        "layer": "Layer",
                        "product": "Product",
                        "lotid": "Lot ID",
                        "slot": "Slot ID",
                        "enlight_recipe": "Enlight Recipe Name",
                        "sem_recipe": "SEM (GeBI) Recipe Name",
                        "enlight_toolname": "Enlight Tool ID",
                        "sem_toolname": "SEM (GeBI) Tool ID",
                        "gebi_adc_t": "GeBI ADC T purity",
                        "bin1_count": "Bin 1 Size",
                        "bin1_t": "Bin 1 True DOI Count",
                        "gebi_adc_f": "GeBI ADC F Purity",
                        "bin3_count": "Bin 3 Size",
                        "bin3_t": "Bin 3 True DOI Count",
                        "purifier_purity": "Purifier Purity",
                        "rank6": "Rank 6 DOI Count",
                        "gebi_true_defect": "GeBI True Defect",
                        "review_count": "Review Count",
                        "template_status": "Template Exist",
                    }
                )
                df.drop_duplicates(keep="first", inplace=True)
                df.to_csv(f"export/{filename}", index=False)
                # Adding empty rows to the file
                with open(f"export/{filename}", "a") as f:
                    f.write("\n" * 2)
                app_log.info("Completed layer sumary data export")
        except Exception as err:
            app_log.exception(err)
            app_log.error("Summary Export API Failed")
            return {"error": err}
        return filename

    async def export_kpi(self, data):
        """get data for export kpi"""
        try:
            app_log.info("export api started")
            export = data["userInputs"].get("export")
            timetrend = TimeTrend()
            bin_names = {}

            if export == "rank6":
                bin_names = {"rank6": "Purifier Purity (%)"}
                bin_list = list(bin_names.keys())
                bin_drop = copy.deepcopy(bin_list)
                bin_drop.remove(export)
                data["chartType"] = data["endpoint"] = "rankpurity6"
            else:
                bin_names = {
                    "bin1": "DR ADC-T",
                    "bin3": "DR ADC-F",
                    "bin4": "Gebi ADC-T",
                    "bin5": "Gebi ADC-F",
                }
                data["chartType"] = data["endpoint"] = "binpurity123"
                bin_list = list(bin_names.keys())
                bin_drop = copy.deepcopy(bin_list)
                bin_drop.remove(export)

            resp = await timetrend.kpi(data)

            for i, k in enumerate(resp):
                for j in bin_list:
                    resp[i][bin_names[j]] = resp[i][j]
                    del resp[i][j]
                if bin_drop:
                    for bin_index in bin_drop:
                        del resp[i][bin_names[bin_index]]

            filename = f"{bin_names[export]}_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            df = pd.DataFrame(resp)
            df.to_csv(f"export/{filename}", index=False)
            # Adding empty rows to the file
            with open(f"export/{filename}", "a") as f:
                f.write("\n" * 2)
            app_log.info(f"Completed {export} data export")

        except RuntimeError as err:
            app_log.exception(err)
            app_log.error("KPI export API Failed")
            return {"msg": err}
        return filename

    async def export_accuracy(self, data):
        """get data for export accuracy"""
        try:
            filename = f"AccuracyMonitor_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            query_data = {}
            user_inputs = data["userInputs"]
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            query_data["num_run"] = "10000"
            query_data["num_run"] = (
                data["facetValues"]["no_run"]
                if int(data["facetValues"]["no_run_option"]) == 1
                else "10000"
            )
            all_class = data["facetValues"].get("classcode", [])
            query_data["classcode"] = resolve_classcode(data)
            query_data["all_class"] = (
                str(tuple(all_class)) if len(all_class) > 0 else None
            )
            query_data["limit"] = get_limit(user_inputs)
            query_data["runid"] = self.queries["runid"].format(**query_data)
            if not query_data["num_run"]:
                query_data["num_run"] = data.get("userInputs").get("rows")
            query_to_execute = self.queries["accrcy_export"].format(**query_data)
            resp = await get_query_with_pool(query_to_execute)

            df = pd.DataFrame(resp)
            df.drop_duplicates(keep="first", inplace=True)
            df.to_csv(f"export/{filename}", index=False)
            # Adding empty rows to the file
            with open(f"export/{filename}", "a") as f:
                f.write("\n" * 2)
        except Exception as err:
            app_log.exception(err)
            app_log.error("Accuracy Monitor Export API Failed")
            return {"error": err}
        return filename

    async def export_doi(self, data):
        """get data for export doi"""
        try:
            lots = [i.get("lot") for i in data["lotids"]]
            lots = tuple(lots)
            waferid = [j.get("waferid") for j in data["lotids"]]
            waferid = tuple(waferid)
            query_data = dict()
            # Get data from table if exists
            if data.get("groupmapping", []):
                trueclasscd = [
                    x["classnumber"]
                    for x in data.get("groupmapping", [])
                    if x["groupname"] == "True"
                ]
                if trueclasscd:
                    query_data["class_mapping"] = f"{tuple(trueclasscd)}"
                else:
                    query_data["class_mapping"] = "([])"
            else:
                query_data["class_mapping"] = "([])"

            query_data["conditions"] = self.prepare_query(
                data, waferid=waferid, lot=lots
            )
            query_data["doi_rank"] = tuple(data.get("doi_rank", [1, 2, 3, 4, 5, 6]))
            filename = (
                f"ExportDOI_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            )

            query_to_execute = self.queries["export_doi"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            if len(data_output) > 0:
                # exporting summery data
                app_log.info("Started export doi")
                df = pd.DataFrame.from_dict(data_output)
                df.to_csv(f"export/{filename}", index=False)
                app_log.info("Completed export T DOI data for budget analysis")
                # Adding empty rows to the file
                with open(f"export/{filename}", "a") as f:
                    f.write("\n" * 2)

        except Exception as err:
            app_log.exception(err)
            app_log.error("Export True DOI data for budget analysis API Failed")
            return {"error": err}
        return filename

    async def export_accumulative(self, data):
        """get data for export accumulative"""
        try:
            accum = BudgetAnalysis()
            resp = await accum.acc_post(data)
            filename = f"Accumulative_Budget_Analysis_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            rank_list = resp["ranktable"].keys()
            rank_list = list(rank_list)
            if 'Batch Size' in rank_list:
                rank_list.remove('Batch Size') 
            ranks = rank_list
            ranktable = resp["ranktable"]
            data = {}
            for i in ranks:
                d_list = []
                for j in ranktable[i]:
                    d_list.append(j["value"])
                data[i] = d_list
            df = pd.DataFrame(data=data.values(), index=data.keys())
            df.sort_index(inplace=True)
            df.rename(index={"1.0": "Rank 1","2.0": "Rank 2","3.0": "Rank 3","4.0": "Rank 4","5.0": "Rank 5","6.0": "Rank 6"},inplace=True)
            for i in range(len(df.columns)):
                df.rename(columns={i: f"Batch {i+1}"}, inplace=True)
            df2 = pd.DataFrame(
                data=[resp["ranktable"]["Batch Size"][0]["value"]]
                * len(resp["ranktable"]["Batch Size"]),
                columns=["Batch Size"],
            )
            df2 = df2.T
            df2.columns = df.columns
            df = df.append(df2)
            df.to_csv(f"export/{filename}", index=True)
            app_log.info("Completed accumualtive BA data export")
            # Adding empty rows to the file
            with open(f"export/{filename}", "a", encoding="utf-8") as f:
                f.write("\n" * 2)
            return filename
        except Exception as err:
            app_log.exception(err)
            app_log.error("Export accumulative budget analysis API Failed")
            return {"error": err}

    def prepare_query(self, data, lot, waferid):
        """Prepare query filters for export"""
        query_list = []
        col_mapping = columns_info["column_mapping"]
        for key, value in data.items():
            col = col_mapping.get(key, key)
            if key == "stepid":
                query = f"{col} in {tuple(value)}"
                query_list.append(query)
        if len(lot) >= 1 and not isinstance(lot, str):
            query = f"carrierid in {lot}"
        else:
            query = f"carrierid = '{lot}'"
        query_list.append(query)
        if len(waferid) >= 1 and not isinstance(waferid, str):
            query = f"waferid in {waferid}"
        else:
            query = f"waferid = '{waferid}'"
        query_list.append(query)
        if len(query_list) > 0:
            return f" and {' and '.join(query_list)}"
        else:
            return ""

    async def raw_data(self, data):
        """get data for raw data export"""
        try:
            filename = (
                f"Raw_Data_{datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            )
            query_data = prepare_query_data(data)
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data[
                "runid_query"
            ] = f",{self.common_queries['runid_query'].format(**query_data)}"
            query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            await self.classcode_classifications(data,query_data)
            query_to_execute = self.queries["kpi"].format(**query_data)
            cols = {
                "bin1": "DR ADC-T",
                "bin3": "DR ADC-F",
                "bin4": "Gebi ADC-T",
                "bin5": "Gebi ADC-F",
                "rank6": "Purifier Purity (%)",
                "xaxis": "X Axis",
                "deviceid": "Device ID",
                "stepid": "Step ID",
                "lotrecord": "Lot record",
                "waferrecord": "Wafer record",
                "truedoicount": "True DOI Count",
                "highdefectcount": "High Defect Count",
                "inspectionstationid": "Inspection Station ID",
                "recipeid": "Recipe ID",
                "datecount": "Date Count",
                "gebi_true_defect": "Gebi True Defect",
                "review_count": "Review Count ",
                "rank1": "Rank 1",
                "rank2": "Rank 2",
                "rank3": "Rank 3",
                "rank4": "Rank 4",
                "rank5": "Rank 5",
            }
            resp = await get_query_with_pool(query_to_execute)
            df = pd.DataFrame(data=resp)
            df.rename(columns=cols, inplace=True)
            df.to_csv(f"export/{filename}", index=False)
            with open(f"export/{filename}", "a", encoding="utf-8") as f:
                f.write("\n" * 2)
            return filename
        except Exception as err:
            app_log.exception(err)
            app_log.error("Export raw data for KPI API Failed")
            return {"error": err}

    async def classcode_classifications(self,data,query_data):
        classcode  =  data.get('chart_classcode')
        if classcode:
            for key, val in classcode.items():
                query_data[f'{key}_all_class'] =sum(list(val.values()), [])
            #     query_data[f'{key}_false_class'] =  val['False']
            # query_data['review_count_allclass'] = query_data['review_count_true_class']+query_data['review_count_false_class']