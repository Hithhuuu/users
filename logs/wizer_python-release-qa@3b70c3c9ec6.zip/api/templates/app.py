"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.templates.templates_api import templateshandler


app.include_router(templateshandler.router)
