import tornado
from api.templates.templates_api.templateshandler import (
    TemplatesHandler,
    TemplatesFilterHandler,
    TemplateIdsHandler,
    TemplateDetailsHandler,
    TemplateNameDetailsHandler,
)

services = {
    "templates": [
        tornado.web.url(r"/templates", TemplatesHandler),
        tornado.web.url(r"/templates/filter", TemplatesFilterHandler),
        tornado.web.url(r"/templates/templateids", TemplateIdsHandler),
        tornado.web.url(r"/templates/templatedetails", TemplateDetailsHandler),
        tornado.web.url(r"/templates/templatenamelist", TemplateNameDetailsHandler),
    ],
}
