"""Model for Template API's"""
import json
import traceback
import datetime

from api.utils.common import create_notification, get_filter_condition
from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, queries

app_log = get_logger("templates")
EXCLUDE_CONDITION = (
    " and (multiSearchAny(cast(templatename as String), ['__timetrend']) <= 0) "
)
DATASELECTIONCHANGES = ["adcclasscode", "mdcclasscode", "adchcclasscode"]
DASHBOARDCHANGES = [
    "bin",
    "binrank",
    "deviceid",
    "lotrecord",
    "no_run",
    "no_run_option",
    "rank",
    "recipeid",
    "resulttimestamp",
    "stepid",
    "templates",
    "waferrecord",
    "adcclasscode",
    "mdcclasscode",
    "adchcclasscode",
    "truedoicount",
    "highdefectcount",
    "truedoicountenable",
    "highdefectcountenable",
]


class Template:
    """Model class for templates"""

    def __init__(self):
        """Initializing query variables"""
        self.queries = queries["templates"]

    async def update_alerts_reports(self, data_details, data, jstr):
        """Update alerts and autoreports"""
        app_log.info("Updating alerts and autoreports...")
        data_changes = {}
        data_changes["dschange"] = {
            key: data_details[key]
            for key in DATASELECTIONCHANGES
            if key in data_details
        }
        data_changes["dschange"] = {"classCode": data_changes["dschange"]}
        data_changes["dsfilter"] = {
            key: data_details[key] for key in DASHBOARDCHANGES if key in data_details
        }
        try:
            # get id of alerts that use current template
            query = self.queries["read_autoalert_list"].format(
                **{
                    "condition": f"(trim(visitParamExtractRaw(dashboardfilters, 'template_id')) = '{data.get('template_id')}')"
                }
            )
            record_list = await get_query_with_pool(query)

            # get data from DB for alert id's
            for alert in record_list:
                query = self.queries["read_alertchange"].format(
                    **{"condition": alert["id"]}
                )
                output = await get_query_with_pool(query)
                output = output[0]
                dataselection = json.loads(output["dataselectionfilters"])
                dashboard = json.loads(output["dashboardfilters"])
                dataselection.update(
                    (k, v) for k, v in data_changes["dschange"].items()
                )
                if 'templates' in data_details:
                    dataselection['templates'] = data_details['templates']
                for cnt, dashbrd in enumerate(dashboard):
                    dashbrd["filters"]["dataMeasurement"].update(
                        (k, v) for k, v in data_changes["dsfilter"].items()
                    )
                    dashbrd["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ] = jstr
                    dashbrd["filters"]["excludeList"] = jstr["dashboardFilters"][
                        "excludeList"
                    ]
                    dashboard[cnt] = dashbrd
                query = self.queries["update_alert"].format(
                    **{
                        "dashboardfilters": f"'{json.dumps(dashboard)}'",
                        "dataselectionfilters": f"'{json.dumps(dataselection)}'",
                        "id": alert["id"],
                    }
                )
                await get_query_with_pool(query, resp_type="None")
                short_descp = f"Your alert {alert.get('reportname')} has been updated"
                app_log.info("Creating notifications...")
                await create_notification([alert.get("username")], short_descp)
            app_log.info("Alerts updated in backend")

            # get id of auto reports that use current template
            query = self.queries["read_autoreport_list"].format(
                **{
                    "condition": f"(trim(visitParamExtractRaw(dashboardfilters, 'template_id')) = '{data.get('template_id')}')"
                }
            )
            record_list = await get_query_with_pool(query)

            for report in record_list:
                query = self.queries["read_autoreportchange"].format(
                    **{"condition": report["id"]}
                )
                output = await get_query_with_pool(query)
                output = output[0]
                dashboard = json.loads(output["dashboardfilters"])
                dataselection = json.loads(output["dataselectionfilters"])
                if 'templates' in data_details:
                    dataselection['templates'] = data_details['templates']
                for cnt, dashbrd in enumerate(dashboard):
                    dashbrd["filters"]["dataMeasurement"].update(
                        (k, v) for k, v in data_changes["dsfilter"].items()
                    )
                    dashbrd["filters"]["dataMeasurement"]["loadedTemplate"][
                        "template_json"
                    ] = jstr
                    dashbrd["filters"]["excludeList"] = jstr["dashboardFilters"][
                        "excludeList"
                    ]
                    dashboard[cnt] = dashbrd
                query = self.queries["update_autoreport"].format(
                    **{
                        "dashboardfilters": f"'{json.dumps(dashboard)}'",
                        "dataselectionfilters": f"'{json.dumps(dataselection)}'",
                        "id": report["id"],
                    }
                )
                await get_query_with_pool(query, resp_type="None")
                short_descp = (
                    f"Your auto report {report.get('reportname')} has been updated"
                )
                app_log.info("Creating notifications...")
                await create_notification([report.get("username")], short_descp)
            app_log.info("Autoreports updated in backend")

        except Exception as err:
            app_log.error("Error while updating alerts and autoreports.")
            app_log.info(traceback.format_exc())
            raise err

    async def get(self, data):
        """Returns list of all templates."""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered", data["endpoint"])
            resp = {}
            query_data = {}
            query_data["detail_flg"] = data["detailed_flag"]
            get_filter_condition(query_data, data)
            query_data["exclude_condition"] = (
                EXCLUDE_CONDITION if data.get("exclude") else ""
            )
            query_data["template_json"] = (
                "template_json," if query_data["detail_flg"] else ""
            )
            if data["endpoint"] in [
                "/templates",
                "/templates/templateids",
            ] and data.get("template_owner"):
                if data.get("template_owner") in [
                    "alertreport@amat.com",
                    "autoreport@amat.com",
                ]:
                    query_data["filter_condition"] = ""
                    query_data["exclude_condition"] = ""
                    query_data[
                        "template_condition"
                    ] = f" and template_owner = '{data.get('template_owner')}' and rfg=1 and tfg=0"
                else:
                    query_data[
                        "template_condition"
                    ] = f" and (layer <> '') and (((rfg = 1) AND (tfg = 1) {query_data['filter_condition']} {query_data['exclude_condition']} )OR (template_owner = '{data.get('template_owner')}' AND (rfg = 1) AND (tfg = 0) {query_data['filter_condition']} {query_data['exclude_condition']}))"
                    query_data["filter_condition"] = ""
                    query_data["exclude_condition"] = ""
            else:
                query_data["template_condition"] = [
                    f"{k if k != 'templatenamelike' else 'templatename'}{' = ' if k != 'templatenamelike' else ' like '}'{v[0] if isinstance(v,list) else v}'"
                    for k, v in data.items()
                    if k
                    not in ["exclude", "endpoint", "stepid", "deviceid", "recipeid"]
                ]
                query_data[
                    "template_condition"
                ] = f" and {' and '.join([i for i in query_data['template_condition'] if not i.__contains__('detailed_flag')])} and rfg = 1"
            query_to_execute = self.queries["template_list"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            if not data_output:
                app_log.info(
                    "%s api took %s to complete",
                    data["endpoint"],
                    str(datetime.datetime.now() - start_time),
                )
                return {}
            resp = sorted(data_output, key=lambda i: (i["udt"]), reverse=True)
            if len(data_output) and query_data["detail_flg"]:
                template_obj = json.loads(
                    data_output[0]["template_json"].replace("\\", "")
                )
                grplist = []
                ### new logic to handle update of json
                data["stepid"] = template_obj["dashboardFilters"]["dataMeasurement"][
                    "stepid"
                ]
                data["deviceid"] = template_obj["dashboardFilters"][
                    "dataMeasurement"
                ].get("deviceid", "")
                data["recipeid"] = template_obj["dashboardFilters"][
                    "dataMeasurement"
                ].get("recipeid", "")
                get_filter_condition(query_data, data)
                data["filter_condition"] = query_data["filter_condition"]
                classnums = await get_query_with_pool(
                    self.queries["get_classnums"].format(**data)
                )
                classnums = classnums[0]["classnum"]
                usrgrplst = template_obj["dashboardFilters"]["userGroupList"]
                clslst = [int(val["classnumber"]) for val in usrgrplst]
                clslst.sort()
                grplist = usrgrplst
                for classnum in classnums:
                    if classnum not in clslst:
                        grplist.append({"classnumber": classnum, "groupname": ""})
                grplist_new = sorted(grplist, key=lambda d: d["classnumber"])
                template_obj["dashboardFilters"]["userGroupList"] = grplist_new
                data_output[0]["template_json"] = json.dumps(template_obj).replace(
                    '"', '"'
                )
                resp = data_output[0]
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return resp
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}

    async def get_filtered_template(self, data):
        """Returns list of all templates filtered."""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered", data["endpoint"])
            resp = {}
            query_data = {}
            get_filter_condition(query_data, data)
            query_data["template_json"] = "template_json,"
            if data.get("type") == "bytemplate":
                query_data[
                    "template_condition"
                ] = f" and template_id = {data['template_id']} and rfg = 1"
                query_data["exclude_condition"] = ""
                query_to_execute = self.queries["template_list"].format(**query_data)
            elif data.get("templatename") and isinstance(
                data.get("templatename"), list
            ):
                query_data[
                    "template_condition"
                ] = f" and ((templatename in {str(tuple(data['templatename']))} and rfg = 1) or (templatename in {str(tuple(data['templatename']))} and template_owner in ('autoreport@amat.com', 'autoalert@amat.com')))"
                query_data["exclude_condition"] = ""
                query_to_execute = self.queries["template_list"].format(**query_data)
            else:
                query_data["exclude_condition"] = (
                    EXCLUDE_CONDITION if data["type"] == "byprimaryfilters" else ""
                )
                query_data[
                    "template_condition"
                ] = f" and (layer <> '') and (((rfg = 1) AND (tfg = 1) {query_data['filter_condition']} {query_data['exclude_condition']} ) OR (template_owner = '{data.get('userid')}' AND (rfg = 1) AND (tfg = 0) {query_data['filter_condition']} {query_data['exclude_condition']}))"
                query_data["filter_condition"] = ""
                query_data["exclude_condition"] = ""
                query_to_execute = self.queries["template_list"].format(**query_data)
            resp = await get_query_with_pool(query_to_execute)

            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return sorted(resp, key=lambda i: (i["udt"]), reverse=True)
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}

    async def create(self, data):
        """Creates a template"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered", data["endpoint"])
            query_data = {}
            query_data[
                "template_condition"
            ] = f" AND templatename = '{data.get('templatename')}'"
            query_data["filter_condition"] = ""
            query_data["exclude_condition"] = ""
            query_data["template_json"] = "template_json,"
            check_query = self.queries["template_list"].format(**query_data)
            app_log.info("Checking if template already exists...")
            res = await get_query_with_pool(check_query)
            if res:
                msg = {"msg": "template already exists!"}
            else:
                data["tfg"] = 1 if data["template_access"].lower() == "global" else 0
                data["product"] = (
                    data.get("deviceid")[0] if data.get("deviceid") else ""
                )
                data["layer"] = data.get("stepid")[0] if data.get("stepid") else ""
                data["setupid"] = (
                    data.get("recipeid", [""])[0]
                    if isinstance(data.get("recipeid", None), list)
                    else data.get("recipeid", "")
                )
                query = self.queries["create"].format(**data)
                await get_query_with_pool(query, resp_type="None")
                msg = {"msg": f"template {data['templatename']} created."}
                app_log.info(
                    "%s api took %s to complete",
                    data["endpoint"],
                    str(datetime.datetime.now() - start_time),
                )
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
        return msg

    async def update(self, data):
        """Update an existing template"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered", data["endpoint"])
            jstr = (
                json.loads(data.get("template_json", None))
                if data.get("template_json", None)
                else None
            )
            data_details = jstr["dashboardFilters"]["dataMeasurement"] if jstr else {}
            data[
                "template_condition"
            ] = f" and template_id = '{data['template_id']}' and template_owner = '{data['template_owner']}'"
            data["exclude_condition"] = ""
            data["filter_condition"] = ""

            query_data = {
                "templatename": f"'{data.get('templatename')}'"
                if data.get("templatename", None)
                else "templatename",
                "template_json": f"'{data.get('template_json')}'"
                if data.get("template_json", None)
                else "template_json",
                "template_owner": f"'{data.get('template_owner')}'"
                if data.get("template_owner", None)
                else "template_owner",
                "layer": f"'{data_details.get('stepid')[0]}'"
                if isinstance(data_details.get("stepid"), list)
                and len(data_details.get("stepid")) > 0
                else f"'{data_details.get('stepid')}'"
                if data_details.get("stepid")
                else "layer",
                "product": f"'{data_details.get('deviceid')[0]}'"
                if isinstance(data_details.get("deviceid"), list)
                and len(data_details.get("deviceid")) > 0
                else f"'{data_details.get('deviceid')}'"
                if data_details.get("deviceid")
                else "product",
                "setupid": f"'{data_details.get('recipeid')[0]}'"
                if isinstance(data_details.get("recipeid"), list)
                and len(data_details.get("recipeid")) > 0
                else f"'{data_details.get('recipeid')}'"
                if data_details.get("recipeid")
                else "setupid",
                "cdt": f"'{data.get('cdt')}'" if data.get("cdt", None) else "cdt",
                "uby": f"'{data.get('uby')}'" if data.get("uby", None) else "uby",
                "rfg": f"'{data.get('rfg')}'" if data.get("rfg", None) else "rfg",
                "tfg": f"'{data.get('tfg')}'" if data.get("tfg", None) else "tfg",
                "template_id": data.get("template_id"),
            }
            app_log.info("Updating the template..")
            query = self.queries["update"].format(**query_data)
            await get_query_with_pool(query, resp_type="None")
            app_log.info("Template updated successfully.")
            app_log.debug(data_details)
            get_filter_condition(query_data, data)
            data["filter_condition"] = query_data["filter_condition"]
            if jstr:
                await self.update_alerts_reports(data_details, data, jstr)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
        return [
            await self.get(
                {
                    "template_id": data.get("template_id"),
                    "detailed_flag": True,
                    "endpoint": data["endpoint"],
                }
            )
        ]

    async def delete(self, data):
        """Deletes a template"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered", data["endpoint"])
            query_data = {}
            query_data[
                "template_condition"
            ] = f" AND template_id = '{data.get('template_id')}'"
            query_data["filter_condition"] = ""
            query_data["exclude_condition"] = ""
            query_data["template_json"] = "template_json,"
            check_query = self.queries["template_list"].format(**query_data)
            # Get template name that is to be deleted
            templatename = await get_query_with_pool(check_query)
            if not templatename:
                return {"error": "Error: template deleted already."}
            template_name = f'"templates": {[templatename[0].get("templatename")]}'
            query = self.queries["delete"].format(**data)
            await get_query_with_pool(query, resp_type="None")

            # delete auto report and alerts linked to the template
            if not templatename[0].get("templatename").__contains__("timetrend"):
                for i in ["wizer_autoalert", "wizer_autoreport"]:
                    query_data = {
                        "templatename": template_name.replace("'", '"'),
                        "table": i,
                    }
                    query_to_execute = self.queries["delete_autoreport_linked"].format(
                        **query_data
                    )
                    app_log.info(f"Autoreport delete Query: {query_to_execute}")
                    await get_query_with_pool(query_to_execute, resp_type="None")
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
        return [
            await self.get(
                {
                    "template_id": data.get("template_id"),
                    "detailed_flag": True,
                    "endpoint": data["endpoint"],
                }
            )
        ]
