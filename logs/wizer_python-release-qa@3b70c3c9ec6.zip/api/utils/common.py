"""Common functions for all API's"""
import traceback
import json
import requests
import zlib
import itertools
import datetime
import aiohttp
import smtplib


from jwt import decode
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from api.utils.fastapi_app import get_query_with_pool
from api.utils.auth import jwtauth
from api.utils.utils import (
    get_logger,
    common_query,
    columns_info,
    env_config,
    queries,
)


app_log = get_logger("common")
alert_log = get_logger("valid_alert")

HEADER_CONST_LIST = [
    "header.resulttimestamp",
    "header.layer",
    "header.product",
    "header.waferid",
    "header.carrierid",
]


def get_classcode(data):
    lst = []
    for i in data.get("adcclasscode", {}).values():
        lst.extend(i)
    for i in data.get("mdcclasscode", {}).values():
        lst.extend(i)
    for i in data.get("adchcclasscode", {}).values():
        lst.extend(i)
    return list(set(lst))


def get_classcode_bin_rank(data, classtype):
    lst = []
    for i in data.get(f"{classtype.lower()}classcode", []).values():
        lst.extend(i)
    return list(set(lst))


def get_classcode_purity(data):
    lst = []
    for i in data.get("mdcclasscode", []).values():
        lst.extend(i)
    return list(set(lst))


def get_adc_classcode(data):
    adc_lst = []
    mdc_lst = []
    adchcc_lst = []
    for i in data.get("adcclasscode", {}).values():
        adc_lst.extend(i)
    for i in data.get("mdcclasscode", {}).values():
        mdc_lst.extend(i)
    for i in data.get("adchcclasscode", {}).values():
        adchcc_lst.extend(i)
    resp_dict = {
        "adcclasscode": list(set(adc_lst)),
        "mdcclasscode": list(set(mdc_lst)),
        "adchcclasscode": list(set(adchcc_lst)),
    }
    return resp_dict


def get_auth_token(request):
    auth = request.headers.get("Authorization")
    token = auth.split()[1]
    return token


def get_user(request):
    """Get auth data"""
    auth = request.headers.get("Authorization")
    options = {
        "verify_signature": True,
        "verify_exp": True,
        "verify_nbf": False,
        "verify_iat": True,
        "verify_aud": False,
    }
    token = auth.split()[1]
    return decode(token, env_config["secret_key"], options=options, algorithms=["HS256"])


def format_template_json(data):
    """Format template json in data"""
    if data.get("dashboardfilters", None):
        for i in range(len(data["dashboardfilters"])):
            if (
                data["dashboardfilters"]
                and data["dashboardfilters"][i]["filters"]
                and data["dashboardfilters"][i]["filters"]["dataMeasurement"]
                and data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                    "loadedTemplate"
                ]
                and data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                    "loadedTemplate"
                ]["template_json"]
            ):
                data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                    "loadedTemplate"
                ]["template_json"] = json.loads(
                    data["dashboardfilters"][i]["filters"]["dataMeasurement"][
                        "loadedTemplate"
                    ]["template_json"]
                )
    return data


def get_tooltips(query_data, tooltip_data):
    """Get tooltip conditions"""
    col_mapping = columns_info["column_mapping"]
    query_list = []
    for key, values in tooltip_data.items():
        col = col_mapping.get(key, key)
        alias = get_alias(col)
        if alias != "" and values not in ("", "", None):
            query_list.append(f" ((header.{col}) = '{values}')")
            query_list.append(f" ((defects.{col}) = '{values}')")
    query_data["header_tooltips"] = " and ".join(
        [q for q in query_list if "header." in q]
    )
    query_data["defect_tooltips"] = " and ".join(
        [q for q in query_list if "defects." in q]
    )
    if query_data["header_tooltips"] != "":
        query_data["header_tooltips"] = f" and {query_data['header_tooltips']}"
    if query_data["defect_tooltips"] != "":
        query_data["defect_tooltips"] = f" and {query_data['defect_tooltips']}"


def resolve_classcode(data):
    """Resolve classcode type"""
    return columns_info["column_mapping"][
        f"classcode{data['userInputs'].get('type','MDC')}"
    ]


def resolve_false_class(data):
    """Resolve false calsscode"""
    if data["userInputs"].get("groupmapping", []):
        falseclasscd = [
            x["classnumber"]
            for x in data["userInputs"].get("groupmapping", [])
            if x["groupname"] == "False" or str.upper(x["groupname"]) == "NVD"
        ]
        if falseclasscd:
            converted_data = [str(element) for element in falseclasscd]
            falseclasscode = ",".join(converted_data)
            return "(" + falseclasscode + ")"
        else:
            return "([])"
    else:
        return "([])"


def resolve_true_class(data):
    """Resolve true classcodes"""
    resp = "([])"
    if data["userInputs"].get("groupmapping", []):
        trueclasscd = [
            x["classnumber"]
            for x in data["userInputs"].get("groupmapping", [])
            if x["groupname"] == "True"
        ]
        if trueclasscd:
            converted_data = [str(element) for element in trueclasscd]
            trueclasscode = ",".join(converted_data)
            resp = "(" + trueclasscode + ")"

    return resp


def get_alias(col):
    """Get wether column is in header or defect table"""
    alias = ""
    if col in columns_info["header_cols"].keys():
        alias = "header."
    elif col in columns_info["main_cols"].keys():
        alias = "defects."
    return alias


def get_limit(user_inputs):
    """Get limit for the query"""
    if "offset" in user_inputs.keys() and "rows" in user_inputs.keys():
        return f" limit {user_inputs['offset']} , {user_inputs['rows']} "
    return ""


def prepare_singledropdown_filter(data):
    """Filters with single select"""
    singledropdown_filters = data["facetFilters"].get("singleDropdown")
    exclude_filters = data["facetFilters"].get("excludeFilters", [])
    singledropdown_filters = [
        filters for filters in singledropdown_filters if filters not in exclude_filters
    ]
    query_list = []
    col_mapping = columns_info["column_mapping"]
    if singledropdown_filters:
        singledropdown_values = {
            col_mapping.get(k, k): v if isinstance(v, list) else [v]
            for k, v in data["facetValues"].items()
            if k in singledropdown_filters and v and v != ""
        }
        for key, val in singledropdown_values.items():
            query_list.append(f"{get_alias(key)}{key} in {tuple(val)}")
    if exclude_filters:
        exclude_values = {
            col_mapping.get(k, k): v if isinstance(v, list) else [v]
            for k, v in data["facetValues"].items()
            if k in exclude_filters
        }
        for key, val in exclude_values.items():
            query_list.append(f"{get_alias(key)}{key} not in {tuple(val)}")
    defect_list = [
        q.replace("header.", "defects.")
        for q in query_list
        if q.startswith("defects.") or any(consts in q for consts in HEADER_CONST_LIST)
    ]
    header_list = [q for q in query_list if q.startswith("header.")]
    defect_list = [cond for cond in defect_list if cond.find("resulttimestamp") < 0]
    if int(data["facetValues"]["no_run_option"]) == 1:
        header_list = [cond for cond in header_list if cond.find("resulttimestamp") < 0]
    return (
        f" and {' and '.join(defect_list)}" if len(defect_list) >0 else "",
        f" and {' and '.join(header_list)}" if len(header_list)>0 else "",
    )


def prepare_multidropdown_filter(data):
    """Filters with multi select"""
    multidropdown_filters = data["facetFilters"].get("multiDropdown", [])
    exclude_filters = data["facetFilters"].get("excludeFilters", [])
    multidropdown_filters = [
        filters for filters in multidropdown_filters if filters not in exclude_filters
    ]
    query_list = []
    col_mapping = columns_info["column_mapping"]
    col_mapping["classcode"] = resolve_classcode(data)
    if multidropdown_filters:
        multidropdown_values = {
            col_mapping.get(k, k): v if isinstance(v, list) else [v]
            for k, v in data["facetValues"].items()
            if k in multidropdown_filters and v not in ("", "", None)
        }
        for key, val in multidropdown_values.items():
            query_list.append(f"{get_alias(key)}{key} in {tuple(val)}")
    if exclude_filters:
        exclude_values = {
            col_mapping.get(k, k): v if isinstance(v, list) else [v]
            for k, v in data["facetValues"].items()
            if k in exclude_filters and v not in ("", "", None)
        }
        for key, val in exclude_values.items():
            query_list.append(f"{get_alias(key)}{key} not in {tuple(val)}")
    defect_list = [
        q.replace("header.", "defects.")
        for q in query_list
        if q.startswith("defects.") or any(consts in q for consts in HEADER_CONST_LIST)
    ]
    header_list = [q for q in query_list if q.startswith("header.")]
    defect_list = [cond for cond in defect_list if cond.find("resulttimestamp") < 0]
    if int(data["facetValues"]["no_run_option"]) == 1:
        header_list = [cond for cond in header_list if cond.find("resulttimestamp") < 0]
    return (
        f" and {' and '.join([i for i in defect_list if i.find('mansemclass')<0])}" if len(defect_list)>0 else "",
        f" and {' and '.join(header_list)}" if len(header_list)>0 else "",
    )


def prepare_range_filter(data):
    """Filters with range values"""
    range_items = data["facetFilters"].get("rangeFilters")
    exclude_filters = (
        data["facetFilters"].get("excludeFilters")
        if data["facetFilters"].get("excludeFilters", None)
        else []
    )
    values = data["facetValues"]
    col_mapping = columns_info["column_mapping"]
    query_list = []
    for key in range_items:
        col = col_mapping.get(key, key)
        alias = get_alias(col)
        equality = "between" if key not in exclude_filters else "not between"
        if isinstance(values.get(key), list):
            if col == "resulttimestamp":
                query = " or ".join(
                    [
                        f"(toDate({alias}{col}) {equality} '{i['min'][0:10]}' and '{i['max'][0:10]}')"
                        for i in values.get(key)
                    ]
                )
            else:
                query = " or ".join(
                    [
                        f"({alias}{col} {equality} {i['min']} and {i['max']})"
                        for i in values.get(key)
                    ]
                )
            query_list.append(query)
        elif isinstance(values.get(key), dict):
            if col == "resulttimestamp":
                query = f"(toDate({alias}{col}) {equality} '{values[key]['min'][0:10]}' and '{values[key]['max'][0:10]}')"
            else:
                query = f"({alias}{col} {equality} {values[key]['min']} and {values[key]['max']})"
            query_list.append(query)
    defect_list = [
        q.replace("header.", "defects.")
        for q in query_list
        if q.startswith("(defects.") or any(consts in q for consts in HEADER_CONST_LIST)
    ]
    header_list = [q for q in query_list if q.find("header.") > 0]
    defect_list = [cond for cond in defect_list if cond.find("resulttimestamp") < 0]
    if int(data["facetValues"]["no_run_option"]) == 1:
        header_list = [cond for cond in header_list if cond.find("resulttimestamp") < 0]
    return (
        f" and {' and '.join(defect_list)}" if len(defect_list)>0 else "",
        f" and {' and '.join(header_list)}" if len(header_list)>0 else "",
    )


def prepare_query(data):
    """Prepare the where clause condition for the queries using filters"""
    defect_query_single, header_query_single = [
        prepare_singledropdown_filter(data)
        if data["facetFilters"].get("singleDropdown", [])
        else ("", "")
    ][0]
    defect_query_multi, header_query_multi = [
        prepare_multidropdown_filter(data)
        if data["facetFilters"].get("multiDropdown", [])
        else ("", "")
    ][0]
    defect_query_range, header_query_range = [
        prepare_range_filter(data)
        if data["facetFilters"].get("rangeFilters", [])
        else ("", "")
    ][0]
    return (
        f" {defect_query_single}{defect_query_multi}{defect_query_range}",
        f" {header_query_single}{header_query_multi}{header_query_range}",
    )


def prepare_defect_count_filter(query_data, data, alias):
    """Add filters for defect counts"""
    query_data["truedoicount"] = ""
    query_data["highdefectcount"] = ""
    if str(data["facetValues"].get("truedoicountenable")).lower() == "true":
        query_data[
            "truedoicount"
        ] = f"AND  {alias}.truedoicount >={data['facetValues'].get('truedoicount',10)}"
    if str(data["facetValues"].get("highdefectcountenable")).lower() == "true":
        query_data[
            "highdefectcount"
        ] = f"AND  {alias}.highdefectcount <={data['facetValues'].get('highdefectcount')}"


def prepare_query_data(data, alias="doicnt"):
    """Format conditions and variable for queries"""
    query_data = {}
    all_class = data["facetValues"].get("classcode", [])
    user_inputs = data["userInputs"]
    (
        query_data["defects_condition"],
        query_data["header_condition"],
    ) = prepare_query(data)
    query_data["classcode"] = resolve_classcode(data)
    query_data["all_class"] = str(tuple(all_class)) if len(all_class) > 0 else None
    query_data["limit"] = get_limit(user_inputs)
    query_data["true_class"] = resolve_true_class(data)
    query_data["doi_rank"] = (
        str(tuple(get_doi_rank(data))) if len(get_doi_rank(data)) > 0 else "([])"
    )
    query_data["bin_condition"] = (
        str(tuple(get_bin(data))) if len(get_bin(data)) > 0 else "([])"
    )
    query_data["false_class"] = resolve_false_class(data)
    prepare_defect_count_filter(query_data, data, alias)
    query_data["num_run"] = (
        data["facetValues"]["no_run"]
        if int(data["facetValues"]["no_run_option"]) == 1
        else "10000"
    )
    return query_data


def prepare_query_filters(data):
    """Prepare the query conditions for global filters"""
    query_list = []
    col_mapping = columns_info["column_mapping"]
    for key, value in data.items():
        col = col_mapping.get(key, key)
        if isinstance(value, list):
            query = f"{col} in {tuple(value)}"
            query_list.append(query)
        elif isinstance(value, str) and key in col_mapping:
            query = f"{col} in {tuple([value])}"
            query_list.append(query)
        elif isinstance(value, dict):
            if key == "resulttimestamp" and data["no_run_option"] == "0":
                query = f" toDate({col}) >= '{value['min'][0:10]}' and toDate({col}) <= '{value['max'][0:10]}'"
                query_list.append(query)
    if len(query_list) > 0:
        return f" and {' and '.join(query_list)}"
    return ""


def prepare_adc_data(query_data, data):
    """Prepare conditions for ADC Monitor"""
    values = data["facetValues"]
    class_condition_list = []
    query_data["autoonsemclass"] = (
        tuple(values.get("autoonsemclass"))
        if values.get("autoonsemclass", [])
        else "([])"
    )
    query_data["true_class"] = str(query_data["autoonsemclass"])
    if not query_data["true_class"] == "([])":
        query_data["true_class"] = resolve_true_class(data)
    query_data["mansemclass"] = (
        tuple(values.get("mansemclass")) if values.get("mansemclass", []) else "([])"
    )
    query_data["hunterclass"] = (
        tuple(values.get("hunterclass")) if values.get("hunterclass", []) else "([])"
    )
    class_condition_list.append(
        " defects.autoonsemclass IN " + str(query_data["autoonsemclass"])
    )

    class_condition_list.append(
        " defects.mansemclass IN " + str(query_data["mansemclass"])
    )

    class_condition_list.append(
        " defects.hunterclass IN " + str(query_data["hunterclass"])
    )

    if len(class_condition_list) > 0:
        query_data["class_condition"] = (
            " and (" + " or ".join(class_condition_list) + ")"
        )
    else:
        query_data["class_condition"] = ""


def get_doi_rank(data):
    """Get DOI ranks"""
    facet_values = data.get("facetValues", None)
    exclude_filters = (
        data["facetFilters"].get("excludeFilters")
        if data["facetFilters"].get("excludeFilters", None)
        else []
    )
    if facet_values and "rank" not in exclude_filters:
        if data["userInputs"].get("chartType") == "rank6":
            return facet_values.get("rank", [6])
    if "rank" in exclude_filters:
        rank = facet_values.get("rank", [])
        doi_rank = [1, 2, 3, 4, 5, 6]
        return [x for x in doi_rank if x not in rank]
    return facet_values.get("rank", [1, 2, 3, 4, 5, 6])


def get_bin(data):
    """Get bins"""
    facet_values = data.get("facetValues", None)
    exclude_filters = (
        data["facetFilters"].get("excludeFilters")
        if data["facetFilters"].get("excludeFilters", None)
        else []
    )
    if facet_values and "bin" not in exclude_filters:
        return facet_values.get("bin", [1, 2, 3])
    if "bin" in exclude_filters:
        bins = facet_values.get("bin", [])
        bin_vals = [1, 2, 3]
        return [x for x in bin_vals if x not in bins]
    return facet_values.get("bin", [1, 2, 3])


def get_templates_condition(data):
    """Get template conditions for query"""
    stepid_join_cond = (
        " header.stepid = templates.layer " if "stepid" in data.keys() else ""
    )
    product_join_cond = (
        " header.deviceid = templates.product " if "deviceid" in data.keys() else ""
    )
    setupid_join_cond = (
        " header.recipeid = templates.setupid " if "recipeid" in data.keys() else ""
    )

    join_condition = " and ".join(
        [i for i in [stepid_join_cond, product_join_cond, setupid_join_cond] if i != ""]
    )
    if join_condition == "":
        join_condition = " header.stepid = templates.layer "

    if "stepid" in data.keys() and isinstance(data["stepid"], str):
        data["stepid"] = [data["stepid"]]
    if "deviceid" in data.keys() and isinstance(data["deviceid"], str):
        data["deviceid"] = [data["deviceid"]]
    if "recipeid" in data.keys() and isinstance(data["recipeid"], str):
        data["recipeid"] = [data["recipeid"]]
    stepid_cond = (
        f" layer in {tuple(data['stepid'])}" if "stepid" in data.keys() else ""
    )
    product_cond = (
        f" product in {tuple(data['deviceid'])}" if "deviceid" in data.keys() else ""
    )
    setupid_cond = (
        f" setupid in {tuple(data['recipeid'])}" if "recipeid" in data.keys() else ""
    )

    template_condition = " and ".join(
        [i for i in [stepid_cond, product_cond, setupid_cond] if i != ""]
    )
    if template_condition != "":
        template_condition = f" and {template_condition}"

    return join_condition, template_condition


async def get_prep_level(data, limit=25000):
    """Get prep levels for wafer map"""
    resp = {}
    orientation = "down"
    q_data = data.copy()
    try:
        if not q_data.get("prep_column"):

            app_log.info("prep_column is empty in payload. Calculating Prep Level")
            resp = {"xsite": f"{q_data['xsite']}", "ysite": f"{q_data['ysite']}"}
            app_log.info("............Prep Calculation started...............")
            resp["islevel2"] = False
            defect_count_0_query = common_query["read_defects_count_level0"]
            read_defect_count = common_query["read_defects_count"]

            count_l0_q = defect_count_0_query.format(**q_data)
            count_level0 = await get_query_with_pool(count_l0_q)
            count_l2_q = read_defect_count.format(**q_data)
            count_level2 = await get_query_with_pool(count_l2_q)
            count_level0 = count_level0[0]["cnt"]
            count_level2 = count_level2[0]["cnt"]
            if count_level0 > limit:
                resp["xsite"] = f"xsite_prep2_{orientation}"
                resp["ysite"] = f"ysite_prep2_{orientation}"
                resp["count"] = count_level2
                resp["islevel2"] = True
                if count_level2 > limit:
                    if q_data.get("waferView", None) == "multi":
                        resp["xsite"] = f"xsite_prep0_{orientation}"
                        resp["ysite"] = f"ysite_prep0_{orientation}"
                    else:
                        resp["xsite"] = f"xsite_prep1_{orientation}"
                        resp["ysite"] = f"ysite_prep1_{orientation}"
                    resp["count"] = count_level2
                    app_log.info(f"SET PREP LEVEL AS X and Y PREP1_{orientation}")
            app_log.info("............Prep Calculation End...............")
        else:
            app_log.info("The Prep column already in payload")
            resp = {
                "xsite": q_data["prep_column"][0],
                "ysite": q_data["prep_column"][1],
            }
            resp["count"] = count_level0
            resp["islevel2"] = False
        app_log.debug(resp)
    except Exception as err:
        app_log.exception(err)
        raise err
    return resp


async def create_notification(user_id, short_desc):
    # userid, title, short_desc, to_user
    query = queries["notification"]
    for user in user_id:
        insert_query = query["create_notification"].format(
            **{"username": user, "short_desc": short_desc}
        )
        await get_query_with_pool(insert_query)


class zlib1:
    """For compressing the response using gzip"""

    def zipit(self, resp):
        gzip_compress = zlib.compressobj(9, zlib.DEFLATED, zlib.MAX_WBITS | 16)
        content = gzip_compress.compress(str.encode(resp)) + gzip_compress.flush()
        compressed_content_length = len(content)
        return content, compressed_content_length



def format_template_string(data):
    for i in range(len(data)):
        if (
            data
            and data[0]["filters"]
            and data[i]["filters"]["dataMeasurement"]
            and data[i]["filters"]["dataMeasurement"]["loadedTemplate"]
            and data[i]["filters"]["dataMeasurement"]["loadedTemplate"]["template_json"]
        ):
            data[i]["filters"]["dataMeasurement"]["loadedTemplate"][
                "template_json"
            ] = json.dumps(
                data[i]["filters"]["dataMeasurement"]["loadedTemplate"]["template_json"]
            )
    return data


def get_filter_condition(query_data, data):
    """Get filter condition from template data"""
    query_list = []
    if data.get("deviceid", None) and data["deviceid"][0]:
        query_list.append(f" ((product) = '{data['deviceid'][0]}')")
    if data.get("stepid", None) and data["stepid"][0]:
        query_list.append(f" ((layer) = '{data['stepid'][0]}')")
    if data.get("recipeid", None) and data["recipeid"][0]:
        if isinstance(data.get("recipeid"), list):
            query_list.append(f" ((setupid) in {tuple(data['recipeid'])})")
        else:
            query_list.append(f" ((setupid) = '{data['recipeid']}')")

    query_data["filter_condition"] = " and ".join([q for q in query_list])
    if query_data["filter_condition"] != "":
        query_data["filter_condition"] = f" and {query_data['filter_condition']}"


def summary_condition(data, alert_flg=False):
    cond_list = []
    query_data = {
        "layer_condition":"",
    }
    cols = {
        "deviceid": "product",
        "stepid": "layer",
        "sem_receipe": "sem_recipe",
        "sem_tool_id": "sem_toolname",
        "inspection_tool_id": "enlight_toolname",
        "inspection_recipie": "enlight_recipe",
        "workweek": "workweek"
    }
    if str(data.get("daterangeflag")) == "1":
        cond_str = f"toDate(enlight_timestamp) between '{data['resulttimestamp']['min'][:10]}' and '{data['resulttimestamp']['max'][:10]}'"
        del cols["workweek"]
        cond_list.append(cond_str)
    try:
        for i, k in cols.items():
            if i in list(data.keys()):
                type = "not" if i in data.get("excludeList", []) else ""
                if  data.get(i):
                    if i == "stepid":
                        layer_list = [f"layer {type} like '%{l}%'" if not isinstance(data.get(i),str) else f"layer {type} like '%{data.get(i)}%'" for l in data.get(i) ]
                        query_data["layer_condition"] = f" and ({' or '.join(layer_list)})" if type !='not' else f" and ({' and '.join(layer_list)})"
                    else:
                        cond_str = f"""{k} {type} in {f"('{data.get(i)}')" if isinstance(data.get(i),str) and len(data.get(i)) >0  else tuple(data.get(i))}"""
                        cond_list.append(cond_str)
    except Exception as err:
        app_log.exception(err)
        app_log.exception(traceback.format_exc())
    query_data["alert_condition"] = (
        f"and layer like '%{data.get('stepid')}%' and lotid = '{data.get('lotid')}' "
        if alert_flg
        else ""
    )
    query_data["sort"] = (
        f" {' , '.join([f'{k} {v}'  for i in data.get('columnSort') for k,v in i.items()])}"
        if data.get("columnSort", []) and len(data.get("columnSort", [])) > 0
        else "layer asc ,product asc,enlight_recipe asc, lotid asc"
    )
    query_data["limit"] = (
        f" limit {data.get('limit')[0]} , {int(data.get('limit')[1]) - int(data.get('limit')[0])}"
        if data.get("limit") and len(data.get("limit", [])) == 2
        else ""
    )
    query_data["summary_condition"] = f" and {' and '.join(cond_list)}" if len(cond_list) else ''
    if not str(data.get("daterangeflag")) == "1":
        query_data["summary_condition"] = 'and DATEDIFF(week, enlight_timestamp , now())<17' + \
            query_data["summary_condition"]
    if alert_flg:
        query_data["summary_condition"] = ''
    if data.get("usergroup"):
        query_data.update(group_classifcation(data))
    return query_data


def rca_condition(data):
    query_list = []
    if data.get("stepid"):
        layer = [i for i in data.get("stepid")]
        query_str = f"layer in {tuple(layer)}"
        query_list.append(query_str)
    if data.get("deviceid"):
        product = [i for i in data.get("deviceid")]
        query_str = f"product in {tuple(product)}"
        query_list.append(query_str)
    if len(query_list) > 0:
        return f" and {' and '.join(query_list)}"
    else:
        return ""


def group_classifcation(data):
    false_group = []
    true_group = []
    null_group = []
    null = "(null)"
    for i in data["usergroup"]:
        if i.get("groupname") == "False":
            false_group.append(i.get("classnumber"))
        elif i.get("groupname") == "True":
            true_group.append(i.get("classnumber"))
        else:
            null_group.append(i.get("classnumber"))
    all_group = null_group + true_group + false_group
    resp = {
        "false_class": tuple(false_group) if len(false_group) > 0 else null,
        "true_class": tuple(true_group) if len(true_group) > 0 else null,
        "all_class": tuple(sorted(all_group)) if len(all_group) > 0 else null,
    }
    return resp


async def node_api_trigger(header, filename, unique_id, jwt, unique_data,type=False ):
    payload = {
        "filename": filename,
        "unique_header_id": unique_id,
        "stepid": header["layer"][0],
        "deviceid": header["product"][0],
        "lotrecord": header["carrierid"][0],
        "waferrecord": header["waferid"][0],
        "recipeid": f"{header.iloc[0]['setupid']}",
        "inspectionstationid": f"{header.iloc[0]['platform'].split(' ')[-1]}",
        "tool_id": header.iloc[0]["tool"],
        "type": "imidiate",
    }
    jwt_token = f"Bearer {jwt}"
    req_head = {"Content-Type": "application/json", "Authorization": f"{jwt_token}"}

    for i in ["alerting_url", "rca_alerting_url", "fm_alerting_url"]:
        try:
            if i == "fm_alerting_url":
                payload.update(
                    {
                        "type": "Immediately",
                        "semrecipie": "",
                        "enlightrecipie": f"{header.iloc[0]['setupid']}",
                        "reviewtool": header["tool"][0] if type else "NA",
                        "inspectiontool": "NA",
                        "filetype": "klarf",
                        "alerttype": "fmonitoring",
                    }
                )
            if i == 'rca_alerting_url' and not (unique_data['filetype'].lower() == 'adc' ):
                continue
            app_log.info(env_config.get(i))
            app_log.info(payload)
            sh_report_resp, response = await req_url(env_config.get(i), payload, req_head)
            app_log.info(
                f" {i}  NODE API status_code: {sh_report_resp}"
            )
            if sh_report_resp != 200:
                app_log.info(f"{i} Node API failed.")
        except Exception as e:
            app_log.error(f"Error while calling {i} Node API for Alerting. {repr(e)}")
        node_status = "successful"


async def req_url(url,payload,headers, resp_type=False):
    app_log.info("url: %s",url)
    app_log.info("payload: %s",payload)
    app_log.info("headers: %s",headers)
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=json.dumps(payload),headers = headers) as response:
            sh_report_resp = response.status
            resp=None
            if resp_type :
                resp = await response.json()
    return sh_report_resp, resp


async def send_mail(**kwargs):
    EMAIL_SIGNATURE  =  "<div><br/><br/><br/>Thanks<br/> Wizer Auto Reports</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
    email_content  = kwargs.get("content")+EMAIL_SIGNATURE
    your_smtp_port = env_config.get("smtp_port")
    host  =  env_config.get("host")
    msg = MIMEMultipart()
    msg["From"] = env_config.get("server_mail")
    msg["To"] = kwargs.get("receiver")
    msg["Subject"] = kwargs.get("subject")
    if kwargs.get("attachment"):
        attach_file_name = kwargs.get("attachment")
        with open(attach_file_name, "rb") as file:
            attachment_content = MIMEApplication(file.read())
            attachment_content.add_header(
                    "Content-Disposition", "attachment", filename=attach_file_name
                )
            msg.attach(attachment_content)
    msg.attach(MIMEText(email_content, "html"))
    with smtplib.SMTP(host, your_smtp_port) as server:
        server.send_message(msg)