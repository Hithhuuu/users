"""App for fast api"""
import itertools
import time
import datetime
import jwt
import pandas as pd
from fastapi import FastAPI, Request
from api.utils.scheduler import scheduler_cron
from api.utils.utils import get_async_connection_pool, get_logger
from schedulers.auto_report_scheduler import get_scheduler_auto_reports

app_log = get_logger("toolapi")

app = FastAPI()

@app.on_event("startup")
async def startup():
    """On server startup"""
    try:
        app.state.pool = await get_async_connection_pool()
        app_log.info(f"Pool size = {app.state.pool.size}")
        app_log.info("startup done")
    except Exception as err:
        app_log.info(err)


@app.on_event("shutdown")
async def shutdown():
    """On server shutdown"""
    try:
        fail_query = """insert into opwi_job_log
                                select id, tool_name, file_name, job_start_time,
                                'failed' as job_status1,
                                copy_start_time, copy_end_time, copy_duration,
                                no_of_copy_retries,
                                copied_flag,
                                'server_shutdown' err_message1,
                                process_start_time,
                                process_end_time,
                                process_duration,
                                file_path,
                                arch_path,
                                imported_on,
                                unique_header_id,
                                re_try,
                                file_cnt,
                                ch_cnt
                                from
                                opwi_job_log ojl final
                                where
                                job_status in ('created', 'picked')""" 
        await get_query_with_pool(fail_query, resp_type="None")
        # header_rfg_reset = """insert into opwi_map_header 
        #                         select map.* from
        #                         (select * from opwi_map_header omh final ) map,
        #                         (select mapid , count(1) as def_cnt from opwi_defect_main odm final  group by mapid )def 
        #                         where  map.mapid=def.mapid and map.defectcnt> def.def_cnt
        #                         """
        # await get_query_with_pool(header_rfg_reset, resp_type="None")
        app.state.pool.close()
        await app.state.pool.wait_closed()
        await app.state.pool.terminate()
        app_log.info(f"Pool size = {app.state.pool.size}")
        app_log.info("shutdown done")
    except Exception as err:
        app_log.info(err)

@app.on_event("startup")
@scheduler_cron(cron_expression="0 16 * * *")
async def trigger_autoreport():
    await get_scheduler_auto_reports()

async def get_query_with_pool(query, resp_type="dict"):
    """Run query using async"""
    conn = await app.state.pool.acquire()
    app_log.debug(f"Query to be executed:\n{query}")
    start_time = datetime.datetime.now()
    memory_executor_settings = ["2G", "4G", "10G"]
    try:
        async with conn.cursor() as cur:
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    time_taken = datetime.datetime.now() - start_time
                    app_log.info(
                        f"QUERY EXECUTED SUCCESSFULLY\nMEMORY SETTING: {memory}B\nTime taken to run the query: {time_taken}"
                    )
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        app_log.error(
                            f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                        )
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")
                    app_log.warning(
                        f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                    )
            if resp_type != "None":
                data = await cur.fetchall()
                col = cur._columns
                if resp_type == "df":
                    data = pd.DataFrame(data, columns=col)
                elif resp_type == "dict":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(col), row)),
                            data,
                        )
                    )
                    if len(data) != 0:
                        data = [
                            {
                                k: " ".join(val.split("\x00")).strip()
                                if isinstance(val, str)
                                else val
                                for k, val in d.items()
                            }
                            for d in data
                        ]
                elif resp_type == "list":
                    data = [record[0] for record in data]
                elif resp_type == "length":
                    data = data
                await app.state.pool.release(conn)
                return data
            await app.state.pool.release(conn)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:%s", str(err))
        raise err

async def insert_data(query, list_data):
    """Insert data from list of tuples or list of dicts.."""
    conn = await app.state.pool.acquire()
    app_log.debug("Inserting data using query:\n%s", query)
    start_time = datetime.datetime.now()
    try:
        async with conn.cursor() as cursor:
            cursor.set_settings({"max_memory_usage": "10G"})
            await cursor.execute(query, list_data)
        time_taken = datetime.datetime.now() - start_time
        app_log.info("Data inserted successfully in %s", time_taken)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:\n%s", str(err))
        raise err
    await app.state.pool.release(conn)
