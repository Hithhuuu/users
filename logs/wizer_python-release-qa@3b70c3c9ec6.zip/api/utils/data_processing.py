import numpy as np
import pandas as pd
from datetime import datetime
import time
from api.utils.utils import (
    get_logger,
    general_queries,
    get_config,
    decrypt,
    get_column_details,
    env_config,
)
import requests, json
from datetime import datetime, timedelta
from enum import IntEnum


# -------------------------------WEEKNUM----------------#
WEEKDAY = IntEnum("WEEKDAY", "MON TUE WED THU FRI SAT SUN", start=1)
# -------------------------------WEEKNUM END----------------#

app_log = get_logger("data_processing")
alias_info = get_column_details("alias")
header_cols = get_column_details("header_cols")
queries = general_queries


# -------------------celery config--------------------------#


# -------------------celery config end ---------------------#

# Set default variables
default_batch_size = get_config()["DEFAULT_BATCH_SIZE"]
MAX_NUM_PROCESSES = get_config()["MAX_NUM_PROCESSES"]


def get_auth_token():
    app_log.info(f"Auth token api call to get the Auth Token.")

    payload = {
        "userid": get_config()["USER_NAME_INPUT"],
        "password": get_config()["encrypted_key"],
    }

    headers = {"Content-Type": "application/json"}
    response = requests.post(
        env_config["auto_auth_token_api"], data=json.dumps(payload), headers=headers
    )
    token_resp = json.loads(
        decrypt(
            response.json()["encryptedData"],
            bytes("c2VjcmV0cGFzc3dvcmRwaHJhc2U=", "utf-8"),
        ).decode("utf-8")
    )
    app_log.info(response.json())
    app_log.info(
        f"Auth Token Api status_code: {response.status_code}, "
        f"elapsed time:{response.elapsed.total_seconds()}"
    )

    if response.status_code != 200:
        raise RuntimeError("Auth Token API request Failed")

    json_token_resp = token_resp
    return json_token_resp["jwt"]


def workweek(data):
    date = datetime.strptime(data["Started on"][0], "%Y-%m-%d %H:%M:%S")
    my_calendar = CustomizedCalendar(
        start_weekday=WEEKDAY.FRI, indicator_weekday=WEEKDAY.MON
    )
    weeknum = my_calendar.calculate(date)[1]
    return weeknum


class CustomizedCalendar:
    def __init__(self, start_weekday, indicator_weekday=None):
        self.start_weekday = start_weekday
        self.indicator_delta = (
            3 if not (indicator_weekday) else (indicator_weekday - start_weekday) % 7
        )

    def get_week_start(self, date):
        delta = date.isoweekday() - self.start_weekday
        return date - timedelta(days=delta % 7)

    def get_week_indicator(self, date):
        week_start = self.get_week_start(date)
        return week_start + timedelta(days=self.indicator_delta)

    def get_first_week(self, year):
        indicator_date = self.get_week_indicator(datetime(year, 1, 1))
        if indicator_date.year == year:  # The date "year.1.1" is on 1st week.
            return self.get_week_start(datetime(year, 1, 1))
        else:  # The date "year.1.1" is on the last week of "year-1".
            return self.get_week_start(datetime(year, 1, 8))

    def calculate(self, date):
        year = self.get_week_indicator(date).year
        first_date_of_first_week = self.get_first_week(year)
        diff_days = (date - first_date_of_first_week).days
        return year, (diff_days // 7 + 1), (diff_days % 7 + 1)
