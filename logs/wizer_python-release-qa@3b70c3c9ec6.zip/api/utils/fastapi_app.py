"""App for fast api"""
import itertools
import time
import datetime
import jwt 
import pandas as pd
from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from api.utils.auth import AuthUtil
from api.utils.utils import get_async_connection_pool, get_logger, env_config

app_log = get_logger("fastapi")

app = FastAPI()
auth_scheme = HTTPBearer()
secret_key = env_config["secret_key"]


@app.on_event("startup")
async def startup():
    """On server startup"""
    try:
        app.state.pool = await get_async_connection_pool()
        print(f"Pool size = {app.state.pool.size}")
        print("startup done")
    except Exception as err:
        print(err)


@app.on_event("shutdown")
async def shutdown():
    """On server shutdown"""
    try:
        app.state.pool.close()
        await app.state.pool.wait_closed()
        await app.state.pool.terminate()
        print(f"Pool size = {app.state.pool.size}")
        print("shutdown done")
    except Exception as err:
        print(err)


async def get_query_with_pool(query, resp_type="dict"):
    """Run query using async"""
    conn = await app.state.pool.acquire()
    app_log.debug(f"Query to be executed:\n{query}")
    start_time = datetime.datetime.now()
    memory_executor_settings = ["2G", "4G", "10G"]
    try:
        async with conn.cursor() as cur:
            for memory in memory_executor_settings:
                try:
                    cur.set_settings({"max_memory_usage": memory})
                    await cur.execute(query)
                    time_taken = datetime.datetime.now() - start_time
                    app_log.info(
                        f"QUERY EXECUTED SUCCESSFULLY\nMEMORY SETTING: {memory}B\nTime taken to run the query: {time_taken}"
                    )
                    break
                except Exception as err:
                    if "memory limit" not in str(err).lower():
                        app_log.error(
                            f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                        )
                        raise RuntimeError(f"Query Execution Failed. Error: {err}")
                    app_log.warning(
                        f"QUERY EXECUTION FAILED\nMEMORY SETTING: {memory}B\nERROR: {err}"
                    )
            if resp_type != "None":
                data = await cur.fetchall()
                col = cur._columns
                if resp_type == "df":
                    data = pd.DataFrame(data, columns=col)
                elif resp_type == "dict":
                    data = list(
                        map(
                            lambda row: dict(itertools.zip_longest(list(col), row)),
                            data,
                        )
                    )
                    if len(data) != 0:
                        data = [
                            {
                                k: " ".join(val.split("\x00")).strip()
                                if isinstance(val, str)
                                else val
                                for k, val in d.items()
                            }
                            for d in data
                        ]
                elif resp_type == "list":
                    data = [record[0] for record in data]
                elif resp_type == "length":
                    data = data
                await app.state.pool.release(conn)
                return data
            await app.state.pool.release(conn)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:%s", str(err))
        raise err


async def insert_data(query, list_data):
    """Insert data from list of tuples or list of dicts.."""
    conn = await app.state.pool.acquire()
    app_log.debug("Inserting data using query:\n%s", query)
    start_time = datetime.datetime.now()
    try:
        async with conn.cursor() as cursor:
            cursor.set_settings({"max_memory_usage": "10G"})
            await cursor.execute(query, list_data)
        time_taken = datetime.datetime.now() - start_time
        app_log.info("Data inserted successfully in %s", time_taken)
    except Exception as err:
        await app.state.pool.release(conn)
        app_log.exception("Query Execution Failed:\n%s", str(err))
        raise err
    await app.state.pool.release(conn)


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add process time in header"""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


# @app.middleware("http")
async def validate_authenticity(request: Request, authorization: HTTPAuthorizationCredentials = Depends(auth_scheme) ):
    """Validate authenticity"""
    if (
        not request.url.path.endswith("/auth")
        and not request.url.path.endswith("/docs")
        and not request.url.path.endswith("/redoc")
        and not request.url.path.endswith("/openapi.json")
        and not (
            request.url.path.find("/auth/") >= 0 and request.method.lower() == "post"
        )
    ):
        jwt_token = authorization.credentials
        try:
            jwt.decode(jwt_token, secret_key, algorithms="HS256")
        except (
                jwt.exceptions.ExpiredSignatureError,
                jwt.exceptions.DecodeError,
                jwt.exceptions.InvalidTokenError,
            ):
                return JSONResponse(
                    status_code=401,
                    content={"message": "Invalid header authorization"},
                )


app.add_middleware(GZipMiddleware, minimum_size=1000)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
