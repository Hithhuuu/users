"""Handler for Chart API's"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.utils.fastapi_app import validate_authenticity
from api.charts.charts_api.wafermapmodel import WaferMap
from api.charts.charts_api.distributionanalysismodel import DistributionAnalysis
from api.charts.charts_api.acycodedistributionmodel import AcyCodeDistribution


router = APIRouter(prefix="/charts", dependencies=[Depends(validate_authenticity)])
charts = WaferMap()
distanalysis = DistributionAnalysis()
acycodedist = AcyCodeDistribution()


@router.post("/wafermap")
async def wafermap(request: Request, body: dict):
    """On POST request get wafermap"""
    body["endpoint"] = request.url.path
    response = await charts.get_wafermap(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/getclasscode")
async def getclasscode(request: Request, body: dict):
    """On POST request get classcodes"""
    body["endpoint"] = request.url.path
    response = await charts.get_classcode(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/waferdetails")
async def waferdetails(request: Request, body: dict):
    """On POST request get classcodes"""
    body["endpoint"] = request.url.path
    response = await charts.get_waferdetails(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/distributionanalysis")
async def distributionanalysis(request: Request, body: dict):
    """On POST request get distribution analysis for accuracymonitor"""
    body["endpoint"] = request.url.path
    response = await distanalysis.post(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/acycodedist")
async def acycodedistribution(request: Request, body: dict):
    """On POST request get accuracy code distiribution"""
    body["endpoint"] = request.url.path
    response = await acycodedist.post(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
