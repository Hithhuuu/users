"""Model for accuracy code distribution in accuracymonitor"""
import datetime

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, get_queries
from api.utils.common import prepare_query

app_log = get_logger("acycodedistribution")

ERROR_MSG = "Accuracy Monitor Code Distribution API Failed"


class AcyCodeDistribution:
    """Model class for accuracy code distribution"""

    def __init__(self):
        """Initializing query variables"""
        queries = get_queries("charts")
        self.queries = queries["accuracymonitor"]

    async def post(self, data):
        """POST call for accuracy code distribution"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            resp = {}
            app_log.info("Preparing the conditions for query..")
            query_data = {}
            dist_std_const = {90: 1.645, 99: 2.575, 100:0.0}
            lots = data.get("userInputs").get("lots", [{}])[0]
            if not lots:
                return {"error": "Empty selection"}
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            query_data["num_run"] = (
                data["facetValues"]["no_run"]
                if int(data["facetValues"]["no_run_option"]) == 1
                else "10000"
            )
            query_data[
                "dist_condition"
            ] = f"((defects.layer = '{lots['layer']}') and (defects.product = '{lots['product']}') \
                and (defects.waferid = '{lots['waferid']}') and \
                (defects.setupid = '{lots['recipieid']}') and (defects.carrierid = '{lots['lotid']}'))"

            query_data["defects_condition"] = (
                query_data["defects_condition"]
                + f" and {query_data['dist_condition']} "
            )

            query_data["header_condition"] = (
                query_data["header_condition"]
                + f" and {query_data['dist_condition'].replace('defects.', 'header.')} "
                + " and src_tool = 'gebi'"
            )

            query_data["runid"] = self.queries["runid"].format(**query_data)
            query_data["population"] = lots.get("population", 0)
            query_data["dist_std_const"] = dist_std_const[query_data["population"]]
            query_data["direction"] = "x"
            query_data["accrcy_code"] = "x"
            query_data["sort_method"] = lots.get("sort", "SORT")
            query_data["metric"] = "fov"
            query_data["accrcy_cnt"] = self.queries["accrcy_cnt"].format(**query_data)
            query_data["accrcy_info"] = self.queries["accrcy_info"].format(**query_data)
            query_to_execute = self.queries["acy_pop"].format(**query_data)
            d_pop_x = await get_query_with_pool(query_to_execute)
            app_log.info("Getting population for the accuracy codes y..")
            query_data["direction"] = "y"
            query_data["accrcy_code"] = "y"
            query_data["accrcy_cnt"] = self.queries["accrcy_cnt"].format(**query_data)
            query_data["accrcy_info"] = self.queries["accrcy_info"].format(**query_data)
            query_to_execute = self.queries["acy_pop"].format(**query_data)
            d_pop_y = await get_query_with_pool(query_to_execute)
            app_log.debug(d_pop_x)
            app_log.debug(d_pop_y)
            resp["acy_pop_x"] = [
                {
                    k: v
                    for k, v in d.items()
                    if k in ["accuracyx", "cnt"] and (v is not None and v != 0.0)
                }
                for d in d_pop_x
            ]
            resp["acy_pop_y"] = [
                {
                    k: v
                    for k, v in d.items()
                    if k in ["accuracyy", "cnt"] and (v is not None and v != 0.0)
                }
                for d in d_pop_y
            ]
            resp["acy_pop_x"] = [] if resp["acy_pop_x"][0] == {} else resp["acy_pop_x"]
            resp["acy_pop_y"] = [] if resp["acy_pop_y"][0] == {} else resp["acy_pop_y"]
            resp["sum_x"] = {
                "acymetric": [
                    {
                        k: v
                        for k, v in d_pop_x[0].items()
                        if k in ["offset", "distribution", "fov"]
                    }
                ]
            }
            resp["sum_y"] = {
                "acymetric": [
                    {
                        k: v
                        for k, v in d_pop_y[0].items()
                        if k in ["offset", "distribution", "fov"]
                    }
                ]
            }

        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"Error": err}
        app_log.info(
            "%s api took %s to complete",
            data["endpoint"],
            str(datetime.datetime.now() - start_time),
        )
        return resp
