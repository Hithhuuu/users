"""Model for distribution analysis"""
import datetime

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, get_queries
from api.utils.common import prepare_query


app_log = get_logger("distributionanalysis")


class DistributionAnalysis:
    """Class for model"""

    def __init__(self):
        """Initializing query variables"""
        queries = get_queries("charts")
        self.queries = queries["accuracymonitor"]

    async def post(self, data):
        """POST method for Distribution Analysis"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            resp = {}
            app_log.info("Preparing the conditions for query..")
            query_data = {}
            query_data["zoom_condition"] = ""
            lots_data = data.get("userInputs").get("lots")
            xsite = data.get("userInputs").get("xsite", {})
            ysite = data.get("userInputs").get("ysite", {})
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)

            query_data["num_run"] = (
                data["facetValues"]["no_run"]
                if int(data["facetValues"]["no_run_option"]) == 1
                else "10000"
            )

            if xsite:
                query_data["zoom_condition"] = (
                    query_data["zoom_condition"]
                    + f" and (xoffset between {xsite['min']} and {xsite['max']}) "
                )
            if ysite:
                query_data["zoom_condition"] = (
                    query_data["zoom_condition"]
                    + f" and (yoffset between {ysite['min']} and {ysite['max']}) "
                )
            if not xsite and not ysite:
                query_data["zoom_condition"] = ""
            query_data["dist_condition"] = [
                f"((defects.layer = '{d['layer']}') and (defects.product = '{d['product']}') \
                and (defects.waferid = '{d['waferid']}') and \
                (defects.setupid = '{d['recipieid']}') and (defects.carrierid = '{d['lotid']}') \
                and (toDate(defects.resulttimestamp) = '{d['resulttimestamp'].split(' ')[0]}'))"
                for d in lots_data
            ]
            query_data[
                "dist_condition"
            ] = f" and ({' or '.join(query_data['dist_condition'])})"

            query_data["header_condition"] = (
                query_data["dist_condition"].replace("defects.", "header.")
                + " and src_tool = 'gebi'"
            )
            query_data["pixels"] = 100
            query_data["runid"] = self.queries["runid"].format(**query_data)
            query_to_execute = self.queries["accrcy_offsets_cnt"].format(**query_data)
            offset_cnt = await get_query_with_pool(query_to_execute)
            offset_cnt = offset_cnt[0].get("cnt", 0)
            if offset_cnt > 25000:
                app_log.info("Fetch offsets stacked for mapids..")
                query_to_execute = self.queries["accrcy_offsets_stack"].format(
                    **query_data
                )
            else:
                app_log.info("Fetch offsets for mapids..")
                query_to_execute = self.queries["accrcy_offsets"].format(**query_data)
            resp = await get_query_with_pool(query_to_execute)

        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"Error": "Accuracy Monitor Distribution Analysis API Failed"}
        app_log.info(
            "%s api took %s to complete",
            data["endpoint"],
            str(datetime.datetime.now() - start_time),
        )
        return resp
