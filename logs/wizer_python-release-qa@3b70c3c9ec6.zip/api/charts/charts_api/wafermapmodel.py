"""Model for Chart API's"""
import datetime

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_logger, get_queries
from api.utils.common import (
    prepare_query,
    resolve_classcode,
    resolve_true_class,
    get_tooltips,
    get_prep_level,
)

app_log = get_logger("wafermap")


class WaferMap:
    """Class for model"""

    def __init__(self):
        """Initializing query variables"""
        queries = get_queries("charts")
        self.queries = queries["wafermap"]

    async def get_waferdetails(self, data):
        """Get the data for the wafer details"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            app_log.info("Preparing response for waferdetails")
            query_data = {}
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            if data["userInputs"].get("tooltipdata", []):
                get_tooltips(query_data, data["userInputs"].get("tooltipdata"))
            elif data.get("tooltipdata", []):
                get_tooltips(query_data, data.get("tooltipdata"))
            else:
                query_data["header_tooltips"] = ""
                query_data["defect_tooltips"] = ""
            query_data["classcode"] = resolve_classcode(data)
            query_to_execute = self.queries["read_waferdetails"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = data_output[0]
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": "WaferDetails API Failed"}
        app_log.info(
            "%s api took %s to complete",
            data["endpoint"],
            str(datetime.datetime.now() - start_time),
        )
        return resp

    async def get_classcode(self, data):
        """Get classcode counts"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            app_log.info("Starting the Process of getting count of the classcode")
            query_data = {}
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            query_data["classcode"] = resolve_classcode(data)
            if data["userInputs"].get("tooltipdata", []):
                get_tooltips(query_data, data["userInputs"].get("tooltipdata"))
            elif data.get("tooltipdata", []):
                get_tooltips(query_data, data.get("tooltipdata"))
            else:
                query_data["header_tooltips"] = ""
                query_data["defect_tooltips"] = ""
            query_to_execute = self.queries["read_classcode"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = {int(v["classcode"]): v["cnt"] for v in data_output}

        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            resp = {"error": "GetClassCode api failed"}
        app_log.info(
            "%s api took %s to complete",
            data["endpoint"],
            str(datetime.datetime.now() - start_time),
        )
        return resp

    async def get_wafermap(self, data):
        """Get the data for wafermaps"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            if data["userInputs"].get("acyFor", "") != "":
                data["facetFilters"]["rangeFilters"].remove('xsite')
                data["facetFilters"]["rangeFilters"].remove('ysite')
            app_log.info("Preparing response for wafermap")
            all_class = data["facetValues"].get("classcode", [])
            query_data = {}
            (
                query_data["defects_condition"],
                query_data["header_condition"],
            ) = prepare_query(data)
            app_log.debug(query_data)
            if data["userInputs"].get("tooltipdata"):
                get_tooltips(query_data, data["userInputs"].get("tooltipdata"))
            else:
                query_data["header_tooltips"] = ""
                query_data["defect_tooltips"] = ""
            query_data["classcode"] = resolve_classcode(data)
            query_data["all_class"] = (
                str(tuple(all_class)) if len(all_class) > 0 else []
            )
            query_data["true_class"] = resolve_true_class(data)
            ## get prep level
            query_data["xsite"] = "xsite"
            query_data["ysite"] = "ysite"
            prep_levels = await get_prep_level(query_data)
            query_data["xsite"] = prep_levels["xsite"]
            query_data["ysite"] = prep_levels["ysite"]
            datecount_query = self.queries["read_defects_count"].format(**query_data)
            output = await get_query_with_pool(datecount_query)
            query_data["datecount"] = output[0]["datecount"] if output else 0
            query_data["read_defects_prep"] = ""
            if query_data["datecount"] > 25000:
                query_data["datecount"] = prep_levels['count']
                query_data["read_defects_prep"] = self.queries[
                    "read_defects_prep"
                ].format(**query_data)
                query_data[
                    "read_defects_prep"
                ] = f" inner join ({query_data['read_defects_prep']}) prep on defects.defectid = prep.defectid and prep.mapid = defects.mapid"
            query_to_execute = self.queries["read_defects"].format(**query_data)
            if data["userInputs"].get("acyFor", "") != "":
                query_to_execute = self.queries["read_defects_acy"].format(**query_data)
            resp = await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": "WaferMap API Failed"}
        app_log.info(
            "%s api took %s to complete",
            data["endpoint"],
            str(datetime.datetime.now() - start_time),
        )
        return resp
