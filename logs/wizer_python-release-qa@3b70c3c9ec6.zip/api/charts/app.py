"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.charts.charts_api import chartshandler


app.include_router(chartshandler.router)
