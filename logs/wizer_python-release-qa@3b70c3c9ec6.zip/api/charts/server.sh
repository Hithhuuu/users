uvicorn api.charts.app:app --port 7550
uvicorn api.charts.app:app --port 7551