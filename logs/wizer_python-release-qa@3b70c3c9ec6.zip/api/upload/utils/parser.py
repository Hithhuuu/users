"""Parses the KLARF files"""
import re
import csv
import json
import pandas as pd
from dateutil.parser import parse
from api.utils.utils import get_logger, get_column_details

app_log = get_logger("parser")


async def parse_v8(lines):
    """Parse V8 KLARF"""
    app_log.info("Remove curly braces")
    lines = [x for x in lines if x not in ("{", "}")]

    field_rec_lines = [
        x for x in lines if x.startswith("Record") or x.startswith("Field")
    ]
    app_log.info("Extracting header dataframe...")
    header_dict = {
        x.split(" ")[1]: x.split(" ")[-1].replace('"', "")
        for x in field_rec_lines
        if x.startswith("Record")
    }
    header_dict.update(
        {
            x.split(" {")[0]
            .split(" ")[1]: x.split(" {")[1]
            .replace("}", "")
            .replace('"', "")
            for x in field_rec_lines
            if x.startswith("Field")
        }
    )
    header_df = pd.DataFrame(
        header_dict.values(), index=[x.lower() for x in list(header_dict.keys())]
    ).T
    header_df = header_df[[x.lower() for x in get_column_details("v8")]]
    header_df[["resulttimestamp", "filetimestamp"]] = header_df[
        ["resulttimestamp", "filetimestamp"]
    ].map(lambda x: x.replace(",", ""))
    header_df[["inspectionstationid"]] = header_df[["inspectionstationid"]].map(
        lambda x: " ".join(x.split(", ")[1:])
    )
    header_df[["diepitch", "samplecenterlocation", "dieorigin"]] = header_df[
        ["diepitch", "samplecenterlocation", "dieorigin"]
    ].map(lambda x: x.replace(", ", ","))
    header_df[
        [
            "recipeid",
            "deviceid",
            "stepid",
            "slotnumber",
            "samplesize",
            "sampleorientationmarktype",
            "orientationmarklocation",
            "sampletype",
        ]
    ] = header_df[
        [
            "recipeid",
            "deviceid",
            "stepid",
            "slotnumber",
            "samplesize",
            "sampleorientationmarktype",
            "orientationmarklocation",
            "sampletype",
        ]
    ].map(
        lambda x: x.split(",")[0]
    )
    app_log.info("Extracting look up lists...")
    lkup_lists = {
        x.lower().split("list ")[1]: lines.index(x)
        for x in lines
        if x.lower().startswith("list")
    }
    data = []
    app_log.info("Extracting class & defect data list dataframe...")
    for key, val in lkup_lists.items():
        temp_dict = {"Key": key}
        col_ind = [
            val + 1 + lines[val + 1 :].index(x)
            for x in lines[val + 1 :]
            if x.lower().startswith("columns")
        ][0]
        data_ind = [
            val + 1 + lines[val + 1 :].index(x)
            for x in lines[val + 1 :]
            if x.lower().startswith("data")
        ][0]

        temp_dict["data_list"] = []

        for line in lines[data_ind + 1 :]:
            if (
                line.lower().find("list") >= 0
                or line.lower().find("field") >= 0
                or line.lower().find("record") >= 0
                or line.lower().find("endof") >= 0
            ):
                break
            if line.lower().find("images") >= 0:
                temp_dict["img_index"] = line.lower().find("images")
                line = line.replace(";", "").replace('""', "NA")
                temp_dict["img_list"] = line[temp_dict["img_index"] :]
                temp_dict["img_list"] = (
                    temp_dict["img_list"]
                    .split("{")[1]
                    .replace("}", "")
                    .replace(" ", "-")
                    .replace('"', "")
                )
                line = line[0 : temp_dict["img_index"]] + temp_dict["img_list"]
            line = (
                line.replace(";", "").replace('""', "NA").replace('"', "")
                if key != "classlookuplist"
                else line.replace(";", "").replace('""', "NA")
            )
            temp_dict["data_list"].append(line)
        if temp_dict["data_list"] == [""]:
            temp_dict["data"] = ()
        else:
            temp_dict["data"] = tuple(
                [
                    row
                    for row in csv.reader(
                        temp_dict["data_list"], delimiter=" ", quotechar='"'
                    )
                ]
            )
            # map(lambda x: x.split(" "), temp_dict["data_list"])
            # )
        temp_dict["col"] = ", ".join(list(lines[col_ind:data_ind]))
        temp_dict["col"] = tuple(
            map(
                lambda x: x.split(" ")[-1].lower().replace(",", ""),
                temp_dict["col"].split("  ")[-1].split(", "),
            )
        )
        temp_df = pd.DataFrame(temp_dict["data"], columns=temp_dict["col"])
        temp_df.reset_index(drop=True, inplace=True)
        temp_dict["df"] = temp_df
        temp_dict.pop("col")
        temp_dict.pop("data")
        temp_dict.pop("data_list")
        data.append(temp_dict)
    class_df = [x.get("df") for x in data if x.get("Key") == "classlookuplist"][0]
    main_df = [x.get("df") for x in data if x.get("Key") == "defectlist"][0]
    return header_df, main_df, class_df


async def parse_v7(lines):
    """Parses V7 KLARF's"""
    app_log.info("Extracting header details...")
    classlkp_columns = ["classnumber", "classname"]
    header = {
        x: lines.index(x)
        for x in lines
        if x.endswith(";") and x.split(" ")[0].isalpha()
    }
    dfct_columns = [x for x in list(header.keys()) if x.startswith("DefectRecord")][0]
    app_log.info("Extracting class dataframe...")
    class_index = [
        lines.index(x)
        for x in lines[1 : header[dfct_columns]]
        if x.lower().find("classlookup") >= 0
    ][0]
    class_end_ind = [
        lines.index(x)
        for x in lines[class_index + 1 : header[dfct_columns]]
        if x.lower().find(";") >= 0
    ][0]
    class_data = lines[class_index + 1 : class_end_ind + 1]

    class_data = [re.findall('([0-9 ]+) (["a-zA-Z0-9 ]+)', x) for x in class_data]
    class_df = pd.DataFrame(
        [t for lst in class_data for t in lst], columns=classlkp_columns
    )
    app_log.info("Extracting defect list dataframe...")
    dfct_end_index = list(header.keys())[list(header.keys()).index(dfct_columns) + 1]
    dfct_data = lines[header[dfct_columns] + 2 : header[dfct_end_index]]

    dfct_data = [
        dfct_data[i]
        + "|"
        + ",".join(
            dfct_data[i + 1 : i + int(dfct_data[i].split(" ")[-1].replace(";", ""))]
        ).replace(" ", "-")
        if len(dfct_data[i].split(" ")) > 2
        and int(dfct_data[i].split(" ")[-1].replace(";", "")) > 0
        else dfct_data[i][:-1]
        if len(dfct_data[i].split(" ")) > 2
        else ""
        for i in range(0, len(dfct_data))
    ]

    dfct_data = [x for x in dfct_data if x != ""]
    dfct_data = tuple(map(lambda x: x.split(" "), dfct_data))
    dfct_columns = tuple(
        re.split("defectrecordspec[0-9 ]+", dfct_columns.lower())[1][:-1].split(" ")
    )
    main_df = pd.DataFrame(dfct_data, columns=dfct_columns)
    app_log.info("Extracting header dataframe...")
    header_list = list(header.keys())
    header_tuple = [
        re.findall('([a-zA-z]+) (["a-zA-Z0-9 _:.@-]+)', x) for x in header_list
    ]
    header_tuple = [t for lst in header_tuple for t in lst]
    header_dict = {x[0]: x[1].replace('"', "").replace(" ", ",") for x in header_tuple}
    header_df = pd.DataFrame(
        header_dict.values(), index=[x.lower() for x in list(header_dict.keys())]
    ).T
    header_df = header_df[[x.lower() for x in get_column_details("v7")]]
    header_df[["fileversion"]] = header_df[["fileversion"]].map(
        lambda x: x.replace(",", ".")
    )
    header_df[["inspectionstationid"]] = header_df[["inspectionstationid"]].map(
        lambda x: " ".join(x.split(",")[1:])
    )
    header_df[["resulttimestamp", "filetimestamp"]] = header_df[
        ["resulttimestamp", "filetimestamp"]
    ].map(lambda x: x.replace(",", " "))
    header_df[["samplesize"]] = header_df[["samplesize"]].map(
        lambda x: str(int(x.split(",")[-1]) * 1000000)
    )
    header_df[["setupid"]] = header_df[["setupid"]].map(lambda x: x.split(",")[-0])
    return header_df, main_df, class_df


async def nm_to_microns(main_df, meta_data):
    """Converts nm to microns"""
    app_log.info("Converting nm to microns.")
    meta_data[["diepitch", "samplecenterlocation"]] = meta_data[
        ["diepitch", "samplecenterlocation"]
    ].map(
        lambda x: ",".join([str(int(float(i) * 1000)) for i in str(x).split(",")])
    )
    change_dict = {"xrel": float, "yrel": float, "dsize": float}
    main_df = main_df.astype(change_dict)
    main_df["xrel"] *= 1000
    main_df["yrel"] *= 1000
    main_df["dsize"] *= 1000
    app_log.info("Converting nm to microns done.")
    return main_df, meta_data


async def parse_klarf(lines):
    """Parse data from the KLARF"""
    app_log.info("Start of KLARF function...")
    lines = list(map(str.strip, lines))
    try:
        if "1.8" in lines[0]:
            app_log.info("Parsing V8 KLARF...")
            header_df, main_df, class_df = await parse_v8(lines)
            app_log.info("Parsing complete.")
        elif "1 7" in lines[0] or "1 1" in lines[0] or "1 2" in lines[0]:
            app_log.info("Parsing V7 KLARF...")
            header_df, main_df, class_df = await parse_v7(lines)
            main_df, header_df = await nm_to_microns(main_df, header_df)
            app_log.info("Parsing complete.")
    except Exception as err:
        app_log.exception(err)
        app_log.error("KLARF Parsing failed")
        header_df, main_df, class_df = pd.DataFrame([])
        return header_df, main_df, class_df
    app_log.info("End of KLARF Parsing.")
    return header_df, main_df, class_df

async def parse_lines(file_content):
    data = {}
    j = 0
    table = []
    for line in file_content:
        line = line.strip().replace('\t\t','\t')
        if line.find(':\t') > 0:
            data[line.split(':\t')[0]] = line.split(':\t')[1].strip()
        elif line.find('Slot\t') >= 0:
            table = (file_content[j+2:])
            table.insert(0,line)
        elif line.find('Started on:')>=0:
            started_on = parse(line.split(": ")[1].strip(), ignoretz=True)
            data[line.split(": ")[0]] = started_on.strftime('%Y-%m-%d %H:%M:%S')
        j = j + 1
    return data, table

async def parser_log(filename):
    """
    This is a caller function for parse_log. This returns the main_df to the data_processing.
    """
    with open(filename, 'r') as f:
        file_content = f.readlines()
    file_content = list(map(str.strip, file_content))
    data, table = await parse_lines(file_content)
    df_data = pd.DataFrame([data])
    df_dict = {}
    columns = table[0].split('\t')
    rows = [row.strip().replace('\t\t','\t').split('\t') for row in table[1:]]
    for row in rows:
        for i in range(0, len(columns)):

            if columns[i] not in df_dict.keys():
                df_dict[columns[i]] = []

            if i >= len(row):
                df_dict[columns[i]].append('')
            else:
                df_dict[columns[i]].append(row[i])

    df = pd.DataFrame(df_dict)
    for col in df_data.columns:
        df[col] = df_data[col][0]
    df.insert(loc=0,column='file_content',value=json.dumps(file_content))
    return df