"""Utils file for data load API"""
import os
import asyncio
import datetime
import math
import numpy as np
import pandas as pd
from pathlib import Path
from api.upload.utils.parser import parser_log
from api.utils.data_processing import get_auth_token
from api.utils.common import node_api_trigger, req_url
from api.utils.utils import (
    alias_info,
    columns_info,
    env_config,
    get_logger,
    get_queries,
    workweek
)

app_log = get_logger("dataload")
DATALOAD_QUERY = get_queries("upload")["dataload"]
UPLOAD_QUERY = get_queries("upload")["upload"]
DEFAULT_BATCH_SIZE = 50000
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFECT_WIP_COLUMN = [
    "diepitch_x",
    "diepitch_y",
    "dieorigin_x",
    "dieorigin_y",
    "scl_x",
    "scl_y",
    "diepitch_x_up",
    "diepitch_y_up",
    "diepitch_x_down",
    "diepitch_y_down",
    "diepitch_x_left",
    "diepitch_y_left",
    "diepitch_x_right",
    "diepitch_y_right",
    "scl_x_up",
    "scl_y_up",
    "scl_x_right",
    "scl_y_right",
    "scl_x_down",
    "scl_y_down",
    "scl_x_left",
    "scl_y_left",
    "orientationmarklocation",
]


class UploadUtils:
    """this class provides methods for upload utils"""

    def __init__(self, toolupload):
        global get_query_with_pool
        global insert_data
        if toolupload:
            from api.utils.tool_app import get_query_with_pool, insert_data
        else:
            from api.utils.fastapi_app import get_query_with_pool, insert_data

    async def verify_mapname(self, header_df, filetype, username, filename):
        """Verify if file is valid"""
        try:
            header_df["resulttimestamp"] = pd.to_datetime(
                header_df["resulttimestamp"])
            header_df["resulttimestamp"] = header_df["resulttimestamp"].dt.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            query_data = {}
            mapelements = map(
                str,
                [
                    username,
                    header_df["product"][0],
                    header_df["layer"][0],
                    header_df["carrierid"][0],
                    header_df["waferid"][0],
                    filename,
                    header_df["resulttimestamp"][0],
                    filetype
                ],
            )
            query_data["filename"] = filename
            query_data["mapname"] = "|".join(mapelements)
            query_data["product"] = header_df.iloc[0]["product"]
            query_data["layer"] = header_df.iloc[0]["layer"]
            query_data["carrierid"] = header_df.iloc[0]["carrierid"]
            query_data["waferid"] = header_df.iloc[0]["waferid"]
            if filetype.upper() in ["ADC", "KLARITY"]:
                output = await self.verify_adcdata(filetype, query_data)
                return {
                    "exists": bool(output["mapid"]),
                    "mapname": query_data["mapname"],
                    "mapid": output["mapid"] if output["mapid"] else "",
                    "klarity_flag": output["klarity_flag"],
                }
            query = DATALOAD_QUERY["mapid"].format(**query_data)
            header_data = await get_query_with_pool(query)
            exists = bool(header_data)
            return {
                "exists": exists,
                "mapname": query_data["mapname"],
                "mapid": header_data[0]["mapid"] if header_data else "",
            }
        except Exception as err:
            data = {"filename": filename}
            data["err_msg"] = f"Error while verifying mapname. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def verify_adcdata(self, filetype, query_data):
        """ADC file validation"""
        try:
            klarity_flag = False
            app_log.info("Check if GEBI record is present in header table..")
            record_exists_query = DATALOAD_QUERY["adc_mapid"].format(
                **query_data)
            mapid = await get_query_with_pool(record_exists_query)
            mapid = mapid[0]["mapid"] if mapid else None
            # check if klarity file is already uploaded for the gebi file
            if filetype.upper() == "ADC" and mapid:
                klarity_query = DATALOAD_QUERY["check_klarity"].format(
                    **query_data)
                uid = await get_query_with_pool(klarity_query)
                if uid:
                    app_log.info("KLARITY file already loaded")
                    klarity_flag = True
            return {"mapid": mapid, "klarity_flag": klarity_flag}
        except Exception as err:
            data = {"filename": query_data["filename"]}
            data["err_msg"] = f"Error while verifying adcdata. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def process_header_df(self, head_df):
        """Process the header dataframe"""
        try:
            head_df.columns = head_df.columns.str.lower()
            head_df[["diepitch_x", "diepitch_y"]] = head_df["diepitch"].str.split(
                ",", expand=True
            )
            head_df[["dieorigin_x", "dieorigin_y"]] = head_df["dieorigin"].str.split(
                ",", expand=True
            )
            head_df[["scl_x", "scl_y"]] = head_df["samplecenterlocation"].str.split(
                ",", expand=True
            )
            head_df = head_df.drop(
                ["diepitch", "dieorigin", "samplecenterlocation"], axis=1
            )
            head_df = head_df.rename(columns=alias_info)
            diff_cols = set(columns_info["header_cols"].keys()).difference(
                head_df.columns)
            for col in diff_cols:
                if columns_info["header_cols"][col] == np.int64:
                    head_df[col] = -999999999
                else:
                    if col != "mapid":
                        head_df[col] = pd.Series(
                            dtype=columns_info["header_cols"][col])
            head_df = head_df.astype(columns_info["header_cols"])
            if not head_df.at[0, "orientationmarklocation"] in [
                "TOP",
                "RIGHT",
                "DOWN",
                "LEFT",
            ]:
                head_df["orientationmarklocation"] = head_df.at[
                    0, "orientationmarklocation"
                ].split(".")[0]
            head_df["orientationmarklocation"] = head_df["orientationmarklocation"].replace(
                columns_info["orientation_data"]
            )
            head_df = await self.add_oriented_col_header(head_df)
            return head_df
        except Exception as err:
            data = {"filename": head_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while processing header df. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def process_main_df(self, main_df, header_df):
        """Process main df"""
        try:
            main_df.columns = [col.lower() for col in main_df.columns]
            main_df = main_df.apply(pd.to_numeric, errors="coerce")
            main_df["product"] = header_df.iloc[0]["product"]
            main_df["layer"] = header_df.iloc[0]["layer"]
            main_df["carrierid"] = header_df.iloc[0]["carrierid"]
            main_df["waferid"] = header_df.iloc[0]["waferid"]
            main_df["platform"] = header_df.iloc[0]["platform"]
            main_df["setupid"] = header_df.iloc[0]["setupid"]
            main_df["resulttimestamp"] = header_df["resulttimestamp"].iloc[0]
            if (
                "alroughbinnumber" not in main_df.columns
                or "roughbinnumber" in main_df.columns
                or (
                    "alroughbinnumber" in main_df.columns
                    and "roughbinnumber" in main_df.columns
                )
            ):
                main_df.rename(
                    columns=columns_info["alias_dict"], inplace=True)
            elif (
                "alroughbinnumber" in main_df.columns
                and "roughbinnumber" not in main_df.columns
            ):
                main_df.rename(
                    columns=columns_info["alias_dict_bin"], inplace=True)
            for i in main_df.columns:
                if i in columns_info["main_cols"].keys():
                    if columns_info["main_cols"][i] in [np.int64, np.float64]:
                        main_df[i] = (
                            main_df[i]

                            .replace([np.nan], [-9999999])
                            .astype(columns_info["main_cols"][i])
                            .replace([-9999999], [None])
                        )
                    else:
                        main_df[i] = main_df[i].astype(
                            columns_info["main_cols"][i])
            return main_df
        except Exception as err:
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while processing main df. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def add_oriented_col_header(self, header_df):
        """Adding oriented columns in header dataframe"""
        try:
            header_df["diepitch_x_up"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_up"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_up"] = np.select(
                [
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_up"] = np.select(
                [
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_down"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_down"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_down"] = np.select(
                [
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_down"] = np.select(
                [
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_left"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_left"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_left"] = np.select(
                [
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_left"] = np.select(
                [
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_right"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_right"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_right"] = np.select(
                [
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )
            header_df["scl_y_right"] = np.select(
                [
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )
            return header_df
        except Exception as err:
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while adding orientation columns. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def dataload(self, main_df, header_df, class_df, unique_data):
        """Load data to clickhouse"""
        start_time = datetime.datetime.now()
        app_log.info("Create an picked entry in JOB log table..")
        await self.insert_job_log(unique_data, status="picked")
        try:
            query_data = {}
            query_data["mapname"] = unique_data["mapname"]
            query_data["product"] = header_df.iloc[0]["product"]
            query_data["layer"] = header_df.iloc[0]["layer"]
            query_data["carrierid"] = header_df.iloc[0]["carrierid"]
            query_data["waferid"] = header_df.iloc[0]["waferid"]
            query_data["src_tool"] = header_df.iloc[0]["src_tool"]
            app_log.info(
                "Marking the older record in header table as 0 before inserting new data.."
            )
            rfgquery = DATALOAD_QUERY["rfgquery"].format(**query_data)
            await get_query_with_pool(rfgquery, resp_type="None")
            app_log.info("Loading the data to clickhouse....")
            main_df = await self.process_main_df(main_df, header_df)
            if unique_data["mapid"] != "" and unique_data["filetype"].lower() in [
                "adc",
                "klarity",
            ]:
                rslttsmp = await get_query_with_pool(
                    DATALOAD_QUERY["rslttsmp_query"].format(**unique_data)
                )
                main_df["resulttimestamp"] = rslttsmp[0]["resulttimestamp"].strftime(
                    DATETIME_FORMAT
                )
            main_df["src_tool"] = unique_data["filetype"]
            main_df[DEFECT_WIP_COLUMN] = header_df[DEFECT_WIP_COLUMN].iloc[0]
            header_df["setupid"] = header_df["recipeid"]
            header_df["ss_flag"] = 0
            header_df["null_cols"] = ",".join(main_df.columns).upper()
            header_df["rfg"] = 1
            header_df.drop(["mapid"], axis=1, inplace=True)
            if unique_data["mapid"] != "":
                app_log.info("Add mapid to header from unique data dict..")
                header_df["mapid"] = unique_data["mapid"]
            header_df["cdt"] = pd.to_datetime(header_df["cdt"])
            header_df["cdt"] = header_df["cdt"].dt.strftime(DATETIME_FORMAT)
            header_df["filetimestamp"] = pd.to_datetime(
                header_df["filetimestamp"])
            header_df["resulttimestamp"] = pd.to_datetime(
                header_df["resulttimestamp"])
            header_df["filetimestamp"] = header_df["filetimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            header_df["resulttimestamp"] = header_df["resulttimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            main_df["resulttimestamp"] = pd.to_datetime(
                main_df["resulttimestamp"])
            main_df["resulttimestamp"] = main_df["resulttimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            await self.push_data(header_df, main_df, class_df)
            app_log.info("Create an successful entry in JOB log table..")
            unique_data["total_cnt"] = len(main_df)
            await self.insert_job_log(unique_data, status="successful")
            await node_api_trigger(header_df,
                                   unique_data['filename'],
                                   unique_data["mapname"],
                                   get_auth_token(),
                                   type=unique_data['upload_type'], unique_data=unique_data
                                   )
        except Exception as err:
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while loading data. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def push_data(self, header_df, main_df, class_df):
        """Push the data to clickhouse"""
        try:
            app_log.info("Inserting header data...")
            header_df = header_df[[x for x in list(
                columns_info['header_cols'].keys()) if x in header_df.columns]]
            cols = ",".join([item.replace("'", "")
                            for item in header_df.columns])
            query_to_execute = f"INSERT INTO wiz.opwi_map_header ({cols}) VALUES "
            await insert_data(
                query_to_execute,
                [tuple(x) for x in header_df.to_records(index=False)]
            )
            query_to_execute = DATALOAD_QUERY["mapid"].format(
                **{"mapname": header_df.loc[0, "mapname"]}
            )
            mapid = await get_query_with_pool(query_to_execute)
            main_df["mapid"] = mapid[0]["mapid"]
            main_df = main_df[[x for x in list(
                columns_info['main_cols'].keys()) if x in main_df.columns]]
            cols = ",".join([item.replace("'", "")
                            for item in main_df.columns])
            query_to_execute = f"INSERT INTO wiz.opwi_defect_main_wip ({cols}) VALUES "
            splits = round(
                1
                if len(main_df) < int(DEFAULT_BATCH_SIZE)
                else len(main_df) / int(DEFAULT_BATCH_SIZE)
            )
            if splits > 1:
                main_df_split = np.array_split(main_df, splits)
            else:
                main_df_split = [main_df]
            # Create a coroutine list where insert data will have the data splits as input
            coros = [
                insert_data(
                    query_to_execute,
                    [tuple(x) for x in i.to_records(index=False)]
                )
                for i in main_df_split
            ]
            # run the tasks to execute inserts parallely
            await asyncio.gather(*coros)
            insert_defect_main_query = DATALOAD_QUERY["insert_defect_main"].format(
                **{"mapid": mapid[0]["mapid"], "src_tool": header_df.loc[0, "src_tool"]}
            )
            await get_query_with_pool(insert_defect_main_query, resp_type="None")
            if not class_df.empty:
                class_df.drop("classcode", axis=1,
                              inplace=True, errors="ignore")
                class_df["mapid"] = mapid[0]["mapid"]
                cols = ",".join([item.replace("'", "")
                                for item in class_df.columns])
                class_df = class_df.drop_duplicates(subset="classnumber")
                class_df["classnumber"] = class_df["classnumber"].astype(int)
                class_df["classname"] = class_df["classname"].fillna(
                    class_df["classnumber"]
                )
                query_to_execute = f"INSERT INTO wiz.opwi_map_class ({cols}) VALUES "
                await insert_data(
                    query_to_execute,
                    [tuple(x) for x in class_df.to_records(index=False)]
                )
                app_log.info("Class data inserted..")
        except Exception as err:
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while inserting data to clickhouse. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def archive_user_file(self, file_path, file_name, file_type):
        """Move the incoming file to archive"""
        base_path = env_config["watchdog_pick_location"]["src"]
        dated_folder = datetime.datetime.now().strftime("%d%b%Y")
        complete_path = os.path.join(
            base_path, "Userload", dated_folder, file_type)
        try:
            Path(complete_path).mkdir(parents=True, exist_ok=True)
            cmd_to_mv = (
                f"""mv -f "{file_path}" "{os.path.join(complete_path, file_name)}" """
            )
            os.system(cmd_to_mv)
        except Exception as err:
            app_log.exception(
                f"Unable to move this file to Archive location. {err}")
        return complete_path

    async def insert_job_log(self, data, status):
        """Insert/Update the job status of file upload"""
        try:

            upload_data = {
                "tool_name": data.get("tool", "NA"),
                "file_name": data.get("filename"),
                "file_path": data.get("abs_path", ""),
                "id": "",
                "id_name": ""
            }
            if status == "created":
                if data.get('id'):
                    upload_data['id'] = f"{data.get('id')},"
                    upload_data['re_try'] = 1
                    upload_data['id_name'] = 'id,'
                query_to_execute = UPLOAD_QUERY["create"].format(**upload_data)
                await get_query_with_pool(query_to_execute, resp_type="None")
            else:
                upload_data["err_message"] = data.get(
                    "err_msg", "").replace("'", '"')
                upload_data['process_start_time'] = 'process_start_time,'
                if status == "picked":
                    upload_data['process_start_time'] = 'now() as process_start_time,'
                query_to_execute = UPLOAD_QUERY["fetch_job_id"].format(
                    **upload_data)
                id_res = await get_query_with_pool(query_to_execute)
                app_log.info(id_res)
                upload_data["id"] = id_res[0]["id"]
                upload_data["job_status"] = status
                upload_data["unique_header_id"] = data.get("mapname", "")
                upload_data["file_cnt"] = data.get("total_cnt", 0)
                upload_data["ch_cnt"] = data.get("total_cnt", 0)
                query_to_execute = UPLOAD_QUERY["update_job_log"].format(
                    **upload_data)
                await get_query_with_pool(query_to_execute, resp_type="None")
        except Exception as err:
            app_log.exception(err)

    async def failure_dataload(self, arch_path, filetype, toolname):
        """load log data to clickhouse """
        try:
            filename = arch_path.split('/')[-1]
            raw_df = await parser_log(arch_path)
            if not (raw_df.columns.__contains__("Product") and raw_df.columns.__contains__("Recipe") and raw_df.columns.__contains__("Layer")):
                return
            final_df = pd.DataFrame()
            csv = pd.read_csv("configs/log_acceptance.csv")
            csv_filetype = {
                "enlight":  "Enlight recipe",
                "sem": "GeBI (SEM) recipe"
            }
            csv_layer = csv[(csv["Product"] == raw_df["Product"][0]) & (csv[csv_filetype[filetype]] == raw_df["Recipe"][0])].to_dict(orient="records")[0]

            if raw_df["Layer"][0].__contains__(csv_layer['Layer']):
                common_cols = {
                    "product": "Product", "lotid": "Lot ID", "slot": "Slot", "layer": "Layer"
                }
                for key, val in common_cols.items():
                    if key == "layer":
                        final_df[key] = csv_layer["Layer"]
                    else:
                        final_df[key] = raw_df[val]
                cols = {
                    "layer": "Layer",
                    "file_json": "file_content",
                    "timestamp": "Started on",
                    "recipe": "Recipe",
                    "start_time": "Start Time",
                    "end_time": "End Time",
                    "defectcnt": "Defect Count"
                }
                for k, v in cols.items():
                    final_df[f"{filetype}_{k}"] = raw_df[v]
                final_df[f"{filetype}_filename"] = filename
                final_df[f"{filetype}_toolname"] = toolname
                final_df['rfg'] = 1
                final_df[f"{filetype}_cdt"] = str(
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                if filetype == "enlight":
                    final_df["workweek"] = str(workweek(raw_df))
                def status_check(val_dict):
                    return "pass" if val_dict.get("Align","").lower() == "succeeded" and (val_dict.get("Scan","").lower() == "succeeded" or val_dict.get("ADR","").lower() == "succeeded") else "fail"
                final_df[f"{filetype}_status"] = raw_df.apply(
                    status_check, axis=1)
                join_query = DATALOAD_QUERY[f"{filetype}_query"].format(**{
                    "layer": final_df["layer"][0],
                    "product": tuple(final_df['product']),
                    "lotid": tuple(final_df['lotid']),
                    "slot": tuple(final_df['slot'])

                })
                final_df.replace(r"", None, inplace=True)
                joining_df = await get_query_with_pool(join_query, resp_type="df")
                final_df.slot = final_df.slot.astype(int)
                if not joining_df.empty:
                    jointype = ['enlight', 'sem']
                    jointype.remove(filetype)
                    for i in ['timestamp', 'cdt']:
                        joining_df[f"{jointype[0]}_{i}"] = pd.to_datetime(
                            joining_df[f"{jointype[0]}_{i}"])
                        joining_df[f"{jointype[0]}_{i}"] = joining_df[f"{jointype[0]}_{i}"].dt.strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                    final_df = pd.merge(final_df, joining_df, how="left", on=["slot", "layer", "product"])
                rfg_query = DATALOAD_QUERY["rfg_query"].format(**{
                    "lotid": final_df["lotid"][0],
                    "product": final_df["product"][0],
                    "layer": tuple(final_df['layer']),
                    "slot": tuple(final_df["slot"])
                })
                for i in [ 'slot', 'rfg','sem_defectcnt', 'enlight_defectcnt']:
                    if i in final_df.columns:
                        final_df[i] = final_df[i].astype(int,errors="ignore")
                await get_query_with_pool(rfg_query, resp_type="None")
                final_cols = ",".join([item.replace("'", "") for item in final_df.columns])
                final_df.replace(r"", None, inplace=True)
                final_df.replace(np.nan, None)
                query_to_execute = f"INSERT INTO wiz.wizer_failuredata ({final_cols}) VALUES "
                list_data = [tuple(x) for x in final_df.to_records(index=False)]
                await insert_data(
                    query_to_execute,
                    list_data
                )
                # ====================================== Failure Monitor ALERT api call start=========================================== #
                try:
                    jwt_token = f"Bearer {get_auth_token()}"
                    fm_node_payload = {
                        "filename": filename,
                        "unique_header_id": "NA",  # /** device, step, lot, wafer */,
                        "stepid": final_df["layer"][0],
                        "deviceid": final_df["product"][0],
                        "lotrecord": final_df["lotid"][0],
                        "enlightrecipie": final_df["enlight_recipe"][0] if filetype=='enlight'  else "",
                        "semrecipie": final_df["sem_recipe"][0] if filetype=='sem' else "",
                        "inspectiontool": final_df["enlight_toolname"][0] if filetype=='enlight' else "",
                        "reviewtool": final_df["sem_toolname"][0] if filetype=='sem' else "",
                        "filetype": filetype,
                        "alerttype": "fmonitoring",
                        "type": "Immediately",
                    }
                    req_head = {
                        "Content-Type": "application/json",
                        "Authorization": f"{jwt_token}",
                    }
                    status, resp = await req_url(url=env_config["fm_alerting_url"], payload=fm_node_payload, headers=req_head)
                    app_log.info(
                        f" fm ALERT API status_code: {status}"
                    )
                    if status != 200:
                        app_log.info("fm Alerting API failed.")
                except Exception as err:
                    app_log.exception(err)
            else:
                app_log.info(
                    f"log file: {filename} upload failed due to mismatch csv combination ")
        except Exception as err:
            app_log.exception(err)
