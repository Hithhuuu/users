"""Model for progress handler"""
import datetime
from api.utils.utils import get_queries, get_logger
from api.utils.fastapi_app import get_query_with_pool

app_log = get_logger("upload_progress")


class ProgressModel:
    """Class for model"""

    def __init__(self):
        """Initializing upload queries"""
        self.queries = get_queries('upload')["upload"]

    async def get_progress_status(self, data):
        """Get proggress of file upload"""
        start_time = datetime.datetime.now()
        try:
            app_log.info("%s API triggered..", data["endpoint"])
            request_data = data['data']
            gebi_file_list = []
            file_type = []
            progress_data = []
            for rec in request_data:
                gebi_file_list.append(rec["filename"])
                file_type.append(rec["type"])

            if len(gebi_file_list) > 0:
                filelist = "', '".join(gebi_file_list)
                q_data = {"filenames": filelist, "file_type": tuple(list(set(file_type)))}
                progress_data = await get_query_with_pool(
                    self.queries["upload_progress"].format(**q_data)
                )
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )

        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
        return progress_data
