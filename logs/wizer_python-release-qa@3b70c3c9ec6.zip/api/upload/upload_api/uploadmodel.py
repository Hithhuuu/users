"""Model for upload"""
import asyncio
from datetime import datetime
from api.upload.utils.parser import parse_klarf
from api.utils.utils import get_logger, get_queries
from api.upload.utils.utils import UploadUtils

app_log = get_logger("upload")


class Upload:
    """Class for model"""

    def __init__(self,toolupload=False):
        """Initialize Upload process."""
        self.queries = get_queries("upload")["upload"]
        self.utils = UploadUtils(toolupload)

    async def post(self, file_data, data):
        """Verify if data already exists or not. If it doesn't then load data to DB."""
        filetype = data["typeoffile"]
        filename = data["filename"]
        app_log.info("Create an entry in JOB log table..")
        # if data.get("endpoint"):
        await self.utils.insert_job_log(data, status="created")
        app_log.info("Extracting data from file..")
        try:
            header_df, main_df, class_df = await parse_klarf(file_data)
        except Exception as err:
            app_log.exception(err)
            return {"error":"Parser Failed "}
        if not header_df.empty and not main_df.empty:
            if "recipeid" in header_df.columns:
                header_df["setupid"] = header_df["recipeid"]
            header_df["defectcnt"] = main_df.shape[0]
            header_df["filename"] = filename
            header_df["filesize"] = data["filesize"]
            header_df["src_tool"] = filetype
            header_df["cby"] = data["username"]
            header_df["tifffilename"] = "NA"  # Change this accordingly.
            header_df["cdt"] = str(datetime.now())
            header_df["tool"] =  data.get("tool","NA") 
            header_df = await self.utils.process_header_df(header_df)
            unique_data = await self.utils.verify_mapname(
                header_df, filetype, data["username"], filename
            )
            header_df["mapname"] = unique_data["mapname"]
            if not unique_data["exists"] and filetype.upper() in ["ADC", "KLARITY"]:
                app_log.info(
                    "Did not find any record in the Header table for given ADC/KLARITY file"
                )
                app_log.info("Create an invalid entry in JOB log table..")
                data[
                    "err_msg"
                ] = "Did not find any record in the Header table for given ADC/KLARITY file"
                await self.utils.insert_job_log(data, status="invalid")
                return {
                    "error": "Did not find any record in the Header table for given ADC file"
                }
            if (
                unique_data["exists"]
                and filetype.upper() in ["ADC"]
                and unique_data["klarity_flag"]
            ):
                app_log.info("KLARITY file already exists")
                app_log.info("Create an invalid entry in JOB log table..")
                data["err_msg"] = "KLARITY file already exists"
                await self.utils.insert_job_log(data, status="invalid")
                return {"error": "Klarity file exists"}
            try:
                unique_data["filetype"] = filetype
                unique_data["filename"] = filename
                unique_data['upload_type'] = True
                unique_data['tool'] = data.get("tool","NA")
                if data.get("endpoint"):
                    complete_path = await self.utils.archive_user_file(
                        data["abs_path"], filename, filetype
                    )
                    unique_data["archive_path"] = complete_path
                    unique_data['upload_type'] = False
                loop = asyncio.get_running_loop()
                loop.create_task(
                    self.utils.dataload(main_df, header_df, class_df, unique_data)
                )

                                
                resp_json = {"status": "upload started"}

            except Exception as err:
                resp_json = {"upload": "failed", "error": str(err)}
                if resp_json["error"] == "Klarf file is missing":
                    resp_json["klarf"] = False
                app_log.info("Create an failure entry in JOB log table..")
                data["err_msg"] = err
                await self.utils.insert_job_log(data, status="failure")
                return resp_json
            return resp_json
        app_log.error("Header or Main dataframe is empty")
        app_log.info("Create an invalid entry in JOB log table..")
        data["err_msg"] = "File is empty."
        await self.utils.insert_job_log(data, status="invalid")
        return {"error": "Header or Main dataframe is empty"}
