"""Handler for upload"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, File, Form, Depends
from api.utils.fastapi_app import get_query_with_pool, validate_authenticity
from api.utils.utils import get_logger, env_config
from api.upload.upload_api.progressmodel import ProgressModel
from api.upload.upload_api.uploadmodel import Upload

app_log = get_logger("upload")

router = APIRouter(prefix="/upload", dependencies=[Depends(validate_authenticity)])


@router.post("")
async def post(
    request: Request,
    # file: bytes = File(),
    # userid: str = Form(),
    # filename: str = Form(),
    # type: str = Form(),
    # filesize: str = Form()
):
    """On POST request upload a file"""
    data = dict(await request.form())
    file =  data.get("file").file.read()
    data["username"] = data['userid']
    data["typeoffile"] = data['type']
    data["endpoint"] = request.url.path
    data["abs_path"] = f"{env_config['directories']['upload_folder_name']}/{data['filename']}"
    uploadmodel = Upload()
    resp_json = await uploadmodel.post(file.decode("utf-8").splitlines(), data)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()):
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)


@router.post("/progress")
async def progress(request: Request ):
    """On POST request get progress of file upload"""
    data = {}
    data["data"] = await request.json()
    data["endpoint"] = request.url.path
    progressmodel = ProgressModel()
    resp = await progressmodel.get_progress_status(data)
    if isinstance(resp, dict) and "error" in list(resp.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": resp.get("error")},
        )
    return JSONResponse(resp)


@router.post("/status")
async def status(request: Request):
    """On POST request get status of file upload"""
    files = []
    resp = []
    body  =  await request.json()
    for rec in body:
        files.append(rec["filename"])
    if len(files) <= 0:
        return JSONResponse(
            status_code=400,
            content={"message": "No Files selected"},
        )
    filelist = "', '".join(files)
    query = f"select id, file_name as task_id, job_status as status, cast(process_start_time as String) process_start_time, cast(process_end_time as String) date_done, err_message as traceback from opwi_job_log final where file_name in  ('{filelist}')"
    resp = await get_query_with_pool(query)
    return JSONResponse(resp)
