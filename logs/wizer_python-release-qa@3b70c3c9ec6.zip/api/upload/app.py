"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.upload.upload_api import uploadhandler


app.include_router(uploadhandler.router)
