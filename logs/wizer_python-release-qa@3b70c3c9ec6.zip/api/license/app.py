"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.license.license_api import licensehandler


app.include_router(licensehandler.router)
