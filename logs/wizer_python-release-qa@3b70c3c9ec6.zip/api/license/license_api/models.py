"""Model for validating license"""
import subprocess
import copy
import re
from api.utils.utils import get_logger, queries
from api.utils.utils import decrypt, get_env_config
from api.utils.fastapi_app import get_query_with_pool


app_log = get_logger("license")


class License:
    """Class for model"""

    def __init__(self):
        self.config = queries["license"]
        self.secret_key = self.config["constants"]["secret_key"]
        self.env_config = get_env_config()
        self.contants = self.config["constants"]

    async def get_tool_data(self):
        """Get the tool data"""
        tool_query = self.config["query"]["tool_key_query"]
        tool_data = await get_query_with_pool(tool_query)

        tool_data_str = decrypt(
            tool_data[0]["toolskey"][0], bytes(self.secret_key, "utf-8")
        ).decode("utf-8")
        tool_list = tool_data_str.split("|")
        tool_data = {i.split(":")[0]: i.split(":")[1] for i in tool_list}
        return tool_data

    async def validate_tools(self, data):
        """Validate the tools"""
        constants = self.contants
        resp = {}
        try:
            tool_data = await self.get_tool_data()
            for tool in data:
                tool_script_data = {}
                tool_script_data["toolname"] = tool_data.get(tool)
                tool_script_data["path"] = self.env_config["licence"]["path"].rstrip()
                tool_script_data["filename"] = self.env_config["licence"][
                    "sh_file"
                ].rstrip()
                cmd = self.config["license"]["cmd"].format(**tool_script_data)
                app_log.info("Command Execution starting")
                subprocess_data = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True
                )
                processed_data = copy.deepcopy(subprocess_data.stdout.readlines())
                status_info = []
                time_to_renew = ""
                is_valid = False
                for line in processed_data:
                    line = str(line, "utf-8")
                    if (
                        re.match(self.contants["pattern_1"], line)
                        and re.match(self.contants["pattern_2"], line)
                        and constants["GetFeatureInfoEx"] not in line
                    ):
                        status_info.append(line)
                    if (constants["PROMOTO_LICENSE"] in line) and (
                        constants["DAYS"] in line
                    ):
                        time_to_renew = f"{line.split(':')[2].split(' ')[1]} {constants['DAYS_LEFT_TO_RENEW']}"
                        app_log.info(
                            "Validity left for " + tool + " is " + time_to_renew
                        )
                cnt = 0
                if len(status_info) > 0:
                    for status in status_info:
                        status = status.lower()
                        if (
                            "ok" not in status
                            and "true" not in status
                            and "yes" not in status
                        ):
                            is_valid = False
                            break
                        if (
                            "isfeatureexpired status" in status
                            or "featuresgettimetoexpiration status" in status
                            or "featuresclose" in status
                        ):
                            cnt += 1
                        if "not expired yet" in status:
                            cnt += 1
                    if cnt >= 4:
                        is_valid = True
                resp.update({tool: is_valid})
        except Exception as err:
            is_valid = False
            app_log.exception(err)
            err_message = str(err).replace("'", "").replace('"', "")
            resp = {tool: is_valid, "err_message": err_message}
        return resp
