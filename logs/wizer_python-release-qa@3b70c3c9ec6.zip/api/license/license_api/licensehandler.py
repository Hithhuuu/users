"""Validate license for WIZER tools"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter
from api.license.license_api.models import License

license_obj = License()

router = APIRouter(prefix="/license")


@router.post("/validatetools")
async def post(request: Request, body: dict):
    """On POST request validate license"""
    body["endpoint"] = request.url.path
    response = await license_obj.validate_tools(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
