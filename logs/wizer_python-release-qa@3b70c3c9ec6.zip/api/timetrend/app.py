"""Application file for FAST API"""
from api.utils.fastapi_app import app
from api.timetrend.timetrend_api import timetrendhandler


app.include_router(timetrendhandler.router)
