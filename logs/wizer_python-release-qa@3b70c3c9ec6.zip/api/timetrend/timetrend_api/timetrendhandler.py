"""Handler for Time Trend API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, Depends
from api.utils.fastapi_app import validate_authenticity
from api.timetrend.timetrend_api.timetrendmodel import TimeTrend

router = APIRouter(prefix="/timetrend")
timetrend = TimeTrend()


@router.post("/kpi/gebitruedefect", dependencies=[Depends(validate_authenticity)])
@router.post("/kpi/rankpurity", dependencies=[Depends(validate_authenticity)])
@router.post("/kpi/binpurity123", dependencies=[Depends(validate_authenticity)])
@router.post("/kpi/reviewcount", dependencies=[Depends(validate_authenticity)])
@router.post("/kpi/rankpurity6", dependencies=[Depends(validate_authenticity)])
async def kpi(request: Request, body: dict):
    """On POST request return KPI time trend as JSON"""
    body["chartType"] = request.url.path.split("/")[-1]
    body["endpoint"] = request.url.path
    response = await timetrend.kpi(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/binclass", dependencies=[Depends(validate_authenticity)])
async def binclass(request: Request, body: dict):
    """On POST request return Bin class as JSON"""
    body["chartType"] = request.url.path.split("/")[-1]
    body["endpoint"] = request.url.path
    response = await timetrend.binclass(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/binrankcount", dependencies=[Depends(validate_authenticity)])
@router.post("/binrankcount/bin123", dependencies=[Depends(validate_authenticity)])
async def binrankcount(request: Request, body: dict):
    """On POST request return binrankcount time trend as JSON"""
    body["endpoint"] = request.url.path
    response = await timetrend.binrankcount(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/adcmonitor", dependencies=[Depends(validate_authenticity)])
@router.post("/adcmonitor/pareto", dependencies=[Depends(validate_authenticity)])
async def adcmonitor(request: Request, body: dict):
    """On POST request return ADC monitor time trend as JSON"""
    body["chartType"] = request.url.path.split("/")[-1]
    body["endpoint"] = request.url.path
    response = await timetrend.adcmonitor(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/accuracymonitor", dependencies=[Depends(validate_authenticity)])
async def accuracymonitor(request: Request, body: dict):
    """On POST request return accuracy monitor time trend as JSON"""
    body["endpoint"] = request.url.path
    response = await timetrend.accuracymonitor(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("/kpialert", dependencies=[Depends(validate_authenticity)])
async def kpialert(request: Request, body: dict):
    """On POST request return kpilaert time trend as JSON"""
    response = await timetrend.kpialert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)
