"""Model for Time Trend API"""
import datetime
import collections

from api.utils.fastapi_app import get_query_with_pool
from api.utils.utils import get_queries, get_logger, common_query
from api.utils.common import prepare_query_data, prepare_adc_data, get_tooltips


app_log = get_logger("timetrend")


class TimeTrend:
    """This class provides methods to get time trends"""

    def __init__(self):
        """Initializing time trend queries"""
        queries = get_queries("timetrend")
        self.common_queries = common_query
        self.queries_kpi = queries["kpi"]
        self.queries_binrankcount = queries["binrankcount"]
        self.queries_adcmonitor = queries["adcmonitor"]
        self.queries_accuracymonitor = queries["accuracymonitor"]


    async def kpi(self, data):
        """Get KPI time trends"""
        start_time = datetime.datetime.now()
        try:
            if not data["facetValues"].get("classcode", []):
                app_log.error("Classcodes are empty..")
                return []
            resp_all_keys = {
                "header": [
                    "datecount",
                    "deviceid",
                    "highdefectcount",
                    "inspectionstationid",
                    "lotrecord",
                    "recipeid",
                    "stepid",
                    "truedoicount",
                    "waferrecord",
                    "xaxis",
                ],
                "binpurity123": ["bin1", "bin3", "bin4", "bin5"],
                "rankpurity": ["rank1", "rank2", "rank3", "rank4", "rank5"],
                "rankpurity6": ["rank6"],
                "gebitruedefect": ["gebi_true_defect"],
                "reviewcount": ["review_count"],
            }
            query_data = prepare_query_data(data)
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data[
                "runid_query"
            ] = f",{self.common_queries['runid_query'].format(**query_data)}"
            query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            query_to_execute = self.queries_kpi["kpi"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp_keys = sum(
                [
                    v
                    for k, v in resp_all_keys.items()
                    if k in ["header", data["chartType"]]
                ],
                [],
            )
            resp = [{k: d[k] for k in resp_keys} for d in data_output]
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            resp = sorted(resp, key=lambda d: d["xaxis"])
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def binrankcount(self, data):
        """Get bin rank count time trends"""
        start_time = datetime.datetime.now()
        try:
            all_class = data["facetValues"].get("classcode", [])
            if data["endpoint"].find("bin123") >= 0:
                data["userInputs"]["chartType"] = "bin123"
            if not all_class:
                return []
            query_data = prepare_query_data(data)
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data["runid_query"] = ""
            query_data["runid_condition"] = ""
            isdate = True
            query_data["xaxis"] = "toString(defects.resulttimestamp)"
            query_data["yaxis"] = data["userInputs"].get("yAxis", "count")
            if data["userInputs"].get("xAxis", "run") == "run":
                isdate = False
                query_data[
                    "runid_query"
                ] = f",{self.common_queries['runid_query'].format(**query_data)}"
                query_data["xaxis"] = "header.runid"
                query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            query_to_execute = self.queries_binrankcount[
                data["userInputs"].get("chartType")
            ].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            if data["userInputs"].get("chartType") == "bin123":
                resp = {}
                for data_dict in data_output:
                    if data_dict["runid"] not in resp:
                        resp[data_dict["runid"]] = {
                            data_dict["roughbinnumber"]: {
                                data_dict["doi_rank"]: data_dict["cnt"]
                            }
                        }
                    else:
                        if data_dict["roughbinnumber"] not in resp[data_dict["runid"]]:
                            resp[data_dict["runid"]].update(
                                {
                                    data_dict["roughbinnumber"]: {
                                        data_dict["doi_rank"]: data_dict["cnt"]
                                    }
                                }
                            )
                        else:
                            resp[data_dict["runid"]][
                                data_dict["roughbinnumber"]
                            ].update({data_dict["doi_rank"]: data_dict["cnt"]})
                return {
                    k: {
                        k2: {k3: resp[k][k2][k3] for k3 in sorted(resp[k][k2])}
                        for k2 in sorted(resp[k])
                    }
                    for k in sorted(resp)
                }
            data_formatted = [
                {
                    k: int(v)
                    if isinstance(v, float)
                    and data["userInputs"].get("yAxis") == "count"
                    else v
                    for k, v in d.items()
                }
                for d in data_output
            ]
            resp = sorted(data_formatted, key=lambda d: d["xaxis"], reverse=isdate)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def adcmonitor(self, data):
        """Get adc monitor time trends"""
        start_time = datetime.datetime.now()
        app_log.info("%s triggered...", data["endpoint"])
        try:
            query_data = prepare_query_data(data)
            prepare_adc_data(query_data, data)
            get_tooltips(query_data, data["userInputs"].get("tooltipdata", {}))
            query_data["true_classes"] = [
                i
                for i in query_data["hunterclass"]
                if i in query_data["true_class"].strip(")").strip("(").split(",")
            ]
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data[
                "runid_query"
            ] = f",{self.common_queries['runid_query'].format(**query_data)}"
            query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            resp = {}
            if data["chartType"] == "adcmonitor":
                query_to_execute = self.queries_adcmonitor["adcmonitor"].format(
                    **query_data
                )
                data_output = await get_query_with_pool(query_to_execute)
                resp["chart"] = data_output
                query_to_execute = self.queries_adcmonitor["classifcation"].format(
                    **query_data
                )
                data_output = await get_query_with_pool(query_to_execute)
                resp["classifcation"] = data_output
            else:
                query_to_execute = self.queries_adcmonitor["pareto"].format(
                    **query_data
                )
                data_output = await get_query_with_pool(query_to_execute)
                if data_output:
                    resp = data_output[0]
                    class_list = ["ADC", "MDC", "ADCHC"]
                    resp["classification"] = {
                        classcode: dict(
                            collections.Counter(data_output[0].get(classcode, []))
                        )
                        for classcode in class_list
                    }
                    for key in class_list:
                        resp.pop(key)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def accuracymonitor(self, data):
        """Get accuracymonitor time trends"""
        start_time = datetime.datetime.now()
        try:
            resp = {"code": [], "acymetric": []}
            dist_std_const = {90: 1.645, 99: 2.575, 100: 0.0}
            app_log.info("Preparing the conditions for query..")
            user_inputs = data["userInputs"]
            query_data = prepare_query_data(data)
            query_data["population"] = data.get("userInputs").get("population")
            query_data["dist_std_const"] = dist_std_const[query_data["population"]]
            query_data["direction"] = data.get("userInputs").get("direction")
            query_data["accrcy_code"] = data.get("userInputs").get("accuracycode")
            query_data["metric"] = data.get("userInputs").get("metric")
            query_data["sort_method"] = data.get("userInputs").get("sort")

            if not query_data["num_run"]:
                query_data["num_run"] = data.get("userInputs").get("rows")
            elif int(data["facetValues"]["no_run_option"]) == 0 and not user_inputs.get(
                "fetchAll", True
            ):
                query_data["num_run"] = "200"
            query_data["runid"] = self.queries_accuracymonitor["runid"].format(
                **query_data
            )
            query_data["accrcy_cnt"] = self.queries_accuracymonitor[
                "accrcy_cnt"
            ].format(**query_data)
            query_to_execute = self.queries_accuracymonitor["accrcy_info"].format(
                **query_data
            )
            output = await get_query_with_pool(query_to_execute)
            resp["acymetric"] = [
                {
                    "runid": d["runid"],
                    "mapid": d["mapid"],
                    "resulttimestamp": d["resulttimestamp"],
                    "lotid": d["lotid"],
                    "layer": d["layer"],
                    "product": d["product"],
                    "waferid": d["waferid"],
                    "recipieid": d["recipieid"],
                    "inspectionstationid": d["inspectionstationid"],
                    "toolid": d["toolid"],
                    "y": d[query_data["metric"]],
                }
                for d in output
            ]
            resp["code"] = [
                {
                    "runid": d["runid"],
                    "mapid": d["mapid"],
                    "resulttimestamp": d["resulttimestamp"],
                    "lotid": d["lotid"],
                    "layer": d["layer"],
                    "product": d["product"],
                    "waferid": d["waferid"],
                    "recipieid": d["recipieid"],
                    "inspectionstationid": d["inspectionstationid"],
                    "toolid": d["toolid"],
                    "y": d["acy_code"],
                }
                for d in output
            ]

            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp

    async def kpialert(self, data):
        """get kpi values for alert"""
        try:
            query_data = prepare_query_data(data)
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data[
                "runid_query"
            ] = f",{self.common_queries['runid_query'].format(**query_data)}"
            query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            query_to_execute = self.queries_kpi["kpi_alert_api"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            resp = {"data": data_output}
        except Exception as err:
            app_log.exception(err)
            return {"error": "KPI Alert API Failed"}
        return resp

    async def binclass(self, data):
        """Get Bin class"""
        start_time = datetime.datetime.now()
        try:

            query_data = prepare_query_data(data)
            query_data["mapid_condition"] = self.common_queries[
                "mapid_condition"
            ].format(**query_data)
            query_data["defect_count_query"] = self.common_queries[
                "defect_count_query"
            ].format(**query_data)
            query_data[
                "runid_query"
            ] = f",{self.common_queries['runid_query'].format(**query_data)}"
            query_data["runid_condition"] = "AND header.mapid = defects.mapid"
            if data["userInputs"].get("tooltipdata", []):
                get_tooltips(query_data, data["userInputs"].get("tooltipdata"))
            elif data.get("tooltipdata", []):
                get_tooltips(query_data, data.get("tooltipdata"))
            else:
                query_data["header_tooltips"] = ""
                query_data["defect_tooltips"] = ""
            query_to_execute = self.queries_kpi["binclass"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output
