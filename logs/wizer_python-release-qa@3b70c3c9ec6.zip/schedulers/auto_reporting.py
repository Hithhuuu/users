
# title                 : autoReporting.py
# description           : main async process for execution.
# date                  : 20-Aug-2021
# version               : 2.0
# usage                 : python3 autoReporting.py
################################################################################################################
import os
import sys
import json
import time
import traceback
import requests
import itertools
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import  get_logger, get_config, env_config
from api.utils.fastapi_app import get_query_with_pool
from api.utils.common import req_url


# Read configuration file and parse environmental variables
config = get_config()

"""Defining an object for Celery tasks"""

# Set up logger with coloring and time-rotating logging
logger = get_logger('auto_report_scheduler')


# On-Demand Execution
async def on_demand_execution_status(body):
    """Handles Auto report API request."""
    autoReportIds = body['autoReportIds'][0]
    logger.info(f"Called: On-Demand WIZER Status API on url -- {env_config['autoreport_hist_rest_url']}")

    try:
        payload = {"username": f"{body['username']}", "autoreportid": body['autoReportIds'],
                    "autoreportidtimestamp": body['autoreportidtimestamp']}
        headers = {"Content-Type": "application/json", "Authorization": f"{body['auth_token']}"}
        print(payload)
        request_status, resp =await req_url(env_config['autoreport_hist_rest_url'],payload,headers,True)
        if request_status == 200:
            resp_json = resp
            if len(resp_json) > 0:
                if resp_json[0]['status'] == 'Success' or resp_json[0]['status'] == 'Failed':
                    logger.info(
                        f'On-Demand: WIZER API execution in progress: {autoReportIds}')
                    return True, resp_json
                else:
                    logger.info(f'On-Demand: WIZER API Execution is in progress...')
                    return False, resp_json

            return False, resp_json

    except Exception as e:
        logger.error(traceback.format_exc())
        logger.error(f'{autoReportIds[0]}: {repr(e)}')
        raise RuntimeError(str("On-Demand: AutoReport API request Failed"))


async def on_demand_execution(body):
    """Handles Auto report API request."""
    logger.info("***************** Auto report On-Demand *****************")
    logger.info(body)
    try:
        payload = {
            "autoReportIds": body['autoReportIds'],
            "autoreportidtimestamp": body['autoreportidtimestamp'],
            "invokedFrom": f"{body['invokedFrom']}",
            "username": f"{body['username']}"
        }
        payload['autoReportIds'] =await validate_autoreport(payload['autoReportIds'])
        if not payload['autoReportIds']:
            logger.info(f"on demand execution not is executed with no template")
            return

        logger.info(f"On-Demand: Payload : {json.dumps(payload)}")

        headers = {"Content-Type": "application/json", "Authorization": f'{body["auth_token"]}'}
        report_resp, resp  = await req_url(env_config['autoreport_rest_url'],payload, headers)

        print("<<<"*50)
        for i in range(0, 910, 5):
            logger.info(f"On-Demand: WIZER Status API wait time to get Response: {i} sec")
            status, resp_data = await on_demand_execution_status(body)
            logger.info(f"On-Demand: WIZER Status API response: {status}, response_data: {resp_data}")

            if status ==200:
                logger.info(f"On-Demand: Auto Report execution completed for username {resp_data[0]['username']}, "
                            f"reportname : {resp_data[0]['reportname']}")
                logger.info("*" * 100)
                break

            if (i > 900) and (status!=200):
                logger.info(f'On-Demand: Auto execution failed for : {resp_data}, Timeout Reached')
                raise TimeoutError('On-Demand: Auto execution failed, Timeout Reached.')

            time.sleep(5)

    except Exception as e:
        logger.error(f"{body['autoReportIds']}: {repr(e)}")
        raise RuntimeError(str("On-Demand: AutoReport API request Failed"))


# Scheduler

async def scheduler_auto_report_task_status(body):
    """Handles Auto report API request."""
    autoReportIds = body['autoreportid']
    logger.info("Call: Scheduler Auto Report WIZER Status API")
    resp_json = ""

    try:
        payload = {"username": f"{body['username']}", "autoreportid": [body['autoreportid']],
                    "autoreportidtimestamp": [body['autoreportidtimestamp']], "reportlimit": "3"}
        headers = {"Content-Type": "application/json", "Authorization": f"{body['auth_token']}"}

        logger.info(f"Scheduler: WIZER Status API payload information : {payload}")
        status , resp = await req_url(env_config['autoreport_hist_rest_url'], payload,headers,True)
        logger.info(f'Scheduler: WIZER Status API status code: {status},')

        if status == 200:
            logger.info(f"Scheduler: WIZER Status API Json Resp: {resp}")
            resp_json = resp

            if len(resp_json) > 0:
                if resp_json[0]['status'] == 'Success' or resp_json[0]['status'] == 'Failed':
                    logger.info(
                        f'Scheduler: WIZER Status API execution in progress for : {autoReportIds}')
                    return True, resp_json
                else:
                    logger.info(f'Scheduler: WIZER Status API Execution is in progress...')
                    return False, resp_json

            return False, resp_json

    except Exception as e:
        logger.error(f'{autoReportIds}: {repr(e)}')
        raise ChildProcessError(str("Scheduler: WIZER Status API request Failed"))


async def scheduler_auto_report_task( body):
    try:
        if body['invokefrom'] == "by_script":
            logger.info("***************** Auto report Scheduler *****************")
            payload = {
                "autoReportIds": [body['autoreportid']],
                "autoreportidtimestamp": [body['autoreportidtimestamp']],
                "invokedFrom": f"{body['invokefrom']}",
                "username": f"{body['username']}"}
            if not payload['autoReportIds']:
                logger.info(f"NO template to execute scheduler")
                return

            logger.info(f"Payload for autoreport_rest_url: {payload}")
            headers = {'Content-Type': 'application/json', 'Authorization': f'{body["auth_token"]}'}
            status, resp =  await req_url(env_config['autoreport_rest_url'],payload,headers)

            if status != 200:
                logger.error(f"Scheduler: AutoReport API request Failed with Status: {status}")
                raise RuntimeError(f'Scheduler: AutoReport API request Failed with status {status}')

            for i in range(0, 910, 5):
                logger.info(f"Scheduler: WIZER Status API wait time to get Response: {i} sec")
                status, resp_data = await scheduler_auto_report_task_status(body)
                logger.info(f"Scheduler: WIZER Status API status: {status}, response_data: {resp_data}")

                if status == 200:
                    logger.info(f"Scheduler: Auto Report execution completed for username "
                                f"{resp_data[0]['username']}, reportname : {resp_data[0]['reportname']}")
                    logger.info("*" * 100)
                    break

                if (i > 900) and (status!=200):
                    logger.error(f'Scheduler: Auto report execution failed for: {resp_data}, Timeout Reached')
                    raise TimeoutError('Scheduler: Auto report execution failed, Timeout Reached.')

                time.sleep(5)

    except Exception as e:
        logger.error(f"{body['autoreportid']}: {repr(e)}")
        raise RuntimeError(str("Scheduler: AutoReport API request Failed"))


# Autoreport Alert
async def alerting_auto_report_task_status(body):
    """Handles Auto report API request."""
    autoReportIds = body['autoreportid']
    logger.info("Alerting: WIZER Status API call")

    try:
        payload = [{"autoreportid": body['autoreportid'], "autoreportidtimestamp": body['autoreportidtimestamp']}]
        headers = {"Content-Type": "application/json", "Authorization": f"{body['auth_token']}"}

        logger.info(f"Alerting: WIZER Status API payload: {payload}")
        status , resp = await req_url(env_config['autoreport_hist_rest_url'],payload,headers,True)
        logger.info(f'Alerting: WIZER Status API status code: {status}, ')

        if status == 200:
            logger.info(f"Alerting: Auto Report Status API Json Resp: {resp}")
            resp_json = resp

            if len(resp_json) > 0:
                if resp_json[0]['status'] == 'Success' or resp_json[0]['status'] == 'Failed':
                    logger.info(f'Alerting: execution in progress for : {autoReportIds}')
                    return True, resp_json
                else:
                    logger.info(f'Alerting: Execution is in progress...')
                    return False, resp_json

            return False, resp_json

    except Exception as e:
        logger.error(f'{autoReportIds}: {repr(e)}')
        raise RuntimeError(str("Alerting: AutoReport API request Failed"))


async def alerting_auto_report_task( body):

    try:
        logger.info("***************** Auto report Alerting Execution *****************")
        payload = {"autoReportIds": [body['autoreportid']], "autoreportidtimestamp": [body['autoreportidtimestamp']],
                   "invokedFrom": f"{body['invokefrom']}", "username": f"{body['username']}",
                   "filename": f"{body['filename']}"}

        payload['autoReportIds'] = await validate_autoreport(payload['autoReportIds'])
        if not payload['autoReportIds']:
            logger.info(f"NO template to execute alerting autoreport")
            return
        headers = {'Content-Type': 'application/json', 'Authorization': f'{body["auth_token"]}'}
        status , resp = await req_url(env_config['autoreport_rest_url'],payload,headers,True)
        logger.info(f'Alerting: Payload: {payload}')
        logger.info(f'Alerting: AutoReport API status code: {status}, ')

        if status != 200:
            logger.error(f'Alerting: AutoReport API request Failed with status: {status}')
            raise RuntimeError(f'Alerting: AutoReport API request Failed with status: {status}')

        for i in range(0, 910, 5):
            logger.info(f"Alerting: WIZER Status API wait time to get Response: {i} sec")
            status, resp_data = await alerting_auto_report_task_status(body)
            logger.info(f"Alerting: WIZER Status API status: {status}, response_data: {resp_data}")

            if status==200:
                logger.info(f"Alerting: Auto Report task execution completed "
                            f"for report name : {resp_data[0]['reportname']}")
                logger.info("*"*100)
                break

            if (i > 900) and (status!=200):
                logger.error(f'Alerting: Auto report execution failed for : {resp_data}, Timeout Reached')
                raise TimeoutError('Alerting: Auto report execution failed, Timeout Reached.')

            time.sleep(5)

    except Exception as e:
        logger.error(f"{body['autoreportid']}: {repr(e)}")
        raise RuntimeError(f"Alerting: AutoReport API request Failed: {repr(e)}")

async def validate_autoreport(data):
    resp = []
    reportids = [ int(i) for i in data ] if isinstance(data,list) else data
    query_to_execute  = f"select id from wiz.wizer_autoreport final where id in {reportids} and reportstatus in ('\"on\"')"
    data_output  =  await get_query_with_pool(query_to_execute)
    for i in data_output:
        resp.append(str(i['id']))
    return resp
