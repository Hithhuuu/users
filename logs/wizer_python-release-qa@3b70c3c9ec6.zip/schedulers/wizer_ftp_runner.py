import os
import sys
import datetime
import subprocess
import itertools

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import  get_logger, get_env_config,connection_pool

config = get_env_config()
watcher_conf = config.get('wizer_ftp')
mount_location = watcher_conf['src']
app_log = get_logger('wizer_ftp_runner')


class run_wizer_ftp:

    def __init__(self):
        self.sleepTime = 300
        self.procs = {}
        self.startTimes = {}
        self.cmd = ['python', 'schedulers/wizer_ftp.py']
    

    def execute_select(self,query):
        connection = connection_pool.connect()
        cursor = connection.cursor()
        cursor.execute(query)
        query_op = cursor.fetchall()
        cursor.close()
        connection.close()
        return cursor._columns, query_op


    def run(self, *args, **kwargs):

        try:
            tool_query = f"select distinct(tool) from wiz.wiz_tools ;"
            col, op = self.execute_select(tool_query)
            tool_info = list(map(lambda row: dict(itertools.zip_longest(list(col), row)), op))
            tools = [x['tool'] for x in tool_info]
        except Exception as e:
            raise RuntimeError('Cannot fetch tool from wizer_tools table.' + str(e))

        for tool in tools:
            py_flag = False
            name = tool
            run_ftp = self.cmd + ['--tool=' + name]
            if name in self.procs:
                if self.procs[name].poll() is None:
                    if (datetime.datetime.now() - self.startTimes[name]) > datetime.timedelta(minutes=2):
                        """it's been running too long - kill it"""
                        app_log.info('Killing wizer_ftp Script ' + name + " it's been running too long")
                        self.procs[name].kill()
                    else:
                        continue

                if self.procs[name].returncode:
                    app_log.info('wizer_ftp Script failed for ' + name + ', error = ' + str(self.procs[name].returncode))
                run_ftp += ['--delay=' + str(self.sleepTime)]
                app_log.info('starting wizer_ftp.py for ' + name + ' at ' + str(datetime.datetime.now()))
                try:
                    self.procs[name] = subprocess.Popen(run_ftp)
                    self.startTimes[name] = datetime.datetime.now()
                except Exception as e:
                    app_log.info('error from Popen: ' + str(e))
                    if 'python' in str(e).lower():
                        py_flag = True
                    else:
                        continue
            else:
                app_log.info('No other instance of wizer_log found, Starting for tool ' + name + ' at ' + str(datetime.datetime.now()))
                try:
                    self.procs[name] = subprocess.Popen(run_ftp)
                    self.startTimes[name] = datetime.datetime.now()
                except Exception as e:
                    app_log.info('error from Popen: ' + str(e))
                    if 'python' in str(e).lower():
                        py_flag = True
                    else:
                        continue

            if py_flag:
                try:    
                    run_ftp[0] = 'python3'
                    app_log.info(f'Command: {run_ftp}')
                    self.procs[name] = subprocess.Popen(run_ftp)
                    self.startTimes[name] = datetime.datetime.now()
                except Exception as e:
                    app_log.info('error from Popen: ' + str(e))
                    continue

"""this file may be run as a script"""
if __name__ == "__main__": 
    run_wizer_ftp = run_wizer_ftp()
    run_wizer_ftp.run()
    app_log.info("run_wizer_ftp complete at " + str(datetime.datetime.now()))
    exit(0)


