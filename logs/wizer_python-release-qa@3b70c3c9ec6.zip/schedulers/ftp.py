"""this file makes a connection to ftp and fetches log files """
import os
import sys
import re
import asyncio
import datetime
import pandas as pd

from ftplib import FTP
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import (get_logger, env_config)
from api.utils.tool_app import get_query_with_pool

app_log = get_logger("wizer_ftp_new")
file_spec = r'.*\.log'
datetime_str = r'(\d{2}\-\d{2}\-\d{2}\s+\d{2}:\d{2}(AM|PM))'

watcher_conf = env_config.get('wizer_ftp')
file_path = watcher_conf['src']
sem_mnt_location = watcher_conf['sem_mount_location']
enlight_mnt_location = watcher_conf['enlight_mount_location']


class WizerFtp():
    """this class provides methods for ftp connection and file movment"""
    def __init__(self) -> None:
        pass
    async def ftp_tool(self):
        """makes a ftp connection based on tool detials  """
        app_log.info(f"ftp triggered at {datetime.datetime.now()}")
        tool_query = f"select distinct tool,tool_type,ip_address,userid,password from wiz.wiz_tools ;"
        tool_details = await get_query_with_pool(tool_query)
        loop = asyncio.get_running_loop()
        for i in tool_details:
            app_log.info(f"running ftp for tool {i.get('tool')}")
            loop.create_task(self.fetch_files(i))

    async def fetch_files(self,tool_details):
        """Fetch files based on tool details """
        try:
            app_log.info(f"connecting to tool ->{tool_details.get('tool')}")
            ftp = FTP(tool_details.get("ip_address"))
            try:
                ftp.login(tool_details.get("userid"),tool_details.get("password"))
            except Exception as err:
                app_log.exception(err)
                return
            app_log.info("successfully connected to tool")
            query = f"""select MAX (file_timestamp) as file_timestamp from wiz.wiz_ftp_file where tool = '{tool_details.get("tool")}' and file_type = '{tool_details.get("tool_type").lower()}' ;"""
            last_import = await get_query_with_pool(query)
            files = await self.get_file_list(ftp, pd.to_datetime(last_import[0].get('file_timestamp')))
            for filename, formatted_timestamp in files.items():
                insert_ftp = f"""insert into  wiz.wiz_ftp_file (file_timestamp, file_name, tool, file_type, imported_on) values ('{formatted_timestamp}','{filename}','{tool_details.get("tool")}','{tool_details.get("tool_type").lower()}',now()) """
                await get_query_with_pool(insert_ftp, resp_type="None")
                if tool_details.get('tool_type').lower() == 'sem':
                    wizer_toolpath = f"{sem_mnt_location}/{tool_details.get('tool')}/today/reports"
                else:
                    wizer_toolpath = f"{enlight_mnt_location}/{tool_details.get('tool')}/today/reports"
                if not os.path.isdir(wizer_toolpath):
                    try:
                        os.makedirs(f"{wizer_toolpath}/archive/")
                        os.system(f"chmod -R 777 {wizer_toolpath}")
                        if not os.path.isdir(f"{wizer_toolpath}/archive/"):
                            os.makedirs(f"{wizer_toolpath}/archive/")
                            os.system(
                                f"chmod -R 777 {wizer_toolpath}/archive/")
                    except Exception as err:
                        app_log.exception(err)
                        return
                try:

                    fp = open(f"{wizer_toolpath}/{filename}", 'wb')
                    ftp.retrbinary("RETR " + filename, fp.write)
                    app_log.info(f" file: {filename} --> written to WIzer ")
                    fp.close()
                except Exception as err:
                    app_log.exception(err)
                    fp.close()
                    return
        except Exception as err:
            app_log.exception(err)
            return


    async def get_file_list(self,ftp,timestamp):
        """fetch list of files to be picked from ftp"""
        files_list = []
        files = {}
        if not ftp.cwd(file_path):
            return {}
        # returns list of files from the connected tool
        ftp.retrlines('LIST',files_list.append)
        filelist = [i for i in files_list if i.endswith(".log") and 'inspectionlog' in i.lower()]
        for file in filelist:
            match = re.search(datetime_str, file)
            if match:
                time_str = match.group(0)
                dt = datetime.datetime.strptime(time_str, '%m-%d-%y %I:%M%p')
                formatted_timestamp = dt.strftime('%Y-%m-%d %H:%M:%S')
                filename = ''.join(file.split()[3:])
                if not timestamp or pd.to_datetime(formatted_timestamp)>timestamp:
                    files.update({filename:formatted_timestamp})
        return files


if __name__ == "__main__":
    abc = WizerFtp()
    asyncio.run(abc.ftp_tool())