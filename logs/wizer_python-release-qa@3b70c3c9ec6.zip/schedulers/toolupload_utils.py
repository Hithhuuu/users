"""This file executes tool upload for wizer"""
import sys
import os
import re
import datetime
import asyncio

sys.path.append(os.path.abspath(
    os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import get_config, get_env_config, get_logger, get_repeated_strings
from api.upload.utils.utils import UploadUtils
"""Config file to get the all the variable defined in the file"""
config = get_config()
env_config = get_env_config()

""" Calling the logger object to get all the logs """
repeated_strings = get_repeated_strings()
wizer_table_name = env_config['wzr_table_name']
tools = env_config['tools']
watch_path = env_config['watchdog_pick_location']['src']
wizer_one_loc = env_config['watchdog_pick_location']['wzr_one_loc']

tool_log = get_logger("tool_upload")



async def file_watcher(type_path, file_type, toolname='NA'):
    """this method watches files in gebi, dr, adc and klarity paths """
    from api.utils.tool_app import get_query_with_pool
    filetype_path = os.path.join(watch_path, type_path)
    file_type = 'gebi' if file_type.split(
        '/')[0] == 'lz' else file_type.split('/')[0]
    try:
        dr_list = []
        if filetype_path.__contains__('lz/today/reports'):
            dr_grep = f'''find {filetype_path} -type f -name '*.001' -exec grep -L "BATCHNUMBER\|TLFSCORE" ''' + \
                '''{} + | sort -u'''
            dr_files = os.popen(dr_grep).read()
            dr_list = dr_files.splitlines() if len(dr_files) > 0 else []
        file = f''' grep -r -i -l 'BATCHNUMBER' {filetype_path} --include="*.001" | xargs -I ''' + '''{} grep -i -H 'resulttimestamp' {}'''
        files = os.popen(file).read()
        file_list = files.splitlines()
        failed_query = f"select arch_path, id from opwi_job_log final where re_try=0 and (err_message = 'server_shutdown' or err_message like '%memory%') and job_start_time >= subtractMinutes(NOW(),30)  and tool_name = '{toolname}' and file_path not like 'upload%' and arch_path not in ('None','') and arch_path not like '%/dr/%'"
        failed_files = await get_query_with_pool(failed_query)
        failed_dict = {i.get('arch_path'): i.get('id') for i in failed_files}
        file_list = file_list + list(failed_dict.keys())
        if len(file_list) == 0:
            return
        v7_grep =  os.popen(f'grep -H -i "FileVersion" {filetype_path}/*.001').read()
        version7_list =[ i.split(':FileVersion')[0] for i in v7_grep.splitlines()]
        v8_grep =  os.popen(f'grep -H -i "FileRecord" {filetype_path}/*.001').read()
        version8_list =  [ i.split(':Record')[0] for i in  v8_grep.splitlines()]
        for i in file_list:
            try:
                failed_obj = {}
                if i in list(failed_dict.keys()):
                    failed_obj = {
                        "retry": 1,
                        "jobid": failed_dict.get(i)
                    }
                    dr_flag = True
                else:
                    dr_flag = False
                    abs_path = i.split(':')[0]
                    file_name = abs_path.split('/')[-1]
                    if abs_path in version8_list:
                        date_regex = '\d{2}\-\d{2}\-\d{4}'
                        date_format = "%m-%d-%Y"
                    elif abs_path in version7_list:
                        date_regex = '\d{2}\-\d{2}\-\d{2}'
                        date_format = "%m-%d-%y"
                    date_str = i.lower().split('resulttimestamp')[-1]
                    val = re.search(date_regex, date_str)
                    date_folder = val.group(0)
                    date_folder = datetime.datetime.strptime(date_folder, date_format)
                    if file_type == 'gebi':
                        if abs_path in dr_list:
                            tool_log.info(
                                f'file not processed due dr conditions {abs_path} ')
                            dr_flag = True
                    arch_path = await archive_folder_creation_unix(
                        toolname, date_folder, file_type.lower() if not dr_flag else 'dr')
                    arch_path = os.path.join(arch_path, file_name)
                    await move_to_archived_folder(abs_path, arch_path)
                if not dr_flag:
                    await on_file_creation(filename=file_name,  tool=toolname, classifier=file_type.lower(), arch_path=arch_path, err_obj=failed_obj)
            except Exception as err:
                tool_log.exception(
                    f"Unable to copy {file_name} in wizer 1.0 location. {err}")
                continue

    except Exception as err:
        tool_log.exception(err)


async def archive_folder_creation_unix(tool_name, job_start_time, classifier):
    """
    Function will create a folder where we will move the files from Today folder.
    :param : tool type, job start time , file source type
    :return: archive path
    """
    forward_path = ""
    base_path = env_config['watchdog_pick_location']['src']
    dated_folder = job_start_time.strftime("%d%b%Y")
    if classifier in ['adc', 'klarity']:
        forward_path = os.path.join(classifier.upper(
        ) if classifier == 'adc' else classifier, dated_folder, 'reports')
    else:
        forward_path = os.path.join(
            tool_name, classifier, dated_folder, 'reports')

    complete_report_path = os.path.join(base_path, forward_path)

    try:
        if os.path.exists(complete_report_path):
            return complete_report_path
        else:
            os.makedirs(complete_report_path, mode=0o777)
        return complete_report_path

    except Exception as err:
        tool_log.exception(
            "Command to create the archive folder Failed : {0}".format(repr(err)))


async def move_to_archived_folder(src_path, dest_path):
    """move files from scr to dest """
    try:
        cmd_to_move = f"""mv -f "{src_path}" "{dest_path}" """
        res = os.system(cmd_to_move)
    except :
        tool_log.exception(
            f"Unable to move {src_path} to {dest_path}")

async def on_file_creation(filename, tool, classifier='gebi', arch_path='NA', err_obj=None):
    """this method makes a entry to joblog based on file location and triggers klarf processing """
    try:
        if classifier in ['gebi', 'dr']:
            file_type = "gebi"
        elif 'adc' in classifier:
            file_type = "adc"
        elif 'klarity' in classifier:
            file_type = "klarity"
        filename = filename.replace(' ', '_')
        retry = err_obj.get('retry')
        job_id = err_obj.get('jobid')
        await process_klarf(filename, file_type, arch_path, tool, retry, job_id)

    except Exception as err:
        tool_log.exception(err)


async def process_klarf(filename, file_type, arch_path, tool, retry=False, job_id=None):
    """
    Function to pick the records from DB and push it to upload handler
    """
    from api.upload.upload_api.uploadmodel import Upload
    uploadmodel = Upload(toolupload=True)
    payload = {
        "username": "pvadmin",
        "typeoffile": file_type,
        "filename":  filename,
        "filesize":  os.stat(arch_path).st_size,
        "abs_path": arch_path,
        "tool": tool
    }
    if retry:
        payload['id'] = job_id
        payload['retry'] = retry
    with open(arch_path, "r") as file:
        lines = file.readlines()
    await uploadmodel.post(file_data=lines, data=payload)
    tool_log.info(f" file upload is completed for {0}".format(
        arch_path.split('/')[-1]))

async def log_file_watcher(log_dir,log_type, toolname):
    """fetches the list of file and pushes it Dataload """
    files  =  os.popen(f'ls {log_dir}|   grep -i "^inspection.*\.log$"').read()
    file_list =  files.splitlines()
    arch_path = os.path.join(log_dir,"archive")
    upload = UploadUtils(toolupload=True)
    for i in file_list:
        abs_path =  os.path.join(log_dir,i)
        arch_path = os.path.join(arch_path,i)
        await move_to_archived_folder(abs_path,arch_path)
        await upload.failure_dataload(arch_path, log_type, toolname)
