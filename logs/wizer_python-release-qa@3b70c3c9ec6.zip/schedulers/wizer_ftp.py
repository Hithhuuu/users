# title                 : wizer_ftp.py
# description           : Script to fetch log files using FTP
# authors               : Shreyansh Singh
# date                  : 09-June-2022
# version               : Wizer 1.8
################################################################################################################
import re
import os
import sys
import time
import signal
import shutil
import datetime
import itertools
from pkg_resources import register_loader_type
from clickhouse_driver import connect
import sqlalchemy as sa
import pandas as pd
from ftplib import FTP
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import (get_logger, get_env_config, connection_pool, get_dbconnection)
from api.utils.common import execute_query
config = get_env_config()
watcher_conf = config.get('wizer_ftp')
mount_location = watcher_conf['src']
sem_tools = watcher_conf['sem_tools']
enlight_tools = watcher_conf['enlight_tools']
sem_mnt_location = watcher_conf['sem_mount_location']
enlight_mnt_location = watcher_conf['enlight_mount_location']
app_log = get_logger('wizer_ftp')
env_config=get_env_config()

class wizer_ftp():
    tool = None
    tool_id = None
    tool_name = None
    delay = 0
    fail = None
    date_time = None
    FTP_ERROR_STRING = 'FTP error: '
    def __init__(self):
        self.connection = connection_pool.connect()
        self.engine = get_dbconnection()

    def getdbconnection(self):
        eng = sa.create_engine(env_config['clickhouse'])
        return eng

    def logerror(self, msg):
        app_log.info("%s: %s: %s" % (str(datetime.datetime.now()), self.tool, msg))

    def run(self, *args, **kwargs):
        tool_query = f"select tool,tool_type,ip_address,userid,password from wiz.wiz_tools where tool = '{self.tool}';"
        app_log.info(f"Tool Query: {tool_query}")
        tool_info = execute_query(self.connection, tool_query, fetch='all')
        if len(tool_info) == 0:
            app_log.info('no tool ' + self.tool + ' found')
            exit(1)
        self.tool_name = tool_info[0]['tool']
        self.lot = None
        tool_type = tool_info[0]['tool_type']
        event_ip = tool_info[0]['ip_address']
        event_user = tool_info[0]['userid']
        event_password = tool_info[0]['password']

        def import_sem():
            # only sem tools have sem log file
            ftp = self.connect(event_ip, event_user, event_password)
            app_log.info(f" inserted to tool :{self.tool_name}")

            if tool_type.lower():
                #self.cd(ftp, '/')
                file_spec = r'.*\.log'
                file_path = r'D_Drive/Runtime/Tool/Log'
                file_type = tool_type.lower()
                app_log.info('import_sem: using ' + file_path)
                query = f"select MAX (file_timestamp) as file_timestamp from wiz.wiz_ftp_file where tool = '{self.tool_name}' " \
                        f"and data_path = '{file_path}' and file_type = '{file_type}' ;"

                last_import = execute_query(self.connection, query, fetch='all')
                # last_import = list(map(lambda row: dict(itertools.zip_longest(list(col), row)), op))
                files = self.get_file_list(ftp, pd.to_datetime(last_import[0]['file_timestamp']), file_path, file_spec)
                app_log.info(f" log files: {files}")
                if len(files) > 0:

                    insert_item = []
                    # get the files and save them
                    for k in files.keys():
                        ret_item = self.get_files(ftp, k, files[k], file_path, tool_type.lower())
                        insert_item.append(ret_item)

                    load_df = pd.DataFrame(insert_item)
                    # Inserting the data into the ftp table
                    load_df = load_df.append(pd.Series(), ignore_index=True)
                    app_log.info(f"Inserting to wiz_ftp_files into tool: {self.tool_name}")

                    engine=self.getdbconnection()
                    conn= engine.connect()
                    load_df.to_sql('wiz_ftp_file', conn, if_exists='append', index=False)
                    app_log.info('Insertion to wiz_ftp_files successful.')
                else:
                    app_log.info("No new SEM log to process.")
            ftp.quit()

        import_sem()
        return 0

    def connect(self, ip, user, password):
        if ip is None: return None
        app_log.info('Connecting to: ' + ip)
        try:
            ftp = FTP(ip)
            ftp.login(user, password)
        except Exception as e:
            app_log.exception(f"[{self.tool}] FTP connection error '{self.FTP_ERROR_STRING}': {e}")
            exit(8)
        return ftp

    def exists(self, event_ip, event_user, event_password, dir):
        try:
            xftp = self.connect(event_ip, event_user, event_password)
            xftp.cwd(dir)
            xftp.quit()
        except Exception as e:
            xftp.quit()
            return 0
        return 1

    def cd(self, ftp, dir):
        try:
            app_log.info(F"Dir value: {dir}")
            ftp.cwd(dir)
        except Exception as e:
            app_log.exception(f"[{self.tool}] FTP change directory error for dir '{dir}': {e}")
            return 0

        return 1

    def get_name(self, entry):
        if entry.startswith('total') or 'Entering Passive Mode' in entry or \
                'Data connection already open' in entry or 'Transfer complete' in entry:
            return None
        d = []
        d = entry.split()
        if len(d) > 8:  # Unix format
            name = ' '.join(d[8:])
        else:  # windows format
            if len(d) > 3:  # with size
                name = ' '.join(d[3:])
            else:  # no size
                name = ' '.join(d[2:])
        return name

    # get list of files to pull and parse
    def get_file_list(self, ftp, last_import_time, dir, file_spec, nocd=False):
        def get_file_list_ftp():
            if not nocd and not self.cd(ftp, dir):
                return {}
            files = {}
            retlist = {}
            data = []
            sortedfiles = []
            try:
                ftp.dir(data.append)
            except Exception as e:
                app_log.exception(f"[{self.tool}] FTP get file list error '{self.FTP_ERROR_STRING}': {e}")
                exit(17)

            for f in data:
                if f.startswith('total'):
                    continue
                if 'Entering Passive Mode' in f:
                    continue
                if 'Data connection already open' in f:
                    continue
                if 'Transfer complete' in f:
                    continue

                d = f.split()
                if d[0][0].isdigit():  # windows format
                    if len(d) > 3:  # with size
                        date = d[0]
                        time = d[1]
                        size = d[2]
                        name = ' '.join(d[3:])
                    else:  # no size
                        date = d[0]
                        time = d[1]
                        name = ' '.join(d[2:])
                    (month, day, year) = date.split('-')
                    am_pm = time[5:]
                    time = time[0:5]
                    dt = datetime.datetime.strptime(
                        "%02d/%02d/%02d %s%s" % (int(month), int(day), int(year), time, am_pm), '%m/%d/%y %I:%M%p')
                else:  # Unix format
                    perms = d[0]
                    month = d[5]
                    day = d[6]
                    timeoryear = d[7]
                    name = ' '.join(d[8:])
                    if perms[0] == 'd':
                        continue
                    if ':' in timeoryear:
                        dt = datetime.datetime.strptime(
                            "%s/%02d/%04d %s" % (month, int(day), datetime.datetime.now().year, timeoryear),
                            '%b/%d/%Y %H:%M')
                    else:
                        dt = datetime.datetime.strptime("%s/%02d/%04d 00:00" % (month, int(day), int(timeoryear)),
                                                        '%b/%d/%Y %H:%M')

                match = re.search(file_spec, name)
                if match is not None:
                    files[dt, name] = 1

            sortedfiles = sorted(files.items(), reverse=True)
            for f in sortedfiles:
                (dt, name) = f[0]
                # if no last import time return 2 newest files
                if last_import_time is None:
                    retlist[name] = dt
                elif dt > last_import_time:
                    retlist[name] = dt
            new=dict()
            for k,v in retlist.items():
                if k.lower().startswith('inspection') and k.lower().endswith('.log'):
                    new[k]=v
            return new


        def get_file_list_local():
            try:
                os.chdir(dir)
            except Exception as e:
                app_log.exception(f"[{self.tool}] OS chdir error for dir '{dir}': {e}")
                exit(23)

            files = {}
            retlist = {}
            data = []
            sortedfiles = []
            try:
                data = os.listdir('.')
            except Exception as e:
                app_log.exception(f"[{self.tool}] OS listdir error for dir '{dir}': {e}")
                exit(24)

            for d in data:
                if os.path.isdir(d):
                    continue
                match = re.search(file_spec, d)
                if match is not None:
                    dt = datetime.datetime.fromtimestamp(int(os.path.getmtime(d)))
                    files[dt, d] = 1

            sortedfiles = sorted(files.iteritems(), reverse=True)
            for f in sortedfiles:
                (dt, name) = f[0]
                # if no last import time return 2 newest files
                if last_import_time is None:
                    retlist[name] = dt
                elif dt > last_import_time:
                    retlist[name] = dt

            return retlist

        if ftp is None:
            return get_file_list_local()
        else:
            return get_file_list_ftp()

    def get_files(self, ftp, file, timestamp, dir, type):

        app_log.info('get_files')

        def get_files_ftp():
            if type == 'sem':
                local_dir = f"{sem_mnt_location}/{self.tool}/today/reports"
            elif type == 'enlight':
                local_dir = f"{enlight_mnt_location}/{self.tool}/today/reports"
            path = f"{local_dir}/{file}"
            app_log.info(f"Local path: {path}")

            # create a DataFile object to keep track of this file

            ftype = type
            filename = file
            file_timestamp = timestamp
            tool = self.tool_name
            data_path = dir
            imported_date = datetime.datetime.now()

            dfo = {}
            dfo_lst = []
            dfo['file_type'] = ftype
            dfo['file_name'] = filename
            dfo['file_timestamp'] = str(file_timestamp)
            dfo['tool'] = tool
            dfo['data_path'] = data_path
            dfo['file_date'] = None
            dfo['imported_on'] = str(imported_date)
            dfo_data = dfo
            dfo_lst.append(dfo_data)
            app_log.info(f"Local dir: {local_dir}")
            app_log.info(f"file: {filename}, inserted to tool :{tool}")
            if not os.path.isdir(local_dir):
                app_log.info("Creating directory.")
                try:
                    os.makedirs(f"{local_dir}/archive/")
                    # os.chmod(local_dir, 0o777)
                    os.system(f"chmod -R 777 {local_dir}")
                    if not os.path.isdir(f"{local_dir}/archive/"):
                        os.makedirs(f"{local_dir}/archive/")
                        # os.chmod(f"{local_dir}/archive/", 0o777)
                        os.system(f"chmod -R 777 {local_dir}/archive/")

                except Exception as e:
                    app_log.exception(f"[{self.tool}] Failed to create dir '{local_dir}': {e}")
                    return

            try:
                fp = open(path, 'wb')
            except Exception as e:
                app_log.exception(f"[{self.tool}] FTP failed to open path '{path}': {e}")
                return

            app_log.info('retrieving ' + dir + '/' + file + ' ==> ' + local_dir)
            try:
                app_log.info("Returning binary")
                ftp.retrbinary("RETR " + file, fp.write)
                app_log.info("File write done.")
            except Exception as e:
                app_log.exception(f"[{self.tool}] FTP failed to retrieve path '{path}': {e}")
                return
            finally:
                fp.close()
            load_df = pd.DataFrame(dfo_lst, columns=['file_type', 'file_name', 'file_timestamp', 'tool', 'data_path',
                                                  'file_date', 'imported_on'])
            return dfo

        dfo = get_files_ftp()
        return dfo


# this file may be run as a script
if __name__ == "__main__":
    usage = "python wizer_ftp.py --tool=tool"
    adr_ftp = wizer_ftp()
    for arg in sys.argv[1:]:
        if arg.startswith('--tool'):
            try:
                adr_ftp.tool = arg.split('=')[1]
            except IndexError as ValueError:
                app_log.info(usage)
                exit(19)
        else:
            app_log.info(usage)

    if adr_ftp.tool is None:
        app_log.info('Tool must be specified.')
        app_log.info(usage)
        exit(23)
    app_log.info(f"Sleeping for {adr_ftp.delay} Second(s)")
    time.sleep(adr_ftp.delay)
    signal.signal(signal.SIGABRT, signal.SIG_IGN)
    adr_ftp.run()
    app_log.info("wizer ftp complete for " + adr_ftp.tool)
    exit(0)
