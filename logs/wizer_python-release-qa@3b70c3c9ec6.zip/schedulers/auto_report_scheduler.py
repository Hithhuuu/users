# title                 : autoReportScheduler.py
# description           : main auto report Cron job process for execution.
# date                  : 20-Aug-2021
# version               : 2.0
# usage                 : python3 autoReportScheduler.py
################################################################################################################
import os
import sys
import json
import time
import datetime
import requests
import traceback
import asyncio

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
from api.utils.utils import  get_logger, get_env_config, get_config, decrypt
from schedulers.auto_reporting import scheduler_auto_report_task
from api.utils.common import req_url


# Read configuration file and parse environmental variables
config = get_config()
env_config = get_env_config()

logger = get_logger('autoreport_scheduler')

# Generate Auth Token
userid = config['USER_NAME_INPUT']
encrypted_key = config['encrypted_key']


async def get_auth_token():
    logger.info(f"Auth token api call to get the Auth Token.")

    payload = {"userid": config['USER_NAME_INPUT'],
               "password": config['encrypted_key']}

    logger.info(f"Payload for Authentication: {payload}")
    headers = {'Content-Type': 'application/json'}
    status,response = await req_url(env_config['auto_auth_token_api'],payload,headers,True)
    token_resp = json.loads(decrypt(response['encryptedData'], bytes('c2VjcmV0cGFzc3dvcmRwaHJhc2U=','utf-8')).decode('utf-8'))
    logger.info(f'Auth Token Api status_code: {status}, ')

    if status != 200:
        raise RuntimeError('Auth Token API request Failed')

    json_token_resp = token_resp
    return json_token_resp["jwt"]


async def get_history_data(task_id, jwt_token):
    logger.info(f"Getting History Data for specific Auto Task Id.")
    payload = {"autoreportid": [f"{task_id}"], "reportlimit": 3}
    logger.info(f"Payload to get history data: {payload}")
    headers = {'Content-Type': 'application/json', 'Authorization': f'{jwt_token}'}
    status, hist_resp = await req_url(env_config['auto_report_scheduler_hst'], payload, headers,True)
    logger.info(f'Hist Api status_code: {status}, ')

    if status != 200:
        raise RuntimeError('Hist API request Failed')
    hist_api_resp = hist_resp
    return hist_api_resp


async def get_scheduler_auto_reports():
    """
        function will fetch all the reports from fetch report api and based on that it will push the
        records for comparision.
    """
    try:
        logger.info(f"Auto report scheduler process has been started.")
        jwt_token = f"Bearer {await get_auth_token()}"
        # Payload for Auto report API fetch all record.
        payload = {}
        headers = {'Content-Type': 'application/json', 'Authorization': jwt_token}
        logger.info(f"Payload to fetch all records: {payload}")
        
        status, fetch_all_resp =  await req_url(env_config['auto_report_scheduler_api'],payload,headers,True)
        logger.info(f'FetchAll auto report for scheduler api status_code: {status}, ')
        if status != 200:
            raise RuntimeError('FetchAll aut report api request Failed')
    
        fetched_task = fetch_all_resp
        fetched_task = [reports for reports in fetched_task if reports["reportfrequency"] != "Runtime"]
        fetched_task = [reports for reports in fetched_task if reports["reportstatus"] == '\"on\"']
        loop = asyncio.get_running_loop()
        for scheduler_task in fetched_task:
            logger.info("************** Task in Progress **************")
            logger.info(scheduler_task['id'])
            hist_data_resp = await get_history_data(scheduler_task['id'], jwt_token)

            logger.info(f"Total records in History : {len(hist_data_resp)}, "
                        f"for Auto report id : {scheduler_task['id']}")

            if len(hist_data_resp) == 0:
                """Call async function here"""
                latest_record = dict()
                latest_record["autoreportid"] = scheduler_task['id']
                auto_report_id = str(latest_record['autoreportid']) + "_" + "".join(str(time.time()).split("."))

                latest_record['autoreportidtimestamp'] = auto_report_id
                latest_record['auth_token'] = jwt_token
                latest_record['username'] = scheduler_task['username']
                latest_record['invokefrom'] = "by_script"
                logger.info(f"Records with No history data : {latest_record}")

                if latest_record['invokefrom'] == "by_script":
                    loop.create_task(scheduler_auto_report_task(latest_record))
                
            else:
                """checking for the condition where the last executed records successful while execution."""
                try:
                    current_date = datetime.datetime.today().strftime("%Y-%m-%d")
                    latest_record = hist_data_resp[0]
                    latest_record['autoreportid'] = scheduler_task['id']
                    latest_record_date = datetime.datetime.strptime(
                        latest_record['datetime'], '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d')
                    if (latest_record['status'] == "Success") and (current_date == latest_record_date):
                        logger.info(f"Records with Success Status")
                        logger.info("Job is completed/executed before, so job re-execution is not required")

                    else:
                        """if the job failed in last three attempt then no need to re-execution."""
                        logger.info("pushing the job in celery queue for re-execution based on the attempts.")
                        fail_counter = 0

                        for data in hist_data_resp:
                            if data['status'] == "Failed":
                                fail_counter += 1

                        logger.info(f"Report ID: {latest_record['autoreportid']}, Fail counter : {fail_counter}")
                        if fail_counter == 3:
                            logger.info("Skipping the job as it executed multiple times and failed in every execution.")

                        else:
                            auto_report_id = str(latest_record['autoreportid']) + "_" + "".join(
                                str(time.time()).split("."))
                            latest_record['autoreportidtimestamp'] = auto_report_id
                            latest_record['auth_token'] = jwt_token

                            logger.info(f"Records with less than 3 failed Count : {latest_record}")
                            latest_record['invokefrom'] = "by_script"
                            """Call async function here"""
                            loop.create_task(scheduler_auto_report_task(latest_record))
                            
                            logger.info("Pushed the job into celery queue for re-trial")
                except Exception as e:
                    logger.error(f"Error while checking for last executed record. {str(e)}")

    except Exception as e:
        logger.info(traceback.format_exc())
        logger.error(e)
        logger.error(f"Error : while getting the auto report from api, {str(e)}")


# if __name__ == "__main__":
#     asyncio.run(get_scheduler_auto_reports())