import os 
from api.utils.utils import env_config 


def log_reload(type):
    src = env_config['wizer_ftp'][f'{type}_mount_location']
    tools= env_config['wizer_ftp'][f'{type}_tools']
     
    # src='/Application/local/motor/data/wizer/sem'
    # tools = ['W6001']
    for tool in tools :
        cmd = f"mv {src}/{tool}/today/reports/archive/*.log {src}/{tool}/today/reports"
        print(cmd)
        os.system(cmd)
        print(f"move files in {src}/{tool}/today/reports/archive/ to reports dir" )


if __name__ == "__main__": 
    type = ['sem','enlight']
    for t in type:
        log_reload(t)
