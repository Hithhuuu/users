
"""this file contains the model for the routes"""
import os
import pandas as pd
import bcrypt
import jwt
import datetime
from test_flas.flask_app import app, db,User,Product

# Load data from CSV and upload to database

class Auth:
    def __init__(self):
        pass

    def load_data(self,csv_file):
        df = pd.read_csv(csv_file)
        df.to_sql('product', db.engine, if_exists='replace', index=False)

    def signup(self,data):
        username = data['username']
        password = data['password']
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        new_user = User(username=username, password=hashed_password)
        try:
            db.session.add(new_user)
            db.session.commit()
            return {"message": "User created successfully"}, 201
        except Exception as err:
            return {"message": "Username already exists"}, 400

    def login(self,data):
        username = data['username']
        password = data['password']
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.checkpw(password.encode('utf-8'), user.password):
            token = jwt.encode({'user_id': user.id, 'exp': datetime.datetime.utcnow() \
                                + datetime.timedelta(hours=24)}, app.config['SECRET_KEY'])
            return {"token": token}
        return {"message": "Invalid credentials"}, 401

    def clean_data(self,df):
        df['price'] = pd.to_numeric(df['price'], errors='coerce')
        df['quantity_sold'] = pd.to_numeric(df['quantity_sold'], errors='coerce')
        df['rating'] = pd.to_numeric(df['rating'], errors='coerce')

        df['price'].fillna(df['price'].median(), inplace=True)
        df['quantity_sold'].fillna(df['quantity_sold'].median(), inplace=True)
        df['rating'].fillna(df.groupby('category')['rating'].transform('mean'), inplace=True)

        return df

    def summary(self):
        try:
            df = pd.read_sql(Product.query.statement, db.session.bind)
            df = self.clean_data(df)

            summary_df = df.groupby('category').agg(
                total_revenue=pd.NamedAgg(column='price', aggfunc='sum'),
                top_product=pd.NamedAgg(column='product_name',
                                        aggfunc=lambda x: x.iloc[df['quantity_sold'].idxmax()]),
                top_product_quantity_sold=pd.NamedAgg(column='quantity_sold', aggfunc='max')
            ).reset_index()

            summary_csv = 'summary_report.csv'
            summary_df.to_csv(summary_csv, index=False)
            return {"message": "Summary report generated", "file": summary_csv}, 200
        except Exception as err:
            return {"message": f"Error generating summary report, error: {err}"}, 400
