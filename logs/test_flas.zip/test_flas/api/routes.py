
from flask import Flask, request, jsonify
from test_flas.flask_app import app
from test_flas.api.model import Auth

auth =Auth()

@app.route('/signup', methods=['POST'])
def signup_route():
    data = request.json
    response, status = auth.signup(data)
    return jsonify(response), status

@app.route('/login', methods=['POST'])
def login_route():
    data = request.json
    response , status= auth.login(data)
    return jsonify(response), status


@app.route('/summary', methods=['GET'])
def summary_route():
    response , status = auth.summary()
    return  jsonify({"message": "Summary report generated", "file": response}), status





