"""This handler executes tool upload for wizer"""
import os
import datetime
import asyncio
import json
from fastapi import APIRouter

from api.services.toolupload.toolupload_utils.scheduler import scheduler_cron
from api.services.toolupload.fastapi_app import get_query_with_pool, app
from api.services.toolupload.toolupload_api.toolupload_model import file_watcher
from api.services.toolupload.utils import get_logger

router = APIRouter()
tool_log = get_logger("tool_upload")




@app.on_event("startup")
@scheduler_cron(interval=True, minutes=1)
async def tool_upload():
    """
    Main function to look for new files in the given tools and accept a directory loc as input and checks for any addition
    or receiver of new file in the same, as it gets one, starts the execution for the file.
    Watcher will check for FileSystem event, which will only check for "*.001" creation.
    """
    tools = json.loads(os.getenv('tools'))
    for i in [r"ADC/today/reports", r"klarity/today/reports", r"lz/today/reports"]:
        file_type = i.split('/')[0]
        if i.startswith('lz'):
            for tool_name in tools:
                path = os.path.join(tool_name, i)
                await file_watcher(path, file_type, tool_name)
        else:
            await file_watcher(i, file_type)



@app.on_event("startup")
@scheduler_cron(cron_expression="0 6 * * *")
async def drop_partition():
    """creeates task for dropping partiton based on tables"""
    try:
        tablelist = ['tlf_defect_main_wip', 'tlf_defect_main_radial_wip']
        loop = asyncio.get_running_loop()
        for tbl in tablelist:
            loop.create_task(partiton(tbl))
    except Exception as err:
        tool_log.exception(err)


@app.on_event("startup")
@scheduler_cron(cron_expression="0 14 * * *")
async def optimise_table():
    """this method triggers optimisation of tables on DB server based on partition created"""
    try:
        tablelist = ['tlf_map_header', 'tlf_user_templates', 'tlf_defect_main',
                     'tlf_job_log','tlf_autoalert ']
        for tbl in tablelist:
            if tbl == 'tlf_defect_main':
                await optimize_defect_main('tlf_defect_main')
            else:
                query = f"OPTIMIZE table {tbl} final"
                await get_query_with_pool(query, resp_type="None")
    except Exception as err:
        tool_log.exception(err)




async def optimize_defect_main(table_name):
    """optimises table based on partitions"""
    query = f"select distinct partition from system.parts where database = 'tlf' and table='{table_name}' and modification_time >= date_sub(DAY, 1, toDate(now()))"
    resp = await get_query_with_pool(query)
    for i in resp:

        optimize_query = f"""OPTIMIZE table tlf.{table_name} PARTITION tuple('{i.get("partition")}') FINAL"""
        await get_query_with_pool(optimize_query, resp_type="None")



async def partiton(table_name):
    """drops partitons on created tasks """
    query = f"select distinct partition from system.parts where database = 'tlf' and table='{table_name}' and modification_time <= date_sub(DAY, 1, toDate(now()))"
    partition = await get_query_with_pool(query)

    for i in partition:
        drop_query = f"""ALTER TABLE tlf.{table_name} DROP PARTITION '{i.get("partition")}'"""
        await get_query_with_pool(drop_query, resp_type="None")
