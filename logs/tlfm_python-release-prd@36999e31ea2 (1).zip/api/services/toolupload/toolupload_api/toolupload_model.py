"""This file executes tool upload for wizer"""
import sys
import os
import re
import datetime
import aiohttp
import json

sys.path.append(os.path.abspath(
    os.path.join(os.path.dirname(__file__), '../')))
from api.services.toolupload.utils import  get_logger, decrypt
from api.services.toolupload.fastapi_app import get_query_with_pool

""" Calling the logger object to get all the logs """
repeated_strings ={ "tlf_db_connect": "DB connection has been created successfully for wizer.",
                   "tlf_db_close": "DB connection has been closed."}
tools = os.getenv('tools')
watch_path = os.getenv("watchdog_pick_location")
tool_log = get_logger("tool_upload")


async def file_watcher(type_path, file_type, toolname='NA'):
    """this method watches files in tlf, dr, adc and klarity paths """
    filetype_path = os.path.join(watch_path, type_path)
    file_type = 'tlf' if file_type.split(
        '/')[0] == 'lz' else file_type.split('/')[0]
    try:
        dr_list = []
        dr_grep = f'''find {filetype_path} -type f -exec grep -L "BATCHNUMBER\|TLFSCORE" ''' +  '''{} + | sort -u'''
        dr_files = os.popen(dr_grep).read()
        dr_list = dr_files.splitlines() if len(dr_files) > 0 else []
        files = os.popen(
            f''' grep -r -i -l 'TLFSCORE' {filetype_path}  | xargs -I ''' + '''{} grep -i -H 'resulttimestamp' {}''').read()
        file_list = files.splitlines()
        failed_query = f"select arch_path, id from tlf_job_log final where re_try=0 and (err_message = 'server_shutdown' or err_message like '%memory%') and job_start_time >= subtractMinutes(NOW(),30)  and tool_name = '{toolname}' and file_path not like 'upload%' and arch_path not in ('None','') and arch_path not like '%/dr/%'"
        failed_files = await get_query_with_pool(failed_query)
        failed_dict = {i.get('arch_path'): i.get('id') for i in failed_files}
        file_list = file_list + list(failed_dict.keys())
        if len(file_list) == 0:
            return
        v7_grep = os.popen(
            f'grep -H -i "FileVersion" {filetype_path}/*').read()
        version7_list = [i.split(':FileVersion')[0]
                         for i in v7_grep.splitlines()]

        v8_grep = os.popen(
            f'grep -H -i "FileRecord" {filetype_path}/*').read()
        version8_list = [i.split(':Record')[0] for i in v8_grep.splitlines()]
        for i in file_list:
            try:
                failed_obj = {}
                if i.split('/')[-1].split(':')[0].split('.')[-1] not in ['tiff', 'tif', 'png', 'bmp', 'gif', 'jpeg', 'xml', 'log', 'xls', 'xlsx', 'doc', 'docx', 'jpg', 'pdf', 'ppt','pptx', 'emsa', 'bcf', 'txt', 'csv', 'png', 'mp3', 'wav', 'zip', 'rar', 'htm', 'html', 'css', 'js', 'exe', 'bat', 'py']:
                    if i in list(failed_dict.keys()):
                        arch_path = i
                        dr_flag = True
                        file_name = arch_path.split('/')[-1]
                    else:
                        dr_flag = False
                        abs_path = i.split(':')[0]
                        file_name = abs_path.split('/')[-1]
                        if abs_path in version8_list:
                            date_regex = '\d{2}\-\d{2}\-\d{4}'
                            date_format = "%m-%d-%Y"
                        elif abs_path in version7_list:
                            date_regex = '\d{2}\-\d{2}\-\d{2}'
                            date_format = "%m-%d-%y"
                        date_str = i.lower().split('resulttimestamp')[-1]
                        val = re.search(date_regex, date_str)
                        date_folder = val.group(0)
                        date_folder = datetime.datetime.strptime(
                            date_folder, date_format)
                        if file_type == 'tlf':
                            if abs_path in dr_list:
                                tool_log.info(
                                    f'file not processed due dr conditions {abs_path} ')
                                dr_flag = True
                        arch_path = await archive_folder_creation_unix(
                            toolname, date_folder, file_type.lower() if not dr_flag else 'dr')
                        arch_path = os.path.join(arch_path, file_name)
                        await move_to_archived_folder(abs_path, arch_path)
                    if not dr_flag:
                        await on_file_creation(
                        filename=file_name,  tool=toolname, classifier=file_type.lower(), arch_path=arch_path)
                else :
                    await discard_file(i.split(':')[0])
            except Exception as err:
                tool_log.exception(
                    f"Unable to copy {file_name} in wizer 1.0 location. {err}")
                continue
        for i in dr_list:
            try :
                if os.path.exists(i):
                    await discard_file(i)
            except Exception as err:
                tool_log.exception(err)
        tool_log.info("End of filewatcher")
    except Exception as err:
        tool_log.exception(err)

async def discard_file(path):
    """this method is to discard files other than klarfs in landing zone path """
    if not os.path.exists(watch_path+'/dicarded_files'):
        mkdir_cmd = f"mkdir -p {watch_path}/dicarded_files"
        os.system(mkdir_cmd)
    move_file = f"mv {path} {watch_path}/dicarded_files"
    tool_log.info("cmd to delete the file : {0}".format(move_file))
    res = os.system(move_file)
    if res != 0:
        tool_log.info(f"Unable to delete this file.")
    else:
        tool_log.info(f"File has been deleted")



async def archive_folder_creation_unix(tool_name, job_start_time, classifier):
    """
    Function will create a folder where we will move the files from Today folder.
    :param : tool type, job start time , file source type
    :return: archive path
    """
    forward_path = ""
    base_path = watch_path
    dated_folder = job_start_time.strftime("%d%b%Y")
    if classifier in ['adc', 'klarity']:
        forward_path = os.path.join(classifier.upper(
        ) if classifier == 'adc' else classifier, dated_folder, 'reports')
    else:
        forward_path = os.path.join(
            tool_name, classifier, dated_folder, 'reports')

    complete_report_path = os.path.join(base_path, forward_path)

    try:
        if os.path.exists(complete_report_path):
            return complete_report_path
        else:
            os.makedirs(complete_report_path, mode=0o777)
        return complete_report_path

    except Exception as err:
        tool_log.exception(
            "Command to create the archive folder Failed : {0}".format(repr(err)))


async def move_to_archived_folder(src_path, dest_path):
    """move files from scr to dest """
    cmd_to_move = f"""mv -f "{src_path}" "{dest_path}" """
    tool_log.info("cmd to move the file : {0}".format(cmd_to_move))
    res = os.system(cmd_to_move)
    if res != 0:
        tool_log.info(f"Unable to copy this file.")
    else:
        tool_log.info(f"File has been moved in archive folder.")


async def on_file_creation(filename, tool, classifier='tlf', arch_path='NA'):
    """this method makes a entry to joblog based on file location and triggers klarf processing """
    try:
        if classifier in ['tlf', 'dr']:
            file_type = "tlf"
        elif 'adc' in classifier:
            file_type = "adc"
        elif 'klarity' in classifier:
            file_type = "klarity"
        filename = filename.replace(' ', '_')
        tool_log.info(repeated_strings['tlf_db_connect'])
        data = {
            "userid": "pvadmin",
            "type": file_type,
            "filename":  filename,
            "filesize":  str(os.stat(arch_path).st_size),
            "tool": tool if classifier in ['tlf', 'dr'] else classifier,
            'file': open(arch_path,'rb'),
            "tool_path": arch_path
        }
        url = os.getenv("uploadurl")
        headers =  {"Authorization": f"Bearer {await get_auth_token()}"}
        status = await req_url(url, data, headers)
        if  status!=200 :
            tool_log.info("file upload started")
    except Exception as err:
        tool_log.exception(err)


async def get_auth_token():
    tool_log.info(f"Auth token api call to get the Auth Token.")

    payload = {
        "userid": "superadmin",
        "password": "U2FsdGVkX1+OBM5UuxMVfNRZ0y3F7mXAwsv32jmYigs=",
    }

    headers = {"Content-Type": "application/json"}
    status, response = await req_url(os.getenv("authurl"), payload, headers, resp_type=True, payload_type=True)
    token_resp = json.loads(
        decrypt(response["encryptedData"],bytes("c2VjcmV0cGFzc3dvcmRwaHJhc2U=", "utf-8"),).decode("utf-8"))
    tool_log.info(
        f"Auth Token Api status_code: {status}, "
    )
    if status != 200:
        raise RuntimeError("Auth Token API request Failed")
    json_token_resp = token_resp
    return json_token_resp["jwt"]


async def req_url(url, payload, headers, resp_type=False,payload_type = False):
    if payload_type:
        payload =  json.dumps(payload)
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=payload, headers=headers) as response:
            sh_report_resp = response.status
            resp = None
            if resp_type:
                resp = await response.json()
    return sh_report_resp, resp

