"""Model for user API"""

import json
import bcrypt
import asyncio
from datetime import datetime, timedelta
from jwt import encode
from api.services.user.utils import queries, env_config,get_logger,  decrypt, encrypt
from api.services.user.fastapi_app import get_query_with_pool

app_log = get_logger("user")


class Users:
    """User class for model"""

    def __init__(self):
        """Initializing queries for user API"""
        self.queries = queries["user"]

    async def get(self):
        '''Get list of users'''
        try:
            app_log.info('Get list of users')
            app_log.info(self.queries['read'])
            data = await get_query_with_pool(self.queries["read"],resp_type="dict")
            app_log.info(data)
            data1 = {'encryptedData': encrypt(f'{json.dumps(data)}', bytes(env_config["password_secret_key"]
                                                              , 'utf-8')).decode('ascii')}
            app_log.info(data1)
        except Exception as e:
            import traceback
            print(traceback.format_exc())
            app_log.error(e)
            return{'error': str(e)}
        return (data1)

    def get_password(self, password):
        """Decode the Users password"""
        salt = bcrypt.gensalt()
        password = bcrypt.hashpw(password.encode(), salt)
        return password.decode()

    async def create(self, data):
        '''creates new user'''
        try:
            app_log.info('Create user')
            data = json.loads(decrypt(data['encryptedData'],
                                       bytes(env_config["password_secret_key"], 'utf-8')). \
                decode("utf-8"))
            ''' Check user exists '''
            user_exists_query = self.queries['user_exists'].format(**data)
            app_log.info(f'user EXISTS QUERY: {user_exists_query}')
            users = await get_query_with_pool(
                user_exists_query, "dict"
            )

            if len(users):
                return {"msg": "user exists"}

            # Encrypt user password
            pass_word = decrypt(
                data["password"], bytes(
                    env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")
            data["password"] = self.get_password(pass_word)

            # Create new user
            data["assignedrole"] = (
                "admin" if data.get("isadmin") == "Y" else "normal user"
            )
            data["rfg"] = 1 if data.get("isactive") == "Y" else 2

            user_create_query = self.queries["create"].format(**data)
            await get_query_with_pool(user_create_query,resp_type="None")
        except Exception as err:
            app_log.error("Error while creating new user")
            app_log.exception(err)
            return {"error": str(err)}
        return {"msg": "user created"}

    async def prepare_query(self, data):
        """Prepare the query filter conditions"""
        query_data = {
            "userid": "userid",
            "firstname": "firstname",
            "lastname": "lastname",
            "email": "email",
            "assignedrole": "assignedrole",
            "uby" : "uby",
            "udt" : "now() ",
            "password": "password",
            "rfg": "rfg"
        }
        for key, value in data.items():
            if key == "isactive":
                query_data["rfg"] = f"""{1 if data.get("isactive") == "Y" else 2} as rfg"""
            elif key == "isadmin":
                query_data["assignedrole"] = f"""'{"normal user" if data.get(
                    "isadmin") == "N" else "admin"}' as assignedrole"""
            elif key == "userid":
                query_data[key] = f"{key} = '{data.get(key)}' "
            else:
                query_data[key] = f"'{data.get(key)}' as {key}"
        return query_data

    async def update(self, data):
        """Update user record"""
        try:
            app_log.info("Update User Record")
            data = json.loads(decrypt(data['encryptedData'],
                                       bytes(env_config["password_secret_key"], 'utf-8')). \
                decode("utf-8"))
            app_log.info("Authenticating users")

            user_auth_query = self.queries["authenticate_update"].format(
                **data)
            user_data = await get_query_with_pool(user_auth_query, resp_type='dict')
            if len(user_data) <= 0 or user_data[0]['rfg'] == 0:
                return {"msg": "UserID not valid"}
            # user_data = user_data[0]
            if data.get("currentPassword", "") != "":
                pass_word = decrypt(
                    data["currentPassword"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                # Verify user input password and user data password are equal or not
                if not bcrypt.checkpw(
                    pass_word.encode(), user_data[0]["password"].encode()
                ):
                    return {
                        "msg": f"Current password is incorrect for user {data['userid']}."
                    }
            if data.get("password"):
                pass_word = decrypt(
                    data["password"],
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("utf-8")
                data["password"] = self.get_password(pass_word)

            query_data = await self.prepare_query(data)
            user_update_query = self.queries["update"].format(**query_data)
            await get_query_with_pool(user_update_query,resp_type=None)

        except Exception as err:
            app_log.error("Error while updating user record")
            app_log.exception(err)
            return {"error": str(err)}
        return {"msg": f"user {data['userid']} updated successfully"}

    async def delete(self, data):
        '''Delete user'''
        try:
            app_log.info('Delete users')
            data['userid'] = "', '".join(data['userid'])
            user_delete_query = self.queries['delete'].format(**data)
            app_log.info(f'user DELETE QUERY: {user_delete_query}')
            await get_query_with_pool(user_delete_query,resp_type=None)
            resp =  await self.get()
            return resp
        except Exception as e:
            app_log.error(e)
            return {"error": str(e)}

    async def data(self, data):
        ''' Get the user details for Authentication '''
        try:
            app_log.info('Authenticating users')
            user_auth_query = self.queries['authenticate'].format(**data)
            app_log.info(f"user AUTH QUERY: {user_auth_query}")
            user_data = await get_query_with_pool(user_auth_query, "dict")
        except Exception as e:
            app_log.error(e)
            return {'error': str(e)}
        return (user_data)

    async def auth(self, data):
        """Authentication users with username and password"""
        try:
            user_data = await self.data(data)
            if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
                return {
                    "status": "error",
                    "status_code": 401,
                    "content": "userID not valid",
                }

            user_data = user_data[0]
            pass_word = decrypt(
                data["password"], bytes(
                    env_config["password_secret_key"], "utf-8")
            ).decode("utf-8")

            if self.check_password(user_data["password"], pass_word):
                to_encode = {
                    "some": "payload",
                    "userid": data["userid"],
                    "a": {2: True},
                    "exp": datetime.utcnow() + timedelta(minutes=480),
                }
                encoded = encode(
                    to_encode, env_config["secret_key"], algorithm="HS256")
                jwt_key = (
                    encoded.decode(
                        "utf-8") if (isinstance(encoded, bytes)) else encoded
                )
                response_data = {
                    "jwt": jwt_key,
                    "userid": user_data["userid"],
                    "username": user_data["email"],
                    "firstname": user_data["firstname"],
                    "isadmin": "Y" if user_data["assignedrole"] == "admin" else "N",
                    "displayName": user_data["firstname"] + " " + user_data["lastname"],
                    "expiredAt": str(to_encode["exp"]),
                }
                response = {
                    "encryptedData": encrypt(
                        f"{response_data}".replace("'", '"'),
                        bytes(env_config["password_secret_key"], "utf-8"),
                    ).decode("ascii")
                }
                app_log.info("Successfully authenticated")

                return response

            return {
                "status": "error",
                "status_code": 401,
                "content": "Authentication failed",
            }
        except Exception as e:
            app_log.exception(e)
            return {
                "status": "error",
                "status_code": 500,
                "content": "Something went wrong",
            }

    async def refresh(self, data):
        try:
            user_data = await self.data(data)
            if len(user_data) <= 0 or user_data[0]["rfg"] != 1:
                return {
                    "status": "error",
                    "status_code": 401,
                    "content": "UserID not valid",
                }
            user_data = user_data[0]
            to_encode = {
                "some": "payload",
                "userid": data["userid"],
                "a": {2: True},
                "exp": datetime.utcnow() + timedelta(minutes=480),
            }
            encoded = encode(to_encode, env_config["secret_key"], algorithm="HS256")
            response = {
                "jwt": encoded.decode("utf-8"),
                "userid": user_data["userid"],
                "username": user_data["email"],
                "firstname": user_data["firstname"],
                "isadmin": "Y" if user_data["assignedrole"] == "admin" else "N",
                "displayName": f"{user_data['firstname']} {user_data['lastname']}",
                "expiredAt": to_encode["exp"],
            }
            response = {
                "encryptedData": encrypt(
                    f"{response}".replace("'", '"'),
                    bytes(env_config["password_secret_key"], "utf-8"),
                ).decode("ascii")
            }
            return response
        except Exception as e:
            app_log.exception(e)
            return {
                "status": "error",
                "status_code": 500,
                "content": "Something went wrong",
            }

    def check_password(self, user_password, requested_password):
        """Check User password"""
        return bcrypt.checkpw(requested_password.encode(), user_password.encode())