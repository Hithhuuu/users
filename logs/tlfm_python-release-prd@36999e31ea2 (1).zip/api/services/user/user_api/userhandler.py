"""Handler for user API's"""
import sys
import os
import json
from datetime import datetime, timedelta
from fastapi import APIRouter, Request
from api.services.user.utils import queries, env_config,get_logger,  decrypt, encrypt
from schema import (authentication,createusers,updateusers,deleteusers)
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
from jwt import encode

from api.services.user.user_api.usermodel import Users
from fastapi import (APIRouter,Depends)
from api.services.user.fastapi_app import verify_jwt
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

router = APIRouter()


@router.get("/user",dependencies=[Depends(verify_jwt)])
async def get():
    """On get request return the user\'s list as JSON"""
    user = Users()
    response = await user.get()
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )

@router.post("/user/auth")
async def auth(body: authentication):
    """On get request return the user\'s list as JSON"""
    user = Users()
    body=jsonable_encoder(body)
    response = await user.auth(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )
@router.post("/user/refresh",dependencies=[Depends(verify_jwt)])
async def authrefresh(body: dict):
    """Refresh call for session"""
    user=Users()
    response = await user.refresh(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )

@router.post("/user",dependencies=[Depends(verify_jwt)])
async def post(body:createusers):
    """On post request create the user if doesn't exist"""
    user = Users()
    body=jsonable_encoder(body)
    return JSONResponse(content=await user.create(body))


@router.put("/user",dependencies=[Depends(verify_jwt)])
async def put(body:updateusers):
    """On get request return the user\'s list as JSON"""
    user = Users()
    body=jsonable_encoder(body)
    response = await user.update(body)
    if response.get("status_code") == 400 or 'Current password' in response.get("msg"):
        return JSONResponse(
            status_code=response.get("status_code",400),
            content={"message": response.get("msg")},
        )
    return JSONResponse(content=response)


@router.delete("/user",dependencies=[Depends(verify_jwt)])
async def delete(body:deleteusers):
    """On get request return the user\'s list as JSON"""
    user = Users()
    body=jsonable_encoder(body)
    response = await user.delete(body)
    if response.get("status", "success") != "error":
        return JSONResponse(response)
    return JSONResponse(
        status_code=response.get("status_code"),
        content={"message": response.get("content")},
    )
