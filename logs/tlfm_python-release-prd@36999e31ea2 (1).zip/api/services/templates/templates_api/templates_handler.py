"""Handler for Filters API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from fastapi_app import verify_jwt
from api.services.templates.templates_api.templates_model import Template

router = APIRouter(dependencies=[Depends(verify_jwt)])
template = Template()



@router.get("/templates")
@router.get("/templates/templateids")
@router.get("/templates/templatedetails")
async def get(request: Request):
    """On GET request return list of templates"""
    data = {
        k: request.query_params[k]
        if k != "templatenamelike"
        else f"%{request.query_params[k]}%"
        for k in list(request.query_params.keys())
        if k != "__z"
    }
    data["endpoint"] = request.url.path
    data['detailed_flag'] = data["endpoint"].endswith("details")
    response = await template.get(data)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/templates")
async def create_template(request: Request, body: dict):
    """On POST request create template"""
    body["endpoint"] = request.url.path
    response = await template.create(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.put("/templates")
async def update_template(request: Request, body: dict):
    """On PUT request update a template"""
    body["endpoint"] = request.url.path
    response = await template.update(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.delete("/templates")
async def delete_template(request: Request):
    """On DELETE request delete template"""
    body = {}
    body["endpoint"] = request.url.path
    body["template_id"] = request.query_params.get("template_id",[])
    body["template_owner"] = request.query_params.get("template_owner",[])
    response = await template.delete(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)