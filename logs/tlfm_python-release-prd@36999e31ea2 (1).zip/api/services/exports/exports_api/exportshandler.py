"""This handler executes export for wizer"""
import os
import re
from datetime import datetime
from fastapi import Request, APIRouter,  Depends, Response,Request
from fastapi.responses import StreamingResponse,JSONResponse
from fastapi_app import verify_jwt
from api.services.exports.exports_api.exportsmodel import Export
from api.services.exports.scheduler import scheduler_cron
from api.services.exports.fastapi_app import app

router = APIRouter(prefix="/exports",dependencies=[Depends(verify_jwt)])
export = Export()

@router.post("/rawdata")
async def exportrawdata(request: Request, body: dict, response: Response):
    """Handler for export raw data """
    file_name = await export.rawdata(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")


@router.post("/truetlf")
async def exporttruetlf(request: Request, body: dict, response: Response):
    """Handler for export true tls score  """
    file_name = await export.truetlf(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")

@router.post("/falsetlf")
async def exportfalsetlf(request: Request, body: dict, response: Response):
    """Handler for export false tls score  """
    file_name = await export.falsetlf(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")

@router.post("/tlfscore")
async def exporttlfscore(request: Request, body: dict, response: Response):
    """Handler for export tlf score  """
    file_name = await export.truetlf(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")

@router.post("/clsbinning")
async def exportclsbinning(request: Request, body: dict, response: Response):
    """Handler for export class binning """
    file_name = await export.classbinning(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")

@router.post("/reviewbinning")
async def exportdrbinning(request: Request, body: dict, response: Response):
    """Handler for export defect review binning """
    file_name = await export.truetlf(data=body)
    if isinstance(file_name, dict) and "error" in list(file_name.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": file_name.get("error")},
        )
    response.headers["Content-Disposition"] = "attachment; filename=" + file_name
    with open(f"export/{file_name}", "r", encoding="utf-8") as file:
        lines = file.readlines()
    if os.path.exists(f"export/{file_name}"):
        os.remove(f"export/{file_name}")

    def gen():
        for i in lines:
            yield "".join(str(i))
    return StreamingResponse(gen(), media_type="csv")

@router.get("/restart")
@app.on_event("startup")
@scheduler_cron(cron_expression = "*/1 * * * *")
async def kill_service():
    """Handler for alert service restart  """
    resp = await export.alert_restart()
    return JSONResponse(
            status_code=200,
            content={"message": "restart done "},
        )

