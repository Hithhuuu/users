"""Model for export"""
import os
import ast
import json
import re
import aiohttp
import asyncio
import pandas as pd
from datetime import datetime
from api.services.upload.utils import get_logger, queries,decrypt
from api.services.exports.fastapi_app import get_query_with_pool


app_log = get_logger("exports")

class Export():

    def __init__(self) :
        self.queries = queries['exports']


    async def rawdata(self,data):
        try:
            start_time = datetime.now()
            data_output = pd.DataFrame()
            if data.get("type") == "tlfanalysis":
                filename = (
                        f"rawdata_tlfscore_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                    )
                if len(data.get("classes"))>0:
                    query_data= await self.make_query(data)
                    if data.get("no_run_option") == "1":
                        query_data["limit"] = f'Limit {data.get("no_run")}'
                    else:
                        query_data["limit"] = ''

                    query_to_execute = self.queries["rawdata"].format(**query_data)
                    data_output = await get_query_with_pool(query_to_execute,resp_type='df')
                    if not data_output.empty and sum([len(i) for i in data_output.inspection_tool]) >0 :
                        for cls in set(query_data['resolve_class']['trueclasscodetdoi']):
                            if not f"Class ID {cls}" in data_output.columns and query_data['resolve_class']['trueclasscodetdoi'] != '[null]':
                                data_output.insert(len(data_output.columns)-1,f"Class ID {cls}",0)
                        for i , k in data_output.iterrows():
                            for ind,val in k['dict'].items():
                                if f"Class ID {ind}" in data_output.columns:
                                    data_output[f"Class ID {ind}"][i] =val
                        data_output.rename(columns={"bucket": "TLF score bucket", "product": "Product", "inspection_tool": "Inspection tool", "recipeid":"Inspection recipe","layer":"Layer"}, inplace=True)
                        data_output.drop('dict',axis=1,inplace=True)
            elif data.get("type") == "w2w":
                filename = (
                    f"rawdata_w2w_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                )
                if len(data.get("classes"))>0:
                    query_data = await self.make_query(data)
                    classes  = await self.resolve_true_class(data)
                    query_data.update(classes)
                    if data.get("no_run_option") == "1":
                        query_data["limits"] = f'Limit {data.get("no_run")}'
                    else:
                        query_data["limits"] = ''
                    query_to_execute = self.queries["defects"].format(**query_data)
                    data_output = await get_query_with_pool(query_to_execute,resp_type='df')
                    if not data_output.empty:
                        for items in ["mapid","slot","reviewtool"]:
                            data_output = data_output.drop(items,axis=1)
                        data_output  = data_output.sort_values('runid', ascending=True)
                        data_output = data_output.rename(
                                columns = {
                                    "runid":"Run ID",
                                    "carrierid":"Lot ID",
                                    "waferid":"Wafer ID",
                                    "product":"Product",
                                    "inspectiontool":"Inspection tool",
                                    "recipeid" : "Inspection recipe",
                                    "layer" : "Layer",
                                    "doicount":"True DOI count",
                                    "kdoicount":"True KDOI count",
                                    "tdoicount":"Total true",
                                    "falsecount":"False count"
                                }
                            )
                        column_order = ["Run ID", "Lot ID", "Wafer ID", "Product", "Inspection tool", "Inspection recipe", "Layer", "True DOI count", "True KDOI count", "Total true","False count"]
                        data_output = data_output.reindex(columns=column_order)
            data_output.to_csv(f"export/{filename}", index=False)
            with open(f"export/{filename}", "a") as f:
                f.write("\n" * 2)

            app_log.info(
            "export/classid_binning api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": err}
        return filename

    async def truetlf(self,data):
        try:
            type = data.get("type")
            filename = f"{type}_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            df= pd.DataFrame()
            if len(data.get("classes"))>0:
                if type == "truedefects":
                    payload = data
                    headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
                    url = os.getenv("exporturl")
                    url = f'{url}/{type}'
                    status, response = await req_url(url, payload, headers, resp_type=True, payload_type=True)
                    resp = response
                    df = pd.DataFrame(resp)
                    if not df.empty:
                        df = df.sort_values('runid', ascending=True)
                        df = df.rename(
                            columns = {
                                "runid":"Run ID",
                                "carrierid":"Lot ID",
                                "waferid":"Wafer ID",
                                "product":"Product",
                                "inspectiontool":"Inspection tool",
                                "recipeid" : "Inspection recipe",
                                "layer" : "Layer",
                                "doicount":"True DOI count",
                                "kdoicount":"True KDOI count",
                                "tdoicount":"Total true"
                            }
                        )
                        column_order = ["Run ID", "Lot ID", "Wafer ID", "Product", "Inspection tool", "Inspection recipe", "Layer", "True DOI count", "True KDOI count", "Total true"]
                        df = df.reindex(columns=column_order)

                elif type == "tlfscore":
                    payload = data
                    headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
                    url = os.getenv("exporturl")
                    url = f'{url}/{type}'
                    status, response = await req_url(url, payload, headers, resp_type=True, payload_type=True)
                    df = pd.DataFrame(response)
                    if not df.empty:
                        for items in ["classname","groupname","slot","reviewtool"]:
                            df = df.drop(items,axis=1)
                        df = df.sort_values('runid', ascending=True)
                        df = df.rename(
                            columns = {
                                "runid":"Run ID",
                                "lot":"Lot ID",
                                "defectid" :"Defect ID",
                                "waferid" :"Wafer ID",
                                "product":"Product",
                                "inspectiontool":"Inspection tool",
                                "recipeid" : "Inspection recipe",
                                "layer" : "Layer",
                                "mansemclass":"Class Number",
                                "tlfscore":"TLF Score"
                            }
                        )
                        column_order = ["Run ID", "Lot ID", "Defect ID", "Wafer ID", "Product", "Inspection tool", "Inspection recipe", "Layer", "Class Number","TLF Score"]
                        df = df.reindex(columns=column_order)

                elif type == "review":
                    payload = data
                    headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
                    url = os.getenv("exporturl")
                    url = f'{url}/{type}'
                    status, response = await req_url(url, payload, headers, resp_type=True, payload_type=True)
                    df = pd.DataFrame(response)
                    if not df.empty:
                        # if len(df.)
                        bins = [10,20,30,40,50,60,70,80,90,100,110]
                        labels = ["[0-10]", "[10-20]", "[20-30]", "[30-40]", "[40-50]", "[50-60]", "[60-70]", "[70-80]", "[80-90]", "[90-100]"]
                        df['ranges'] = pd.cut(df['bu_ed'], bins=bins, labels=labels, right=False)
                        df = df.rename(
                            columns = {
                                "product":"Product",
                                "ranges" :"TLF score bucket",
                                "inspectiontool":"Inspection tool",
                                "recipeid" : "Inspection recipe",
                                "layer" : "Layer",
                                "doi":"DOI + KDOI value",
                                "tdoi":"Total defects value"
                            }
                        )
                        column_order = ["TLF score bucket", "Product", "Inspection tool", "Inspection recipe", "Layer", "DOI + KDOI value", "Total defects value"]
                        df = df.reindex(columns=column_order)

            df.to_csv(f"export/{filename}", index=False)
            app_log.info(f"csv {type}  export completed ")
            return filename

        except Exception as err:
            app_log.exception(err)
            app_log.error(" Export API Failed")
            return {"error": err}

    async def falsetlf(self,data):
        try:
            type = data.get("type")
            filename = f"{type}_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
            df= pd.DataFrame()
            if len(data.get("classes"))>0 and type == "falsedefects":
                payload = data
                headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
                url = os.getenv("exporturl")
                url = f'{url}/{type}'
                status, response = await req_url(url, payload, headers, resp_type=True, payload_type=True)
                df = pd.DataFrame(response)
                if not df.empty:
                    df = df.sort_values('runid', ascending=True)
                    for items in ["mapid","slot","reviewtool"]:
                        df = df.drop(items,axis=1)
                    df = df.rename(
                        columns = {
                            "runid":"Run ID",
                            "carrierid":"Lot ID",
                            "waferid":"Wafer ID",
                            "product":"Product",
                            "inspectiontool":"Inspection tool",
                            "recipeid" : "Inspection recipe",
                            "layer" : "Layer",
                            "falsecount":"False count"
                        }
                    )
                    column_order = ["Run ID", "Lot ID", "Wafer ID", "Product", "Inspection tool", "Inspection recipe", "Layer", "False count"]
                    df = df.reindex(columns=column_order)

            df.to_csv(f"export/{filename}", index=False)
            app_log.info(f"csv {type}  export completed ")
            return filename

        except Exception as err:
            app_log.exception(err)
            app_log.error(" Export API Failed")
            return {"error": err}

    async def classbinning(self,data):
        try:
            start_time = datetime.now()
            data_output =  pd.DataFrame()
            if len(data.get("classes"))>0:
                query_data= await self.make_query(data)
                if data.get("no_run_option") == "1":
                    query_data["limit"] = f'Limit {data.get("no_run")}'
                else:
                    query_data["limit"] = ''

                query_to_execute = self.queries["classid"].format(**query_data)
                data_output = await get_query_with_pool(query_to_execute,resp_type='df')
                if not data_output.empty and 'null' not in query_data['resolve_class']['trueclasscodetdoi'] and sum([len(i) for i in data_output.inspection_tool]) >0:
                    for cls in set(query_data['resolve_class']['trueclasscodetdoi']):
                        if not f"Class ID {cls}" in data_output.columns:
                            data_output.insert(len(data_output.columns)-1,f"Class ID {cls}",0)
                    for i , k in data_output.iterrows():
                        for ind,val in k['dict'].items():
                            if f"Class ID {ind}" in data_output.columns:
                                data_output[f"Class ID {ind}"][i] =val
                    data_output.rename(columns={"bucket": "TLF score bucket", "product": "Product", "inspection_tool": "Inspection tool", "recipeid":"Inspection recipe","layer":"Layer"}, inplace=True)
                    data_output.drop('dict',axis=1,inplace=True)
                else :
                    data_output= pd.DataFrame()

            filename = (
                    f"classbinning_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.csv"
                )
            data_output.to_csv(f"export/{filename}", index=False)
            with open(f"export/{filename}", "a") as f:
                f.write("\n" * 2)

            app_log.info(
            "export classid_binning api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": err}
        return filename

    async def make_query(self, data):
        """This function is used to create queries"""
        defect_list = []
        header_list = []
        filter_data = data.get('filters')
        query_data = {'defect_cdtn': '',
                      'header_cdtn': ''}
        query_data['unselected_class'] = await self.unselect_class(data)
        if data.get('no_run_option') == '0':
            query_data['header_cdtn'] = f" and toString(toDate(header.resulttimestamp)) >= '{data.get('timestamp').get('resulttimestamp').get('min')[:10]}' and toString(toDate(header.resulttimestamp)) <='{data.get('timestamp').get('resulttimestamp').get('max')[:10]}' "
        query_data['limit'] = f'limit {data.get("no_run")}' if data.get(
            'no_run_option') == '1' else ''
        query_data['plr_condition'] = f"""'{filter_data["gfilter"].get("deviceid")[0]}' as product,'{filter_data["gfilter"].get("recipeid")[0]}' as recipeid,'{filter_data["gfilter"].get("stepid")[0]}' as layer """
        if filter_data:
            header_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i, k in filter_data.get(
                "gfilter").items() if len(k) > 0 and '' not in k and i not in ("templates","toolid")]
            defect_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i, k in filter_data.get(
                "sfilter").items() if len(k) > 0 and '' not in k and i not in ['runid']] + header_list
            if filter_data["sfilter"].get("runid"):
                runid = [i.split(":")[-1].strip() for i in filter_data["sfilter"].get("runid")  ]
                defect_list.append(f"concat(carrierid,',',waferid) in {runid}" )
                header_list.append(f"concat(carrierid,',',waferid) in {runid}" )
            if filter_data.get("gfilter").get("toolid"):
                header_list.append(f""" toolid in {filter_data.get("gfilter").get("toolid")}""")
            query_data['defect_cdtn'] = f"and {' and '.join(defect_list)}".replace("deviceid", "product").replace(
                "stepid", "layer").replace("recipeid", "setupid").replace('lotid','carrierid').replace('inspectionstationid', "splitByChar(' ', platform)[-1]") if len(defect_list) > 0 else ''
            query_data['header_cdtn'] = f"{query_data['header_cdtn']} and {' and '.join(header_list)}".replace("deviceid", "product").replace("stepid", "layer").replace(
                "recipeid", "setupid").replace("reviewtool", "tool").replace("toolid", "tool").replace('inspectionstationid', "splitByChar(' ', header.platform)[-1]") if len(header_list) > 0 else ''
        true_class = await self.resolve_true_class(data)
        query_data['mansemclass'] = f"and defect.mansemclass in {tuple(data.get('classes'))} "
        query_data['resolve_class'] = true_class
        query_data['classes'] = (true_class['trueclasscodetdoi'])
        query_data['unselected_class'] = await self.unselect_class(data)
        return query_data

    async def resolve_true_class(self, data):
        """Resolve true classcodes"""
        resp = {}
        if data["filters"].get("usergroup", []):
            resp['trueclasscodedoi'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "True (DOI)" and str(x["classnumber"]) in data.get("classes")
            ]
            resp['trueclasscodekdoi'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "True (KDOI)" and str(x["classnumber"]) in data.get("classes")
            ]
            resp['falseclasscode'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "False" and str(x["classnumber"]) in data.get("classes")
            ]

            resp["trueclasscodetdoi"] = resp['trueclasscodedoi'] + \
                resp['trueclasscodekdoi']
            for i, k in resp.items():
                if not len(k) > 0:
                    resp[i] = '[null]'

        return resp

    async def unselect_class(self, data):
        """provides a  list of unselected class """
        usg = data.get('filters').get('usergroup')
        df = pd.DataFrame(usg)
        class_diff = set(df[df['tlftoggle'] == 'True']['classnumber'].to_list(
        )) - {int(i) for i in data.get('classes')}
        return f" and defect.mansemclass not in {tuple(class_diff)}" if len(class_diff) > 0 else ''

    async def alert_restart(self):
        try:
            with open("/Application/tlfm_python/logs/smtp_log.log", "r") as file :
                data = file.readlines()
            pattern = r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})"
            if (not data or \
                data[-1] == "\n" \
                or data[-1] == "" \
                or 'Email end' in data[-1] \
                or data[-1] == " "\
                ):
                return
            match = re.search(pattern, data[-1])
            if not match:
                return

            time_format = "%Y-%m-%d %H:%M:%S"
            lastlogtime = datetime.strptime(match.group(1), time_format)
            current_time = datetime.now()
            diff = current_time - lastlogtime

            watch_path = os.getenv("watchdog_pick_location")
            if diff.total_seconds() > 300:
                if not os.path.exists(watch_path+f'/alert_monitor/{lastlogtime.strftime("%d%b%Y")}'):
                    mkdir_cmd = f"mkdir -p {watch_path}/alert_monitor/{lastlogtime.strftime('%d%b%Y')}"
                    os.system(mkdir_cmd)
                destination_dir = f"{watch_path}/alert_monitor/{lastlogtime.strftime('%d%b%Y')}"
                for i in ['smtp_log.log',
                        'alerts.log',
                        'alerts_validate.log']:
                    if os.path.exists(f"/Application/tlfm_python/logs/{i}"):
                        mv_cmd =f"mv /Application/tlfm_python/logs/{i} {destination_dir}/{i}_{lastlogtime.strftime('%Y%m%d-%H%M%S')}"
                        os.system(mv_cmd)

                command =  ''' kill -9 $(ps aux | grep 'port 4300' | awk '{print $2}') '''
                os.system(command)
                await asyncio.sleep(5)

                command =  ''' /Application/scripts/tlfm_python_api_startup_scripts/alerts_start.sh '''
                os.system(command)

                await asyncio.sleep(5)
                payload = json.dumps({"restart": "True" })
                headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
                url = os.getenv("alert_restart")
                status, response = await req_url(url, payload, headers, resp_type=False, payload_type=False)

        except Exception as err:
            app_log.exception(err)
            return {"error": err}

async def req_url(url, payload, headers, resp_type=False,payload_type = False):
    if payload_type:
        payload =  json.dumps(payload)
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=payload, headers=headers) as response:
            sh_report_resp = response.status
            resp = None
            if resp_type:
                resp = await response.json()
    return sh_report_resp, resp

async def get_auth_token():
    app_log.info(f"Auth token api call to get the Auth Token.")
    payload = {
        "userid": "superadmin",
        "password": "U2FsdGVkX1+OBM5UuxMVfNRZ0y3F7mXAwsv32jmYigs=",
    }

    headers = {"Content-Type": "application/json"}
    status, response = await req_url(os.getenv("authurl"), payload, headers, resp_type=True, payload_type=True)
    token_resp = json.loads(
        decrypt(response["encryptedData"],bytes("c2VjcmV0cGFzc3dvcmRwaHJhc2U=", "utf-8"),).decode("utf-8"))
    app_log.info(
        f"Auth Token Api status_code: {status}, "
    )
    if status != 200:
        raise RuntimeError("Auth Token API request Failed")
    json_token_resp = token_resp
    return json_token_resp["jwt"]