"""Utils file for WIzer"""
import os
import sys
import base64
import logging
import yaml
import numpy as np

from datetime import datetime, timedelta
from enum import IntEnum
from glob import glob
from hashlib import md5
from logging.handlers import TimedRotatingFileHandler

from asynch import pool as pool_async
from Crypto import Random
from Crypto.Cipher import AES

FORMATTER = logging.Formatter(
    "%(asctime)s — %(name)s — %(levelname)s — %(lineno)d — %(funcName)s — %(message)s"
)
CONFIG_FILE = "api/services/charts/config.yaml"
COLUMNS_FILE = "api/services/charts/columns.yaml"



def unpad(data):
    """doing unpaddling"""
    return data[: -(data[-1] if type(data[-1]) == int else ord(data[-1]))]


def bytes_to_key(data, salt, output=48):
    """creates key_iv"""
    assert len(salt) == 8, len(salt)
    data += salt
    key = md5(data).digest()
    final_key = key
    while len(final_key) < output:
        key = md5(key + data).digest()
        final_key += key
    return final_key[:output]


def pad(data):
    """adds padding"""
    bs = 16
    return data + (bs - len(data) % bs) * chr(bs - len(data) % bs)


def encrypt(password, key):
    """Encrypts password"""
    data = pad(password)
    salt = Random.new().read(8)
    key_iv = bytes_to_key(key, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return base64.b64encode(b"Salted__" + salt + aes.encrypt(bytes(data, "utf-8")))


def decrypt(encrypted, passphrase):
    """Decrypts password"""
    encrypted = base64.b64decode(encrypted)
    assert encrypted[0:8] == b"Salted__"
    salt = encrypted[8:16]
    key_iv = bytes_to_key(passphrase, salt, 32 + 16)
    key = key_iv[:32]
    iv = key_iv[32:]
    aes = AES.new(key, AES.MODE_CBC, iv)
    return unpad(aes.decrypt(encrypted[16:]))


async def get_async_connection_pool():
    """Creates and returns an async Connection Pool"""
    return await pool_async.create_pool(
        minsize=6,
        maxsize=10,
        host=os.getenv("DB_SERVER"),
        port=9000,
        database="tlf",
        user=decrypt(os.getenv("DB_USER"), bytes(
            os.getenv("password_secret_key"), "utf-8")).decode("utf-8"),
        password=decrypt(os.getenv("DB_PASSWORD"), bytes(
            os.getenv("password_secret_key"), "utf-8")).decode("utf-8")
    )

def get_filter_config():
    config = columns_info
    root_dict = {}
    for item in config["filter_col"]:
        root_dict.update(item)
    return root_dict

# def get_common_queries():
#     """Get common queries"""
#     path = os.path.abspath(os.getcwd())
#     query_file = path + "/queries/queries.yaml"
#     common_query_file = path + "/queries/common.yaml"
#     queries = {}
#     with open(query_file) as file:
#         queries["queries"] = yaml.load(file, Loader=yaml.SafeLoader)
#     with open(common_query_file) as file:
#         queries["common"] = yaml.load(file, Loader=yaml.SafeLoader)
#     return queries


def get_queries(apiname =None):
    """Get api queries"""
    path = os.path.abspath(os.getcwd())
    query_files = glob(path + f"/api/{apiname}/queries/*.yaml", recursive=True) if apiname else glob(path + "/api/*/*/*.yaml", recursive=True)
    queries = {}
    for qfile in query_files:
        key = os.path.splitext(os.path.basename(qfile))[0]
        with open(qfile) as file:
            queries[key] = yaml.load(file, Loader=yaml.SafeLoader)
            file.close()
    return queries



def get_console_handler():
    """Get console handler for logs"""
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def get_file_handler(log_file):
    """Get file handler for logs"""
    env = {
        "dev": 3,
        "demo": 3,
        "prd": 10
    }
    file_handler = TimedRotatingFileHandler(log_file, when="midnight", backupCount=env.get(os.getenv("tlfpyenv")))
    file_handler.setFormatter(FORMATTER)
    return file_handler


def get_logger(logger_name):
    """
    Creates a logger for the api's
    param: logger name
    return: logger object
    """
    logger = logging.getLogger(logger_name)
    # better to have too much log than not enough
    logger.setLevel(logging.DEBUG)
    # add new handlers for the logger
    logger.addHandler(get_console_handler())
    logger.addHandler(get_file_handler(f"logs/{logger_name}.log"))
    # with this pattern, it's rarely necessary to propagate the error up to parent
    logger.propagate = False
    return logger


def get_column_details(key):
    """Gets the details from columns file in config"""
    with open(COLUMNS_FILE) as file:
        columns = yaml.load(file, Loader=yaml.SafeLoader)
    if key in ["v7", "v8"]:
        return columns[f"header_meta_for_{key}_file"]
    elif key == "filter":
        return columns["filter_dict"]
    elif key == "alias":
        return columns["alias_dict"]
    elif key == "header_cols":
        return columns["header_cols"]
    elif key == "columns":
        return columns


def workweek(data):
    # -------------------------------WEEKNUM----------------#
    WEEKDAY = IntEnum("WEEKDAY", "MON TUE WED THU FRI SAT SUN", start=1)
    # -------------------------------WEEKNUM END----------------#
    date = datetime.strptime(data["Started on"][0], "%Y-%m-%d %H:%M:%S")
    my_calendar = CustomizedCalendar(
        start_weekday=WEEKDAY.FRI, indicator_weekday=WEEKDAY.MON
    )
    weeknum = my_calendar.calculate(date)[1]
    return weeknum


class CustomizedCalendar:
    def __init__(self, start_weekday, indicator_weekday=None):
        self.start_weekday = start_weekday
        self.indicator_delta = (
            3 if not (indicator_weekday) else (indicator_weekday - start_weekday) % 7
        )

    def get_week_start(self, date):
        delta = date.isoweekday() - self.start_weekday
        return date - timedelta(days=delta % 7)

    def get_week_indicator(self, date):
        week_start = self.get_week_start(date)
        return week_start + timedelta(days=self.indicator_delta)

    def get_first_week(self, year):
        indicator_date = self.get_week_indicator(datetime(year, 1, 1))
        if indicator_date.year == year:  # The date "year.1.1" is on 1st week.
            return self.get_week_start(datetime(year, 1, 1))
        else:  # The date "year.1.1" is on the last week of "year-1".
            return self.get_week_start(datetime(year, 1, 8))

    def calculate(self, date):
        year = self.get_week_indicator(date).year
        first_date_of_first_week = self.get_first_week(year)
        diff_days = (date - first_date_of_first_week).days
        return year, (diff_days // 7 + 1), (diff_days % 7 + 1)


# reused variables
queries = get_queries()
# common_query = get_common_queries()["common"]
dtypes = {"str": str, "float": np.float64, "int": np.int64}
columns_info = get_column_details("columns")
alias_info = get_column_details("alias")
columns_info["main_cols"] = {
    key: dtypes[val] for key, val in columns_info["main_cols"].items()
}
columns_info["header_cols"] = {
    key: dtypes[val] for key, val in columns_info["header_cols"].items()
}
