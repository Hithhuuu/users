"""Handler for Filters API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from fastapi_app import verify_jwt
from api.services.charts.charts_api.chartsmodel import Charts

router = APIRouter(prefix="/charts",dependencies=[Depends(verify_jwt)])
charts = Charts()


@router.post("/truedefects")
async def usergroups( body: dict):
    """On POST request return global filters as JSON"""
    response = await charts.truedefects(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/falsedefects")
async def usergroups( body: dict):
    """On POST request return global filters as JSON"""
    response = await charts.falsedefects(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/tlfscore")
async def tlfscore( body: dict):
    """On POST request return global filters as JSON"""
    response = await charts.tlfscore(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/classid")
async def classid( body: dict):
    """On POST request return global filters as JSON"""
    response = await charts.classid_binning(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/review")
async def reviewid( body: dict):
    """On POST request return global filters as JSON"""
    response = await charts.review_binning(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)