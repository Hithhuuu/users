"""Model for filters API"""
import pandas as pd
from datetime import datetime

from api.services.charts.fastapi_app import get_query_with_pool
from api.services.charts.utils import get_logger, queries, get_filter_config


app_log = get_logger("charts")


class Charts:
    """This class provides methods to get filters"""

    def __init__(self):
        """Initializing filter queries"""
        self.queries = queries["charts"]

    async def truedefects(self, data):
        """Get TLF True defects"""
        try:
            start_time = datetime.now()
            query_data = await self.make_query(data)
            classes  = await self.resolve_class(data)
            query_data.update(classes)
            if not len(data.get("classes")) > 0  or 'null'  in classes['trueclasscodetdoi'] :
                return []
            if data.get("no_run_option") == "1":
                query_data["limits"] = f'Limit {data.get("no_run")}'
            else:
                query_data["limits"] = ''
            app_log.info("User group API triggered..")
            app_log.info("Query parameters created.")
            query_to_execute = self.queries["truedefects"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='dict')
            # app_log.info("Formatting data....")
            app_log.info(
                "charts/truedefects api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output

    async def falsedefects(self, data):
        """Get TLF True defects"""
        try:
            start_time = datetime.now()
            query_data = await self.make_query(data)
            classes  = await self.resolve_class(data)
            query_data.update(classes)
            if not len(data.get("classes")) > 0  or 'null'  in classes['falseclasscode'] :
                return []
            if data.get("no_run_option") == "1":
                query_data["limits"] = f'Limit {data.get("no_run")}'
            else:
                query_data["limits"] = ''
            app_log.info("User group API triggered..")
            app_log.info("Query parameters created.")
            query_to_execute = self.queries["falsedefects"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='dict')
            # app_log.info("Formatting data....")
            app_log.info(
                "charts/truedefects api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output

    async def resolve_class(self, data):
        """Resolve true classcodes"""
        resp = {}
        if data["filters"].get("usergroup", []):
            resp['trueclasscodedoi'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "True (DOI)" and str(x["classnumber"]) in data.get("classes")
            ]
            resp['trueclasscodekdoi'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "True (KDOI)" and str(x["classnumber"]) in data.get("classes")
            ]

            resp['falseclasscode'] = [
                x["classnumber"]
                for x in data["filters"].get("usergroup", [])
                if x["groupname"] == "False" and str(x["classnumber"]) in data.get("classes")
            ]

            resp["trueclasscodetdoi"] = resp['trueclasscodedoi'] + \
                resp['trueclasscodekdoi']
            for i, k in resp.items():
                if not len(k) > 0:
                    resp[i] = '[null]'

        return resp

    async def tlfscore(self, data):
        """Get TLF True defects"""
        try:
            start_time = datetime.now()
            query_data = await self.make_query(data)
            trueclass = await self.resolve_class(data) 
            classnumber = data.get("classes", {})
            if not len(classnumber) > 0  or 'null'  in trueclass['trueclasscodetdoi']:
                return []
            query_data["classnumber"] = tuple(trueclass['trueclasscodetdoi'])
            if data.get("no_run_option") == "1":
                query_data["limits"] = f'Limit {data.get("no_run")}'
            else:
                query_data["limits"] = ''
            app_log.info("User group API triggered..")
            app_log.info("Query parameters created.")
            query_to_execute = self.queries["tlfscore"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='dict')
            app_log.info(
                "charts/tlfscore api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output

    async def classid_binning(self, data):
        try:
            start_time = datetime.now()
            query_data = await self.make_query(data)
            classnumber = data.get("classes", {})
            classes  = await self.resolve_class(data)
            query_data['trueclasses'] = classes['trueclasscodetdoi']
            query_data['classes'] = f" and defect.mansemclass in {tuple(classes['trueclasscodetdoi'])}"
            query_data["classnumber"] = tuple(classnumber)
            if not len(classnumber) > 0 or 'null'  in classes['trueclasscodetdoi'] :
                return []
            if data.get("no_run_option") == "1":
                query_data["limits"] = f'Limit {data.get("no_run")}'
            else:
                query_data["limits"] = ''
            app_log.info("User group API triggered..")
            app_log.info("Query parameters created.")
            query_to_execute = self.queries["classid"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='dict')
            app_log.info(
                "charts/classid_binning api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output

    async def review_binning(self, data):
        try:
            start_time = datetime.now()
            query_data = await self.make_query(data)
            classes  = await self.resolve_class(data)
            query_data['trueclasses'] = classes['trueclasscodetdoi']
            classnumber = data.get("classes",)
            if not len(classnumber) > 0 :
                return []
            query_data["classnumber"] = tuple(classnumber)
            if data.get("no_run_option") == "1":
                query_data["limits"] = f'Limit {data.get("no_run")}'
            else:
                query_data["limits"] = ''
            app_log.info("User group API triggered..")
            app_log.info("Query parameters created.")
            query_to_execute = self.queries["review"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='dict')
            df = pd.DataFrame(data_output)
            if  set(df.doi) == {0} and  set(df.tdoi) == {0}:
                return []
            app_log.info(
                "charts/review_binning api took %s to complete",
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output

    async def make_query(self, data):
        """This function is used to create queries"""
        defect_list = []
        header_list = []
        filter_data = data.get('filters')

        query_data = {'defect_cdtn': '',
                      'header_cdtn': '',
                      'runid': '' }
        query_data['unselected_class'] = await self.unselect_class(data)
        if data.get('no_run_option') == '0':
            query_data['header_cdtn'] = f" and toString(toDate(header.resulttimestamp)) >= '{data.get('timestamp').get('resulttimestamp').get('min')[:10]}' and toString(toDate(header.resulttimestamp)) <='{data.get('timestamp').get('resulttimestamp').get('max')[:10]}' "
        query_data['limits'] = f'limit {data.get("no_run")}' if data.get(
            'no_run_option') == '1' else ''
        query_data['plr_condition'] = f"""'{filter_data["gfilter"].get("deviceid")[0]}' as product,'{filter_data["gfilter"].get("recipeid")[0]}' as recipeid,'{filter_data["gfilter"].get("stepid")[0]}' as layer """
        if filter_data:
            header_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i, k in filter_data.get(
                "gfilter").items() if len(k) > 0 and '' not in k and i not in ("templates","toolid")]
            defect_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i, k in filter_data.get(
                "sfilter").items() if len(k) > 0 and '' not in k and i not in ['runid']] + header_list
            if filter_data["sfilter"].get("runid"):
                runid = [i.split(":")[-1].strip() for i in filter_data["sfilter"].get("runid")  ]
                defect_list.append(f"concat(carrierid,',',waferid) in {runid}" )
                query_data['runid']= f" and concat(carrierid,',',waferid) in {runid}" 
            if filter_data.get("gfilter").get("toolid"):
                header_list.append(f""" toolid in {filter_data.get("gfilter").get("toolid")}""")
            query_data['classes'] = f" and defect.mansemclass in {tuple(data.get('classes'))}"
            query_data['defect_cdtn'] = f"and {' and '.join(defect_list)}".replace("deviceid", "product").replace(
                "stepid", "layer").replace("recipeid", "setupid").replace('lotid','carrierid').replace('inspectionstationid', "splitByChar(' ', platform)[-1]") if len(defect_list) > 0 else ''
            query_data['header_cdtn'] = f"{query_data['header_cdtn']} and {' and '.join(header_list)}".replace("deviceid", "product").replace("stepid", "layer").replace(
                "recipeid", "setupid").replace("reviewtool", "tool").replace("toolid", "tool").replace('inspectionstationid', "splitByChar(' ', header.platform)[-1]") if len(header_list) > 0 else ''
        return query_data

    async def unselect_class(self,data):
        """provides a  list of unselected class """
        usg = data.get('filters').get('usergroup')
        df = pd.DataFrame(usg)
        class_diff = set(df[df['tlftoggle']=='True']['classnumber'].to_list()) - {int(i) for i in data.get('classes')}
        return f" and defect.mansemclass not in {tuple(class_diff)}"   if len(class_diff)>0 else ''                                                                                                                   