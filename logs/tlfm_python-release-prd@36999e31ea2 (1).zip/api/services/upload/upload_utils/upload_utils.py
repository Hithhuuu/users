"""Utils file for data load API"""
import os
import asyncio
import datetime
import math
import json
import aiohttp
from pathlib import Path
import numpy as np
import pandas as pd

from api.services.upload.fastapi_app import get_query_with_pool, insert_data
from api.services.upload.utils import (get_column_details,
    get_logger,
    queries,decrypt
)

app_log = get_logger("dataload")
DATALOAD_QUERY = queries["upload"]["dataload"]
UPLOAD_QUERY = queries["upload"]["upload"]

columns_info = get_column_details("columns")
DEFAULT_BATCH_SIZE = 50000
DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFECT_WIP_COLUMN = [
    "diepitch_x",
    "diepitch_y",
    "dieorigin_x",
    "dieorigin_y",
    "scl_x",
    "scl_y",
    "diepitch_x_up",
    "diepitch_y_up",
    "diepitch_x_down",
    "diepitch_y_down",
    "diepitch_x_left",
    "diepitch_y_left",
    "diepitch_x_right",
    "diepitch_y_right",
    "scl_x_up",
    "scl_y_up",
    "scl_x_right",
    "scl_y_right",
    "scl_x_down",
    "scl_y_down",
    "scl_x_left",
    "scl_y_left",
]

class UploadUtils:
    """this class provides methods for upload utils"""

    async def verify_mapname(self,header_df, filetype, username, filename):
        """Verify if file is valid"""
        try:
            app_log.info("Checking if record already exists..")
            header_df["resulttimestamp"] = pd.to_datetime(header_df["resulttimestamp"])
            header_df["resulttimestamp"] = header_df["resulttimestamp"].dt.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
            query_data = {}
            mapelements = map(
                str,
                [
                    username,
                    header_df["product"][0],
                    header_df["layer"][0],
                    header_df["setupid"][0],
                    header_df["carrierid"][0],
                    header_df["waferid"][0],
                    filename,
                    header_df["resulttimestamp"][0],
                    filetype
                ],
            )
            query_data["filename"] = filename
            query_data["mapname"] = "|".join(mapelements)
            query_data["product"] = header_df.iloc[0]["product"]
            query_data["layer"] = header_df.iloc[0]["layer"]
            query_data["carrierid"] = header_df.iloc[0]["carrierid"]
            query_data["waferid"] = header_df.iloc[0]["waferid"]
            if filetype.upper() in ["ADC","KLARITY"]:
                app_log.info("Verify if tlf file exists for ADC/KLARITY data..")
                output = await self.verify_adcdata(filetype, query_data)
                return {
                    "exists": bool(output["mapid"]),
                    "mapname": query_data["mapname"],
                    "mapid": output["mapid"] if output["mapid"] else "",
                    "klarity_flag": output["klarity_flag"],
                    "tlf_tool": output["tlf_tool"]
                }
            app_log.info("Fetch mapid if record already exists..")
            query = DATALOAD_QUERY["mapid"].format(**query_data)
            header_data = await get_query_with_pool(query)
            exists = bool(header_data)
            return {
                "exists": exists,
                "mapname": query_data["mapname"],
                "mapid": header_data[0]["mapid"] if header_data else "",
            }
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": filename}
            data["err_msg"] = f"Error while verifying mapname. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def verify_adcdata(self, filetype, query_data):
        """ADC file validation"""
        try:
            klarity_flag = False
            app_log.info("Check if tlf record is present in header table..")
            record_exists_query = DATALOAD_QUERY["adc_mapid"].format(**query_data)
            mapid = await get_query_with_pool(record_exists_query)
            tlftool = mapid[0]['tool'] if mapid else None
            mapid = mapid[0]["mapid"] if mapid else None
            # check if klarity file is already uploaded for the tlf file
            if filetype.upper() == "ADC" and mapid:
                klarity_query = DATALOAD_QUERY["check_klarity"].format(**query_data)
                app_log.info(
                    "Check if KLARITY file is already present for incoming ADC file.."
                )
                uid = await get_query_with_pool(klarity_query)
                if uid:
                    app_log.info("KLARITY file already loaded")
                    klarity_flag = True
            return {"mapid": mapid, "klarity_flag": klarity_flag, "tlf_tool": tlftool }
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": query_data["filename"]}
            data["err_msg"] = f"Error while verifying adcdata. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def insert_job_log(self,data, status):
        """Insert/Update the job status of file upload"""
        try:

            app_log.info(
                f"Insert/Update the status in job log table with the status..{status}"
            )
            app_log.info(data.get("filename"))
            upload_data = {
                    "tool_name": data.get("tool","NA"),
                    "file_name": data.get("filename"),
                    "file_path": data.get("abs_path",""),
                    "id" : "",
                    "id_name":""
                }
            if status == "created":
                if data.get('id'):
                    upload_data['id'] = f"{data.get('id')},"
                    upload_data['re_try'] = 1
                    upload_data['id_name']= 'id,'
                query_to_execute = UPLOAD_QUERY["create"].format(**upload_data)
                app_log.info(query_to_execute)
                await get_query_with_pool(query_to_execute, resp_type="None")
            else:
                upload_data["err_message"]  = data.get("err_msg", "").replace("'", '"')
                upload_data['process_start_time'] = 'process_start_time,'
                if status == "picked":
                    upload_data['process_start_time'] = 'now() as process_start_time,'
                query_to_execute = UPLOAD_QUERY["fetch_job_id"].format(**upload_data)
                id_res = await get_query_with_pool(query_to_execute)
                app_log.info(id_res)
                upload_data["id"] = id_res[0]["id"]
                upload_data["job_status"] = status
                upload_data["unique_header_id"] = data.get("mapname", "")
                upload_data["file_cnt"] = data.get("total_cnt", 0)
                upload_data["ch_cnt"] = data.get("total_cnt", 0)
                query_to_execute = UPLOAD_QUERY["update_job_log"].format(**upload_data)
                await get_query_with_pool(query_to_execute, resp_type="None")
        except Exception as err:
            app_log.exception(err)

    async def archive_user_file(self,file_path, file_name, file_type):
        """Move the incoming file to archive"""
        base_path = os.getenv("watchdog_pick_location")
        dated_folder = datetime.datetime.now().strftime("%d%b%Y")
        complete_path = os.path.join(base_path, "Userload", dated_folder, file_type)
        app_log.info("Moving to archived folder")
        try:
            Path(complete_path).mkdir(parents=True, exist_ok=True)
            cmd_to_mv = (
                f"""mv -f "{file_path}" "{os.path.join(complete_path, file_name)}" """
            )
            os.system(cmd_to_mv)
        except Exception as err:
            app_log.exception(f"Unable to move this file to Archive location. {err}")
        return complete_path

    async def dataload(self, main_df, header_df, unique_data):
        """Load data to clickhouse"""
        start_time = datetime.datetime.now()
        app_log.info("Create an picked entry in JOB log table..")
        await self.insert_job_log(unique_data, status="picked")
        try:
            query_data = {}
            query_data["mapname"] = unique_data["mapname"]
            query_data["product"] = header_df.iloc[0]["product"]
            query_data["layer"] = header_df.iloc[0]["layer"]
            query_data["carrierid"] = header_df.iloc[0]["carrierid"]
            query_data["waferid"] = header_df.iloc[0]["waferid"]
            query_data["setupid"] = header_df.iloc[0]["setupid"]
            query_data["src_tool"] = header_df.iloc[0]["src_tool"]
            app_log.info(
                "Marking the older record in header table as 0 before inserting new data.."
            )
            rfgquery = DATALOAD_QUERY["rfgquery"].format(**query_data)
            await get_query_with_pool(rfgquery, resp_type="None")
            app_log.info("Loading the data to clickhouse....")
            main_df = await self.process_main_df(main_df, header_df)
            if unique_data["mapid"] != "" and unique_data["filetype"].lower() in [
                "adc",
                "klarity",
            ]:
                app_log.info(
                    f"Getting resulttimestamp of tlf data from header table..")
                abc = DATALOAD_QUERY["rslttsmp_query"].format(**unique_data)
                rslttsmp = await get_query_with_pool(
                    DATALOAD_QUERY["rslttsmp_query"].format(**unique_data)
                )
                main_df["resulttimestamp"] = rslttsmp[0]["resulttimestamp"].strftime(DATETIME_FORMAT) if rslttsmp else header_df.resulttimestamp[0]
            main_df["src_tool"] = unique_data["filetype"]
            app_log.info(
                "Add header cols to WIP table to calculate default values..")
            main_df[DEFECT_WIP_COLUMN] = header_df[DEFECT_WIP_COLUMN].iloc[0]
            header_df["setupid"] = header_df["recipeid"] if "recipeid" in header_df.columns else header_df["setupid"]
            header_df["rfg"] = 1
            if unique_data["mapid"] != "":
                app_log.info("Add mapid to header from unique data dict..")
                header_df["mapid"] = unique_data["mapid"]
            app_log.info(
                "Format datetime columns in main and header dataframe")
            header_df["cdt"] = pd.to_datetime(header_df["cdt"])
            header_df["cdt"] = header_df["cdt"].dt.strftime(DATETIME_FORMAT)
            header_df["filetimestamp"] = pd.to_datetime(
                header_df["filetimestamp"])
            header_df["resulttimestamp"] = pd.to_datetime(
                header_df["resulttimestamp"])
            header_df["filetimestamp"] = header_df["filetimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            header_df["resulttimestamp"] = header_df["resulttimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            main_df["resulttimestamp"] = pd.to_datetime(
                main_df["resulttimestamp"])
            main_df["resulttimestamp"] = main_df["resulttimestamp"].dt.strftime(
                DATETIME_FORMAT
            )
            if main_df['dynamic'].isna().any():
                main_df['dynamic'] = [{} for i in range(0,len(main_df))]
            await self.push_data(header_df, main_df,unique_data)
            app_log.info(
                f"Total time to load data to clickhouse: {datetime.datetime.now() - start_time}"
            )
            app_log.info("Create an successful entry in JOB log table..")
            unique_data["total_cnt"] = len(main_df)
            await self.insert_job_log(unique_data, status="successful")
            if header_df.src_tool[0].lower() in ['adc','klarity']:
                await self.alert_trigger(header_df)
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while loading data. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def unified_map(self,header_df, unique_data):
        query_data = {}
        if unique_data['exists'] and unique_data['filetype'].lower() in ['adc','klarity']:
            header_df['mapid'] = unique_data['mapid']
            header_df['tool'] = unique_data['tlf_tool'] if unique_data['tool'].lower() in ['adc','klarity'] else header_df['tool']
            query_data["product"] = header_df.iloc[0]["product"]
            query_data["layer"] = header_df.iloc[0]["layer"]
            query_data["carrierid"] = header_df.iloc[0]["carrierid"]
            query_data["waferid"] = header_df.iloc[0]["waferid"]
            query_data["setupid"] = header_df.iloc[0]["setupid"]
            rfg_query =  DATALOAD_QUERY["tlfrfg"].format(**query_data)
            await get_query_with_pool(rfg_query, resp_type="None")
        return header_df

    async def push_data(self,header_df, main_df, unique_data):
        """Push the data to clickhouse"""
        try:
            app_log.info("Inserting header data...")
            # header_df = header_df[[x for x in list(columns_info['header_cols'].keys()) if x in header_df.columns]]
            header_df = await self.unified_map(header_df,unique_data)
            cols = ",".join([item.replace("'", "") for item in header_df.columns])
            query_to_execute = f"INSERT INTO tlf.tlf_map_header ({cols}) VALUES "
            await insert_data(
                query_to_execute,
                [tuple(x) for x in header_df.to_records(index=False)]
            )
            app_log.info("Header data inserted...")
            app_log.info("Fetch Mapid for the file loaded..")
            query_to_execute = DATALOAD_QUERY["mapid"].format(
                **{"mapname": header_df.loc[0, "mapname"]}
            )
            mapid = await get_query_with_pool(query_to_execute)
            main_df["mapid"] = mapid[0]["mapid"]
            # main_df = main_df[[x for x in list(columns_info['main_cols'].keys()) if x in main_df.columns]]
            app_log.info("Inserting main data...")
            cols = ",".join([item.replace("'", "") for item in main_df.columns])
            query_to_execute = f"INSERT INTO tlf.tlf_defect_main_wip ({cols}) VALUES "
            splits = round(
                1
                if len(main_df) < int(DEFAULT_BATCH_SIZE)
                else len(main_df) / int(DEFAULT_BATCH_SIZE)
            )
            if splits > 1:
                app_log.info(f"Splitting the main df into {splits} batches")
                main_df_split = np.array_split(main_df, splits)
            else:
                main_df_split = [main_df]
            ## Create a coroutine list where insert data will have the data splits as input
            coros = [
                insert_data(
                    query_to_execute,
                    [tuple(x) for x in i.to_records(index=False)]
                )
                for i in main_df_split
            ]
            # run the tasks to execute inserts parallely
            await asyncio.gather(*coros)
            insert_defect_main_query = DATALOAD_QUERY["insert_defect_main"].format(
                **{"mapid": mapid[0]["mapid"], "src_tool": header_df.loc[0, "src_tool"]}
            )
            await get_query_with_pool(insert_defect_main_query, resp_type="None")
            app_log.info("Main data inserted..")
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while inserting data to clickhouse. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def process_header_df(self,head_df):
        """Process the header dataframe"""
        try:
            app_log.info("Enrich the header df with calculations and missing columns..")
            head_df.columns = head_df.columns.str.lower()
            head_df[["diepitch_x", "diepitch_y"]] = head_df["diepitch"].str.split(
                ",", expand=True
            )
            head_df[["dieorigin_x", "dieorigin_y"]] = head_df["dieorigin"].str.split(
                ",", expand=True
            )
            head_df[["scl_x", "scl_y"]] = head_df["samplecenterlocation"].str.split(
                ",", expand=True
            )
            head_df = head_df.drop(
                ["diepitch", "dieorigin", "samplecenterlocation"], axis=1
            )
            head_df = head_df.rename(columns=columns_info.get("alias_dict"))
            app_log.info("Add missing columns with default empty values..")
            # diff_cols = set(columns_info["header_cols"].keys()).difference(head_df.columns)
            # for col in diff_cols:
            #     if columns_info["header_cols"][col] == np.int64:
            #         head_df[col] = -999999999
            #     else:
            #         if col != "mapid":
            #             head_df[col] = pd.Series(dtype=columns_info["header_cols"][col])
            head_df = head_df.astype(columns_info["header_cols"])
            if not head_df.at[0, "orientationmarklocation"] in [
                "TOP",
                "RIGHT",
                "DOWN",
                "LEFT",
            ]:
                head_df["orientationmarklocation"] = head_df.at[
                    0, "orientationmarklocation"
                ].split(".")[0]
            head_df["orientationmarklocation"] = head_df["orientationmarklocation"].replace(
                columns_info["orientation_data"]
            )
            head_df = await self.add_oriented_col_header(head_df)
            return head_df
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": head_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while processing header df. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def add_oriented_col_header(self, header_df):
        """Adding oriented columns in header dataframe"""
        app_log.info("Add UP,LEFT,RIGHT,DOWN orientations in header..")
        try:
            header_df["diepitch_x_up"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_up"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_up"] = np.select(
                [
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_up"] = np.select(
                [
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_down"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_down"] = np.select(
                [
                    (header_df.orientationmarklocation == "RIGHT")
                    | (header_df.orientationmarklocation == "LEFT")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_down"] = np.select(
                [
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_down"] = np.select(
                [
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_left"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_left"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_left"] = np.select(
                [
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )

            header_df["scl_y_left"] = np.select(
                [
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "LEFT",
                    header_df.orientationmarklocation == "RIGHT",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )

            header_df["diepitch_x_right"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_y"]],
                default=header_df["diepitch_x"],
            )
            header_df["diepitch_y_right"] = np.select(
                [
                    (header_df.orientationmarklocation == "UP")
                    | (header_df.orientationmarklocation == "DOWN")
                ],
                [header_df["diepitch_x"]],
                default=header_df["diepitch_y"],
            )

            header_df["scl_x_right"] = np.select(
                [
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                ],
                [
                    (
                        header_df["scl_x"] *
                        round(math.cos(-90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(-90 * math.pi / 180), 0)
                    ),
                    (
                        header_df["scl_x"] *
                        round(math.cos(90 * math.pi / 180), 0)
                        + header_df["scl_y"] *
                        round(math.sin(90 * math.pi / 180), 0)
                    ),
                    header_df["scl_x"],
                    (
                        header_df["scl_x"] * round(math.cos(math.pi), 0)
                        + header_df["scl_y"] * round(math.sin(math.pi), 0)
                    ),
                ],
                default=header_df["scl_x"],
            )
            header_df["scl_y_right"] = np.select(
                [
                    header_df.orientationmarklocation == "DOWN",
                    header_df.orientationmarklocation == "UP",
                    header_df.orientationmarklocation == "RIGHT",
                    header_df.orientationmarklocation == "LEFT",
                ],
                [
                    -header_df["scl_x"] *
                    round(math.sin(-90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(-90 * math.pi / 180), 0),
                    -header_df["scl_x"] *
                    round(math.sin(90 * math.pi / 180), 0)
                    + header_df["scl_y"] *
                    round(math.cos(90 * math.pi / 180), 0),
                    header_df["scl_y"],
                    -header_df["scl_x"] * round(math.sin(math.pi), 0)
                    + header_df["scl_y"] * round(math.cos(math.pi), 0),
                ],
                default=header_df["scl_y"],
            )
            return header_df
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while adding orientation columns. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def process_main_df(self, main_df, header_df):
        """Process main df"""
        try:
            app_log.info("Enrich the main df with proper data..")
            main_df.columns = [col.lower() for col in main_df.columns]
            # main_df = main_df.apply(pd.to_numeric, errors="coerce")
            main_df["product"] = header_df.iloc[0]["product"]
            main_df["layer"] = header_df.iloc[0]["layer"]
            main_df["carrierid"] = header_df.iloc[0]["carrierid"]
            main_df["waferid"] = header_df.iloc[0]["waferid"]
            main_df["platform"] = header_df.iloc[0]["platform"]
            main_df["setupid"] = header_df.iloc[0]["setupid"]
            main_df["resulttimestamp"] = header_df["resulttimestamp"].iloc[0]
            if (
                "alroughbinnumber" not in main_df.columns
                or "roughbinnumber" in main_df.columns
                or (
                    "alroughbinnumber" in main_df.columns
                    and "roughbinnumber" in main_df.columns
                )
            ):
                main_df.rename(
                    columns=columns_info["alias_dict"], inplace=True)
            elif (
                "alroughbinnumber" in main_df.columns
                and "roughbinnumber" not in main_df.columns
            ):
                main_df.rename(
                    columns=columns_info["alias_dict_bin"], inplace=True)
            app_log.info("Format the columns to their proper datatype..")
            for i in main_df.columns:
                if i in columns_info["main_cols"].keys():
                    if columns_info["main_cols"][i] in [np.int64, np.float64]:
                        main_df[i] = (
                            main_df[i]

                            .replace([np.nan], [-9999999])
                            .astype(columns_info["main_cols"][i])
                            .replace([-9999999], [None])
                        )
                    else:
                        if i!= 'dynamic' :
                            main_df[i] = main_df[i].astype(
                                columns_info["main_cols"][i])
            return main_df
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data = {"filename": header_df.iloc[0]["filename"]}
            data["err_msg"] = f"Error while processing main df. {err}"
            await self.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def alert_trigger(self,header_df):
        payload  = {
                    "filename": header_df.iloc[0]["filename"],
                    "stepid": header_df.iloc[0]["layer"],
                    "deviceid": header_df.iloc[0]["product"],
                    "waferid": header_df.iloc[0]["waferid"],
                    "setupid": header_df.iloc[0]["setupid"],
                    "carrierid": header_df.iloc[0]["carrierid"],
                    "toolid": header_df.iloc[0]["tool"],
                    "slot": header_df.iloc[0]["slotnumber"],
                    "inspectiontool": header_df.iloc[0]["platform"].split(' ')[-1],
                    "unique_header_id":header_df.iloc[0]["mapname"],
                    "reportfrequency": "Immediately"
                    }
        bearer = await get_auth_token()
        headers = {"Content-Type": "application/json","Authorization": f"Bearer {await get_auth_token()}"}
        url = os.getenv("alertvalidate")
        app_log.info(f"payload -> {payload}")
        app_log.info(f"header -> {headers}")
        app_log.info(f"url -> {url}")
        status, response = await req_url(url, payload, headers,method ='post', resp_type=True, payload_type=True)


async def req_url(url, payload, headers,method='post', resp_type=False,payload_type = False):
    """
    Sends a POST request to the specified URL with the given payload and headers.

    Parameters:
    - url (str): The URL to send the request to.
    - payload (dict): The payload to include in the request body.
    - headers (dict): The headers to include in the request.
    - resp_type (bool, optional): Whether to parse the response as JSON. Defaults to False.
    - payload_type (bool, optional): Whether to convert the payload to JSON. Defaults to False.

    Returns:
    - sh_report_resp (int): The HTTP status code of the response.
    - resp (dict or None): The parsed JSON response, if resp_type is True. Otherwise, None.
    """
    if payload_type:
        payload =  json.dumps(payload)
    async with aiohttp.ClientSession() as session:
        if method =='post':
            async with session.post(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
                data = None
                if response.headers['Content-Type'] == 'application/json':
                    data = await response.json()
                else:
                    data = await response.text()
        elif method =='put':
            async with session.put(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
                data = None
                if response.headers['Content-Type'] == 'application/json':
                    data = await response.json()
                else:
                    data = await response.text()
    return sh_report_resp, data

async def get_auth_token():
    """
    Retrieves the authentication token by making an API call to get the Auth Token.

    Returns:
        str: The authentication token (JWT).

    Raises:
        RuntimeError: If the Auth Token API request fails.
    """
    app_log.info(f"Auth token api call to get the Auth Token.")
    payload = {
        "userid": "superadmin",
        "password": "U2FsdGVkX1+OBM5UuxMVfNRZ0y3F7mXAwsv32jmYigs=",
    }

    headers = {"Content-Type": "application/json"}
    status, response = await req_url(os.getenv("authurl"), payload, headers, resp_type=True, payload_type=True)
    token_resp = json.loads(
        decrypt(response["encryptedData"],bytes("c2VjcmV0cGFzc3dvcmRwaHJhc2U=", "utf-8"),).decode("utf-8"))
    app_log.info(
        f"Auth Token Api status_code: {status}, "
    )
    if status != 200:
        raise RuntimeError("Auth Token API request Failed")
    json_token_resp = token_resp
    return json_token_resp["jwt"]
