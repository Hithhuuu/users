"""Auth file for application"""
import os
from jose.jwt import decode
from jose.exceptions import JWTError
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from api.services.user.utils import env_config

SECRET_KEY = os.getenv('SECRET_KEY')

auth_scheme = HTTPBearer()


async def verify_jwt(authorization: HTTPAuthorizationCredentials = Depends(auth_scheme)):
    jwt_token = authorization.credentials
    try:
        decode(jwt_token, SECRET_KEY, algorithms="HS256")
    except JWTError:
        raise HTTPException(status_code=401, detail="Unauthorized token")


async def get_auth_data(authorization_header):
    if not (request.url.path.endswith("/auth")):
        jwt_token = authorization_header.split()[1]
        return decode(jwt_token, SECRET_KEY, algorithms="HS256")
