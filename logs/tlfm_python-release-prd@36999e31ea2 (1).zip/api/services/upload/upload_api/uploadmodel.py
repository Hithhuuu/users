"""Model for upload"""
import asyncio
from datetime import datetime
from api.services.upload.utils import get_logger, get_queries,queries
from api.services.upload.upload_utils.parser import parse_klarf
from api.services.upload.upload_utils.upload_utils import UploadUtils
from api.services.upload.fastapi_app import insert_data, get_query_with_pool
app_log = get_logger("upload")


class Upload:
    """Class for model"""

    def __init__(self):
        """Initialize Upload process."""
        self.queries = queries["upload"]["upload"]
        self.utils = UploadUtils()

    async def post(self, file_data, data):
        """Verify if data already exists or not. If it doesn't then load data to DB."""
        filetype = data["typeoffile"].strip()
        filename = data["filename"]
        app_log.info("Create an entry in JOB log table..")
        if filename.split('.')[-1]  in ['tiff', 'tif', 'png', 'bmp', 'gif', 'jpeg', 'xml', 'log', 'xls', 'xlsx', 'doc', 'docx', 'jpg', 'pdf', 'ppt','pptx', 'emsa', 'bcf', 'txt', 'csv', 'png', 'mp3', 'wav', 'zip', 'rar', 'htm', 'html', 'css', 'js', 'exe', 'bat', 'py']:
            return {"process_error": "file not supported"}
        await self.utils.insert_job_log(data, status="created")
        app_log.info("Extracting data from file..")
        try:
            header_df, main_df = await parse_klarf(file_data)
            if "tlfscore" not in main_df.columns or "mansemclass" not in main_df.columns:
                await self.utils.insert_job_log(data, status="failure")
                return {"process_error": "file error"}
        except Exception as err:
            app_log.exception(err)
            await self.utils.insert_job_log(data, status="failure")
            return {"process_error": "Parser Failed"}
        if not header_df.empty and not main_df.empty:
            if "recipeid" in header_df.columns:
                header_df["setupid"] = header_df["recipeid"]
            header_df["defectcnt"] = main_df.shape[0]
            header_df["filename"] = filename
            header_df["filesize"] = data["filesize"]
            header_df["src_tool"] = filetype
            header_df["cby"] = data["username"]
            header_df["tifffilename"] = "NA"  # Change this accordingly.
            header_df["cdt"] = str(datetime.now())
            header_df["tool"] = data.get("tool", "NA")
            header_df = await self.utils.process_header_df(header_df)
            unique_data = await self.utils.verify_mapname(
                header_df, filetype, data["username"], filename
            )
            header_df["mapname"] = unique_data["mapname"]
            if not unique_data["exists"] and filetype.upper() in ["ADC", "KLARITY"]:
                app_log.info(
                    "Did not find any record in the Header table for given ADC/KLARITY file"
                )
                app_log.info("Create an invalid entry in JOB log table..")
                data[
                    "err_msg"
                ] = "Did not find any record in the Header table for given ADC/KLARITY file"
                await self.utils.insert_job_log(data, status="invalid")
                return {
                    "process_error": "Did not find any record in the Header table for given ADC file"
                }
            if (
                unique_data["exists"]
                and filetype.upper() in ["ADC"]
                and unique_data["klarity_flag"]
            ):
                app_log.info("KLARITY file already exists")
                app_log.info("Create an invalid entry in JOB log table..")
                data["err_msg"] = "KLARITY file already exists"
                await self.utils.insert_job_log(data, status="invalid")
                return {"process_error": "Klarity file exists"}
            try:
                unique_data["filetype"] = filetype
                unique_data["filename"] = filename
                unique_data['tool'] = data.get("tool", "NA")
                if data.get("endpoint") and unique_data['tool'] == "NA":
                    with open(data["abs_path"], 'w') as f:
                        f.writelines(file_data)
                    complete_path = await self.utils.archive_user_file(
                        data["abs_path"], filename, filetype
                    )
                    unique_data["archive_path"] = complete_path
                loop = asyncio.get_running_loop()
                loop.create_task(
                    self.utils.dataload(main_df, header_df,
                                        unique_data)
                )

                resp_json = {"status": "upload started"}

            except Exception as err:
                resp_json = {"upload": "failed", "error": str(err)}
                if resp_json["error"] == "Klarf file is missing":
                    resp_json["klarf"] = False
                app_log.info("Create an failure entry in JOB log table..")
                data["err_msg"] = err
                await self.utils.insert_job_log(data, status="failure")
                return resp_json
            return resp_json
        app_log.error("Header or Main dataframe is empty")
        app_log.info("Create an invalid entry in JOB log table..")
        data["err_msg"] = "File is empty."
        await self.utils.insert_job_log(data, status="invalid")
        return {"error": "Header or Main dataframe is empty"}

    async def csv_uplaod(self,file_data,data):
        """this method verifies and inserts data in db"""
        try:
            app_log.info("Create an entry in JOB log table..")
            await self.utils.insert_job_log(data, status="created")
            csv_df= file_data
            csv_df.rename(columns={"Class number":"classnumber","Class name":"classname","Group name":"groupname"},inplace=True)
            csv_df.fillna('', inplace=True)
            csv_df.classname =  csv_df.classname.astype(str)
            csv_df.groupname = csv_df.groupname.astype(str)
            app_log.info("inserting csv data ... ")
            cols = ",".join([item.replace("'", "") for item in csv_df.columns])
            query_to_execute = f"INSERT INTO tlf.tlf_usergroup ({cols}) VALUES "
            await insert_data(
                query_to_execute,
                [tuple(x) for x in csv_df.to_records(index=False)]
            )
            app_log.info("CSV data inserted...")
            await self.utils.insert_job_log(data, status="successful")
            return {"status": "file upload is success"}
        except Exception as err:
            app_log.info("Create an failure entry in JOB log table..")
            data["err_msg"] = f"Error while verifying mapname. {err}"
            await self.utils.insert_job_log(data, status="failed")
            app_log.exception(err)
            raise err

    async def get_progress_status(self,data):
        start_time = datetime.now()
        try:
            app_log.info("%s API triggered..", data["endpoint"])
            request_data = data['data']
            tlf_file_list = []
            file_type = []
            progress_data = []
            for rec in request_data:
                tlf_file_list.append(rec["filename"])
                file_type.append(rec["type"])

            if len(tlf_file_list) > 0:
                filelist = "', '".join(tlf_file_list)
                q_data = {"filenames": filelist,
                          "file_type": tuple(list(set(file_type)))}
                progress_data = await get_query_with_pool(
                    self.queries["upload_progress"].format(**q_data)
                )
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            app_log.info(
                "%s api took %s to complete",
                data["endpoint"],
                str(datetime.datetime.now() - start_time),
            )
            return {"error": str(err)}
        return progress_data

    async def get_history(self, data):
        """this method gives file history"""
        try:
            app_log.info('Start of the File History API')
            if data['type'] == 'adc':
                query_to_execute = self.queries['read_adc_history'].format(**data)
            elif data['type'] == 'tlf':
                query_to_execute = self.queries['read_tlf_history'].format(**data)
            data_output = await get_query_with_pool(query_to_execute)
        except Exception as err:
            app_log.exception(err)
            app_log.info("History API failed")
            return {'error': str(err)}
        return data_output

