"""Handler for upload"""
import pandas as pd
from typing import Optional,List
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter, File, Form, Depends
from api.services.upload.fastapi_app import verify_jwt, get_query_with_pool
from api.services.upload.utils import get_logger
from api.services.upload.upload_api.uploadmodel import Upload


app_log = get_logger("upload")
uploadmodel = Upload()
router = APIRouter(prefix="/upload",dependencies=[Depends(verify_jwt)])


@router.post("")
async def post(
    request: Request,
    # file: bytes = File(),
    # userid: str = Form(),
    # filename: str = Form(),
    # type: str = Form(),
    # filesize: str = Form(),
    # tool: Optional[str]= Form(None),
    # tool_path: Optional[str]= Form(None),
):
    """On POST request upload a file"""
    data = dict(await request.form())
    file =  data.get("file").file.read()
    data["username"] = data.get('userid')
    data["typeoffile"] = data.get('type')
    data["endpoint"] = request.url.path
    data["abs_path"] = f"api\\services\\upload\\{data['filename']}"
    if  data.get('tool'):
        data["abs_path"] = data.get('tool_path')
    resp_json = await uploadmodel.post(file.decode("utf-8").splitlines(), data)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()) :
        if  "process error"  in list(resp_json.keys()):
            return JSONResponse(
                status_code=415,
                content=resp_json,
            )
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)

@router.post("/csv")
async def csv_post(
    request: Request,
#     file: bytes = File(),
#     userid: str = Form(),
#     filename: str = Form(),
#     type: str = Form(),
#     filesize: str = Form(),
):
    """On POST request upload a file"""
    data = await request.form()
    file =  data.get("file").file.read()
    data["username"] = data.get('userid')
    data["typeoffile"] = data.get("type")
    data["endpoint"] = request.url.path
    data["abs_path"] = f"api\\services\\upload\\{data.get('filename')}"
    resp_json = await uploadmodel.csv_uplaod(pd.read_excel(file), data)
    if isinstance(resp_json, dict) and "error" in list(resp_json.keys()):
        return JSONResponse(
            status_code=400,
            content=resp_json,
        )
    return JSONResponse(resp_json)

@router.post("/progress")
async def progress(request: Request):
    """On POST request get progress of file upload"""
    data = {}
    data["data"] = await request.json()
    data["endpoint"] = request.url.path
    resp = await uploadmodel.get_progress_status(data)
    if isinstance(resp, dict) and "error" in list(resp.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": resp.get("error")},
        )
    return JSONResponse(resp)

@router.post("/status")
async def status(request: Request):
    """On POST request get status of file upload"""
    files = []
    resp = []
    body = await request.json()
    for rec in body:
        files.append(rec["filename"])
    if len(files) <= 0:
        return JSONResponse(
            status_code=400,
            content={"message": "No Files selected"},
        )

    filelist = "', '".join(files)
    query = f"select id, file_name as task_id, job_status as status, cast(process_start_time as String) process_start_time, cast(process_end_time as String) date_done, err_message as traceback from tlf_job_log final where file_name in  ('{filelist}')"
    resp = await get_query_with_pool(query)
    return JSONResponse(resp)


@router.post("/history")
async def tlf_history(request : Request, body : dict):
    """On post request get list of  file upload history"""
    resp = await uploadmodel.get_history(body)
    if isinstance(resp, dict) and "error" in list(resp.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": resp.get("error")},
        )
    return JSONResponse(resp)
