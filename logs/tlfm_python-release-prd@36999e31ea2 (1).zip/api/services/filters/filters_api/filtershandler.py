"""Handler for Filters API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.services.filters.filters_api.filtersmodel import Filters
from fastapi_app import verify_jwt
router = APIRouter(prefix="/filters",dependencies=[Depends(verify_jwt)])
filters = Filters()


@router.post("/gfilter")
async def gfilter(request: Request, body: dict):
    """On POST request return global filters as JSON"""
    response = await filters.gfilter(request = request, data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/usergroup")
async def usergroups(request: Request, body: dict):
    """On POST request return global filters as JSON"""
    response = await filters.usergroup(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/sfilter")
async def post(request: Request, body: dict):
    """On post request fetch Secondary Filters"""
    resp = await filters.sfilter(data=body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)

@router.post("/alerts")
async def alert_filter(request: Request, body: dict):
    """On post request fetch Secondary Filters"""
    resp = await filters.alert(data=body)
    if "error" in resp:
        return JSONResponse(
            status_code=400,
            content={"message": "Something went wrong"},
        )
    return JSONResponse(content=resp)

