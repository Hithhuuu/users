"""Model for filters API"""
import os
import datetime
from jwt import decode
from api.services.filters.fastapi_app import get_query_with_pool
from api.services.filters.utils import get_logger,queries,get_filter_config

app_log = get_logger("filters")


class Filters:
    """This class provides methods to get filters"""

    def __init__(self):
        """Initializing filter queries"""
        self.queries = queries["filters"]
        self.utils  =  Utils()

    async def gfilter(self,request, data):
        """Get global filters"""
        data["template_owner"] =  self.utils.get_user(request)["userid"]
        start_time = datetime.datetime.now()
        try:
            app_log.info("Global Filters API triggered..")
            query_data = {}
            query_data["no_run_option"] = data["no_run_option"]
            if data["no_run_option"] == "0":
                # timestamp query
                query_data["num_run"] = 10000
            elif data["no_run_option"] == "1":
                # runid query
                query_data["num_run"] = data["no_run"]
                data.pop("timestamp", "")
            elif data["no_run_option"] == "2":
                # only header data
                data.pop("timestamp", "")
            query_data.update(await self.utils.get_templates_condition(data))
            query_data["template_owner"] = data["template_owner"]
            app_log.info("Query conditions prepared")
            query_to_execute = self.queries["globalfilter"].format(**query_data)
            app_log.info("Query parameters created.")
            data_output = await get_query_with_pool(query_to_execute,resp_type='dict')
            app_log.info("Formatting data....")
            resp = data_output[0]
            if data["no_run_option"] == "2":
                resp.pop("from_date")
                resp.pop("toolid")
                resp.pop("inspectionstationid")
                resp = [{"name": k, "values": v} for k, v in resp.items()]
            else:
                resp = [
                    {
                        "name": k,
                        "values": v
                        if k not in ["from_date", "templates"]
                        else v
                    }
                    for k, v in resp.items()
                ]
            app_log.info(
                "filters/gfilter api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return resp


    async def usergroup(self, data):
        """Get usergroup"""
        try:
            start_time = datetime.datetime.now()
            query_data = await self.utils.get_templates_condition(data)
            query_to_execute = self.queries["usergroup"].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute,resp_type='dict')
            app_log.info(
                "filters/gfilter api took %s to complete",
                str(datetime.datetime.now() - start_time),
            )
        except Exception as err:
            app_log.exception(err)
            return {"error": str(err)}
        return data_output


    async def sfilter(self,data):
        """get sfilter details """
        try:
            response=[]
            app_log.info("Get the secondary filter value")
            query_data = await self.utils.get_templates_condition(data)
            filter_query = self.queries["read_sfilters"].format(**query_data)
            data_output = await get_query_with_pool(filter_query,resp_type="dict")
            if not data_output:
                return []
            data_formatted = {
                k: sorted(
                    list(
                        set(
                            sum([d.get(k)
                                for d in data_output if k != "runid_val"], [])
                        )
                    )
                )
                for k in set().union(*data_output)
            }
            data_formatted["runid"] = sorted(
                    list(
                        set(
                            dict["runid_val"].replace("::", ": ")
                            for dict in data_output
                        )
                    ),
                    key=lambda x: int(x.split(": ")[0].split(" ")[-1]),
                )
            data_formatted.pop("runid_val")
            resp = [{"name": k, "values": sorted(v)}
                    for k, v in data_formatted.items() if k != "runid"]
            resp.append({
                "name":"runid", "values": data_formatted["runid"]
            })
        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return resp


    async def alert(self,data):
        """this method provides filter details for alert """
        try:
            app_log.info("Get the secondary filter value")
            query_data = await self.utils.alert(data)
            filter_query = self.queries["read_alert"].format(**query_data)
            data_output = await get_query_with_pool(filter_query,resp_type="dict")
            if not data_output:
                return []
            data_formatted = {
                k: sorted(
                    list(
                        set(
                            sum([d.get(k)
                                for d in data_output ], [])
                        )
                    )
                )
                for k in set().union(*data_output)
            }
            resp = [{"name": k, "values": sorted(v)}
                    for k, v in data_formatted.items() if k != "runid"]

        except Exception as e:
            app_log.exception(e)
            return {"error": str(e)}
        return resp

class Utils:
    """This class provides methods for filter utils """

    def get_user(self, request):
        """Get auth data"""
        auth = request.headers.get("Authorization")
        options = {
            "verify_signature": True,
            "verify_exp": True,
            "verify_nbf": False,
            "verify_iat": True,
            "verify_aud": False,
        }
        token = auth.split()[1]
        return decode(token, os.getenv("secret_key") if os.getenv("secret_key") else os.getenv("SECRET_KEY"), options=options, algorithms=["HS256"])


    async def get_templates_condition(self, data):
        """Get template conditions for query"""
        query_data ={'template_condition' : '',
                     'header_condition':''}
        if data.get('no_run_option') =='0':
            query_data['header_condition']= f" and toString(toDate(header.resulttimestamp)) >= '{data.get('timestamp').get('resulttimestamp').get('min')[:10]}' and toString(toDate(header.resulttimestamp)) <='{data.get('timestamp').get('resulttimestamp').get('max')[:10]}' "
        query_data['limits'] =  f'limit {data.get("no_run")}' if data.get('no_run_option') =='1' else ''
        filter_data =data.get('filters')
        if filter_data:
            query_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i,k in filter_data.get("gfilter").items() if len(k)>0 and '' not in k and i not in("inspectionstationid", "toolid")]
            header_list = [f"{i} in {tuple(k)if isinstance(k,list) or isinstance(k,tuple) else f'({k})'} " for i,k in filter_data.get("gfilter").items() if len(k)>0 and '' not in k and i  in("inspectionstationid", "toolid")] + query_list
            query_data['template_condition'] = f"and {' and '.join(query_list)}".replace("deviceid", "product").replace("stepid","layer").replace("recipeid","setupid") if len(query_list)>0 else ''
            query_data['header_condition'] = f"{query_data['header_condition']} and {' and '.join(header_list)}".replace("deviceid", "product").replace("stepid", "layer").replace("recipeid","setupid").replace("reviewtool", "tool").replace("toolid", "tool").replace('inspectionstationid',"splitByChar(' ', header.platform)[-1]") if len(header_list)>0 else ''
        return query_data


    async def make_query(self,data):
        """This function is used to create queries"""
        cols = ['deviceid','stepid','recipeid']
        query_data = {}
        query_condition = []
        for i in cols:
            if i in data.get('filters').get('gfilter') and len(data.get('filters').get('gfilter').get(i))>0:
                query_condition.append( f"header.{i} in {tuple(data.get('filters').get('gfilter').get(i))}")
            else :
                continue
        query_data['defect_cdtn'] = f"and {' and '.join(query_condition)}".replace('stepid', 'layer').replace(
            'recipeid', 'setupid').replace('header.', 'defect.').replace('deviceid', 'product')
        query_data['header_cdtn'] = query_data['defect_cdtn'].replace("defect.", "header.")
        return query_data

    async def alert(self,data):
        """this method provides query params for alert filter """
        query_data = {}
        query_condition = []
        cols = ['deviceid','stepid','reviewtool','inspectiontool']
        if len(data)>0:
            query_condition = [f"{i} in {data.get(i)}" for i in cols if data.get(i)]
        query_data['header_condition'] = f"and {' and '.join(query_condition)}" if len(query_condition)> 0  else ''
        return query_data