"""this model provides methods for CRUD operation on alerts """
import json
import traceback
import pandas as pd
from datetime import datetime

from api.services.alerts.fastapi_app import get_query_with_pool
from api.services.alerts.utils import get_logger, queries


app_log = get_logger("alerts")


class Alerts:
    """This class provides methods to get alert"""

    def __init__(self):
        """Initializing alert queries"""
        self.queries = queries["alerts"]
        self.utils = AlertUtils()

    async def get_alerts(self,data):
        """Gets the list of alerts for the current user.

        Args:
            data (dict): The data containing the user ID.

        Returns:
            dict: The response containing the list of alerts or an error message.
        """
        try:
            app_log.info("Preparing to get alert list")
            query_to_execute = self.queries['get_alert'].format(**{"username":data.get('userid')})
            resp=await get_query_with_pool(query_to_execute)
            response = await self.utils.response_formatter(resp)   
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert get API failed"}
        return response

    async def create_alert(self,data):
        """Inserts data to create an alert.

        Args:
            data (dict): The data containing the alert details.

        Returns:
            dict: The response indicating the success or failure of the alert creation.
        """
        try:
            app_log.info("Preparing to save alert")
            query_data = await self.utils.prepare_data(data, op_type="insert")
            query_to_execute = self.queries['create_alert'].format(**query_data)
            await get_query_with_pool(query_to_execute,resp_type="None")
            resp = {"msg": f"Alert created successfully"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert create API failed"}
        return resp

    async def update_alert(self,data):
        """Updates an existing alert.

        Args:
            data (dict): The data containing the updated alert details.

        Returns:
            dict: The response indicating the success or failure of the alert update.
        """
        try:
            app_log.info("Preparing to update alert")
            if data.get("reportstatus"):
                query_data = {
                    "id" : data.get('id'),
                    "reportstatus" : f'"{data.get("reportstatus")}"'
                }
                query_to_execute = self.queries['update_alertstatus'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                resp = await self.get_alerts({"userid": data.get("username")})
            else:
                query_data = await self.utils.prepare_data(data, op_type="update")
                query_to_execute = self.queries['update_alert'].format(**query_data)
                await get_query_with_pool(query_to_execute,resp_type="None")
                resp = {"msg": "Alert updated successfully"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert update API failed"}
        return resp

    async def delete_alert(self,data):
        """Deletes an alert based on the alert ID.

        Args:
            data (dict): The data containing the alert ID.

        Returns:
            dict: The response indicating the success or failure of the alert deletion.
        """
        try:
            app_log.info("Preparing to delete alert")
            query_to_execute = self.queries['delete_alert'].format(**{"id":data.get('id')})
            await get_query_with_pool(query_to_execute,resp_type="None")
            resp = {"msg": "Alert deleted successfully"}
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert delete API failed"}
        return resp

    async def get_details(self,data):
        """Provides details of an alert based on the alert ID.

        Args:
            data (dict): The data containing the alert ID.

        Returns:
            dict: The response containing the alert details or an error message.
        """
        try:
            app_log.info("Preparing to get alert details")
            query_to_execute = self.queries['get_alertdetails'].format(**{"id":data.get('id')})
            resp=await get_query_with_pool(query_to_execute)
            response = await self.utils.response_formatter(resp) 
        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': "Alert details API failed"}
        return response

class AlertUtils():
    """This class provides utility methods for CRUD operations on auto alerts"""

    async def prepare_data(self, data, op_type):
        """Formats the input data to insert into the database.

        Args:
            data (dict): The data containing the alert details.
            op_type (str): The operation type, either "insert" or "update".

        Returns:
            dict: The formatted data dictionary.
        """
        try:
            datetime_format = '%Y-%m-%d %H:%M:%S'
            dataselectionfilters = data.get('dataselectionfilters', '')
            dataselectionfilters.update({"type":data.get('basics').get("type")})
            if op_type == "insert":
                reportdayselected = data.get('basics').get('reportSchedule').get('when')
                data_dict = {
                    "reportname": f"""{data.get("basics").get('reportname')}""",
                    "username":data.get('username'),
                    "dashboardConnectedCount": len(data.get('dashboardfilters')) \
                        if data.get('dashboardfilters') else '' ,
                    "reportcreateddate": 
                        pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency": 
                    f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency', ''))}",
                    "reportstatus": f"{json.dumps(data.get('basics').get('status', ''))}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                    "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                    "rfg" : 1
                }

            elif op_type == "update":
                reportdayselected = data.get('basics').get('reportSchedule').get('when')
                data_dict = {
                    "id": data.get("id"),
                    "reportname": f"""{data.get("basics").get('reportname')}""",
                    "username":data.get('username'),
                    "dashboardConnectedCount": len(data.get('dashboardfilters')) \
                        if data.get('dashboardfilters') else '' ,
                    "reportcreateddate": 
                        pd.to_datetime(str(datetime.now())).strftime(datetime_format),
                    "reportdayselected": f"{json.dumps(reportdayselected)}",
                    "reportfrequency": 
                    f"{json.dumps(data.get('basics').get('reportSchedule').get('frequency', ''))}",
                    "reportstatus": f"{json.dumps(data.get('basics').get('status', ''))}",
                    "reportinvitees": f"{json.dumps(data.get('basics').get('invitees', ''))}",
                    "dataselectionfilters": f"{json.dumps(data.get('dataselectionfilters', ''))}",
                    "dashboardfilters": f"{json.dumps(data.get('dashboardfilters', ''))}",
                    "rfg" : data.get('rfg') if data.get('rfg',[]) else "rfg"
                }
        except Exception as err:
            app_log.error(f"{traceback.format_exc()}")
            app_log.error(f"Error while preparing data {err}")
            data_dict = {"error": f"Error while preparing data {err}"}

        return data_dict

    async def response_formatter(self,data):
        resp_list=[]
        for d, val in enumerate(data):
            resp = {}
            for i,k in data[d].items():
                try:
                    resp.update({i:json.loads(k)})
                except (Exception, TypeError):
                    resp.update({i:k})
            resp_list.append(resp)
        return resp_list            

