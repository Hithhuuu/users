"""Handler for Filters API"""
from fastapi.responses import JSONResponse
from fastapi import Request, APIRouter,Depends
from api.services.alerts.fastapi_app import verify_jwt,app
from api.services.alerts.alerts_api.alertsmodel import Alerts
from api.services.alerts.alerts_api.alertshistory import AlertHistory
from api.services.alerts.alerts_api.alertsvalidate import AlertValidate
from api.services.alerts.scheduler import scheduler_cron
from api.services.alerts.utils import get_user

router = APIRouter(prefix="/alerts",dependencies=[Depends(verify_jwt)])
alerts = Alerts()
alerthistory = AlertHistory()
alertvalidate = AlertValidate()


@router.get("")
async def getalerts(request: Request):
    """On GET returns list of alerts as JSON"""
    response = await alerts.get_alerts(data={"userid": get_user(request)['userid']})
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.post("")
async def createalerts(request: Request,body : dict):
    """On POST request creates alerts """
    body['username'] = get_user(request)['userid']
    response = await alerts.create_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)


@router.put("")
async def updatealerts(request: Request,body : dict):
    """On PUT updates alerts based on alert id """
    body['username'] = get_user(request)['userid']
    response = await alerts.update_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.delete("")
async def deletealerts(request: Request,body : dict):
    """On DELETE removes alerts """
    response = await alerts.delete_alert(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/details")
async def alertsdetails(request: Request,body : dict):
    """On POST request return alert details based on id as JSON"""
    response = await alerts.get_details(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/history")
async def get_history(request: Request,body : dict):
    """On POST request return history details as JSON"""
    response = await alerthistory.get_alerthistory(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.put("/history")
async def create_history(request: Request,body : dict):
    """On PUT updates history based on ID"""
    response = await alerthistory.create_alerthistory(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@router.post("/validate")
async def validate_alert(request: Request,body : dict):
    """On PUT updates history based on ID"""
    response = await alertvalidate.validate(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
@router.get("/dailyvalidate")
async def dailyalert():
    """On PUT updates history based on ID"""
    body = {
        "reportfrequency" : "Daily"
    }
    response = await alertvalidate.validate(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)

@app.on_event("startup")
@scheduler_cron(cron_expression = "0 2 */1 * *")
@router.get("/weeklyvalidate")
async def weeklyalert():
    """On PUT updates history based on ID"""
    body = {
        "reportfrequency" : "Weekly"
    }
    response = await alertvalidate.validate(data=body)
    if isinstance(response, dict) and "error" in list(response.keys()):
        return JSONResponse(
            status_code=400,
            content={"message": response.get("error")},
        )
    return JSONResponse(response)