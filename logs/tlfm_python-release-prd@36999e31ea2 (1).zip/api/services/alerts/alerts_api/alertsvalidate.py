"""this file triggers email for validated alerts """
import os
import traceback
import json
import asyncio
import aiohttp
import smtplib

from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from api.services.alerts.alerts_api.alertshistory import AlertHistory
from api.services.alerts.fastapi_app import get_query_with_pool
from api.services.alerts.utils import get_logger, queries, decrypt

app_log = get_logger("alerts_validate")
mail_log = get_logger("smtp_log")

weekday = {
    0: "Monday",
    1: "Tuesday",
    2: "Wednesday",
    3: "Thursday",
    4: "Friday",
    5: "Saturday",
    6: "Sunday"
}
class AlertValidate:
    def __init__(self) -> None:
        self.queries = queries["alerts"]['alertsvalidate']
        self.history = AlertHistory()

    async def validate(self,data ):
        try:
            if data.get("restart"):
                paylaod_list = await get_query_with_pool(self.queries['fetch_payload'])
                file_list_output = [json.loads(i.get("payload")) for i in paylaod_list]
            else:
                if  data.get('reportfrequency') == "Immediately":
                    file_list_output = [{
                        "filename": data.get('filename'),
                        "layer": data.get('stepid'),
                        "product": data.get('deviceid'),
                        "waferid": data.get('waferid'),
                        "setupid": data.get('setupid'),
                        "carrierid": data.get('carrierid'),
                        "tool": data.get('toolid'),
                        "slot": data.get("slot"),
                        "inspectiontool": data.get('inspectiontool'),
                        "src_tool":data.get('unique_header_id').split('|')[-1].lower(),
                        "reportfrequency": "Immediately"
                    }]
                else:
                    ################ scheduled execution #########################
                    days = {"Daily":1,
                            "Weekly": 7}
                    file_list_output = await get_query_with_pool(self.queries['file_data'].format(**{"days":days[data.get("reportfrequency")]}))

            for filedata in file_list_output:
                layer_details = {
                    "layer_condition":
                      f"""and JSONExtractString(dataselectionfilters, 'stepid') =  '["{filedata.get('layer')}"]'
                          and reportfrequency in '"{data.get("reportfrequency", filedata.get("reportfrequency"))}"'
                          and arrayExists(x -> x = '"{filedata.get('product')}"',
                          JSONExtractArrayRaw(JSONExtractString(COALESCE(dataselectionfilters, ''), 'deviceid'))) """ ,
                    "day_condition": f"""and arrayExists(x -> x in '"{weekday.get(datetime.today().weekday())}"', JSONExtractArrayRaw(COALESCE(reportdayselected ,''))) """ if  data.get('reportfrequency', filedata.get("reportfrequency")) in ["Daily", "Weekly"]  else '',
                    "history_condition":
                        f"""and product = '{filedata.get("product")}'
                        and layer = '{filedata.get("layer")}' and lotid =
                        '{filedata.get("carrierid")}'and recipe = '{filedata.get("setupid")}' and waferid = '{filedata.get("waferid")}' """
                          }

                alert_list =  await get_query_with_pool(self.queries['alert_list'].format(**layer_details))
                loop = asyncio.get_running_loop()
                for alert in alert_list:
                    loop.create_task(self.validate_alertid(alert,filedata))
                    # await self.validate_alertid(alert,filedata)
        except Exception as err :
            app_log.info(traceback.format_exc())
            app_log.error(err)

    async def validate_alertid(self, alertdetails,filedetails):
        alert_payload = {"payload":json.dumps(filedetails),
                         "id": alertdetails.get("id")}
        await get_query_with_pool(self.queries['save_payload'].format(**alert_payload))
        dataselection = json.loads(alertdetails.get("dataselectionfilters"))
        reviewtool = dataselection.get("reviewtool")
        inspectiontool = dataselection.get("inspectiontool")

        if reviewtool and filedetails.get("tool") not in reviewtool:
            return

        if inspectiontool and filedetails.get("inspectiontool") not in inspectiontool:
            return
        dashboard = json.loads(alertdetails.get("dashboardfilters"))
        query_data= {
            "group_size": [ i['groupsize'] for i in json.loads(alertdetails['combos'][0]) if i['product'] == filedetails ['product']][0],
            "tlf_th" : [ i['tlfth'] for i in json.loads(alertdetails['combos'][0]) if i['product'] == filedetails ['product']][0],
            "product": filedetails['product'],
            "layer": filedetails['layer'],
            "carrierid": filedetails['carrierid'],
            "setupid": filedetails['setupid'],
            "waferid": filedetails['waferid'],
            "filename": filedetails['filename'],
        }
        if dashboard[0].get("usergroup", []):
            resp_doi = [
                x["classnumber"]
                for x in dashboard[0].get("usergroup", [])
                if x["groupname"] == "True (DOI)" and x["classnumber"] in dashboard[0].get("classification").get("True (DOI)")
            ] if dashboard[0].get("classification").get("True (DOI)") else []
            resp_kdoi = [
                x["classnumber"]
                for x in dashboard[0].get("usergroup", [])
                if x["groupname"] == "True (KDOI)" and x["classnumber"] in dashboard[0].get("classification").get("True (KDOI)")
            ] if dashboard[0].get("classification").get("True (KDOI)") else []
        query_data['true_doi_kdoi'] = tuple(resp_doi+resp_kdoi)
        if len(query_data['true_doi_kdoi'])<1 :
            app_log.info("no true data selected")
            return
        kpi_query = self.queries['kpi'].format(**query_data)

        result = await get_query_with_pool(kpi_query)
        if len(result)<1:
            return
        filedetails['doicount'] = result[0].get("doicount")
        filedetails['doilimit'] = dashboard[0].get("doilimit") if dashboard[0].get("doilimitenable") else ''
        filedetails['tlf_th'] = query_data['tlf_th']
        filedetails['group_size'] = query_data['group_size']
        if dashboard[0].get("doilimitenable"):
            if int(result[0].get("groupsize_flag"))>0 and int(dashboard[0].get("doilimit")) <= result[0].get("doicount"):
                await self.trigger_email(alertdetails,filedetails)
                app_log.info(f"aler triggered for id : {alertdetails.get('id')}")
                return {"msg": "alert triggered "}
        if int(result[0].get("groupsize_flag"))>0 and not dashboard[0].get("doilimitenable"):
            await self.trigger_email(alertdetails,filedetails)

    async def trigger_email(self, alertdetails, filedetails):
            """
            Sends an email for the TLF alert.

            Args:
                alertdetails (dict): Details of the alert.
                filedetails (dict): Details of the file.

            Returns:
                None
            """
            app_log.info("sending mail for tlf alert")
            header_str =  f"""<div> Hello <span style='text-transform: capitalize'>{alertdetails.get("username")}</span> </div><br />
                        <div>The file {filedetails.get("filename")} has met the alert rules.</div>
                        <h3> Data Selection: </h3>
                        <table style='width:80%;border-collapse: collapse;'>
                        """
            table_data ={
                        "Alert name" :alertdetails.get("reportname"),
                        "Product":  filedetails.get("product"),
                        "Layer":   filedetails.get("layer"),
                        "Recipe" : filedetails.get("setupid"),
                        "Inspection Tool" :   filedetails.get("inspectiontool") ,
                        "Review Tool"  :  filedetails.get("tool") if filedetails.get("tool") not in ['',None,'None'] else 'NA',
                        "Lot" : filedetails.get("carrierid"),
                        "Wafer": filedetails.get("waferid"),
                        "Slot": filedetails.get("slot"),
                        "TLF TH" : filedetails.get("tlf_th"),
                        "Group size": filedetails.get("group_size"),
                        "Total DOI+KDOI count": filedetails.get("doicount"),
                        "DOI+KDOI TH limit": filedetails.get("doilimit") if filedetails.get("doilimit") not in ['', None,'None'] else  'NA'
                        }
            table_list= []
            for key,val in table_data.items():
                table_list.append(f"<tr><td style='border:thin solid black;padding: 5px;'><strong>{key}<strong></td><td style='border:thin solid black;padding: 5px;'>{val}</td></tr>")
            table_str = '\n'.join(table_list)
            email_str = header_str+table_str+"</table>"
            email =  ', '.join(json.loads(alertdetails.get("reportinvitees")))
            app_log.info("started to send mail for alert ")
            await self.send_mail(content=email_str, receiver=email, subject=f"Alert :- {alertdetails.get('reportname')}")
            app_log.info("email triggered for alert ")
            await self.create_history(alertdetails,filedetails,alertdetails.get("reportinvitees"))
            query_data = f"""
                            id = '{alertdetails.get("id")}' and
                            JSONExtractString(payload, 'layer') ='{filedetails.get("layer")}' and
                            JSONExtractString(payload, 'product') ='{filedetails.get("product")}' and
                            JSONExtractString(payload, 'waferid') ='{filedetails.get("waferid")}' and
                            JSONExtractString(payload, 'setupid') ='{filedetails.get("setupid")}' and
                            JSONExtractString(payload, 'carrierid') ='{filedetails.get("carrierid")}' and
                            JSONExtractString(payload, 'tool') ='{filedetails.get("tool")}'
                  """
            await get_query_with_pool(self.queries['delete_payload'].format(**{"condition":query_data}))

            app_log.info("history added for alert ")

    async def send_mail(self, **kwargs):
            """
            Sends an email with the specified content, receiver, subject, and optional attachment.

            Args:
                content (str): The content of the email.
                receiver (str): The email address of the receiver.
                subject (str): The subject of the email.
                attachment (str, optional): The file path of the attachment (if any). Defaults to None.

            Returns:
                None
            """
            EMAIL_SIGNATURE = "<div><br/><br/><br/>Thanks<br/> Wizer Auto Reports</div> <style type='text/css'>    div, h1, h2, h3 {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}    table,    tr,    td, th {      border-width: 1px;border-color: #ccc;border-style: solid;      border-collapse: collapse;      text-align: left;      padding: 0 0.5vw;      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;      align: left;      align-items: left;    }    tr:nth-child(even) {background: #efefef}    tr:nth-child(odd) {background: #FFF}  </style>"
            email_content = kwargs.get("content") + EMAIL_SIGNATURE
            your_smtp_port = os.getenv("smtp_port")
            host = os.getenv("host")
            msg = MIMEMultipart()
            msg["From"] = os.getenv("server_mail")
            msg["To"] = kwargs.get("receiver")
            msg["Subject"] = kwargs.get("subject")
            if kwargs.get("attachment"):
                attach_file_name = kwargs.get("attachment")
                with open(attach_file_name, "rb") as file:
                    attachment_content = MIMEApplication(file.read())
                    attachment_content.add_header(
                        "Content-Disposition", "attachment", filename=attach_file_name
                    )
                    msg.attach(attachment_content)
            msg.attach(MIMEText(email_content, "html"))
            mail_log.info(f"Email started")
            app_log.info(f"Sending email to {kwargs.get('receiver')}")
            with smtplib.SMTP(host, your_smtp_port) as server:
                server.set_debuglevel(1)
                server.send_message(msg)
            mail_log.info(f"Email end")


    async def create_history(self, alertdetails, filedetails, email):
            """
            Creates a history record for an alert.

            Args:
                alertdetails (dict): Details of the alert.
                filedetails (dict): Details of the file.
                email (str): Email address.

            Returns:
                tuple: A tuple containing the status code and response from the API.
            """
            payload = {
                "alertid": alertdetails.get("id"),
                "alertname": alertdetails.get('reportname'),
                "filename": filedetails.get("filename"),
                "username": alertdetails.get("username"),
                "status": "success",
                "invokefrom": "alerting_report",
                "email": email,
                "stepid": filedetails.get("layer"),
                "deviceid": filedetails.get("product"),
                "setupid": filedetails.get("setupid"),
                "waferid": filedetails.get("waferid"),
                "carrierid": filedetails.get("carrierid")
            }
            headers = {'CONTENT-TYPE': 'application/json',"Authorization": f"Bearer {await get_auth_token()}"}
            url = os.getenv("historyurl")
            status, response = await req_url(url, payload, headers, method='put', resp_type=True, payload_type=True)
            app_log.info("history added for alert ")


async def req_url(url, payload, headers,method='post', resp_type=False,payload_type = False):
    """
    Sends a POST request to the specified URL with the given payload and headers.

    Parameters:
    - url (str): The URL to send the request to.
    - payload (dict): The payload to include in the request body.
    - headers (dict): The headers to include in the request.
    - resp_type (bool, optional): Whether to parse the response as JSON. Defaults to False.
    - payload_type (bool, optional): Whether to convert the payload to JSON. Defaults to False.

    Returns:
    - sh_report_resp (int): The HTTP status code of the response.
    - resp (dict or None): The parsed JSON response, if resp_type is True. Otherwise, None.
    """
    if payload_type:
        payload =  json.dumps(payload)
    async with aiohttp.ClientSession() as session:
        if method =='post':
            async with session.post(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
                resp = None
                if response.headers['Content-Type'] == 'application/json':
                    data = await response.json()
                else:
                    data = await response.text()
        elif method =='put':
            async with session.put(url, data=payload, headers=headers) as response:
                sh_report_resp = response.status
                resp = None
                if response.headers['Content-Type'] == 'application/json':
                    data = await response.json()
                else:
                    data = await response.text()
    return sh_report_resp, data

async def get_auth_token():
    """
    Retrieves the authentication token by making an API call to get the Auth Token.

    Returns:
        str: The authentication token (JWT).

    Raises:
        RuntimeError: If the Auth Token API request fails.
    """
    app_log.info(f"Auth token api call to get the Auth Token.")
    payload = {
        "userid": "superadmin",
        "password": "U2FsdGVkX1+OBM5UuxMVfNRZ0y3F7mXAwsv32jmYigs=",
    }

    headers = {"Content-Type": "application/json"}
    status, response = await req_url(os.getenv("authurl"), payload, headers, resp_type=True, payload_type=True)
    token_resp = json.loads(
        decrypt(response["encryptedData"],bytes("c2VjcmV0cGFzc3dvcmRwaHJhc2U=", "utf-8"),).decode("utf-8"))
    app_log.info(
        f"Auth Token Api status_code: {status}, "
    )
    if status != 200:
        raise RuntimeError("Auth Token API request Failed")
    json_token_resp = token_resp
    return json_token_resp["jwt"]
