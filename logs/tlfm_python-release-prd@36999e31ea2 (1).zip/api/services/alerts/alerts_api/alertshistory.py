"""Model for Alert history """
import json
import traceback

from datetime import datetime
from api.services.alerts.fastapi_app import get_query_with_pool
from api.services.alerts.utils import get_logger, queries


app_log = get_logger("alertshistory")

class AlertHistory():
    """this class provides methods for rca history"""
    def __init__(self):
        """initialisation of rca queries """
        query = queries["alerts"]
        self.queries = query['alerthistory']

    async def get_alerthistory(self, data):
        """this method creates alert history"""
        try:
            startdate = data.get('startDate')+'T00:00:00'
            enddate = data.get('endDate')+'T23:59:59'
            strptime_str = "%Y-%m-%dT%H:%M:%S"
            strftime_str= "%Y-%m-%d %H:%M:%S"
            app_log.info(f"get alert history paylaod {data}")
            resp = {"data":[],"numFound":0}
            start_date = datetime.strptime(startdate, strptime_str).strftime(strftime_str)
            end_date = datetime.strptime(enddate, strptime_str).strftime(strftime_str)
            query_data = {
                'startDate':start_date,
                'endDate':end_date,
                'alertid':data.get('id'),
                'limit' : f'''limit {data.get("offset")}, {data.get("limit")} ''' 
            }
            query_to_execute = self.queries['read_alert_history'].format(**query_data)
            data_output = await get_query_with_pool(query_to_execute, resp_type='df')
            resp = {"data":[],"numFound":0}
            if not data_output.empty:
                data_output.drop('date_time', axis=1, inplace=True)
                data_output = json.loads(data_output.to_json(orient='records'))
                resp = {"data":data_output,"numFound":data_output[0].get("total")}
            
        except Exception as err:
            app_log.error(traceback.format_exc())
            app_log.error(err)
            resp={'error':f"error while preparing data {err}"}

        return resp

    async def create_alerthistory(self, data):
        """this method updates alert history"""
        try:
            app_log.info(f"create alert history paylaod {data}")
            date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            query_data = {
                "autoreportid": data.get('alertid'),
                "reportname": data.get('alertname'),
                "filename": data.get('filename'), 
                "username": data.get('username'),
                "status": data.get('status'), 
                "invokefrom": data.get("invokefrom"),
                "autoreportidtimestamp": int((datetime.now() - datetime(1970, 1, 1)).total_seconds()),
                "email": data.get('email'), 
                "numberoffiles": 1, 
                "datetime": date_time,
                "deviceid" : data.get('deviceid'),
                'stepid' :data.get('stepid'),
                "waferid": data.get("waferid"),
                'recipeid': data.get('setupid'),
                'lotrecord': data.get('carrierid')
                }
            query_to_execute = self.queries['create_alert_hist'].format(
                **query_data)
            await get_query_with_pool(query_to_execute, resp_type="None")
            resp = {"msg": "alert history updated Successfully"}

        except Exception as err:
            app_log.info(traceback.format_exc())
            app_log.error(err)
            resp = {'error': f"alert history api failed"}
        return resp
    
