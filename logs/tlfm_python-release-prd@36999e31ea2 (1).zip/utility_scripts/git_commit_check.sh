#!/bin/bash
echo -e "#!/bin/bash\nblack .\npython ./utility_scripts/lint.py -p ../tlfm_python/"> ./.git/hooks/pre-commit
chmod +x ./.git/hooks/pre-commit