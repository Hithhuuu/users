import easyocr


class ImgParser():
    async def extract_text_from_image(path):
        # Creating an instance of EasyOCR
        reader = easyocr.Reader(['en'])  # Specifying the language(s) for OCR

        # Reading the text from the image
        result = reader.readtext(path)

        # Initializing an empty string to store the extracted text
        extracted_text = ""

        # Extract text from each detection
        for detection in result:
            text = detection[1]
            extracted_text += text + " "  # Add a space between each extracted text

        return extracted_text