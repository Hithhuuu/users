from pptx import Presentation
from image_parser import extract_text_from_image

class PptxParser():
    def __init__(self) -> None:
        pass

    async def pptx(self, **kwargs):
        """ 
            Extracts all text content from each slide in a PowerPoint presentation.
                Args:
                    file_path (str): The file path of the PowerPoint presentation.
                Returns:
                    str: A string containing all the text content from the slides concatenated.
                Raises:
                    None
                Examples:
                    >>> pptx(file_path='example.pptx')
             'Slide 1 text Slide 2 text Slide 3 text'
        """
        prs = Presentation(kwargs.get("file_path"))
        text = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if not shape.has_text_frame:
                    continue
                text.append(shape.text_frame.text)
                if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    image = shape.image
                    with open(f"image.{image.ext}", "wb") as f:
                        f.write(image.blob)
                    text.append(await extract_text_from_image(f"image.{image.ext}"))
        all_slide_text = " ".join(text)
        return all_slide_text
