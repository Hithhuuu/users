import io
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LTTextBoxHorizontal



class PDFParser():
    def __init__(self) -> None:
        # TODO To Add default value of start page in coming changes
        pass

    async def pdf_to_text(self, **kwargs):
        """
            Extracts all text as a raw_data from the PDF.
                Args:
                    file_path (str): The file path of the PDF.
                Returns:
                    str: A string containing all the text content from PDF.
                Raises:
                    None
                Examples:
                    >>> pdf_to_text(file_path='example.pdf')
        """
        rsrcmgr = PDFResourceManager()
        retstr = io.StringIO()
        codec = 'utf-8'
        laparams = LAParams()
        path  = kwargs.get("file_path")
        device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
        fp = open(path, 'rb')
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        password = ""
        maxpages = 0
        caching = True
        pagenos = set()

        for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages,
                                    password=password,
                                    caching=caching,
                                    check_extractable=True):
            interpreter.process_page(page)

        fp.close()
        device.close()
        text = retstr.getvalue()
        retstr.close()
        return text

    async def pdf_to_list(self, **kwargs):
        """
         Extracts all text as a list of String from the PDF.
                Args:
                    file_path (str): The file path of the PDF.
                Returns:
                    [str]: A list of string containing all the text content from PDF.
                Raises:
                    None
                Examples:
                    >>> pdf_to_list(file_path='example.pdf')
        """
        path = kwargs.get("file_path")
        document = open(path, 'rb')
        lines = []
        rsrcmgr = PDFResourceManager()
        laparams = LAParams()
        device = PDFPageAggregator(rsrcmgr, laparams=laparams)
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.get_pages(document):
            interpreter.process_page(page)
            layout = device.get_result()
            for element in layout:
                if isinstance(element, LTTextBoxHorizontal):
                    lines.extend(element.get_text().splitlines())
        return lines
