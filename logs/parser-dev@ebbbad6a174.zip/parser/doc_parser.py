# title                 : doc_parser.py
# description           : This script will parse the doc files.
# author                : Rajasima Patra
# date                  : 11-Sep-2023
################################################################################################################

import docx2txt
import textract


class DocsParser():
    def __init__(self) -> None:
        pass

     async def doc_parser_type1(self, **kwargs):
        """
            This function will parse the document file and return the text exactly same as the doc file.
            arg1: file_path (str): The path of the doc file.
            arg2: image_dir (str): The path to store images after extracting from document file.
        """
        image_dir = kwargs.get('image_dir')
        file_path = kwargs.get('file_path')
        text = docx2txt.process(file_path, image_dir)
        return text

    def doc_parser_type2(self, **kwargs):
        """
            This function will parse the document file and return the text in a paragraph without any newline.
            args: file_path (str): The path of the doc file.
        """
        file_path = kwargs.get('file_path')
        text = textract.process(file_path)
        return text
