import os 
import json
import asyncio
from doc_parser import DocsParser
from image_parser import ImgParser
from pdf_parser import PDFParser
from pptx_parser import PptxParser

class MainParser():
    def __init__(self) :
        self.docs_parser = DocsParser
        self.img_parser = ImgParser
        self.pdf_parser = PDFParser
        self.pptx_parser = PptxParser

    async def parse(self, filedata):
        try:
            result = []
            for file in filedata:
                if os.path.isdir(file.get("filepath")):
                    loop = asyncio.get_event_loop()
                    file_list = os.listdir(file.get("filepath"))
                    for i in file_list :
                        if not i.endswith('json'):
                            if i.endswith('.pdf'):
                                task = [loop.create_task(self.pdf_parser.pdf_to_text(filedata.get("filepath")))]
                            if i.split('.')[-1] in ['pptx','ppt']:
                                task =  [loop.create_task(self.pptx_parser.pptx(filedata.get("filepath")))]
                            if i.split('.')[-1] in ['png', 'jpeg','jpg','gif','tiff']:
                                task = [loop.create_task(self.img_parser.extract_text_from_image(filedata.get("filepath")))]
                            if i.split('.')[-1] in ['docs','doc', 'txt']:
                                task = [loop.create_task(self.docs_parser.doc_parser_type1(filedata.get("filepath")))]
                            file['text_data'] = await asyncio.gather(*task)
                        elif i.endswith('json'):
                            with open(i) as json_file:
                            file['metadata'] = json.load(json_file)
                result.append(file)
            return result
        except Exception as err:
            print(err)


        
        